@echo off
cd override
oggdec bk*.ogg
del bk*.ogg
del oggdec.exe
cd ..

