del override\bk*.wav
@ECHO
@ECHO Touch the Moon Audio Uninstalled
@ECHO

