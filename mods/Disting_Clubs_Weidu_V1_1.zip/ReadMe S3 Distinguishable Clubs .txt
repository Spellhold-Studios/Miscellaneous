This is a mod by artificial_sunlight on the BGEE forums and Spellholdstudios

Current version V1.1
--------------------------------------------------------------------------------------------------------

My Prefix is S3 on http://www.blackwyrmlair.net/prefixes/ , so if you see an mod item that starts with S3 it should be created by me.

The forum link is http://forum.baldursgate.com/discussion/34524/  (BG:EE modding)

Send me a private message if you have questions, or post them in the forum.


--------------------------------------------------------------------------------------------------------
Tools used: WEIDU, DLTCP, NI Thanks for the great tools.

I will make this mod in different languages on request AND with help.


MOD DESCRIPTION
--------------------------------------------------------------------------------------------------------
There is no difference in the graphics of the differt clubs in the game (Night club, +1 and Mighty oak all look like normal clubs). I fixed that.


Tested on: BGEE 1.2 and 1.3
Currently no support on other games and versions



INSTALLING on Windows
--------------------------------------------------------------------------------------------------------

This is a Weidu Mod so installation is simple.
- Put setup-S3DisClubs.exe in your BGEE installation folder
- Put the S3DisClubs folder in your BGEE installation folder (it should contain: S3DisClubs.tp2, Graphics folder > S3ICL01.bam,S3ICL02.bam,S3ICL04.bam)
- Run setup-S3DisClubs.exe, follow the instuctions
- Enjoy


INSTALLING on MAC OSxxxx
--------------------------------------------------------------------------------------------------------
I don't have a mac so I can't help you but look at:
http://forum.baldursgate.com/discussion/31155/the-hitchhiker-s-guide-to-installing-mods-on-osx


VERSION HISTORY
--------------------------------------------------------------------------------------------------------

V1.1 	-Weidu version 236
v1.0	-Added Melee Bam
v0.1	-First release Non Weidu


--------------------------------------------------------------------------------------------------------
GRTZ artificial_sunlight 