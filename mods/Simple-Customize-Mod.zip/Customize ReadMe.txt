                          BG:EE Customize Mod
                                  For
                     Baldur's Gate: Enhanced Edition


		Table of Contents
		~~~~~~~~~~~~~~~~~
1. 	About
2. 	Installation
3.      Uninstall
4.      How to: Usage

		Section 1. About
		~~~~~~~~~~~~~~~~
This is a simple mod that does a great deal of customization for you.  It can also give you an
idea of how a WeiDU mod can work with BG:EE.  This mod does the following:

- Copy custom portraits to your portrait folder.
- Copy custom sounds for you PC to your lang\sounds folder
- Copy custom scripts to your Scripts folder
- Copy your Characters to your characters folder.

So here is where it helps you; Anything you want to add to your customization you can drop into
the specific folders inside the \bgee_customize directory.

*****Currently this is only in English.

What it does NOT do:

- It does not have clairvoyance!  So you will need to edit some paths described below.
- Does not patch your baldur.ini.  You will still have to do that manually.
- Does not create the necessary folders.


		Section 2. Installation
		~~~~~~~~~~~~~~~~~~~~~~~~
Extract to your C:\Programs Files\Baldur's Gate Enhanced Edition\Data\00766 Folder.
Or wherever your main BG:EE installation resides.

Open your BG:EE installation directory, and look for a file named "bgee_customize.tp2". 
Open it with Notepad (right-click -> Open with -> Notepad), and look for the following chunk of text:

COPY ~bgee_customize/BS~                    ~scripts~
     ~bgee_customize/copy~                  ~override~
     ~bgee_customize/Sounds~                ~lang/en_US/sounds~
     ~bgee_customize/CHR~                   ~D:\Users\My Documents\Baldur's Gate - Enhanced Edition\characters~
     ~bgee_customize/Portraits~             ~D:\Users\My Documents\Baldur's Gate - Enhanced Edition\portraits~

The last two lines point to the folders where your saved characters and custom portraits are located. 
The path to these folders may vary from user to user, and from PC to PC, so it is vital that you write the correct path for your installation in there.

Both folders are most typically found within your My Documents\Baldur's Gate - Enhanced Edition folder.
However, if you have never used custom portraits before, chances are that you don't have a "Portraits" folder yet. If that is the case, access your My Documents\Baldur's Gate - Enhanced Edition folder, right-click, then hit New -> Folder and name it "Portraits" (omit the quotation marks). 
Then, open the folder and copy its address as shown in the address bar at the top of the Window (right-click -> Copy). You may then paste it in the .tp2 file as the path to your portraits folder (right-click -> Paste).
Similarly, access your My Documents\Baldur's Gate - Enhanced Edition\characters folder, copy its address and paste it in the .tp2 file as the path to your characters folder.
Save the changes. The mod is now set up and ready to install!

Make sure you have the appropriate folders in you game. If not, create them before running the install.
C:\xxxxxx\Baldur's Gate Enhanced Edition\Data\00766\override  --> create: override
C:\User\My Documents\Baldur's Gate - Enhanced Edition\characters --> create: characters
C:\User\My Documents\Baldur's Gate - Enhanced Edition\portraits --> create: portraits

Double-click on "install_bgee_customize.bat" to start the WeiDU installer.


		Section 3. Uninstallation
		~~~~~~~~~~~~~~~~~~~~~~
Double-click on "install_bgee_customize.bat" to start the WeiDU uninstaller.  Choose U (Uninstall)

		Section 4. How to: Usage
		~~~~~~~~~~~~~~~~~~~~~~
~~~~~~~~~~~
- Portraits:

I have included a portrait in the installer as an example to use if you wish to create or convert your own portraits to work with BG:EE

Example:
BLANKL.bmp - 210 x 330 pixels, 200 Resolution, 204K
BLANKM.bmp - 169 x 266 pixels, 200 Resolution, 132K
BLANKS.bmp - 54 x 84 pixels, 200 Resolution, 16K

Assign xxxM to your big portrait, xxxS to your party portrait. 300 res may also work, but the core pix are 200 so went with that.

You can then use this installer to dump your portraits in the correct folder and keep things clean.  Simply drop all the portraits you wish to use into the \Baldur's Gate Enhanced Edition\Data\00766\bgee_customize\Portraits and re-run the installer.

~~~~~~~~~~
- Scripts:  
I have included some cheat/debug scripts for players wishing to try things out. These are hotkey scripts, meaning a single keyboard key will perform the actions in the script.
GiveXP.bs -  Add party XP 24,000 - Hit D / Add Player XP 5,000 - Hit C
GIVSPCL.bs - Add Special Abilities (True Sight, Set Snare, Summon Spirit Animal, etc) - Hit D
GoArea.bs - Move party to AR0900 via cutscene (Baldur's Gate Bridge) - Hit D
PlaySnd.bs - Play variety of game songs - Hit D or A or S or F
REPInc.bs - Increase Reputation by 2 - Hit D

Simply go into your character record page -> Customize -> Scripts -> choose -> back to game.  Ensure PartyAI is ON.  Hit the key indicated by each script above to perform that action instantly.
Feel free to edit these with NI or DLTCEP and recompile with your personal desires.

~~~~~~~~~~~~~
- Characters:

Place any characters you wish to import into the CHR folder and run the setup again.  I have included one example.

~~~~~~~~~~~~~
- Sounds:

This is the most complicated section.  I have included ONE example: FEMALE7.  You can add more as you desire.
I have included an edited 2da that will not crash your game - \Baldur's Gate Enhanced Edition\Data\00766\bgee_customize\2DA\CHARSND.2da
New entries have been added as an example for you.  You may open and edit this with Notepad or ConTEXT (preferred).

You will see under FEMALE7 that there are a number listings.  These are placehold numbers that the setup will use to replace those numbers with text strings.
There are known issues with this as attack and damage sounds either never or rarely play.  Waiting for the new WeiDU to repair this.

These numbers are referenced in the bgee_customize.tp2 and replaced with strings found in the setup.tra.
You can follow the existing example to add your own strings to your custom sounds by renaming a soundset to an existing column I have provided, or edit in your own column if you are feeling frisky.
- Add in your temp string numbers to the 2da.  Use care not to use strings within the existing string range of the game or you will overwrite them.
- Add in your own strings and numbers to the setup.tra
- Rerun setup.

I know this sounds portion isnt terribly clear, and I apologize.  The example is here for you to use.


Hope this is helpful to some players.  Enjoy!
You are welcome to do anything with this you desire; alter, edit, destroy.  But please do not
redistribute as your own. The point here is for people to see how a simple content installer works.

Lorne Ledger (Cuv or Cuvieronius)
12\2\12