BEGIN ~MACDRIZ~

IF ~NumberOfTimesTalkedTo(0)~ THEN BEGIN 0
  SAY @1

  IF ~!Dead("Ordulinian")~ THEN GOTO 1
  IF ~Dead("Ordulinian")~ THEN GOTO 2
END

IF ~~ THEN BEGIN 1
  SAY @2

  IF ~~ THEN DO
  ~
    StartCutSceneMode()
    ActionOverride("Ordulinian",EscapeArea())
    Wait(5)
    EndCutSceneMode()
  ~
  EXIT
END

IF ~~ THEN BEGIN 2
  SAY @3

  IF ~~ THEN DO ~SetNumTimesTalkedTo(2)~
  GOTO 6

  IF
  ~
    PartyGoldGT(29999)
  ~
  THEN DO
  ~
    SetNumTimesTalkedTo(2)
  ~
  GOTO 5

  IF
  ~
    ReputationGT(Player1,7)
    PartyGoldGT(19999)
  ~
  THEN DO
  ~
    SetNumTimesTalkedTo(2)
  ~
  GOTO 4

  IF
  ~
    ReputationGT(Player1,13)
    PartyGoldGT(9999)
  ~
  THEN DO
  ~
    SetNumTimesTalkedTo(2)
  ~
  GOTO 3
END

IF
~
  NumberOfTimesTalkedTo(1)
  ReputationGT(Player1,13)
  PartyGoldGT(9999)
~
THEN BEGIN 3
  SAY @5
    =
  @6
    =
  @9

  IF ~~ THEN REPLY @51 DO ~TakePartyGold(10000)~ GOTO 7
  IF ~~ THEN REPLY @52 GOTO 8
END

IF
~
  NumberOfTimesTalkedTo(1)
  ReputationGT(Player1,7)
  PartyGoldGT(19999)
~
THEN BEGIN 4
  SAY @5
    =
  @7
    =
  @9

  IF ~~ THEN REPLY @51 DO ~TakePartyGold(20000)~ GOTO 7
  IF ~~ THEN REPLY @52 GOTO 8
END

IF
~
  NumberOfTimesTalkedTo(1)
  PartyGoldGT(29999)
~
THEN BEGIN 5
  SAY @5
    =
  @8
    =
  @9

  IF ~~ THEN REPLY @51 DO ~TakePartyGold(30000)~ GOTO 7
  IF ~~ THEN REPLY @52 GOTO 8
END

IF ~NumberOfTimesTalkedTo(1)~ THEN BEGIN 6
  SAY @4

  IF ~~ THEN DO ~Enemy()~
  EXIT
END

IF ~~ THEN BEGIN 7
  SAY @10

  IF ~~ THEN DO
  ~
    SetGlobal("MACDrizztRevenge","GLOBAL",3)
    EscapeArea()
  ~
  EXIT
END

IF ~~ THEN BEGIN 8
  SAY @11

  IF ~~ THEN DO ~Enemy()~
  EXIT
END
