This mod adds a portable hole to Ribald's store.

And that's all it does.

(Other than removing a critical flaw in BG2, namely the lack of portable holes.)

No dragons, undead or +5 axes included.

You'll need to start a new game if you've already visited Ribald. Or not, since you can just create the item with the console (as JL#HOLE).

Warranty void if seal is broken.

And no, you can't put it in a bag of holding.

-v