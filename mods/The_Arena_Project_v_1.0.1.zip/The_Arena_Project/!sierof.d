
BEGIN ~!SIerof~


/*-------------// Seconda conversazione \\---------*/


IF ~Global("!SIntroduzioneFatta","GLOBAL",1) Global("!STarneshSummoned","GLOBAL",0) Global("!SIerofanteOffeso","GLOBAL",0)~ THEN BEGIN SecondConv
  SAY @26 /* You are back, <CHARNAME>. Do you feel ready to start summoning the spirits of your past, present and future? */
  IF ~~ THEN REPLY @24 /* Yes, you can proceed, Hierophant. */ GOTO TarneshSummon
  IF ~~ THEN REPLY @27 /* Nope, I will come back. */  EXIT
END


/*-------------// Ierofante Offeso \\---------*/

IF ~Global("!SIerofanteOffeso","GLOBAL",1) GlobalGT("!SIerofanteAttaccato","GLOBAL",1)~ THEN BEGIN IerofanteOffeso
  SAY @208 /* Ierofante non aiuta pi� */
  IF ~~ THEN DO ~DialogInterrupt(TRUE)~ EXIT
END



/////////////////////////////////////////////////////////////
//////* Ierofante attaccato prima della presentazione *//////
/////////////////////////////////////////////////////////////

IF ~!Global("!SIntroduzioneFatta","GLOBAL",1) Global("!SIerofanteAttaccato","GLOBAL",1) ~ THEN BEGIN AttaccatoAVista
  SAY @29 /* your intentions are clearly evil. I will not die without fighting! */
  IF ~~ THEN REPLY @201 /* Muori! */ DO ~Enemy()~ EXIT
  IF ~~ THEN REPLY @30 /* Wait! It was an accident, I didn't mean to hurt you. Can we start again? */ DO ~SetGlobal("!SIerofanteAttaccato","GLOBAL",0) DialogInterrupt(TRUE)~ GOTO PersoneCivili
END



IF ~~ THEN BEGIN PersoneCivili
  SAY @31=@32
  IF ~~ THEN GOTO WellMet1
END





/* ----------------L'evocatore arriva------------------------ */


IF ~!Global("!SIntroduzioneFatta","GLOBAL",1) Global("!SIerofanteOffeso","GLOBAL",0) Global("!SIerofanteAttaccato","GLOBAL",0)~ THEN BEGIN WellMet
  SAY @1 /* Cosa ci faccio qui? */
  IF ~~ THEN REPLY @2 /* You suppose well, stranger, and this is my home. Do I know you? */  GOTO WellMet1
  IF ~~ THEN REPLY @3 /* It is me, and I don't like intruders inside my home. Now tell me who you are and do it quickly, before I lose my patience. */ GOTO WellMet2
END

IF ~~ THEN BEGIN WellMet1
  SAY @4 /* I guess I'm stuck here...for now. You can address me as The Hierophant */
  IF ~~ THEN REPLY @5 /* Well met, Hierophant. So, what exactly can you do for me? */ GOTO WellMet1_2
  IF ~~ THEN REPLY @6 /* I didn't do it on purpose, Hierophant... */ GOTO WellMet1_2
  IF ~~ THEN REPLY @7 /* You just called me Bhaalspawn, how do you know of my lineage? */ GOTO WellMet2_1
END

IF ~~ THEN BEGIN WellMet2
  SAY @8  /* It was not my choice to come here, You can call me The Hierophant. */
  IF ~~ THEN REPLY @5 /* Well met, Hierophant. So, what exactly can you do for me? */ GOTO WellMet1_2
  IF ~~ THEN REPLY @6 /* I didn't do it on purpose...What is your purpose here? */ GOTO WellMet1_2
  IF ~~ THEN REPLY @7 /* You just called me Bhaalspawn, how do you know of my lineage? */ GOTO WellMet2_1
END


IF ~~ THEN BEGIN WellMet1_2
  SAY @11  /* I'm a summoner, I have the power to drag beings and spirits out of their plane of existance to bring them here. */
  IF ~~ THEN REPLY @12   /* Spirits and beings...And how can they be of any help to me? */  GOTO WellMet1_3
  IF ~~ THEN REPLY @13   /* You are telling me you can summon any living creatures and dead alike? */ GOTO WellMet1_4
END


IF ~~ THEN BEGIN WellMet2_1
  SAY @9  /* This bloody war between demigods has caused far more pain that you would imagine */
  IF ~~ THEN REPLY @10   /* I see. Well, now that you are here, what kind of assistance can you provide? */ GOTO WellMet1_2
END



IF ~~ THEN BEGIN WellMet1_3
  SAY @14  /* They can prove useful in many ways, Bhaalspawn. Don't underestimate the potential of my powers. */
  IF ~~ THEN REPLY @15  /* You may actually be right, summoner, I can't wait to try your powers.*/ GOTO WellMet1_4
  IF ~~ THEN REPLY @16  /* We will see. What if you are only some kind of imposter trying to take advantage of me. */ GOTO WellMet1_5
END


IF ~~ THEN BEGIN WellMet1_5
  SAY @20  /* Don't be silly, I am confined in this pocket plane of existance and my powers are bound to your will. */
  IF ~~ THEN REPLY @21  /* Alright, I will trust you...For now. Go on with your speech, you were telling me you can summon spirits.*/ GOTO WellMet1_4
END



IF ~~ THEN BEGIN WellMet1_4
  SAY @17  /* Yes but you should know that there are some rules about this, Bhaalspawn. */
  IF ~~ THEN REPLY @18  /* Very interesting. Why are we still wasting time talking, then? Let's get started summoning! */  DO ~SetGlobal("!SIntroduzioneFatta","GLOBAL",1)~ GOTO FirstSummon
  IF ~~ THEN REPLY @19  /* Alright then, you are not that useless afterall. I will come back later to test your powers. */ DO ~SetGlobal("!SIntroduzioneFatta","GLOBAL",1)~ EXIT
  IF ~~ THEN REPLY @22  /* Everything clear, I just have some unfinished business to take care of. See you later */        DO ~SetGlobal("!SIntroduzioneFatta","GLOBAL",1)~ EXIT

END






/*-------------// Evocazione Tarnesh \\---------*/


IF ~~ THEN BEGIN FirstSummon
  SAY @23  /* @23=~Not so fast, <CHARNAME>. We will start from the very beginning. I want you to focus on your past. */
  IF ~~ THEN REPLY @24  /* Yes, you can proceed, Hierophant. */ DO ~SetGlobal("!STarneshSummoned","GLOBAL",1)~ EXIT
  IF ~~ THEN REPLY @25  /* Maybe I'm not ready for this yet. I will see you later */ EXIT
END




IF ~~ THEN BEGIN TarneshSummon
  SAY @28 /* Ierofante evoca Tarnesh */
  IF ~~ THEN DO ~SetGlobal("!STarneshSummoned","GLOBAL",1)~ EXIT
END





IF ~Global("!STarneshSummoned","GLOBAL",3) Global("!SCongratz","GLOBAL",0) Global("!SIerofanteOffeso","GLOBAL",0)~ THEN BEGIN Congratz1
  SAY @34  /* Bravo, ora Brage Bassilus */
  IF ~~ THEN  DO ~SetGlobal("!SCongratz","GLOBAL",1) AddXPObject(Player1,20000)~ GOTO SummonBrageBassilus1
END


IF ~~ THEN BEGIN SummonBrageBassilus1
  SAY @35  /* Now we can proceed with the next challenge. Are you ready? */
  IF ~~ THEN REPLY @36 /*  yes  */ DO ~SetGlobal("!SCongratz","GLOBAL",2)~ GOTO SummonBrageBassilus2
  IF ~~ THEN REPLY @37 /*  no  */  EXIT
END




/*-------------// Evocazione Brage/Bassilus \\---------*/

IF ~Global("!STarneshSummoned","GLOBAL",3) Global("!SCongratz","GLOBAL",1) Global("!SIerofanteOffeso","GLOBAL",0)~ THEN BEGIN Congratz2
  SAY @38  /* Ora sei pronto? */
  IF ~~ THEN REPLY @36 /* sono pronto */  DO ~SetGlobal("!SCongratz","GLOBAL",2)~ GOTO SummonBrageBassilus2
  IF ~~ THEN REPLY @37 /* non ancora */   EXIT
END



IF ~~ THEN BEGIN SummonBrageBassilus2
  SAY @39  /* You met with Khalid and Jaheira and they shed some light upon the iron shortage.... */
  IF ~~ THEN DO ~SetGlobal("!SBrageBassilusSummoned","GLOBAL",1)~ EXIT
END




/*-------------// Ricompensa brage & Evocazione Mulahey \\---------*/


IF ~Global("!SBrageBassilusSummoned","GLOBAL",4) Global("!SCongratz","GLOBAL",2) Global("!SIerofanteOffeso","GLOBAL",0) Global("!SbragRedempt","GLOBAL",4)~ THEN BEGIN Congratz3-1
  SAY @51  /* Not only you killed the crazy priest of Cyric, but you rescued Brage's tormented soul. */
  IF ~~ THEN DO ~SetGlobal("!SCongratz","GLOBAL",3) AddXPObject(Player1,50000)~ GOTO SummonMulahey
END


IF ~Global("!SBrageBassilusSummoned","GLOBAL",4) Global("!SCongratz","GLOBAL",2) Global("!SIerofanteOffeso","GLOBAL",0) Global("!SbragRedempt","GLOBAL",1)~ THEN BEGIN Congratz3-2
  SAY @52  /* A good victory, though it's so sad that Brage had to die, isn't it? */
  IF ~~ THEN DO ~SetGlobal("!SCongratz","GLOBAL",3) AddXPObject(Player1,25000)~ GOTO SummonMulahey
END


IF ~Global("!SBrageBassilusSummoned","GLOBAL",4) Global("!SCongratz","GLOBAL",2) Global("!SIerofanteOffeso","GLOBAL",0) GlobalLT("!SbragRedempt","GLOBAL",1)~ THEN BEGIN Congratz3-3
  SAY @53  /* You slained your foes without efforts, well done. That was not an easy task. */
  IF ~~ THEN DO ~SetGlobal("!SCongratz","GLOBAL",3) AddXPObject(Player1,20000)~ GOTO SummonMulahey
END




IF ~~ THEN BEGIN SummonMulahey
  SAY @35  /* Now we can proceed with the next challenge. Are you ready? */
  IF ~~ THEN REPLY @36 /* yes */  DO ~SetGlobal("!SCongratz","GLOBAL",4)~ GOTO SummonMulahey2
  IF ~~ THEN REPLY @37 /* no  */  EXIT
END


IF ~Global("!SCongratz","GLOBAL",3) Global("!SMulaheySummoned","GLOBAL",0) Global("!SIerofanteOffeso","GLOBAL",0)~ THEN BEGIN SummonMulaheyReady
  SAY @38  /* You are back. Are you ready? */
  IF ~~ THEN REPLY @36 /* yes */  DO ~SetGlobal("!SCongratz","GLOBAL",4)~  GOTO SummonMulahey2
  IF ~~ THEN REPLY @37 /* no  */  EXIT
END


IF ~~ THEN BEGIN SummonMulahey2
  SAY @54  /* you finally reached the bottom of the mines */
  IF ~~ THEN DO ~SetGlobal("!SMulaheySummoned","GLOBAL",1)~ EXIT
END




/*-------------// Ricompensa Mulahey & evocazione Narcillicus \\---------*/

IF ~Global("!SMulaheyRedeemed","GLOBAL",2) Global("!SCongratz","GLOBAL",4) Global("!SIerofanteOffeso","GLOBAL",0)~ THEN BEGIN CongratzMula1
  SAY @80 /* Oh that was pretty easy mh? Sometimes being good hearted pays off. */
  IF ~~ THEN DO ~SetGlobal("!SCongratz","GLOBAL",5) AddXPObject(Player1,25000)~ GOTO SummonNarcillicus1
END


IF ~Global("!SMulaheyRedeemed","GLOBAL",0) Global("!SMulaheySummoned","GLOBAL",3) Global("!SCongratz","GLOBAL",4) Global("!SIerofanteOffeso","GLOBAL",0)~ THEN BEGIN CongratzMula2
  SAY @81  /* Welcome back. You have overcome the challenge, well done */
  IF ~~ THEN DO ~SetGlobal("!SCongratz","GLOBAL",5) AddXPObject(Player1,20000)~ GOTO SummonNarcillicus1
END


IF ~~ THEN BEGIN SummonNarcillicus1
  SAY @35  /* Now we can proceed with the next challenge. Are you ready? */
  IF ~~ THEN REPLY @36 /* yes */  GOTO SummonNarcillicus3
  IF ~~ THEN REPLY @37 /* no  */  EXIT
END



IF ~Global("!SCongratz","GLOBAL",5) Global("!SNarcillicusSummoned","GLOBAL",0) Global("!SIerofanteOffeso","GLOBAL",0)~ THEN BEGIN SummonNarcillicus2
  SAY @38  /* You come back. Are you ready? */
  IF ~~ THEN REPLY @36 /* yes */ GOTO SummonNarcillicus3
  IF ~~ THEN REPLY @37 /* no  */  EXIT
END



IF ~~ THEN BEGIN SummonNarcillicus3
  SAY @82  /* You left the darkness behind, but a new horrow was waiting for you on the surface...  */
  IF ~~ THEN DO ~SetGlobal("!SNarcillicusSummoned","GLOBAL",1)~ EXIT
END




/*-------------// Ricompensa Narcillicus & evocazione Mercenari \\---------*/



IF ~Global("!SCongratz","GLOBAL",5) Global("!SNarcillicusSummoned","GLOBAL",3) Global("!SIerofanteOffeso","GLOBAL",0)~ THEN BEGIN RewardNarcillicus1
  SAY @106  /* What is this bad smell on you?? Phua! Maybe it's better if I don't ask what happened inside there... */
  IF ~~ THEN REPLY @107 /* got slimed */ DO ~SetGlobal("!SCongratz","GLOBAL",6) AddXPObject(Player1,20000)~ GOTO RewardNarcillicus2
END


IF ~~ THEN BEGIN RewardNarcillicus2
  SAY @123=@35  /* I will not investigate on the meaning of that word... Now we can proceed with the next challenge. Are you ready? */
  IF ~~ THEN REPLY @36 /* yes */  GOTO SummonBandits1
  IF ~~ THEN REPLY @37 /* no  */  EXIT
END


IF ~Global("!SCongratz","GLOBAL",6) Global("!SBanditsSummoned","GLOBAL",0) Global("!SIerofanteOffeso","GLOBAL",0)~ THEN BEGIN SummonBandits2
  SAY @38  /* You come back. Are you ready? */
  IF ~~ THEN REPLY @36 /* yes */ GOTO SummonBandits1
  IF ~~ THEN REPLY @37 /* no  */  EXIT
END


IF ~~ THEN BEGIN SummonBandits1
  SAY @108  /* You and your group interrogated a man by the name of Tranzig, back in Beregost and found new elements regarding the location of the well hidden Bandits' Camp. */
  IF ~~ THEN DO ~SetGlobal("!SBanditsSummoned","GLOBAL",1)~ EXIT
END





/*-------------// Ricompensa Mercenari & Dynaheir o Regina Ragni \\---------*/


IF ~Global("!SCongratz","GLOBAL",6) Global("!SBanditsSummoned","GLOBAL",3) Global("!SIerofanteOffeso","GLOBAL",0) Global("!SKhalidDead","GLOBAL",0)~ THEN BEGIN RewardBandits1
  SAY @124 /* That was a tough battle mh? Some spirits are moved only by anger and are beyond redemption, I guess. I hope you learned something from that. */
  IF ~~ THEN DO ~SetGlobal("!SCongratz","GLOBAL",7) AddXPObject(Player1,30000)~ GOTO RewardBandits2
END




IF ~~ THEN BEGIN RewardBandits2
  SAY @35  /* Now we can proceed with the next challenge. Are you ready? */
  IF ~~ THEN REPLY @36 /* yes */  GOTO SpiderQueen
  IF ~~ THEN REPLY @37 /* no  */  EXIT
END




IF ~Global("!SCongratz","GLOBAL",7) Global("!SBanditsSummoned","GLOBAL",3) Global("!SIerofanteOffeso","GLOBAL",0) Global("!SKhalidDead","GLOBAL",0) Global("!SpQueenSummoned","GLOBAL",0)~ THEN BEGIN SpiderQueenReady1
  SAY @35  /* Now we can proceed with the next challenge. Are you ready? */
  IF ~~ THEN REPLY @36 /* yes */  GOTO SpiderQueen
  IF ~~ THEN REPLY @37 /* no  */  EXIT
END


IF ~Global("!SCongratz","GLOBAL",7) Global("!SBanditsSummoned","GLOBAL",3) Global("!SIerofanteOffeso","GLOBAL",0) Global("!SKhalidDead","GLOBAL",2) Global("!SpQueenSummoned","GLOBAL",0)~ THEN BEGIN SpiderQueenReady2
  SAY @35  /* Now we can proceed with the next challenge. Are you ready? */
  IF ~~ THEN REPLY @36 /* yes */  GOTO SummonSpiderQueen
  IF ~~ THEN REPLY @37 /* no  */  EXIT
END




IF ~~ THEN BEGIN SpiderQueen
  SAY @145  /* Very well, focus on the events of your past. */
  IF ~~ THEN GOTO SummonSpiderQueen
  IF ~InParty("Jaheira")~ THEN EXTERN JAHEI25J xyz
END


IF ~~ THEN BEGIN SummonSpiderQueen
  SAY @168  /* In the Bandits' Camp you spoke with Ender Sai and retrieved some important letters confirming the Iron Throne's implication */
  IF ~~ THEN DO ~SetGlobal("!SpQueenSummoned","GLOBAL",1) SetDialogue("!sierof2")~ EXIT
END




IF ~Global("!SCongratz","GLOBAL",7) Global("!SBanditsSummoned","GLOBAL",3) Global("!SIerofanteOffeso","GLOBAL",0) Global("!SKhalidDead","GLOBAL",1)~ THEN BEGIN khaliddead1-3
  SAY @134  /* I tried to summon his spirit, but it is nowhere to be found. I guess he died in a way that prevents resurrection or spirit summoning. */
IF ~!InParty("Minsc")~ THEN REPLY @135  /* Jaheira, I'm so sorry...~ */ DO ~SetGlobal("!SKhalidDead","GLOBAL",2)~ EXTERN ~jahei25j~ NoKhalid1
IF ~ InParty("Minsc")~ THEN REPLY @135  /* Jaheira, I'm so sorry...~ */ DO ~SetGlobal("!SKhalidDead","GLOBAL",2)~ EXTERN ~jahei25j~ NoKhalidButDyna1
IF ~!InParty("Minsc")~ THEN REPLY @136  /* Maybe it's better this way. Khalid already knows you will never forget him. */ DO ~SetGlobal("!SKhalidDead","GLOBAL",2)~ EXTERN ~jahei25j~ NoKhalid2
IF ~ InParty("Minsc")~ THEN REPLY @136  /* Maybe it's better this way. Khalid already knows you will never forget him. */ DO ~SetGlobal("!SKhalidDead","GLOBAL",2)~ EXTERN ~jahei25j~ NoKhalidButDyna2
IF ~!InParty("Minsc")~ THEN REPLY @137  /* Just as I told you...A waste of your time.  */ DO ~SetGlobal("!SKhalidDead","GLOBAL",2)~ EXTERN ~jahei25j~ NoKhalid3
IF ~ InParty("Minsc")~ THEN REPLY @137  /* Just as I told you...A waste of your time.  */ DO ~SetGlobal("!SKhalidDead","GLOBAL",2)~ EXTERN ~jahei25j~ NoKhalidButDyna3
END




APPEND JAHEI25J
IF ~~ THEN BEGIN xyz
  SAY @125=@126
IF ~~ THEN REPLY @127  GOTO khaliddead1
IF ~~ THEN REPLY @128  GOTO khaliddead2
IF ~~ THEN REPLY @129  GOTO khaliddead3
END 
END


APPEND ~!sierof~
IF ~~ THEN BEGIN SummonDyna
  SAY @144  /* Mmm a dead companion...I will try to summon the spirit of the one you know as Dynaheir.~ */
  IF ~~ THEN DO ~StartCutSceneMode() ClearAllActions() ForceSpellRES("!Sjelly",Myself) Wait(2) StartCutScene("!Sumdyna")~ EXIT
END
END



APPEND JAHEI25J
IF ~~ khaliddead3
  SAY @132 /* You will never understand, <CHARNAME>... */
  IF ~~ DO ~SetGlobal("!SKhalidDead","GLOBAL",1)~ EXTERN ~!sierof~ SummonFailed
END
END


APPEND JAHEI25J
IF ~~ khaliddead2
  SAY @131 /* I don't know... I just wish to tell him goodbye, that way our souls will finally find peace. */
  IF ~~ DO ~SetGlobal("!SKhalidDead","GLOBAL",1)~ EXTERN ~!sierof~ SummonFailed
END
END


APPEND JAHEI25J
IF ~~ khaliddead1
  SAY @130  /* Yes...As you remember, we were brutally parted when Irenicus ambushed our group and then... */
  IF ~~ DO ~SetGlobal("!SKhalidDead","GLOBAL",1)~ EXTERN ~!sierof~ SummonFailed
 END
END



APPEND JAHEI25J
IF ~~ NoKhalid1
  SAY @138=@139 /* Damn you, Irenicus! - let's move on with the next challenge if you wish. */
  IF ~~ THEN EXIT
END
END

APPEND MINSC25J
IF ~~ THEN BEGIN abc
  SAY @148=@149 /* Summoner! Can you bring our precious Dynaheir here? */
  IF ~~ EXTERN ~!sierof~ SummonDyna
END
END


APPEND JAHEI25J
IF ~~ NoKhalidButDyna1
  SAY @138=@146=@147 /* Damn you, Irenicus! - let's move on with the next challenge if you wish. Minsc & Dyna */
  IF ~~ THEN EXTERN MINSC25J abc
END
END



APPEND JAHEI25J
IF ~~ NoKhalid2
  SAY @140=@139 /* Khalid didn't deserve to end like that! -  let's move on with the next challenge if you wish. */
  IF ~~ THEN EXIT 
END
END


APPEND JAHEI25J
IF ~~ NoKhalidButDyna2
  SAY @140=@146=@147 /* Damn you, Irenicus! - let's move on with the next challenge if you wish. Minsc & Dyna */
  IF ~~ THEN EXTERN MINSC25J abc
END
END



APPEND JAHEI25J
IF ~~ NoKhalid3
  SAY @141=@142 /* No compassion - I will not bother you any longer, go on with your next challenge if you please. */
  IF ~~ THEN EXIT
END
END



APPEND JAHEI25J
IF ~~ NoKhalidButDyna3
  SAY @141=@150=@147 /* No compassion - I will not bother you any longer, Minsc & Dyna. */
  IF ~~ THEN EXTERN MINSC25J abc
END
END



APPEND ~!sierof~
IF ~~ THEN BEGIN SummonFailed
  SAY @133 /* Mmm a dead companion...I will try to summon the spirit of the one you know as Khalid. */
  IF ~~ THEN DO ~StartCutSceneMode() ClearAllActions() ForceSpellRES("!sjelly",Myself) Wait(3) EndCutSceneMode() StartDialogueNoSet(Player1)~ EXIT
END
END



