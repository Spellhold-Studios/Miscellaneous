BEGIN ~!Starn~

IF ~Global("!STarneshSummoned","GLOBAL",2)~ THEN BEGIN 0
  SAY @40 /* Ahahahahah! We meet again, <CHARNAME>. */
  IF ~~ THEN REPLY @41 /* What? Not you, please... */  GOTO 1
  IF ~~ THEN REPLY @42 /* I don't remember you. Are you one of the fools I killed in my past? */ GOTO 2
END


IF ~~ THEN BEGIN 1
  SAY @43=@44 /* Oh yes, the great Tarnesh is back. You look very surprised to see me. Sarevok, that slimy bastard..... */
  IF ~~ THEN REPLY @47 /* We will see, Tarnesh. You'd better prepare your bet spells! */  GOTO 4
  IF ~~ THEN REPLY @46 /* Enough with your useless raving! fight */ GOTO 5
  IF ~~ THEN REPLY @45 /* the <CHARNAME> you remember had just a fraction of my powers. */ GOTO 5
END


IF ~~ THEN BEGIN 2
  SAY @49 /* I was a bounty hunter */
  IF ~~ THEN GOTO 3
END

IF ~~ THEN BEGIN 3
  SAY @44 /* my powers are greater than before */
  IF ~~ THEN REPLY @47 /* We will see, Tarnesh. You'd better prepare your bet spells! */  GOTO 4
  IF ~~ THEN REPLY @46 /* Enough with your useless raving! fight */ GOTO 5
  IF ~~ THEN REPLY @45 /* the <CHARNAME> you remember had just a fraction of my powers. */ GOTO 5
END



IF ~~ THEN BEGIN 4
  SAY @48 /* Die, insolent */
  IF ~~ THEN EXIT
END

IF ~~ THEN BEGIN 5
  SAY @50 /* Die, insolent */
  IF ~~ THEN EXIT
END
