
BEGIN ~!staugo~


CHAIN
IF ~NumTimesTalkedTo(0)~
THEN ~!staugo~ taugoszardenor1
@109 /* What? WHO dares disturb my soul? */
= @110 /* It can't be! I remember you! You are the one Sarevok was so obsessed with */
== ~!sardeno~ @111 /* Yes, Sarevok, that dog. He said this kid would be no threat to us, and look what happened */
== ~!staugo~  @112 /* Mph! The Black Talons would have easily killed this weakling in our camp, if only... */
== ~!sardeno~ @113 /* Ooh really? But why the mighty Taugosz is among the dead */
== ~!staugo~  @114 /* Shut up, dog! When I am over with him I will settle the score with you too! */
END


++  @115 /* Err- I'm so sorry to interrupt your lovely chatting, but now it's time to die...again. */  + taugoszardenor2
++  @116 /* Enough with this! I will send your miserable spirits back to the oblivion! */ + taugoszardenor2
++  @117 /* Aren't you tired of dying by my hand? */ + taugoszardenor2





CHAIN
IF ~~ THEN ~!staugo~ taugoszardenor2
@120     /* It will not be so easy, this time! You was a coward! You sneaked in our camp like a rat, and attacked us by surprise. */
= @118  /* Ardenor, let's put our hatred aside and attack this bastard! If we kill him we will probably come back to life! */
== ~!sardeno~ @119  /*  Deal, but know that I'm no friend of yours. */ DO ~ENEMY()~
== ~!staugo~  @121  /* Very well! Attack!! */   DO ~ENEMY()~
END


++  @122 /* Don't say I didn't warn you */ EXIT
