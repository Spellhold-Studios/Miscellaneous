
BEGIN ~!SKRYST~




APPEND ~!slythe~
  IF ~~ 1
    SAY @308
    IF ~~ THEN EXTERN ~!SKRYST~ SlyKryMeeting3
  END
END




CHAIN
IF ~Global("!SlyKrySummoned","GLOBAL",2) Global("!Saggro","LOCALS",0)~ THEN ~!SKRYST~ SlyKryMeeting2
@296
== ~!SLYTHE~ @297
== ~!SKRYST~ @298
== ~!SLYTHE~ @299
== ~!SKRYST~ @300
== ~!SLYTHE~ @301
== ~!SKRYST~ @302
=  @303
== ~!SLYTHE~ @304
== ~!SKRYST~ @305
=  @306
END

++ @307 EXTERN ~!SLYTHE~ 1



CHAIN
IF ~~ THEN ~!SKRYST~ SlyKryMeeting3
@309  DO ~SetGlobal("!Saggro","LOCALS",1)~
== ~!SLYTHE~ @310 DO ~SetGlobal("!Saggro","LOCALS",1)~
END

++ @318 EXIT


