
BEGIN ~!sdavaeo~


IF ~Global("!sDavaeornDemon","GLOBAL",0)~ THEN BEGIN DavaFirstMeeting
  SAY @224  /* Mmm excellent! Everything is going exactly as my Master foresaw.~ */
  IF ~~ THEN REPLY @225  /* Davaeorn! I see the Hell itself didn't want a miserable bastard such as you...You speak of a plan and a master, would you mind explaining? */  GOTO Dava01
  IF ~~ THEN REPLY @226  /* I don't remember you, spirit. Who are you? And what are you talking about? */  GOTO Dava02
  IF ~~ THEN REPLY @227  /* Oh! Yes! This is a spirit I would gladly kill again and again and again. */  GOTO Dava01
END


IF ~~ THEN BEGIN Dava01
  SAY @228  /* The last time we met I foolishly underestimated you, <CHARNAME>. The Iron Throne didn't know of your origins, and me neither, otherwise I would have taken better precautions. */
  IF ~~ THEN REPLY @229  /* You speak about a Master. Who is he? What does he want from me? */ GOTO Dava02-1
  IF ~~ THEN REPLY @230  /* Your plan doesn't really matter, Davaeorn... you're like a fly compared to me. */ GOTO Dava02-2
END

IF ~~ THEN BEGIN Dava02-2
  SAY @235  /* Ahahah...fool! You know nothing of me or my Master. */
  IF ~~ THEN GOTO Dava02-1
END

IF ~~ THEN BEGIN Dava02
  SAY @243  /* I can't believe you forgot me. I am Davaeorn, when we met I was leading the activities of extraction in the Cloakwood Mines, on behalf of the Iron Throne. */
  IF ~~ THEN GOTO Dava01
END



IF ~~ THEN BEGIN Dava02-1
  SAY @231   /* He is the Lord of Hell himself, the magnificent Lord Asmodeus! He knew I would be summoned here and so he hired me to defeat you, son of Bhaal! */
  IF ~~ THEN REPLY @232  /* The lord of Hell...Are you kidding me? And why does he need you? What reward did he promised you for such task? */  GOTO Dava02-3
  IF ~~ THEN REPLY @233  /* I don't believe anything you said. Hell really made you completely crazy. */   GOTO Dava02-4
  IF ~~ THEN REPLY @234  /* Asmodeus! Now that would be a fight worth of my time! */ GOTO Dava02-5
END

IF ~~ THEN BEGIN Dava02-3
  SAY @236   /* All I said is true, Bhaalspawn. Lord Asmodeus hired me because he cannot leave the plane of Hell personally, he needs someone to act on his behalf. */
  IF ~~ THEN REPLY @237  /* Do you really believe the Lord of Hell would reward you after you succeed? Devils are not exactly famous for their honesty...*/ GOTO Dava02-6
  IF ~~ THEN REPLY @238  /* Puah! I'm not worried about this even if it's true, because you have absolutely no chance of succeeding. */ GOTO Dava02-5
  IF ~~ THEN REPLY @239  /* Very well then, the time for words is over. Show me this new powers of yours! */ GOTO Dava02-7
END

IF ~~ THEN BEGIN Dava02-4
  SAY @241  /* That does not concern me, the opinion of the dead is not really important.~ */
  IF ~~ THEN DO ~Enemy()~ EXIT
END

IF ~~ THEN BEGIN Dava02-5
  SAY @242  /* You should better not underestimate me, <CHARNAME>, nor the power of my Master. You would be sorry for yourself. Now get ready to meet your final death, son of Bhaal! */
  IF ~~ THEN DO ~Enemy()~ EXIT
END

IF ~~ THEN BEGIN Dava02-6
  SAY @244  /* My master would never betray me! I will be at his side when he will become the rightful ruler of the multiverse! Prepare to die, dog! */
  IF ~~ THEN DO ~Enemy()~ EXIT
END

IF ~~ THEN BEGIN Dava02-7
  SAY @240  /* It appears we finally agree on something! */
  IF ~~ THEN DO ~Enemy()~ EXIT
END





IF ~Global("!sDavaeornDemon","GLOBAL",1)~ THEN BEGIN DavaDemon
  SAY @245   /* Enough! My master was right about you, my spells are not as effective as I thought on you. It's time to change strategy. Be ready to experience the true taste of fear! */
  IF ~~ THEN DO ~SetGlobal("!sDavaeornDemon","GLOBAL",2) StartCutSceneMode() DestroyItem("!S1hp")  MoveViewObject(Myself,VERY_Fast) Wait(1) SmallWait(8) ReallyForceSpellRES("!sbuffet",Player1) ApplySpellRES("!sdemon",Myself) EndCutSceneMode()~ EXIT
END

