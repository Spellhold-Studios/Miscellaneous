BEGIN ~!Snarcil~





IF ~True()~ THEN BEGIN Narcillicus1
  SAY @83  /* Ahahahah I'm alive! I knew it! The power of my magic is unmatched. */
  IF ~~ THEN REPLY  @84 /* Errr- I'm sorry to interrupt the expansion of your ego...  */  GOTO Narcillicus1-2
  IF ~~ THEN REPLY  @85 /* Not enother lunatic...Who are you, spirit?*/                   GOTO Narcillicus2-1
END


IF ~~ THEN BEGIN Narcillicus1-2
  SAY @86  /* What? Who are you to question the magnificence of Narcillicus Harwilliger Neen? */
  IF ~~ THEN REPLY  @87  /* Wait a second...It can't be! You are that amateur that was trying to control gelatinous creatures!  */  GOTO Narcillicus1-4
  IF ~~ THEN REPLY  @88  /* I am <CHARNAME>, lord of this plane. And who might you be?  */              GOTO Narcillicus2-1
  IF ~~ THEN REPLY  @89  /* If you don't temper your arrogance you will die before even knowing my name. */  GOTO Narcillicus3-1
END


IF ~~ THEN BEGIN Narcillicus1-4
  SAY @90  /*  AMATEUR!? The ignorance! I'm a mage of infinite power and I have developed the ultimate spell. */
  IF ~~ THEN REPLY  @91  /* Mm..Interesting, you have my attention now.  */  GOTO Narcillicus1-5
  IF ~~ THEN REPLY  @92  /* Yes yes...whatever you say... */              GOTO Narcillicus1-6
END


IF ~~ THEN BEGIN Narcillicus1-5
  SAY @93   /*  Ahahahah! Fool! You really think I would share my knowledge with you? evoca jelly king */
  IF ~~ THEN DO ~SetGlobal("!Sjellykingsummoned","GLOBAL",1) Enemy()~ EXIT
END



IF ~~ THEN BEGIN Narcillicus1-6
  SAY @94  /* You still doubt my powers mh? Very well, it is time to move on to the practice! evoca jelly king */
  IF ~~ THEN DO ~SetGlobal("!Sjellykingsummoned","GLOBAL",1) Enemy()~ EXIT
END



IF ~~ THEN BEGIN Narcillicus2-1
  SAY @95 /* Mph! The ignorant asks me who I am...Kneel in front of the great Narcillicus Harwilliger Neen! */
  IF ~~ THEN REPLY  @87  /* Wait a second...It can't be! You are that amateur that was trying to control gelatinous creatures!  */  GOTO Narcillicus1-4
  IF ~~ THEN REPLY  @97  /* Oh...ehm...Yes of course, his majesty, but...I still don't remember about you. */  GOTO Narcillicus2-2
END



IF ~~ THEN BEGIN Narcillicus2-2
  SAY @98  /* *groans* I am the first mage in the planes that ever controlled a gelatinous creature! Jellies, slimes, oozes! They are all at my command! */
  IF ~~ THEN REPLY  @99  /* Sorry but it doesn't really sound that useful...why not dragons?  */  GOTO Narcillicus2-3
  IF ~~ THEN REPLY  @100 /* ~Oh! I MUST have that power!~ */  GOTO Narcillicus1-5
END



IF ~~ THEN BEGIN Narcillicus2-3
  SAY @103=@104=@105  /* the kid has a point...evoca jelly king */
  IF ~~ THEN DO ~SetGlobal("!Sjellykingsummoned","GLOBAL",1) Enemy()~ EXIT
END



IF ~~ THEN BEGIN Narcillicus3-1
  SAY @101 /* This is not arrogance, my ignorant friend, it is the weight of greatness. */
  IF ~~ THEN REPLY @102  /* Maybe you want to try the weight of my warhammer. */ GOTO Narcillicus1-6
END



