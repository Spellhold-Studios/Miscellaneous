
BEGIN ~!stamok~


IF ~Global("!Sattacked","LOCALS",0) Global("!stamokred","GLOBAL",0)~ THEN BEGIN 01
SAY @335 /* A peculiar place. Where am I? */
IF ~OR(4) Alignment(Protagonist,MASK_GOOD)
Alignment(Protagonist,NEUTRAL)
Alignment(Protagonist,CHAOTIC_NEUTRAL)
Alignment(Protagonist,LAWFUL_NEUTRAL)~ THEN GOTO 02
IF ~Alignment(Protagonist,MASK_EVIL)~ THEN GOTO 03
END


IF ~~ THEN BEGIN 03
SAY @337 /*You are my beloved Sarevok's <PRO_BROTHERSISTER>, and the one who took my life.*/
IF ~~ THEN REPLY @339 /*I killed far too many in my life to remember them all. Who are you?*/ GOTO 04-Evil
IF ~~ THEN REPLY @338 /*You speak about Sarevok, Spirit, but I can't remember you*/ GOTO 04-Evil
IF ~~ THEN REPLY @341 /*you are that chick from the east. What do you want?*/ GOTO 02-2
END

IF ~~ THEN BEGIN 04
SAY @343 /*I am Tamoko, once priest of Cyric and Sarevok's lover.*/
IF ~~ THEN REPLY @342 /*Oh, yes, Tamoko. I spared your life. What happened to you?*/ GOTO 02-1
IF ~~ THEN REPLY @341 /*you are that chick from the east. What do you want?*/ GOTO 02-2
END

IF ~~ THEN BEGIN 04-Evil
SAY @343 /*I am Tamoko, once priest of Cyric and Sarevok's lover.*/
IF ~~ THEN REPLY @341 /*you are that chick from the east. What do you want?*/ GOTO 02-2
END


IF ~~ THEN BEGIN 02-3
SAY @373 /* Save your false pity, Bhaalspawn. The taint in your blood hardly allows any compassion.*/
IF ~~ THEN GOTO 02-2
END

IF ~~ THEN BEGIN 02-2
SAY @372 /*I have a request for you, <CHARNAME>.~*/
IF ~~ THEN GOTO 06
END




IF ~~ THEN BEGIN 02
SAY @336 /* I- I think I remember your face, <PRO_RACE>. You are my beloved Sarevok's bro-sis */
IF ~~ THEN REPLY @340 /*Ah, it must be Tamoko. I spared your life. What happened to you?*/ GOTO 02-1
IF ~~ THEN REPLY @341 /*you are that chick from the east. What do you want?*/ GOTO 02-2
IF ~~ THEN REPLY @338 /*You speak about Sarevok, Spirit, but I can't remember you.*/ GOTO 04
END

IF ~~ THEN BEGIN 02-1
SAY @344 /*Sarevok found out that I was helping you. a spy found me. The assassin ambushed me in the woods and took my life.*/
IF ~~ THEN REPLY @345 /*This story sounds very familiar. u killed Gorion. Serves you right!*/ GOTO 05
IF ~~ THEN REPLY @346 /*Oh, poor sweetheart...Such is the fate of double agents*/  GOTO 02-3
IF ~~ THEN REPLY @347 /*I'm sorry about your story, Tamoko. So tell me now, why are you here?*/ GOTO 06
END

IF ~~ THEN BEGIN 05
SAY @348 /*I remember that night...I was just trying to save the person I loved.*/
IF ~~ THEN REPLY @349 /*There's no salvation for you, spirit.Prepare yourself!*/ DO ~SetGlobal("!stamokNotRed","GLOBAL",1) Enemy()~ EXIT
IF ~Alignment(Protagonist,LAWFUL_GOOD)~ THEN REPLY @350 /*The past is the past.I forgive you, spirit, as I forgave Sarevok.*/ GOTO 06
IF ~~ THEN REPLY @351 /*Somehow, I understand you. Love makes us do things we would never think possible. So tell me, why are you here?*/ GOTO 06
END

IF ~~ THEN BEGIN 06
SAY @352 /*I have not come to seek your forgiveness, there's no hope for that.the fate of my beloved one.*/
IF ~Dead("Sarevok")~ THEN REPLY @353 /*I killed him in the ancient temple of Bhaal and I sent his cursed soul back to the Abyss where it belongs.*/ GOTO 07
IF ~!Dead("Sarevok") GlobalGT("SarevokAlive","GLOBAL",0) !InParty("Sarevok")~ THEN REPLY @354 /*I accepted his request but he's not in my group...*/ GOTO 08
IF ~!Dead("Sarevok") GlobalGT("SarevokAlive","GLOBAL",0) InParty("Sarevok") !Alignment("Sarevok",CHAOTIC_GOOD)~ THEN REPLY @355 /*I accepted his request and now he's following me in my quest.*/ GOTO 09
IF ~!Dead("Sarevok") GlobalGT("SarevokAlive","GLOBAL",0) InParty("Sarevok") Alignment("Sarevok",CHAOTIC_GOOD)~ THEN REPLY @356 /*I accepted his request and now he's following me in my quest. I even managed to redeem him.*/ GOTO 10
END


IF ~~ THEN BEGIN 07
SAY @357 /*I understand...Then, I have no other choice but to fight you! Otherwise my spirit will never find peace!*/
IF ~CheckStatGT(Protagonist,17,CHR) Alignment(Protagonist,MASK_GOOD)~ THEN REPLY @367 /*You don't have to do this. Why don't you just let him go? The gods will have mercy on you.*/ GOTO Redeemed
IF ~CheckStatLT(Protagonist,18,CHR) Alignment(Protagonist,MASK_GOOD)~ THEN REPLY @367 /*You don't have to do this. Why don't you just let him go? The gods will have mercy on you.*/ GOTO NotRedeemed
IF ~CheckStatGT(Protagonist,17,CHR)
OR(3) Alignment(Protagonist,NEUTRAL)
Alignment(Protagonist,CHAOTIC_NEUTRAL)
Alignment(Protagonist,LAWFUL_NEUTRAL)~ THEN REPLY @371 /*Don't you understand that with your actions you condemn yourself to eternal torment?*/ GOTO Redeemed
IF ~CheckStatLT(Protagonist,18,CHR)
OR(3) Alignment(Protagonist,NEUTRAL)
Alignment(Protagonist,CHAOTIC_NEUTRAL)
Alignment(Protagonist,LAWFUL_NEUTRAL)~ THEN REPLY @371 /*Don't you understand that with your actions you condemn yourself to eternal torment?*/ GOTO NotRedeemed
IF ~~ THEN REPLY @366 /*As you wish. A little bit of action it's exactly what I need after this drama. I'm ready when you are.*/ DO ~SetGlobal("!stamokNotRed","GLOBAL",1) Enemy()~ EXIT
END


IF ~~ THEN BEGIN Redeemed
SAY @369=@370 /*I...I guess there's wisdom in your words...I might try to let him go and give peace to my restless spirit. - farewell*/
IF ~~ THEN DO ~StartCutSceneMode() Wait(2) SetGlobal("!stamokNeutralRed","GLOBAL",1) CreateVisualEffectObject("SPCCWOUI","!stamok") PlaySound("EFF_M80") WAIT(1) EndCutSceneMode() DestroySelf()~ EXIT
END

IF ~~ THEN BEGIN NotRedeemed
SAY @368 /* You can't understand! I have to do this!~*/
IF ~~ THEN DO ~SetGlobal("!stamokNotRed","GLOBAL",1) Enemy()~ EXIT
END

IF ~~ THEN BEGIN 08
SAY @358 /*He is alive. I can only hope that he is well.my punishment will be a little less bitter.Farewell.*/
IF ~~ THEN DO ~StartCutSceneMode() Wait(2) SetGlobal("!stamokNeutralRed","GLOBAL",1) CreateVisualEffectObject("SPCCWOUI","!stamok") PlaySound("EFF_M80") WAIT(1) EndCutSceneMode() DestroySelf()~ EXIT
END

IF ~~ THEN BEGIN 09
SAY @359 /*Is he? Oh it is such a relief...*/
IF ~~ THEN GOTO 09-2
END


IF ~~ THEN BEGIN 09-2
SAY @360 /*Would you- *she stops for a moment, her hands shacking a bit* let me see him once more before my demise?*/
IF ~CheckStatGT(Protagonist,17,CHR)~ THEN REPLY @362 /*I don't think it would be a good idea, Tamoko. Maybe you should leave everything as it is.*/ GOTO 09-3
IF ~CheckStatLT(Protagonist,18,CHR)~ THEN REPLY @362 /*I don't think it would be a good idea, Tamoko. Maybe you should leave everything as it is.*/ GOTO 09-4
IF ~~ THEN REPLY @374 /*Why are you so sure he wants to see you again? Sorry but I will not allow that meeting.*/ GOTO 09-4
IF ~Alignment(Protagonist,CHAOTIC_EVIL)~ THEN REPLY @420 /* He has moved on and he's part of my group now. I won't allow you to bother Sarevok any further.*/ GOTO 09-4
IF ~~ THEN REPLY @363 /*I guess there's no harm in that, yes...I can arrange this meeting for you.*/ GOTO 09-5
IF ~Alignment(Protagonist,CHAOTIC_EVIL)~ THEN REPLY @421 /* Alright, but be quick with it!*/ GOTO 09-5
END



IF ~~ THEN BEGIN 09-3
SAY @365 /*I see...Maybe you are right, afterall...He's alive and he has moved on since that tragic day...Thank you, <CHARNAME>, I guess my punishment will be a little less bitter. Farewell.*/
IF ~~ THEN DO ~StartCutSceneMode() Wait(2) SetGlobal("!stamokNeutralRed","GLOBAL",1) CreateVisualEffectObject("SPCCWOUI","!stamok") PlaySound("EFF_M80") WAIT(1) EndCutSceneMode() DestroySelf()~ EXIT
END

IF ~~ THEN BEGIN 09-4
SAY @375 /*If that is your final decision I have no choice but to kill you! And then I will meet him again...My beloved Sarevok...*/
IF ~~ THEN DO ~SetGlobal("!stamokNotRed","GLOBAL",1) Enemy() ~ EXIT
END



IF ~~ THEN BEGIN 09-5
SAY @364 /*I...Thank you.*/
IF ~Alignment("Sarevok",CHAOTIC_GOOD)~ THEN DO ~StartCutSceneMode() SmallWait(22) StartCutScene("!SrvkCG")~ EXIT
IF ~Alignment("Sarevok",CHAOTIC_EVIL)~ THEN DO ~StartCutSceneMode() SmallWait(22) StartCutScene("!SrvkCE")~ EXIT
END


IF ~~ THEN BEGIN 10
SAY @361 /*It is not a lie, isn't it? Not only is he alive but...you managed to change him? */
IF ~~ THEN GOTO 09-2
END