BEGIN ~!Sbrag~



IF ~Global("!SbragRedempt","GLOBAL",2) StateCheck("!sbassil",STATE_DEAD) StateCheck("!sthurm",STATE_DEAD) NumDeadGT("!skel",6)~ THEN BEGIN finallyfree
  SAY ~It is over, <CHARNAME>. Now my spirit will finally be free from the guilt. Thank you and farewell.~
  IF ~~ THEN DO ~ClearAllActions() SetGlobal("!SbragRedempt","GLOBAL",3) StartCutSceneMode() CreateVisualEffectObject("spsarmor","!sbrag") smallwait(20) CreateVisualEffectObject("spsump","!sbrag") wait(4) EndCutSceneMode() DestroySelf() ~ EXIT
END



APPEND ~!sthurm~
  IF ~~ 1
    SAY ~GGhhhhaaaaaaaa....bllllllggggh~
IF ~Global("!SbragRedempt","GLOBAL",0)~ THEN EXTERN ~!Sbrag~ Vengeance
IF ~Global("!SbragRedempt","GLOBAL",1)~ THEN EXTERN ~!Sbrag~ bragehelps1
  END
END


APPEND ~!sthurm~
  IF ~~ 2
    SAY ~GGhhhhaaaaaaaa....bllllllggggh~
IF ~~ THEN EXIT
  END
END




APPEND ~!sbassil~
  IF ~~ 1
    SAY ~Help me!? You killed me and all the family members I reunited! How could you be so evil??~
= ~Eh? What are you saying, brother Thurm? Oh yes indeed, we will make <PRO_HIMHER> pay for what <PRO_HESHE> did to us!~
    IF ~~ THEN EXTERN ~!sthurm~ 1
  END
END


APPEND ~!sbassil~
  IF ~~ 2
    SAY ~Come brother Thurm, it is time to kill our enemies.~
    IF ~~ THEN EXTERN ~!sthurm~ 2
  END
END


CHAIN
IF ~~ THEN ~!Sbrag~ Vengeance
~Who is he talking to now? It doesn't matter, as long as he doesn't interfere with my vengeance! After you killed me, I was sent to Hell, <CHARNAME>. I've suffered so long, and now you will know exactly how it feels!~ DO ~ENEMY()~
END

++ ~Oh great...I have no choice again, I suppose. Prepare to meet your ultimate death, freaks!~ EXTERN ~!sbassil~ 2




CHAIN
IF ~~ THEN ~!Sbrag~ bragehelps1
~He's clearly out of his mind. I will help you, <CHARNAME>, as a token of my gratitude. My spirit will finally be redeemed.~
END

++ ~I really appreciate that, Brage. Let's put an end to him, now!~ DO ~ChangeEnemyAlly(Myself,ALLY)~ EXIT



CHAIN
IF ~~ THEN ~!Sbrag~ bragehelps2
~He's clearly out of his mind. I will help you, <CHARNAME>, as a token of my gratitude. My spirit will finally be redeemed.~ DO ~ChangeEnemyAlly(Myself,ALLY)~
END

++ ~I really appreciate that, Brage. Let's put an end to him, now!~ DO ~ChangeEnemyAlly(Myself,ALLY)~  EXTERN ~!sbassil~ 2





CHAIN
IF ~Global("!SBrageBassilusSummoned","GLOBAL",2)~
THEN ~!Sbrag~ BrageBassil1
~Where am I? Who brought this damned soul back to the world of the living?~ DO ~SetGlobal("!SBrageBassilusSummoned","GLOBAL",3)~
END

++ ~Oh...It is Brage. I remember you. You became crazy because of that cursed sword of yours. I had no chance but to slain you.~ + BrageBassil1-2
++ ~Brage! This cannot be! I clearly remember I knocked you unconscious and brought you back to the Temple of Helm in Nashkel where brother Nalin healed you and helped you to redeem yourself.~ + BrageBassil1-3
++ ~Mph! You really think I can remember every vermin I slained during my life. They are far too many to remember...~ + BrageBassil1-4



CHAIN
IF ~~ THEN ~!Sbrag~ BrageBassil1-2
~I remember it. My madness killed so many innocents...~
== ~!Sbassil~ IF ~Gender(Player1,MALE)~ THEN
   ~Father! It is you! You are back to save your son!~
== ~!Sbassil~ IF ~Gender(Player1,FEMALE)~ THEN
   ~Mother! It is you! You are back to save your son!~
== ~!Sbrag~ ~Who is this mad man?~
END


+~Gender(Player1,MALE)~+ ~Bassilus! The crazy priest of Cyric!~ + BrageBassil2-1
+~Gender(Player1,FEMALE)~+ ~Bassilus! The crazy priest of Cyric!~ + BrageBassil3-1


CHAIN
IF ~~ THEN ~!Sbrag~ BrageBassil2-1
~Cyric, you say. It doesn't sound promising.~
== ~!sbassil~ ~Oh father! I remember the last time we met you were not exactly a good daddy.~
END

++ ~Errr... Um-I'm SO sorry, my son. Your daddy was just trying to help you.~ EXTERN ~!sbassil~ 1
+~Global("!SbragRedempt","GLOBAL",0)~+ ~Stop it, lunatic. I'm not your father! I killed you once and I'll do it again if I have to.~ + BrageBassil2-3
+~Global("!SbragRedempt","GLOBAL",1)~+ ~Stop it, lunatic. I'm not your father! I killed you once and I'll do it again if I have to.~ + bragehelps2




CHAIN
IF ~~ THEN ~!Sbrag~ BrageBassil3-1
~Cyric, you say. It doesn't sound promising.~
== ~!sbassil~ ~Oh Mother! I remember the last time we met you were not exactly a good mommy.~
END

++ ~Errr... Um-I'm SO sorry, my son. Your mommy was just trying to help you.~ EXTERN ~!sbassil~ 1
+~Global("!SbragRedempt","GLOBAL",0)~+ ~Stop it, lunatic. I'm not your mother! I killed you once and I'll do it again if I have to.~ + BrageBassil2-3
+~Global("!SbragRedempt","GLOBAL",1)~+ ~Stop it, lunatic. I'm not your mother! I killed you once and I'll do it again if I have to.~ + bragehelps2


CHAIN
IF ~~ THEN ~!Sbrag~ BrageBassil2-3
~Not so fast, <CHARNAME>! We still have a score to settle! After you killed me, I was sent to Hell. I've suffered so long, and now you will know exactly how it feels!~ DO ~ENEMY()~
END

++ ~Oh great...I have no choice again, I suppose. Prepare to meet your ultimate death, freaks!~ EXTERN ~!sbassil~ 2



CHAIN
IF ~~ THEN ~!Sbrag~ BrageBassil1-3
~It is true, <CHARNAME>...But there's no redemption for the crimes I committed. So many innocents died because of my madness.~
= ~I was truly a fool to trust that merchant. The sword he showed me was very cheap, despite its high quality. I didn't suspect it could be cursed.~
= ~Brother Nalin was indeed a great man. He really tried to help me, but my inner wound was too deep to be healed. My...guilt was too heavy to endure, and after few weeks I committed suicide.~
END

++ ~A very sad story...I'm sorry I couldn't help you.~ DO ~SetGlobal("!SbragRedempt","GLOBAL",1)~ + BrageBassil1-5


CHAIN
IF ~~ THEN ~!Sbrag~ BrageBassil1-5
~You did much for me, I'm the only one to blame.~
== ~!Sbassil~ IF ~Gender(Player1,MALE)~ THEN
   ~Father! It is you! You are back to save your son!~
== ~!Sbassil~ IF ~Gender(Player1,FEMALE)~ THEN
   ~Mother! It is you! You are back to save your son!~
== ~!Sbrag~ ~Who is this mad man?~
END

+~Gender(Player1,MALE)~+ ~Bassilus! The crazy priest of Cyric!~ + BrageBassil2-1
+~Gender(Player1,FEMALE)~+ ~Bassilus! The crazy priest of Cyric!~ + BrageBassil3-1



CHAIN
IF ~~ THEN ~!Sbrag~ BrageBassil1-4
~You are merciless and wicked. People's lives mean nothing to you...~
END

++ ~Oh I remember you now. You are the wimp who was too weak to fight like a real man and bought that magic sword.~ + BrageBassil3-2



CHAIN
IF ~~ THEN ~!Sbrag~ BrageBassil3-2
~*clenches his fists*~
== ~!Sbassil~ IF ~Gender(Player1,MALE)~ THEN
   ~Father! It is you! You are back to save your son!~
== ~!Sbassil~ IF ~Gender(Player1,FEMALE)~ THEN
   ~Mother! It is you! You are back to save your son!~
== ~!Sbrag~ ~Who is this mad man?~
END

+~Gender(Player1,MALE)~+ ~Bassilus! The crazy priest of Cyric!~ + BrageBassil2-1
+~Gender(Player1,FEMALE)~+ ~Bassilus! The crazy priest of Cyric!~ + BrageBassil3-1
