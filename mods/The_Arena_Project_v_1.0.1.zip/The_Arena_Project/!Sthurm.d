BEGIN ~!sthurm~

