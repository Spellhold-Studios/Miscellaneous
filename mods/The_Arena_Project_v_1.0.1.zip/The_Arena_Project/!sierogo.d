BEGIN ~!SieroGO~



/////////////////////////////////////////////////////////
//////* Ierofante attaccato dopo presentazione */////////
/////////////////////////////////////////////////////////

IF ~global("!SIerofanteAttaccato","GLOBAL",1) ~ THEN BEGIN 0
  SAY @200 /* Sei pazzo! */
  IF ~~ THEN REPLY @201 /* Muori! */  DO ~Setglobal("!SIerofanteAttaccato","GLOBAL",2) Enemy() DialogInterrupt(TRUE)~ EXIT
  IF ~~ THEN REPLY @202 /* sorry!! */ DO ~Setglobal("!SIerofanteAttaccato","GLOBAL",2)~ GOTO 1
END

IF ~~ THEN BEGIN 1
  SAY @203 /* Devi giurare che mi libererai */
  IF ~~ THEN REPLY @204 /* vero giuramento */   DO ~SetGlobal("!SVeroGiuramento","GLOBAL",1)~   GOTO 2
  IF ~~ THEN REPLY @205 /* falso fiuramento */  DO ~SetGlobal("!SFalsoGiuramento","GLOBAL",1)~  GOTO 2
  IF ~~ THEN REPLY @206 /* non prometto niente */ DO ~SetGlobal("!SIerofanteOffeso","GLOBAL",1)~ GOTO 4
END


IF ~~ THEN BEGIN 4
  SAY @207 /* non ti aiuter� pi� */
  IF ~~ THEN DO ~DialogInterrupt(TRUE)~ EXIT
END


IF ~~ THEN BEGIN 2
  SAY @209 /* molto bene */
  IF ~~ THEN DO ~DialogInterrupt(TRUE) RealSetGlobalTimer("!SieroTimer","GLOBAL",10)~ EXIT
END





///////////////////////////////////////////
//////* Ierofante stufo attacca */////////
/////////////////////////////////////////

IF ~Global("!SIerofanteOffeso","GLOBAL",2)~ THEN BEGIN IerofanteStufoAttacca
  SAY @33 /* Sono stufo! */
  IF ~~ THEN DO ~SetGlobal("!SIerofanteOffeso","GLOBAL",3) DestroyItem("!siering") Enemy()~ EXIT
END





///////////////////////////////////////////
//////*        Teleport         */////////
/////////////////////////////////////////


IF ~Global("!SIerofanteAttaccato","GLOBAL",3) Global("!SVeroGiuramento","GLOBAL",1)~ THEN BEGIN 5
  SAY @210 /* Mi hai attaccato di nuovo, sono libero */
  IF ~~ THEN DO ~SetGlobal("!SIerofanteVeroTeletrasporto","GLOBAL",1) SetGlobal("!SIerofanteAttaccato","GLOBAL",4) StartCutSceneMode() ClearAllActions() SetInterrupt(FALSE) DialogueInterrupt(FALSE) ForceSpell(Myself,POOF_GONE) Wait(1) EndCutSceneMode()~ EXIT
END


IF ~Global("!SIerofanteAttaccato","GLOBAL",3) Global("!SFalsoGiuramento","GLOBAL",1)~ THEN BEGIN 6
  SAY @210 /* Mi hai attaccato di nuovo, sono libero */
  IF ~~ THEN DO ~SetGlobal("!SIerofanteFalsoTeletrasporto","GLOBAL",1) SetGlobal("!SIerofanteAttaccato","GLOBAL",4) StartCutSceneMode() StartCutScene("!sierdie")~ EXIT
END

