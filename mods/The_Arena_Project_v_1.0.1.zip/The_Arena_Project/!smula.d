 BEGIN ~!Smula~
 
 
 
IF ~TRUE()~ THEN BEGIN Mula1
  SAY @55  /* You! Why do you keep tormenting my soul even after death? */
  IF ~~ THEN REPLY @56  /*  I remember I spared your life in exchange of information. */  GOTO Mula1-2
  IF ~~ THEN REPLY @57  /* It looks like you remember me very well but I can't say the same about you. */ GOTO Mula2-2
  IF ~~ THEN REPLY @58  /* Another pathetic shadow of the past with no purpose. */ GOTO Mula3-2
END



IF ~~ THEN BEGIN Mula1-2
  SAY @59  /* Yes and your pity only led me to an even worse fate. */
  IF ~~ THEN REPLY @60  /*  Why, what happened to you? */  GOTO Mula1-3
END


IF ~~ THEN BEGIN Mula1-3
  SAY @61  /* After you let me go I came back to the bandit's camp to make report to Tazok */
  IF ~~ THEN REPLY @62  /*  Honestly, you couldn't expect anything different from a beast like Tazok. */  GOTO Mula1-4
  IF ~~ THEN REPLY @63  /*  Yes, apparently your cowardice was nothing, if compared to your stupidity... */  GOTO Mula1-5
END


IF ~~ THEN BEGIN Mula1-5
  SAY @70  /* How dare you? Fight */
  IF ~~ THEN DO ~Enemy()~ EXIT
END


IF ~~ THEN BEGIN Mula1-4
  SAY @64  /* Thank you for pointing out the obvious. So, what do you want from me? Did you summon my spirit to inflict more pain? */
  IF ~~ THEN REPLY @65  /* I pity you, Mulahey. I guess you paid enough for your mistakes. I dismiss you. */  GOTO Mula1-6
  IF ~~ THEN REPLY @66  /* Actually it wouldn't be a bad idea to have some more fun with you. */  GOTO Mula1-7
END


IF ~~ THEN BEGIN Mula1-7
  SAY @68 /* You are a monster just like Tazok! But this time I will not be subdued so easily, I am ready to fight! */
  IF ~~ THEN REPLY @69  /* Very well, I was starting to tire of this chatter. */ DO ~Enemy()~ EXIT
END


IF ~~ THEN BEGIN Mula1-6
  SAY @67  /* You- will really do that? I am very grateful. One day I will repay my debt of gratitude. Farewell! */
  IF ~~ THEN DO ~SetGlobal("!SMulaheyRedeemed","GLOBAL",1) StartCutSceneMode() CreateVisualEffectObject("sphlybls","!smula") wait(4) CreateVisualEffectObject("spsnrayi","!smula")  wait(1) EndCutSceneMode() DestroySelf()~ EXIT
END




IF ~~ THEN BEGIN Mula2-2
  SAY @71  /* My name is Mulahey, I worked for Tazok, Sarevok's right-hand man. */
  IF ~~ THEN REPLY @72  /* I remember you now. Why are you among the dead? I spared your life in exchange of information. */ GOTO Mula1-2
  IF ~~ THEN REPLY @73  /* Mmmm, Mulahey. Yes, you left me no choice but to kill you. */  GOTO Mula2-3
END


IF ~~ THEN BEGIN Mula2-3
  SAY @74  /* No choice?? I begged you to spare my life and yet you ended it mercilessly. */
  IF ~~ THEN REPLY @75 /* You was not exactly a saint, Mulahey. You can't blame me for my actions! */ GOTO Mula2-4
END


IF ~~ THEN BEGIN Mula2-4
  SAY @76  /* So, what do you want from me? Did you summon my spirit to inflict more pain? */
  IF ~~ THEN REPLY @65  /* I pity you, Mulahey. I guess you paid enough for your mistakes. I dismiss you. */  GOTO Mula1-6
  IF ~~ THEN REPLY @66  /* Actually it wouldn't be a bad idea to have some more fun with you. */  GOTO Mula1-7
END




IF ~~ THEN BEGIN Mula3-2
  SAY @77  /* Beast! The name is Mulahey. You know no mercy, even for the dead?  */
  IF ~~ THEN REPLY @78  /*  Why should I? You made the inexcusable mistake of getting in my way. That's what happen to those stupid enough to hinder me.. */  GOTO Mula1-5
  IF ~~ THEN REPLY @79  /* Mercy? Sorry but I leave such feelings to the weak. */  GOTO Mula1-7
END




