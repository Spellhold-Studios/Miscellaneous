
BEGIN ~!sierof2~

/*-------------// Ierofante Offeso \\---------*/

IF ~Global("!SIerofanteOffeso","GLOBAL",1) GlobalGT("!SIerofanteAttaccato","GLOBAL",1)~ THEN BEGIN IerofanteOffeso
  SAY @208 /* Ierofante non aiuta pi� */
  IF ~~ THEN DO ~DialogInterrupt(TRUE)~ EXIT
END



/*-------------// Ricompensa Regina Ragni e summon Davaeorn \\--------- */


IF ~Global("!SCongratz","GLOBAL",7) Global("!SpQueenSummoned","GLOBAL",3) Global("!sCenteolRedeemed","GLOBAL",0) Global("!SIerofanteOffeso","GLOBAL",0)~ THEN BEGIN RewardCenteolDead
  SAY @221 /* There's some...mush on your clothes, <CHARNAME>...but you acheived victory nonetheless. Well done. */
  IF ~~ THEN DO ~SetGlobal("!SCongratz","GLOBAL",8) AddXPObject(Player1,25000)~ GOTO RewardCenteol2
END


IF ~Global("!SCongratz","GLOBAL",7) Global("!SpQueenSummoned","GLOBAL",3) Global("!sCenteolRedeemed","GLOBAL",3) Global("!SIerofanteOffeso","GLOBAL",0)~ THEN BEGIN RewardCenteolRedeemed
  SAY @220  /* A very interesting event, mh? You saved another tormented soul from endless pain and grudge. You will be proud be proud of yourself, I guess. */
  IF ~~ THEN DO ~SetGlobal("!SCongratz","GLOBAL",8) AddXPObject(Player1,40000)~ GOTO RewardCenteol2
END


IF ~~ THEN BEGIN RewardCenteol2
  SAY @35  /* Now we can proceed with the next challenge. Are you ready? */
  IF ~~ THEN REPLY @36 /* yes */  GOTO SummonDavaeorn2
  IF ~~ THEN REPLY @37 /* no  */  EXIT
END


IF ~Global("!SCongratz","GLOBAL",8) Global("!SpQueenSummoned","GLOBAL",3) Global("!SIerofanteOffeso","GLOBAL",0) Global("!SDavaeornSummoned","GLOBAL",0)~ THEN BEGIN SummonDavaeorn1
  SAY @35  /* Now we can proceed with the next challenge. Are you ready? */
  IF ~~ THEN REPLY @36 /* yes */  GOTO SummonDavaeorn2
  IF ~~ THEN REPLY @37 /* no  */  EXIT
END



IF ~~ THEN BEGIN SummonDavaeorn2
  SAY @222 /* Your courageous group survived the endless dangers of the Cloakwood Forest, the time to venture inside the Iron Throne's mines had finally arrived. */
  IF ~~ THEN DO ~SetGlobal("!SDavaeornSummoned","GLOBAL",1)~ EXIT
END


/*-------------// Ricompensa Davaeorn & summon Slythe e Krystin \\--------- */


IF ~Global("!SCongratz","GLOBAL",8) Global("!SDavaeornSummoned","GLOBAL",3) Global("!SIerofanteOffeso","GLOBAL",0)~ THEN BEGIN RewardDavaeorn
  SAY @246  /* What's scarier than an angry archmage? An angry archmage with daemonic powers. These spirits are becoming very dangerous, <CHARNAME>, are you sure you want to continue? */
  IF ~~ THEN REPLY @247  /* Absolutely, these spirits are clearly restless. I can still save them or at least, put an ultimate end to their struggle. */  DO ~SetGlobal("!SCongratz","GLOBAL",9) AddXPObject(Player1,50000)~ GOTO HierophantPower1
  IF ~~ THEN REPLY @248  /* You would stop me now that I'm having so much fun? I think the best has yet to come, dear Hierophant! */      DO ~SetGlobal("!SCongratz","GLOBAL",9) AddXPObject(Player1,50000)~ GOTO HierophantPower2
  IF ~~ THEN REPLY @249  /* Have you forgot that I am going to ascend and soon become the new lord of murder? Killing is the reason why I was born. */   DO ~SetGlobal("!SCongratz","GLOBAL",9) AddXPObject(Player1,50000)~ GOTO HierophantPower3
END

IF ~~ THEN BEGIN HierophantPower1
  SAY @250 /* Your intent is noble, <CHARNAME>, but you can't save them all. Some of them are happy to walk on the path of revenge. */
  IF ~Class(Player1,PALADIN_ALL)~ THEN REPLY @251 /* not only my intent, it is my duty. As a paladin, I can understand the aura of living beings, but for some strange reason, yours is still concealed from my sixth sense. */ GOTO HierophantPower1-1
  IF ~~ THEN REPLY @252 /* In my life I have always been chased and attacked by people that haven't really left me a choice but to kill them. tell me something about you...  */ GOTO HierophantPower2-1
  IF ~~ THEN REPLY @253 /* I have seen far too many unbelievable things in my life, a bunch of angry spirits pose no threat to me. Let's continue. */ GOTO HierophantPower3-1
END

IF ~~ THEN BEGIN HierophantPower3-1
  SAY @254 /* Self confident as usual, I guess I should stop worrying for a semi-divine entity. Very well, as you wish, <CHARNAME>.*/
  IF ~~ THEN DO ~SetGlobal("!SHierophantPast","GLOBAL",1)~ EXIT
END

IF ~~ THEN BEGIN HierophantPower1-1
  SAY @255  /* Strange feeling? I don't understand what you are trying to say, <CHARNAME>. There's nothing special or strange about me, I can assure you, and I'm not hiding anything. */
  IF ~~ THEN REPLY @256  /* You have to admit you are quite a mysterious figure. Shrouded in your hooded robe, not very willing to speak about your past and your origins...~ */ GOTO HierophantPower1-2
  IF ~~ THEN REPLY @257  /* Do you really expect me to believe you are just a simple commoner? You are obviously hiding something from me.~ */ GOTO HierophantPower1-2
  IF ~~ THEN REPLY @258  /* Whatever, I myself don't enjoy talking about the past. We have wasted enough time.~ */ GOTO HierophantPower1-3
END

IF ~~ THEN BEGIN HierophantPower1-3
  SAY @259 /* Very well, then. Time to get back to our activities. */
  IF ~~ THEN DO ~SetGlobal("!SHierophantPast","GLOBAL",1)~ EXIT
END

IF ~~ THEN BEGIN HierophantPower1-2
  SAY @264  /* Now you are definitely exaggerating with your suspicion. I am here serving you in order to regain my freedom ...don't you agree, Bhaalspawn */
  IF ~~ THEN REPLY @265  /* I don't like the emphasis you put on the word "Bhaalspawn"...However, I admit that I have been a little bit too harsh on you. Let's forget about this, shall we? */ GOTO HierophantPower1-4
  IF ~~ THEN REPLY @266  /* You are a smart one, Hierophant. I want to trust you, for now, but I will keep an eye on you.  */ GOTO HierophantPower1-5
END

IF ~~ THEN BEGIN HierophantPower1-4
  SAY @267 /* No harm done. I agree we should focus on more important matters now. */
  IF ~~ THEN DO ~SetGlobal("!SHierophantPast","GLOBAL",1)~ EXIT
END

IF ~~ THEN BEGIN HierophantPower1-5
  SAY @268  /* You will find me here as usual. */
  IF ~~ THEN DO ~SetGlobal("!SHierophantPast","GLOBAL",1)~ EXIT
END

IF ~~ THEN BEGIN HierophantPower2-1
  SAY @260  /* Mmm there's nothing special about me, I can assure you. I am as surprised as you for being summoned at the service of a demi-god. */
  IF ~~ THEN REPLY @256  /* You have to admit you are quite a mysterious figure. Shrouded in your hooded robe, not very willing to speak about your past and your origins...~ */ GOTO HierophantPower1-2
  IF ~~ THEN REPLY @257  /* Do you really expect me to believe you are just a simple commoner? You are obviously hiding something from me.~ */ GOTO HierophantPower1-2
  IF ~~ THEN REPLY @258  /* Whatever, I myself don't enjoy talking about the past. We have wasted enough time.~ */ GOTO HierophantPower1-3
END


IF ~~ THEN BEGIN HierophantPower2
  SAY @269  /* Some may say my powers are dreadful, but you look very comfortable dealing with vengeful spirits.~ */
  IF ~~ THEN REPLY @270  /* Since I left Candlekeep my life has always been full of perils. I'm no longer the scared, helpless orphan. tell me something of you */ GOTO HierophantPower2-1
  IF ~~ THEN REPLY @271  /* I have to improve my abilities if I have to fight against a demi-goddess, don't you think so?~ */ GOTO HierophantPower2-2
  IF ~~ THEN REPLY @272  /* It is how I have always lived my life, I don't see why I should change now. I'm fine, we can continue.~ */ GOTO HierophantPower2-3
END

IF ~~ THEN BEGIN HierophantPower2-3
  SAY @273  /* You can follow the path that suits you best, <CHARNAME>. You brought me here to serve you, not to judge you. */
  IF ~~ THEN DO ~SetGlobal("!SHierophantPast","GLOBAL",1)~ EXIT
END

IF ~~ THEN BEGIN HierophantPower2-2
  SAY @261 /* The challenge in your future surely lives up to your lineage, son of Bhaal.~ */
  IF ~~ THEN REPLY @262  /* I hope so! I would hate being disappointed by my enemy. Now, don't you think you should tell me something of you, Hierophant?~ */ GOTO HierophantPower2-1
  IF ~~ THEN REPLY @263  /* Indeed, and I don't want to  be caught off guard.~ */ GOTO HierophantPower1-3
END

IF ~~ THEN BEGIN HierophantPower3
  SAY @274  /* Charging enemies head down is absolutely a good tactic if you want to slay them, not quite so if you want to understand them. */
  IF ~~ THEN REPLY @275  /* There's nothing to understand, it's just the natural order of things: the strong wins over the weak. */ GOTO HierophantPower3-2
  IF ~~ THEN REPLY @276  /* Enemies are not meant to be understood, just killed. */ GOTO HierophantPower3-2
  IF ~~ THEN REPLY @277  /* You are strange, Hierophant, why do you care for the inferiors? Who are you, really? */ GOTO HierophantPower3-3
END

IF ~~ THEN BEGIN HierophantPower3-2
  SAY @278  /* I see. Your powers must be truly unimaginable, <CHARNAME>, for being so self confident. */
  IF ~~ THEN REPLY @279  /* They are, and you should better not question them again in the future. Enough with this conversation. */ DO ~SetGlobal("!SHierophantPast","GLOBAL",1)~ EXIT
END

IF ~~ THEN BEGIN HierophantPower3-3
  SAY @280  /* Care for the inferiors? You misunderstood me, I just think there's much to be learned from your enemies. */
  IF ~CheckStatLT(Player1,18,INT)~ THEN REPLY @281  /* Candles? Colors? I didn't understand a word of what you just said. You are strange, Hierophant. */ GOTO HierophantPower3-4
  IF ~CheckStatGT(Player1,17,INT)~ THEN REPLY @282  /* You must be referring to the aura of living being. */ GOTO HierophantPower3-5
END

IF ~~ THEN BEGIN HierophantPower3-4
  SAY @283  /* You are not ready for such things. Time to get back to our activities. */
  IF ~~ THEN DO ~SetGlobal("!SHierophantPast","GLOBAL",1)~ EXIT
END

IF ~~ THEN BEGIN HierophantPower3-5
  SAY @284=@285 /* Exactly. I see you are familiar with this notion but you lack wisdom / If you allow me, I will teach you how to take advantage of the spirits of your enemies. */
  IF ~~ THEN REPLY @286  /* I am intrigued by your offer, what are we waiting for? */ GOTO HierophantPower3-6
  IF ~~ THEN REPLY @287  /* This sounds like some kind of evil spell and I will not give in to your dark powers. */ GOTO HierophantPower3-7
END


IF ~~ THEN BEGIN HierophantPower3-6
  SAY @209  /* very well */
  IF ~~ THEN DO ~SetGlobal("!SierofSkill","GLOBAL",1)~ EXIT
END


IF ~~ THEN BEGIN HierophantPower3-7
  SAY @289 /* Mistrustful as usual, I see...Very well, <CHARNAME>, I was just trying to improve your knowledge. */
  IF ~~ THEN DO ~SetGlobal("!SHierophantPast","GLOBAL",1)~ EXIT
END



IF ~Global("!SierofSkill","GLOBAL",2)~ THEN BEGIN HierophantPower3-8
  SAY @288  /* It is done, don't forget to try this ability in the battles to come. */
  IF ~~ THEN DO ~CreateVisualEffectObject("spcontin",Player1) SetGlobal("!SierofSkill","GLOBAL",3) ActionOverride(Player1,AddSpecialAbility("!souldr1"))~ EXIT
END









IF ~Global("!SCongratz","GLOBAL",9) Global("!SIerofanteOffeso","GLOBAL",0) Global("!SlyKrySummoned","GLOBAL",0) OR(2) Global("!SierofSkill","GLOBAL",3) Global("!SHierophantPast","GLOBAL",1)~
THEN BEGIN SummonSlytheKrystin
  SAY @38 /* You are back, <CHARNAME>. Are you ready to face the next spirits? */
  IF ~~ THEN REPLY @36 /* yes */  GOTO SummonSlytheKrystin2
  IF ~~ THEN REPLY @37 /* no  */  EXIT
END

IF ~~ THEN BEGIN SummonSlytheKrystin2
  SAY @290=@291=@292=@293 /* blablabla */
  IF ~~ THEN REPLY @294 /* get to the point */ GOTO SummonSlytheKrystin3
END

IF ~~ THEN BEGIN SummonSlytheKrystin3
  SAY @295 /* Your mission was to kill them and acquire the invites to the ducal palace, but it was a task most easily said than done... */
  IF ~~ THEN DO ~SetGlobal("!SlyKrySummoned","GLOBAL",1)~ EXIT
END



/*-------------// Ricompensa Slythe & summon Tamoko \\--------- */


IF ~Global("!SCongratz","GLOBAL",9) Global("!SlyKrySummoned","GLOBAL",3) Global("!SIerofanteOffeso","GLOBAL",0)~ THEN BEGIN RewardSlyKry
  SAY @311  /* That was impressive! A dangerous battle indeed, but you triumphed, as always... */
   IF ~~ THEN REPLY @312 /* I barely managed to survive this time, actually...These spirits are getting tougher*/ DO ~SetGlobal("!SCongratz","GLOBAL",10) AddXPObject(Player1,65000)~ GOTO RewardSlyKry2
   IF ~~ THEN REPLY @315 /* Those dogs were no match for me, I'm not even panting. */ DO ~SetGlobal("!SCongratz","GLOBAL",10) AddXPObject(Player1,65000)~ GOTO RewardSlyKry3
   IF ~~ THEN REPLY @317 /* Yeah, I made a lot of friends in my life uh..  */ DO ~SetGlobal("!SCongratz","GLOBAL",10) AddXPObject(Player1,65000)~ GOTO RewardSlyKry4
END


IF ~~ THEN BEGIN RewardSlyKry2
  SAY @313=@314  /* The hate for you empowers their strength -- continuiamo? */
  IF ~~ THEN REPLY @36 /* yes */  GOTO SummonTamoko2
  IF ~~ THEN REPLY @37 /* no  */  EXIT
END


IF ~~ THEN BEGIN RewardSlyKry3
  SAY @316=@314  /* Err...yes. Your modesty is an example for us all. -- continuiamo? */
  IF ~~ THEN REPLY @36 /* yes */  GOTO SummonTamoko2
  IF ~~ THEN REPLY @37 /* no  */  EXIT
END


IF ~~ THEN BEGIN RewardSlyKry4
  SAY @314  /*  continuiamo? */
  IF ~~ THEN REPLY @36 /* yes */  GOTO SummonTamoko2
  IF ~~ THEN REPLY @37 /* no  */  EXIT
END



IF ~Global("!SCongratz","GLOBAL",10) Global("!StamokSummoned","GLOBAL",0) Global("!SIerofanteOffeso","GLOBAL",0)~ THEN BEGIN SummonTamoko1
  SAY @38  /*  continuiamo? */
  IF ~~ THEN REPLY @36 /* yes */  GOTO SummonTamoko2
  IF ~~ THEN REPLY @37 /* no  */  EXIT
END




IF ~~ THEN BEGIN SummonTamoko2-2
  SAY @332 /* Mmm sure, where was I...Ah yes! */
  IF ~~ THEN GOTO SummonTamoko3
END

IF ~~ THEN BEGIN SummonTamoko3
  SAY @333=@334 /* During his speech you showed proof of his schemes to the dukes. - an acquaintance of yours unexpectedly showed up with a request*/
  IF ~~ THEN DO ~SetGlobal("!StamokSummoned","GLOBAL",1)~ EXIT
END



IF ~~ THEN BEGIN SummonTamoko2
  SAY @318  /* Against all odds you survived the attack of the assassins in the undercellar and obtained the invaluable invitations from their cold hands just in time for the ceremony held at the Ducal Palace.*/
  IF ~~ THEN GOTO SummonTamoko3
  IF ~InParty("Sarevok") IsValidForPartyDialogue("Sarevok")~ THEN EXTERN ~SAREV25J~ Tamoko01
END


//---------------Ricompensa Tamoko e finale------------------//


IF ~Global("!SCongratz","GLOBAL",10) Global("!StamokSummoned","GLOBAL",3) Global("!SIerofanteOffeso","GLOBAL",0)~ THEN BEGIN TamokoReward
  SAY @410 /* A spirit moved by love instead of revenge...That was an unexpected meeting, was it?*/
  IF ~Global("!stamokRedeemed","GLOBAL",1)~ THEN DO ~AddXPObject(Player1,100000) AddXPObject("Sarevok",100000) SetGlobal("!SCongratz","GLOBAL",11)~ GOTO TamokoRewardGOOD
  IF ~Global("!stamokNeutralRed","GLOBAL",1)~ THEN DO ~AddXPObject(Player1,65000) SetGlobal("!SCongratz","GLOBAL",11)~ GOTO TamokoRewardNEU
  IF ~Global("!stamokNotRed","GLOBAL",1)~ THEN DO ~AddXPObject(Player1,50000) SetGlobal("!SCongratz","GLOBAL",11)~ GOTO TamokoRewardBAD
END




IF ~~ THEN BEGIN TamokoRewardGOOD
 SAY @416 /* You even managed to quell her restless spirit */
  IF ~~ THEN GOTO Riposo
END

IF ~~ THEN BEGIN TamokoRewardNEU
  SAY @417 /* Unfortunately she didn't find what she came for...*/
  IF ~~ THEN GOTO Riposo
END

IF ~~ THEN BEGIN TamokoRewardBAD
 SAY @411 /* and of course you slew it with your innate empathy and delicacy...*/
  IF ~~ THEN  GOTO Riposo
END


IF ~~ THEN BEGIN Riposo
  SAY @413=@414=@415=@418=@419 /*I also need to inform you that I don't sense the presence of any other spirit...for now.*/
  IF ~~ THEN DO ~SetGlobal("!SFarewell","GLOBAL",1) DialogInterrupt(FALSE)~ EXIT
END



/*--------------------Append dialogo Sarevok */


APPEND ~SAREV25J~
IF ~~ Tamoko01
    SAY @319 /* I remember that day very clearly. The fools almost entrusted me with the title of Grand Duke of Baldur's Gate */
    IF ~Alignment("Sarevok",CHAOTIC_GOOD)~ THEN REPLY @320 /*I feel a nostalgic trace in that statement, Sarevok. I thought you changed your view about life and your actions*/ GOTO Tamoko02
    IF ~OR(3) Alignment(PROTAGONIST,MASK_GOOD) Alignment(PROTAGONIST,NEUTRAL) Alignment(PROTAGONIST,CHAOTIC_NEUTRAL)~ THEN REPLY @322 /* That was close enough. I have to admit it was a cunning plan */ GOTO Tamoko03
    IF ~Alignment(PROTAGONIST,MASK_EVIL)~ THEN REPLY @326 /*I am the chosen one, Sarevok, what did you expect? You always underestimated me*/ GOTO Tamoko04
    IF ~Alignment(PROTAGONIST,MASK_EVIL)~ THEN REPLY @329 /*I could not let you keep all the fun for yourself, don't you think, brother?*/ GOTO Tamoko05
  END
END

APPEND ~SAREV25J~
IF ~~ Tamoko02
    SAY @321 /*I did, <PRO_BROTHERSISTER>, it is merely an observation of how things could have been*/
    IF ~~ THEN REPLY @322 /*That was close enough. I have to admit it was a cunning plan*/ GOTO Tamoko03
  END
END


APPEND ~SAREV25J~
IF ~~ Tamoko03
    SAY @323 /*Have you ever asked yourself how things would be now if I had succeeded?*/
    IF ~~ THEN REPLY @324 /* It's hard enough to get some good sleep already, I don't need more nightmares, don't you think?*/ GOTO Tamoko03-2
  END
END

APPEND ~SAREV25J~
IF ~~ Tamoko03-2
    SAY @325 /* Maybe everything was just destined to be this way. */
    IF ~~ THEN EXTERN ~!sierof2~ SummonTamoko2-2
  END
END


APPEND ~SAREV25J~
IF ~~ Tamoko04
    SAY @327 /*I overlooked that the essence of our father runs stronger in your blood than ever did in mine...A mistake I paid dearly.*/
    IF ~~ THEN REPLY @328 /* Good, now that you admitted my superiority, we can proceed with the Hierophant's speech. */ EXTERN ~!sierof2~ SummonTamoko2-2
  END
END

APPEND ~SAREV25J~
IF ~~ Tamoko05
    SAY @330 /* You don't need to remind me my defeat, it still burns inside.*/
    IF ~~ THEN REPLY @331 /* Who knows...You might still be a valuable asset in the things to come. Go on, Hierophant.*/ EXTERN ~!sierof2~ SummonTamoko2-2
  END
END




