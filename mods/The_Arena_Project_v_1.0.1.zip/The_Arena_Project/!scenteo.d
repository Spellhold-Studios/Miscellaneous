BEGIN ~!Scenteo~

IF ~Global("!sCenteolRedeemed","GLOBAL",1)~ THEN BEGIN Centeol01
  SAY @216=@217 /* It is...It is over. The curse has finally been lifted! and reward */
  IF ~~ THEN DO ~SetGlobal("!sCenteolRedeemed","GLOBAL",2) StartCutSceneMode() CreateVisualEffectObject("sphlybls",Myself) wait(4) CreateVisualEffectObject("spsnrayi",Myself)  wait(1)  Deactivate(Myself) wait(3) FadeToColor([30.0],0)  wait(3) FadeFromColor([30.0],0)  EndCutSceneMode()  GiveItemCreate("!scentrw",Player1,1,1,0) DestroySelf()~ EXIT
END





IF ~NumTimesTalkedTo(0)~ THEN BEGIN Centeol01
  SAY @169 /* Who brought my spirit back from the depthsss of nothingnessss? Was the curse on my body not enough to torment my exissssstence? */
  IF ~~ THEN REPLY  @170  /* I remember you, creature. I met you in the Cloakwood Forest, in your infested lair. */ GOTO Centeol01-1
  IF ~~ THEN REPLY  @171  /* I don't know who, or what, you are, but my eyes bleeds at your presence.*/  GOTO Centeol01-2
  IF ~~ THEN REPLY  @172  /* Disgusting creature, I put an end to your miserable life in the past and yet your spirit still dwells in this plane. Is it a second death you are looking for? */  GOTO Centeol01-3
END


IF ~~ THEN BEGIN Centeol01-3
  SAY @197  /* You know nothing of Centeol! And you will not listen! Come, my broodlings, the feast awaitsss! */
  IF ~~ THEN DO ~Enemy()~ EXIT
END



IF ~~ THEN BEGIN Centeol01-2
  SAY @176  /* Centeol is my name...Jon Irenicusss cursed me and condemned me to live in this horrifying body. */
  IF ~~ THEN REPLY  @178  /* You mean THAT Jon Irenicus? Why would he do such thing? And why did you know him? */ GOTO Centeol02-2
  IF ~~ THEN REPLY  @179  /* Mph, I really hated that bastard, but for once I approve of his decision. */  GOTO Centeol01-3
END



IF ~~ THEN BEGIN Centeol01-1
  SAY @173  /* And I remember you, killer of my progeny and my hope asssswell. You had no pity of Centeol the cursed. */
  IF ~~ THEN REPLY  @174  /* You speak of a curse, spirit. Who cursed you and why? */ GOTO Centeol02-1
  IF ~~ THEN REPLY  @175  /* Whatever it happened to you, I'm sure you deserved it, monster! */  GOTO Centeol01-3
END



IF ~~ THEN BEGIN Centeol02-1
  SAY @177 /* Irenicussss...Jon Irenicusss cursed me and condemned me to live in this horrifying body. */
  IF ~~ THEN REPLY  @178  /* You mean THAT Jon Irenicus? Why would he do such thing? And why did you know him? */ GOTO Centeol02-2
  IF ~~ THEN REPLY  @179  /* Mph, I really hated that bastard, but for once I approve of his decision. */  GOTO Centeol01-3
END


IF ~~ THEN BEGIN Centeol02-2
  SAY @180=@181=@182=@183  /* Centeol hasss not always been like thisss...I once was an elf priestess, and Jon Irenicus was my love, but he never reciprocated that feeling. */
  IF ~Alignment(Player1,MASK_GOOD)~ THEN REPLY  @184   /* A very sad story indeed...Is there no way to lift this curse of yours? */ GOTO Centeol02-3
  IF ~Alignment(Player1,CHAOTIC_NEUTRAL)~ THEN REPLY  @199 /* An interesting story. I want to help you, you are just too ugly to be left in this state. */ GOTO Centeol02-3
  IF ~Alignment(Player1,NEUTRAL)~ THEN REPLY  @213  /* I have sympathy for you, creature, if only because Irenicus is a common enemy. Can I help you lift this curse? */ GOTO Centeol02-3
  IF ~~ THEN REPLY  @185   /* You hideous harlot. You deserve this curse, there's no redemption for people like you. */  GOTO Centeol02-6
  IF ~~ THEN REPLY  @186   /* You have to admit your actions were very questionable... */ GOTO Centeol02-6
END



IF ~~ THEN BEGIN Centeol02-3
  SAY @187  /* Why would you do that, <PRO_RACE>? Why are you trying to sssave Centeol?~ */
  IF ~CheckStatGT(Player1,17,REPUTATION)~ THEN REPLY  @188 /* Your actions were clearly evil, but nobody deserves to end like this. Tell me what has to be done and I will do my best to help you. */ GOTO Centeol02-4
  IF ~CheckStatLT(Player1,18,REPUTATION)~ THEN REPLY  @188 /* Your actions were clearly evil, but nobody deserves to end like this. Tell me what has to be done and I will do my best to help you. */ GOTO Centeol02-8
  IF ~~ THEN REPLY  @189 /* On a second thought, maybe I will just end your life here and now. */  GOTO Centeol02-7
END



IF ~~ THEN BEGIN Centeol02-4
  SAY @191  /* Would you really help Centeol? This curssse of mine is strong, <PRO_RACE>. It requires a sacrifice, to be dissolved. */
  IF ~~ THEN REPLY  @192 /* And what might that be? Speak. */ GOTO Centeol02-5
  IF ~~ THEN REPLY  @195 /* Mmm it doesn't sound like a good idea...Sorry but I changed my mind. */ GOTO Centeol02-7
END



IF ~~ THEN BEGIN Centeol02-5
  SAY @193   /* A sssmall fraction of your life force can lift the curssse.  */
  IF ~~ THEN REPLY  @194 /* So be it. I will set you free from this horrible curse. */ GOTO Centeol02-9
  IF ~~ THEN REPLY  @195 /* Mmm it doesn't sound like a good idea...Sorry but I changed my mind. */ GOTO Centeol02-7
END


IF ~~ THEN BEGIN Centeol02-6
  SAY @196  /* You can't understand Centeol! And now you will sssufer! Come, my broodlings, the feast awaitsss! */
  IF ~~ THEN DO ~Enemy()~ EXIT
END


IF ~~ THEN BEGIN Centeol02-7
  SAY @198  /* You will not help Centeol?? You will sssufer! Come, my broodlings, the feast awaitsss! */
  IF ~~ THEN DO ~Enemy()~ EXIT
END


IF ~~ THEN BEGIN Centeol02-8
  SAY @190  /* I don't believe you! Nobody can sssave Centeol! I will have my sssweet revenge. Come, my broodlings, the feast awaitsss! */
  IF ~~ THEN DO ~Enemy()~ EXIT
END



IF ~~ THEN BEGIN Centeol02-9
  SAY @214  /*  Aaah the <PRO_RACE> will really help Centeol. Close your eyessss and surrender your will now, or the spell will not work. */
  IF ~~ THEN DO ~ClearAllActions() StartCutSceneMode() ForceSpellRES("!scenteo",Player1) SmallWait(5) CreateVisualEffectObject("SPFLESHS",Player1) ActionOverride(Player1,DisplayStringHead(Myself,@215)) Wait(3) CreateVisualEffectObject("SPWHIRL",Myself) Wait(1)  Polymorph(CLERIC_FEMALE_ELF)  SetGlobal("!sCenteolRedeemed","GLOBAL",1) Wait(3) EndCutSceneMode() StartDialogNoSet(Protagonist)~ EXIT
END


