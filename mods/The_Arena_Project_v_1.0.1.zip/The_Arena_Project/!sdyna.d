BEGIN ~!Sdyna~



IF ~Global("!SMinscPotential","GLOBAL",1)~ THEN BEGIN MinscBlessed
  SAY @166  /* It is done. Go back at your journey, my dear Minsc. Now my spirit will be free, at long last. Fare thee well! */
  IF ~~ THEN DO ~SetGlobal("!SMinscPotential","GLOBAL",2) StartCutSceneMode() CreateVisualEffectObject("sphlybls","!sdyna") wait(4) CreateVisualEffectObject("spsnrayi","!sdyna")  wait(1)  Deactivate(Myself) wait(3) FadeToColor([30.0],0)  wait(3) FadeFromColor([30.0],0)  EndCutSceneMode() AddXPObject("Minsc",30000) DestroySelf()~ EXIT
END




CHAIN
IF ~NumTimesTalkedTo(0)~ 
THEN ~!sdyna~ Dynaheir01
  @151 /* What kind of malevolent sorcery is this? */
  = @152  /* I can't believe my eyes, it is you, Minsc! */
 == MINSC25J @153  /* This is a great day for rangers and hamsters! Our beloved Dynaheir is back for us! */
 == ~!sdyna~ @154  /* Oh, you still find solace in carrying that rodent with you...*/
 == MINSC25J @155  /* Minsc and Boo cannot be divided! We already lost a very good friend, and it was all our fault.*/
 == ~!sdyna~ @156  /* Oh Minsc, my dear, I'm more than sure that the gods made you so big just to be sure that you would have enough space for your heart.*/
 == MINSC25J @157  /* Boo is a little confused because Dynaheir always speaks strangely.*/
 == ~!sdyna~ @158  /* I know why you summoned my spirit here, Minsc. Thy feel guilty for my demise.*/
 == MINSC25J @159  /* I failed, Dynaheir! I failed my rite of passage and your trust! Shame on me, I will never come back home in Rashemen.*/
 == ~!sdyna~ @160  /* Blockhead, don't blame thyself. That Irenicus was not an enemy we could fight, in that moment. My magic failed just as much as your sword.*/
 == MINSC25J @161  /* You are not angry with me?*/
 == ~!sdyna~ @162  /* Not in the slightest degree. Look at yourself, Minsc. You have become a gargantuan bearer of justice. Wherever you go, evil trembles.*/
 =  @163           /* Your sense of guilt is much unnecessary. I forgive thee, and as your witch, I declare your duty completed.*/
 == MINSC25J @164  /* Look at Boo now, he is so moved by your words...I think he will cry soon...*/
 == ~!sdyna~ @165  /* I will do something for you, I will set your spirit free from the guilt, thus unleashing your full potential. Don't move now.*/ DO ~SetGlobal("!SMinscPotential","GLOBAL",1) StartCutSceneMode() ForceSpellRES("!sdyna","Minsc") smallwait(5) CreateVisualEffectObject("spcmwoui","Minsc") ActionOverride("Minsc",DisplayStringHead(Myself,@167))  wait(4)  EndCutSceneMode() StartDialogNoSet(Protagonist)~
EXIT



