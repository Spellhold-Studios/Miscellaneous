===================================================
===============Sarevok-related tweaks==============
===================================================
================A mod by Crevs Daak================
========================v1.3=======================

This mod offers two different components
with two subcomponents each (resulting
in four components total) that give the
player different options to change Sarevok's
weapon and turn him more powerful by
restoring him to his non-TotSC BG1 version.

This mod is only compatible with BG:EE,
BGT, EET, TuTu and BG1 (through some
components will only install if you have
TotSC).

Thanks to elminster at the BG:EE forums,
for giving me this idea, to Sergio at the
same place, for reminding me I hadn't done
this before, to the IESDP for having a full
entry of the CRE file format, and to all of
the WeiDU creators and maintainers.

Thanks to Erg for bugging me to add TuTu
compatibility and finding a (rather important)
typo.
