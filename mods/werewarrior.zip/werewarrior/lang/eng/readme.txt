WEREWARRIOR

A mod for Baldur's Gate II

Version 0.31 (090929)
Contact: jonalun@gmail.com

--------------------------------------------------------------------------------

Table of contents
i.	Introduction
ii.	Installation
iii.	Kit description
iv.	License

--------------------------------------------------------------------------------

i.	Introduction

A fighter kit based on an idea by Stardusk on the SHS boards. It is open to all races and alignment and requires 9 STR. Nothing fancy here.

--------------------------------------------------------------------------------

ii.	Installation

Unpack WEREWARRIOR.ZIP to the folder where you have Baldur's Gate II installed. Unless you specified a different location on install, this is normally: 
C:\Program Files\Black Isle\BGII - SoA\

Run SETUP-WEREWARRIOR.EXE and follow the on-screen instructions. You will be asked to choose a "claw proficiency type". The options are as follows:
	1: Claws are considered fist weapons (default)
		In werewolf form, your claws will be considered fists, and will not use a weapon proficiency. You will suffer no penalties, but you will also not be able to specialize. This option is most similar to how other shape-changing classes are handled in the game.
	2: Claws are considered daggers
		In werewolf form, your claws will use the dagger proficiency. You will need to assign points to daggers, or you will suffer a penalty in combat. This also allows you to specialize and reach the highest level of mastery in daggers.

(Note that your werewolf form will also benefit from any points put into the "one-handed weapon" style, regardless of your choice.)

You can uninstall the mod by running SETUP-WEREWARRIOR.EXE a second time.

--------------------------------------------------------------------------------

iii.	Kit description

WEREWARRIOR: A fighter who has devoted all his efforts to learning and controlling the inner beast which dwells in everyone; he can become a werewolf that gains in strength and power over time.


Advantages:
- Can shapechange into werewolf form which becomes progressively stronger with time. 
    Level  1: +1 to STR/DEX/CON, +2 to AC, claws deal 1d6+1 damage and strike as +1 weapons
    Level  7: +2 to STR/DEX/CON, +3 to AC, claws deal 1d8+2 damage and strike as +2 weapons
    Level 13: +3 to STR/DEX/CON, +4 to AC, immunity to non-magical weapons, regenerate 1 HP/round, +20% magic resistance, claws deal 1d10+3 damage and strike as +3 weapons
    Level 19: +4 to STR/DEX/CON, +5 to AC, immunity to non-magical and +1 weapons, regenerate 3 HP/round, +40% magic resistance, claws deal 1d12+4 damage and strike as +4 weapons
    Level 25: +5 to STR/DEX/CON, +6 to AC, immunity to non-magical and +2 weapons, regenerate 6 HP/round, +60% magic resistance, claws deal 1d20+5 damage and strike as +5 weapons


Disadvantages:
- May not wear armour, gauntlets or bracers
- May not use missile weapons
- May not multi- or dualclass
- May only become proficient (one star) in the use of any weapon

(If you select the "Claws are considered daggers" option, these changes will be noted in the kit description.)

--------------------------------------------------------------------------------

iv.	License

Public domain: no rights reserved. This mod may be freely copied, edited and distributed. 
