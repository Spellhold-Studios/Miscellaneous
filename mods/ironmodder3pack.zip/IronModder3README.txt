                          IRON MODDER 3 DL PACK
                          "A KISS BEFORE DYING"
                    http://www.pocketplane.net/ironmod



Iron Modder 3 was held May 16, 2004 on the theme "A Kiss Before Dying."
Competing Iron Modders had just four hours from the announcement of the theme to
create a new mod that they felt best captured the essence of "A Kiss Before
Dying."


These modders submitted entries before the deadline:

Bons
Cuv
Icelus
Idobek
Ghreyfain
Kismet
Pirengle
Riklaunim

And are joined in this pack by these modders who completed projects after the
four-hour time elapsed:

Neriana

Bons and Icelus were the winners, unseating two-time Iron Pirate Ghreyfain.


Special notes for experimenting players:

Cuv: If you don't see Dirk in the Cuv mod, use a game where you haven't visited
the Coronet yet.

Ghrey: Notes for the Ghrey mod:
'In the readme, I tell you to set "npcnameromance" to 2. This should be
"npcnameromanceactive" to 2.'
Also: "They need to do CLUAConsole:SetGlobal("J#CurseDead","GLOBAL",2) after
talking to the confused underdark person."

Ice: Ice's entry may require either that you enter the tomb directly (it's the
one in the SE corner of the map) and/or not have cleared that area in your
saved game yet.

Idobek: Party AI must be ON for the test script to work properly.
