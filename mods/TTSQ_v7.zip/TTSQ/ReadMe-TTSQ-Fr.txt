
THE TORTURED SOUL QUEST (La qu�te de l'�me tortur�e)


Ajoute une petite qu�te � Shadows of Amn, � la fin de laquelle vous obtenez un objet in�dit int�ressant.
Pour d�marrer cette qu�te, parlez � un �tranger dans l'une des cryptes du cimeti�re d'Athkatla. 


Versions

v1 - Publication initiale
v2 - Conversion au format WeiDU par Badgert 
     Ajout de la traduction russe par www.aerie.ru
v3 - Ajout de la traduction allemande par Leonardo Watson (merci!!!)
     Correction du fichier METBAE2.d
v4 - Dor�navant, le mod modifie les fichiers et ne les remplace plus (merci White Agnus!!!)
     Ajout d'une petite description du mod dans le fichier ReadMe-TTSQ.txt
     Correction du nom de l'auteur de la traduction en allemand
     Ajout de la signalisation de VERSION
     Mise � jour concernant le passage � WeiDU v210
v5 - Ajout de la traduction espagnole par Clan REO (merci!!!)
   - Ajout de l'am�lioration de la traduction allemande
v6 - Ajout de la traduction francais par Fouinto (of the d'Oghmatiques)
   - Ajout de README-command
   - Mise � jour concernant le passage � WeiDU v211
v7 - Ajout de la traduction italiano par Ilot (merci!!!)
