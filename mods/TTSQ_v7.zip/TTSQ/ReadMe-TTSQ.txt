
THE TORTURED SOUL QUEST


Adds a small quest to Shadows of Amn, at the end of which you gain a new, interesting item.
To start the quest talk with a stranger in one of the crypts in Athkatla's graveyard. 


HISTORY

v1 - The Initial Release
v2 - WeiDU-conversion by Badgert 
     Added Russian translation by www.aerie.ru
v3 - Added German translation by Leonardo Watson (thank you!!!)
     Fixed the file METBAE2.d
v4 - Now, the mod patches the files and not overwrites them (thanks White Agnus!!!)
     Added a small description of the mod in the ReadMe-TTSQ.txt
     Corrected the wrong named German translator
     Added VERSION flag
     Updated to WeiDU v210
v5 - Added Spanish translation by Clan REO (thank you!!!)
   - Added revised German translation
v6 - Added French translation by Fouinto (of the d'Oghmatiques) (thank you!!!)
   - Changed to README-command
   - Updated to WeiDU v211
v7 - Added Italian translation by Ilot (thank you!!!)
