	       Ultimate Shapeshifting and Rebalancing Fix
		   a Weidu mod for Baldur's Gate II
		        Version Beta 0.1 by No1


1. Introduction

This is beta version of mod that finally makes shapeshifting the way it's meant to be.
For now you can see how it would be working if i'll bring this mod to final version.
It's my first mod actually and i've installed dltcep few days ago, so be tolerant.

2. Instalation

Since it's beta a weidu installer will only copy essential files into your override folder. If you want to see how does it work you you have to open your druid in shadowkeeper and add him innate ability "wform1" for werewolf, and "wform2" for greater werewolf.

3. Compability
None :)
Install this for your own resposibility :)

4. Statistics of the forms are insane in this moment, it will be fixed in next version because i'm still waiting for original AD&D werewolves statistics. Just placing this to show you how this thing works, so you could give me some feedback.

If there are some language problems report it to me at forums.

Thanks for reading - I know that "no one" reads that crap :)