@echo off
del override\hf2001.tis
ECHO
ECHO hlid's Tilesets Uninstalled
ECHO
