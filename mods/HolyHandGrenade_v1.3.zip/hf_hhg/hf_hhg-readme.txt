The Quest for the Holy Hand Grenade


I admit it, this mod is monumentally silly. It is something that SOMEONE should've done a long time ago however,
heheheh.

If you're outside the underdark and still have the Light Gem, then you'll receive the Holy Hand Grenade of Antioch.
Otherwise you can just console in MISC9R. Once you have the item, go kill a bunnyrabbit with it.
The grenade will ONLY kill rabbits due to some bizarre cross-dimensional gesalt.
 
If none of this makes sense or is funny to you, go rent some damn Monty Python ya' freak! ;)


VERSION-HISTORY

Version 1
- Initial release

Version 1.1
- Changed the sungem changing from chapter 5 to 6, to avoid that this will happen in the Underdark
  and you haven't anymore the needed sungem for Avalon
- Traified the mod
- Changed to README command
- Updated to WeiDU v211

Version 1.2 (11 January 2010)
- Added Russian translation by Fess updated by Prowler
- Updated to WeiDU v213

Version 1.3 (01 April 2010 by Leomar)
- Lollorian's Grenade and Adalon fix - sBALDUR.BAF
  (http://www.shsforums.net/topic/44560-gem-for-adalon/page__view__findpost__p__481971)
- Added Spanish translation by Lisandro
- Moved setup-hf_hhg.tp2 into the mod-folder
- Updated to WeiDU v215
