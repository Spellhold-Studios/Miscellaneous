@echo off
cd Override
tisunpack -f hf2001.tiz
del hf2001.tiz
del tisunpack.exe
cd ..
