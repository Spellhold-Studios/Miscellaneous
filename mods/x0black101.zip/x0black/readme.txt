>>>Blackguard fighter kit for BG2 (BGT, BGTutu), by x0abar<<<


This mod allows you to choose a new kit for your character when starting a new game. Its intention is to let you create a character that is as close to the idea of "evil paladin" as is possible within limits of the BG2 engine.
When making this mod, my priorities were as follows: to keep it simple, relatively bug free, avoid making it overpowered, make the kit useful from 1st level to 40th, and avoid placing too many restrictions that would limit your gameplay choices. You decide if I managed to do any or all that. I hope you'll enjoy it!



>>>Installation<<<


Requires Baldur's Gate 2 and its Throne of Bhaal expansion.

Extract the archive to your Baldur's Gate 2 (BGTutu, BGT) folder. Run "setup-x0black.exe" and follow the instructions. To uninstall, run the program again.



>>>Description<<<


BLACKGUARD: The Blackguard epitomizes evil and is nothing short of a mortal fiend. The quintessential black knight, this villain carries a reputation of the foulest sort that is very well deserved. Consorting with demons and devils and serving dark deities, the Blackguard is hated and feared by all. Some people call these villains "antipaladins" due to their completely evil nature.

  
Advantages:
- Immune to fear
- May cast Doom once per day per 3 levels, as first level priest spell of the same name (starting at 1st level with one use)
- May use Poison Weapon ability once per day per 5 levels (starting at 1st level with one use)
- May use Aura of Despair ability once per day at 2nd level and every 10 levels thereafter
- May use Life Drain ability once per day at 4th level and every 8 levels thereafter

Disadvantages:
- Must be evil
- May not specialize in weapons past normal specialization (two proficiency points)


POISON WEAPON: Each successful hit within the next 5 rounds will inject poison into the target, dealing an extra 1d3 points of poison damage. Furthermore, unless a Saving Throw vs. Poison is made, the poison will be injected into the bloodstream of the victim dealing one additional point of damage for every 2 levels of the Blackguard (up to a maximum of 10 points of damage over 10 seconds).

LIFE DRAIN: Deals one point of damage per level (up to a maximum of 20) every round, healing the Blackguard the same number of Hit Points. The spell lasts for 3 rounds, and the victim is allowed a Saving Throw vs. Death at the beginning of each round to break the enchantment and avoid any further damage.

AURA OF DESPAIR: Bestows nearby enemies with penalties to hit, damage and Armor Class for one turn (no save). At higher levels, the enemies must also make a successful Saving Throw vs. Spell to avoid being slowed or paralyzed for 5 rounds.
  2nd level: -1 penalty
  6th level: -2 penalty; slows enemies
  15th level: -4 penalty; paralyzes enemies



>>>Other info<<<


- has the same dual-class options and equipment restrictions as normal fighter
- can get Summon Fallen Deva as HLA

Also included in this mod are 9 sets of portraits that you can add to your portrait folder during the installation.

For added fun, turn your companions into Blackguards with Level1NPC (easy to use mod, found at www.gibberlings3.net) or create a multiclass Blackguard Player Character with NearInfinity (powerful game editor, but beginners to BG2 modding might need to ask for help how to use it, download from http://www.idi.ntnu.no/~joh/ni/)



>>>Thanks<<<


Gibberlings3
Pocket Plane Group
Sorcerer's Place
Spellhold Studios

Everyone from Infinity Engine modding communities

Authors of the mods I used as examples when trying to code this mod (including but not limited to: Divine Remix, Rogue Rebalancing, BG2 Fixpack)

Creators of the portraits I included (sadly I can't give proper credit, I don't remember where I found them)



>>>Version<<<


1.01  -  corrrected kitlist.2da (un)usability flag from "none" to "trueclass" (it was working OK before, but better safe than sorry...)

1  -  initial release


>>>Contact<<<


x0abarAttGeMailDotKom
 