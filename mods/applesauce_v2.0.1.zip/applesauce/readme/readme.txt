hello,

the applesauce mod is a tribute to my late pet rabbit.
it changes the name of the rabbit familiar to Applesauce and gives him a portrait.
there are no other gameplay adjustments. 

they say nothing disappears from the internet, so i hope this simulacrum of spending time with him doesn't either.

shout out to all people who showered Appy with love when he was around.