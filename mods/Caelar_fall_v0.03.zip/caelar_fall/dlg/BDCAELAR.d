REPLACE BDCAELAR


IF ~~ THEN BEGIN 63 // from: 62.0
  SAY ~So be it! The child of Bhaal and the Shining Lady will stand together against this devil's darkness!~ [BD59720] 
  IF ~~ THEN DO ~SetGlobal("bd_caelar_fate","global",2)
ActionOverride("bdhepher",DestroyItem("minhp1"))
ActionOverride("bdbelhif",DestroyItem("minhp1"))
DestroyItem("minhp1")
DestroyItem("monhp1")
~ EXTERN ~BDHEPHER~ 23
//  IF ~  NumInPartyLT(6)
//~ THEN DO ~SetGlobal("bd_caelar_fate","global",2)
//ActionOverride("bdhepher",DestroyItem("minhp1"))
//ActionOverride("bdbelhif",DestroyItem("minhp1"))
///DestroyItem("minhp1")
//DestroyItem("monhp1")
//JoinParty()
//	SetDialog("BDCAELAR")
//~ EXTERN ~BDHEPHER~ 23
END


IF ~~ THEN BEGIN 85 // from:
  SAY  ~The rift 'twixt the planes was opened by me—not by my hand, but I am responsible nonetheless.~ [BD39320]
  IF ~~ THEN REPLY ~Caelar, you don't deserve this. Come with us, we will find a way to protect you from execution.~ GOTO GoodbyePleased 
  IF ~Global("CaelarFall","GLOBAL",1)~ THEN REPLY ~This a ideal place for fallen paladin, Caelar. Wish you a millenium of pain.~ GOTO GoodbyeEvil
  IF ~Global("CaelarPledged","GLOBAL",1)~ THEN REPLY ~Caelar, you forgot something. You have pledged your loyality to me, remember?~ GOTO GoodbyePledge
  IF ~Global("CaelarFall","GLOBAL",0)~ THEN REPLY ~I must admit you are a brave woman, at least. Goodbye, Caelar.~ GOTO 87
END



IF ~~ THEN BEGIN 86 // from:
  SAY ~The portal can only be closed from this side. Someone must remain behind. I shall sever Avernus's connection to Toril, and then stand guard. Whosoever would cross the threshold to Dragonspear will first face Caelar Argent.~ [BD39321]
  IF ~~ THEN REPLY ~Caelar, you don't deserve this. Come with us, we will find a way to protect you from execution.~ DO ~SetGlobal("CaelarPleased","global",1)~ GOTO GoodbyePleased 
  IF ~Global("CaelarFall","GLOBAL",1)~ THEN REPLY ~This a ideal place for fallen paladin, Caelar. Wish you a millenium of pain.~ GOTO GoodbyeEvil
  IF ~Global("CaelarPledged","GLOBAL",1)~ THEN REPLY ~Caelar, you forgot something. You have pledged your loyality to me, remember?~ GOTO GoodbyePledge
  IF ~Global("CaelarFall","GLOBAL",0)~ THEN REPLY ~I must admit you are a brave woman, at least. Goodbye, Caelar.~ GOTO 87
END

END

EXTEND_TOP BDCAELAR 76 #1
   IF ~~ THEN REPLY ~Honestly, if I were in your place, I would do the same.~ GOTO 79
END

APPEND BDCAELAR


IF ~Dead("BDBELHIF")
Global("CaelarFall","GLOBAL",1)
Global("CaelarFallTalk","GLOBAL",0)~ THEN BEGIN BelhifetDead
   SAY ~I cannot believe it! You killed Belhifet! I was her blackguard for a few minutes.~
   =
   ~Please, don't kill me now, I must do for what I came here. I must free Aun and make sure he is saved.~
   IF ~~ THEN REPLY ~No, Argent. You will pay for all you have done to me, right now.~ GOTO BelhifetDead1
   IF ~~ THEN REPLY ~Okay, I will let you free Aun. But then you will come with us.~ GOTO BelhifetDead2
   IF ~~ THEN REPLY ~Okay, I will let you free Aun. But for that you will serve me as blackguard. I am a son of god, anyway.~ GOTO BelhifetDead3
END   

IF ~~ BelhifetDead1
  SAY ~I turned to evil under pressure of situation. But you are evil by your nature, I was blind to not see this.~
  IF ~~ THEN DO ~SetGlobal("CaelarFallTalk","GLOBAL",1)
  Enemy()~ EXIT
END


  IF ~~ BelhifetDead2
  SAY ~Thank you, <CHARNAME>.~
  IF ~~ THEN DO ~SetGlobal("bd_plot","global",570)
SetGlobal("CaelarPleased","global",1)
SetGlobal("CaelarFallTalk","GLOBAL",1)~ EXIT
END



  IF ~~ BelhifetDead3
  SAY ~I will serve you, <CHARNAME>, that is my pledge.~
  IF ~~ THEN DO ~SetGlobal("bd_plot","global",570)
SetGlobal("CaelarPledged","global",1)
SetGlobal("CaelarFallTalk","GLOBAL",1)~ EXIT
END

  IF ~~ GoodbyeEvil
  SAY ~I will wait you there, <CHARNAME>, you will surely get here after death.~
  IF ~~ THEN EXTERN ~BDAUN~ 48
END

  IF ~~ GoodbyePledge
  SAY ~Yes, and this is one of reasons why I am doing it.~
  =
  ~If you really need me at your side, find a way to get me out of here, <CHARNAME>.~
  =
  ~But now goodbye. I will fight and wait for you here.~
  IF ~~ THEN EXTERN ~BDAUN~ 48
END

  IF ~~ GoodbyePleased
  SAY ~I am pleased you care for me. But I must do this, and for you also.~
  =
  ~If you really need me at your side, find a way to get me out of here, <CHARNAME>.~
  =
  ~But now goodbye. I will fight and wait for you here.~
  IF ~~ THEN EXTERN ~BDAUN~ 48
END

END