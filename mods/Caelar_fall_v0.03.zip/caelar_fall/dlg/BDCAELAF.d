BEGIN ~BDCAELAF~

IF ~See(Player1)~ THEN BEGIN WelcomeToHell
  SAY ~I was in one Hell and I am dragged into another.~
  =
  ~At least I don't see hordes of demons trying to kill me.~
  =
  ~I am so exchausted...~
  =
  ~I see now, it's you, <CHARNAME>.~
  =
  ~You finally managed to move me from Avernus. But where am I?~
  IF ~~ THEN REPLY ~This is a part of Abyss.~ GOTO WelcomeToHell2
  IF ~~ THEN REPLY ~I went on vacation to hot springs. Want to take a bath together?~ GOTO WelcomeToHell3  
END
  
IF ~~  BEGIN WelcomeToHell2
  SAY ~I see.~  
  IF ~Global("CaelarPleased","GLOBAL",1)~ THEN REPLY ~I was interrupted in Avernus. I will slaughter you right now. Prepare to die, Caelar!~ GOTO  FightPleased 
  IF ~Global("CaelarPledged","GLOBAL",1)~ THEN REPLY ~I was interrupted in Avernus. I will slaughter you right now. Prepare to die, Caelar!~ GOTO   FightPleased
  IF ~Global("CaelarPleased","GLOBAL",1)~ THEN REPLY ~Caelar, I need your help. I must stop a group of Bhaalspawns from making Alaundo prophecies about rivers of blood come true.~ GOTO  JoinPleased 
  IF ~Global("CaelarPledged","GLOBAL",1)~ THEN REPLY ~You pledged to me in Avernus, Caelar. Bend before me and serve me.~ GOTO   JoinPledged  
END

IF ~~  BEGIN WelcomeToHell3
  SAY ~How funny.~  
  IF ~Global("CaelarPleased","GLOBAL",1)~ THEN REPLY ~I was interrupted in Avernus. I will slaughter you right now. Prepare to die, Caelar!~ GOTO  FightPleased 
  IF ~Global("CaelarPledged","GLOBAL",1)~ THEN REPLY ~I was interrupted in Avernus. I will slaughter you right now. Prepare to die, Caelar!~ GOTO   FightPleased
  IF ~Global("CaelarPleased","GLOBAL",1)~ THEN REPLY ~Caelar, I need your help. I must stop a group of Bhaalspawns from making Alaundo prophecies about rivers of blood come true.~ GOTO  JoinPleased 
  IF ~Global("CaelarPledged","GLOBAL",1)~ THEN REPLY ~You pledged to me in Avernus, Caelar. Bend before me and serve me.~ GOTO   JoinPledged  
END


IF ~~ BEGIN FightPleased
  SAY ~Time changed you to worst, <CHARNAME>. You are a slave to your blood.~ 
  =
  ~I will fight you and free you from life!~
  IF ~~ THEN DO ~ChangeAIScript("BDCAELAC",GENERAL)
  Enemy()~ EXIT
  END

IF ~~ BEGIN FightPledged
  SAY ~Wait, <CHARNAME>. I see your bloodlust and anger. You became worthy of your father.~ 
  =
  ~Do you remember I pledged to serve to you, <CHARNAME>?~
  =
  ~I have changed. I don't want to die. Please, give me a chance to fight by your side and murder those who stand on your way.~
  =
  ~My soul is cursed in Heavens, I can only live in Hells.~
  IF ~~ THEN REPLY ~No, Caelar, your story ends now. There are only a milleniums of pain for you.~ GOTO  FightPledged2
  IF ~~ THEN REPLY ~It's good you remember how to bend before master. Okay, join me and serve me, my blackguard.~ GOTO JoinPledged
  END

IF ~~ BEGIN FightPleased2
  SAY ~Than I will fight. I became stronger in Avernus, killing all these hordes non-stop.~
  IF ~~ THEN DO ~ChangeAIScript("BDCAELAC",GENERAL)
  Enemy()~ EXIT
  END
  
  IF ~~ BEGIN FightPledged2
  SAY ~I will defend!~
  IF ~~ THEN DO ~ChangeAIScript("BDCAELAC",GENERAL)
  Enemy()~ EXIT
  END
  
IF ~~ BEGIN JoinPledged
  SAY ~I will serve you, my master. I owe you my life.~
  IF ~~ THEN DO ~
ChangeStat(Myself,XP,1579680,ADD)
JoinParty()~ EXIT
END
  
IF ~~ BEGIN JoinPleased
  SAY ~I will fight side by side to you and dedicate my sword to you, <CHARNAME>. I owe you my soul.~
  IF ~~ THEN DO ~
ChangeStat(Myself,XP,1579680,ADD)
JoinParty()~ EXIT
END