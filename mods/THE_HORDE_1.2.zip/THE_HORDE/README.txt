	-------------------------------------------------------
	*** *** *** The Horde, Version 1.0 *** *** ***
	-------------------------------------------------------

I N D E X :

1. Introduction - [int]
2. Installation - [inst]
3. Components list and Install Order - [compl]
4. Compatibility issues [ciss]
5. Credits and Acknowledgements [cack]
6. Version notes - [version]

---------------------------------------------------------------------------------------------
1. Introduction - [int]

This mod doubles the number of creatures in the game.

I hope you'll like this mod as i do, and if you have any feedback or questions you can mail me at yowavegamer@gmail.com

---------------------------------------------------------------------------------------------
2.	*** INSTALLATION *** - [inst]

You should note that the mod comes in ZIP format. Most versions of windows should be able to extract the file.
Winzip can be used if you can't extract the files using windows built in zip extractor: http://www.winzip.com/win/en/prod_down.html

Instructions:

1) Place the zip file in your root Baldur's Gate 1/2 directory (where baldur.exe is), right click and select Extract Here. Then move the zip file to another location.

2) Open your Baldur's Gate 1/2 folder, and double-click 'SETUP-THE_HORDE.exe'. If there is no 'SETUP-THE_HORDE.exe' in this directory, you have extracted it to the wrong place.

3) This mod should be installed last and before generalized biffing.

If you want to uninstall the mod, just double-click again 'SETUP-THE_HORDE.exe' and press 'U' for uninstall.

Note, do not delete therefore the THE_HORDE folder (this goes for any WeiDU installed mod) otherwise you cannot uninstall.

---------------------------------------------------------------------------------------------
3.	*** Components list and Install Order *** - [compl]

0 - THE HORDE CORE - This mod should be installed last and before generalized biffing.
1 - LESS DUPE DROPS - make duplicated creatures items undroppable
2 - NO DUPE XP - duplicated creatures give no xp

---------------------------------------------------------------------------------------------
4.	*** Compatibility issues *** - [ciss]

The mod should work with BG1,BG2,TOB,BG1:EE,BG2:EE,EET.

Steam/GOG SOD dlc:
You can install it after merging SOD with BG1:EE installation.
Can find instructions here:
https://forums.beamdog.com/discussion/50441/modmerge-merge-your-steam-gog-zip-based-dlc-into-something-weidu-nearinfinity-dltcep-can-use/p1

---------------------------------------------------------------------------------------------
5.	*** Credits and Acknowledgements *** - [cack]

I would like to thank the creators of the tools I used in the writing of this mod:
1. WeiDu, by Westley Weimer, the bigg and Wisp
2. Near Infinity, by Jon Hauglid and Argent77
3. NotePad++, by Don Ho
4. Thanks for the aowesome ppl from Gibberlings3 that helped to shape this mod for the better!
   Special thanks to abg1 and Ardanis, for thier valuable insight.

---------------------------------------------------------------------------------------------
6.	*** Version notes *** - [version]

Version 1.2 - 17/12/2016:
	* made CROSS PLATFORM by the power of JAVA - tested on Windows and it works, need feedback from ppl with MAC OS and Linux
	* Credits and Acknowledgements - Special thanks to the awesome people from Gibberlings3.
	* Added Component - LESS DUPE DROPS - you can choose to restrict item drops from duplicated creatures
	* Added Component - NO DUPE XP - you can choose to remove xp for killing duplicated creatures
	* Fixed no duplicate on dialogue with null chars, some creatures that had dialogues was duplicated because their cre dialogue had null chars
	* Now also duplicating creatures with dialogues that have no actions or triggers, in this case the creature is duplicated but it's dialogue field is deleted (need feedback)
	* Restricted install to BG1,BG2,TOB,BG1:EE,BG2:EE,EET

Version 1.1 - 13/12/2016:
	* Made compatible with WeiDU uninstall

Version 1.0 - 12/12/2016:
	* First public release