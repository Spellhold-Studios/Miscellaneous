REPLACE_TRIGGER_TEXT ~famil1~ ~Alignment(Player1,MASK_LAWFUL)~ ~Global("FamilID","GLOBAL",1)~
REPLACE_TRIGGER_TEXT ~famil1~ ~Alignment(Player1,MASK_LCNEUTRAL)~ ~Global("FamilID","GLOBAL",1)~
REPLACE_TRIGGER_TEXT ~famil1~ ~Alignment(Player1,MASK_CHAOTIC)~ ~Global("FamilID","GLOBAL",2)~

REPLACE_TRIGGER_TEXT ~famil2~ ~Alignment(Player1,MASK_LAWFUL)~ ~Global("FamilID","GLOBAL",6)~
REPLACE_TRIGGER_TEXT ~famil2~ ~Alignment(Player1,MASK_LCNEUTRAL)~ ~Global("FamilID","GLOBAL",7)~
REPLACE_TRIGGER_TEXT ~famil2~ ~Alignment(Player1,MASK_CHAOTIC)~ ~Global("FamilID","GLOBAL",8)~

REPLACE_TRIGGER_TEXT ~famil3~ ~Alignment(Player1,MASK_LAWFUL)~ ~Global("FamilID","GLOBAL",3)~
REPLACE_TRIGGER_TEXT ~famil3~ ~Alignment(Player1,MASK_LCNEUTRAL)~ ~Global("FamilID","GLOBAL",4)~
REPLACE_TRIGGER_TEXT ~famil3~ ~Alignment(Player1,MASK_CHAOTIC)~ ~Global("FamilID","GLOBAL",5)~