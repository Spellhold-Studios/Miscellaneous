BAG BONUS

Just a little something that adds a potion case and a ammo belt to Deidre in the Adventurer's Mart.
As requested by 'Himself' on the ol' BP forums. Cheers.
  hlid.


History:

v1.0.1 - Added German translation (thanks Leonardo Watson) and Russian translation (thanks aerie.ru)
v1.0.2 - Corrected typos in the German translation
         Added WeiDU v210
v1.0.3 - Added Italian translation (thanks Stoneangel)
v1.0.4 - Added Spanish translation (thanks Lisandro)
       - Moved bagbonus.tp2 into the mod folder
       - Changed to README command
       - Updated to WeiDU v215
