Name: The Old Gold
Games: BGT/BWP/BWS

Author:	Creepin
Contact: creepin@yandex.ru

Version: 0.2

----------------

Contents

1. Introduction
2. Installation
3. Compatibility
4. Thanks
5. Legal information
6. Version History

----------------

1. Introduction

This mod is aimed to eventually add new items, spells, friends and enemies to the game, but most
importantly to bring a feeling of warm and cozy nostalgia to those who knew old D&D PC games.
Love to these games was, in fact, what gave me inspiration to create this mod, so expect it to
bring back both treasures and trinkets of the past.

Keep in mind though that this is v0.2, very much WIP, so there's only few items so far.


2. Installation

As with any other WeiDU mod, just unzip to the main game directory and run setup exe. This mod is constructed
in such way as to acknowledge many other mods and adjust itself accordingly, so the later in the install order
you will install it, the better. Preferable installation time is after all mods adding new locations, encounters
or other in-game content. It might be safe to install it before rule-changing mods, but ideally it should be
installed as late as possible, right before post-install biffing. This way some rule tweaks done by mods
installed before may possibly be ignored by the content of The Old Gold (though I'm having a hard time coming
up with a single example of such), but other than that all will be fine.


I plan to procure a place for the mod in BWP and, possibly, to update BWS accordingly, but that would
happen when there's more content done. So far manual installation like in good old times is the
only option. However the mod should install flawlessly upon BWP or BWS megamod. 

3. Compatibility

The mod will need at least BGT (won't work on pure BG2), but will detect other mods installed and
adjust accordingly content-wise. Being a compatibility fanatic, I've tried to made this mod as
compatible with the rest of BWP/BWS as possible. It should work flawlessly with bare BGT or any
combination of mods under BWP/BWS.


4. Thanks

First and foremost I would like to thank the whole community for answering my questions and teaching
me stuff. Thanks, really, that was and is appreciated!

Special thanks to the developers of the tools I have used while creating this mod:
WeiDU, maintained by Wisp
NearInfinity, maintained by Argent77
BAM Batcher by Miloch
and last but not least
Palette Generator by Sam.


5. Legal Information

Copyright (C) 2017-2019 by Creepin, All Rights Reserved

The Old Gold was created to be freely enjoyed by all classic Baldur's Gate players. However,
this mod may not be sold, published, compiled, modified, adapted, converted or redistributed in any form
without the consent of its author.


6. Version History

Version 0.2
- paperdolls improved
- 1PP compatibility fixed
- more content added

Version 0.1
- Initial release