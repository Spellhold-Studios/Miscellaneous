Sun Soul Monk kit v1.2a
By: Everyone's Fail Geek.

SUN SOUL MONK: Monks of the Sun Soul Order believe that they each harbor a small fragment of the sun's divine essence, long absent from the Realms and are trained to tap into the "spiritual light" within and manifest it externally. Their training does provide some drawbacks to their melee capabilities.

Advantages:
- May use the Sun Soulray abilitiy once per day every 3 levels (starts at 1st level with one use). Maximum of 7 uses at 19th level.
- May use the Flaming Fists ability once per day every 5 levels (starts at 5th level with one use). Maximum of 4 uses at 20th level.
- May use the Abundant Step ability once per day at 11th level. Gains another use at 21st level.
- May use the Sun Soul ability once per day at 16th level.
- May use the Sun Soulbeam ability once per day at 21st level.

SUN SOULRAY: The Sun Soul Monk projects a beam of light from his/her open palm, doing 1d6 fire damage per 2 levels up to a maximum of 5d6. Undead take 2d6 fire damage per 2 levels, up to a maximum of 10d6.

FLAMING FISTS: The Sun Soul Monk wreathes his fists in flame, giving them 1d6 damage for 2 rounds. The duration increases by 1 round every 5 levels up to a maximum of 5 rounds.

ABUNDANT STEP: The Sun Soul Monk teleports to a single place in visual range.

SUN SOUL: The Sun Soul Monk protects him/herself by using his/her inner flame to create a Red Fireshield.

SUN SOULBEAM: The Sun Soul Monk focuses his/her inner light, emitting a dazzling Sunray.

Disadvantages:
- May only be of Lawful Good or Lawful Neutral alignment.
- May not gain additional uses of Stunning Blow until after 20th level.
- May not use Quivering Palm.
- May not be Proficient with melee weaponry.

Just a quick and dirty mod: A Sun Soul Kit for Rasaad. I was never good with balance but I did want to give him ranged damage capabilities because a monk at early levels is just a tad bit underpowered.

Comes with three components: The actual kit itself, some Sun Soul Kit items, and the files to make Rasaad the kit. While the actual kit can be installed in non-BGEE installs, you won't be able to select it (I believe it's a hardcoded thing).

Newest Version:
Tiny fixes.

Most of the info came from this: http://www.wizards.com/default.asp?x=dnd/ex/20050601a&page=4

Version History:
1.0 - Made the kit.
1.0a - Fixed game crashing bug when casting Sun Soulray. Also Flaming Fists works now!
1.1 - Added Will of the Sun, Boots of the Sun Soul +1-5. Fixed kit usability flag (used Undead Hunter flag by mistake, this means that overriding RSBOOT and RSBRAC is now unnecessary)
      Modified the TP2 to copy the Monk 2DA tables, then replace the first row (The Stunning Blow row) with an adjusted row to slow Stunning Blow acquisition.
1.2 - Using The Will of the Sun will now show the visual effect only if the class has changed kit. You can now change to Sun Soul Monk kit if you have 9 DEX, CON or WIS. A sound now plays when Flaming Fists end.
1.2a - Sun Soulbeam had no name. Also made a much neater removal of the quivering palm skill.