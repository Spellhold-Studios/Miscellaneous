// creator  : weidu.exe (version 185)
// argument : SHADEDRG.DLG
// game     : C:\Program Files\Black Isle\BGII - SoA
// source   : C:\Program Files\Black Isle\BGII - SoA/override/SHADEDRG.DLG
// dialog   : C:\Program Files\Black Isle\BGII - SoA/dialog.tlk
// dialogF  : (none)

BEGIN ~SHADEDRG~ 35892 // non-zero flags may indicate non-pausing dialogue

IF ~NumTimesTalkedTo(0)
~ THEN BEGIN 0 // from:
  SAY @0 /* #35892 */
  IF ~~ THEN REPLY @1 /* #29119 */ DO ~Enemy()
Shout(880)~ EXIT
  IF ~~ THEN REPLY @2  /* #11126 */ DO ~Enemy()
Shout(880)
~ EXIT
END
