**********************************************************************************************************************************
*                                                                                                                                *
* This is a weidu'd version of Kensai Ryu's under-distributed mod, "Deeper Shadows of Amn".                                      *
*I have made some slight modifications to the original files. For some custom spells of KR's I've                                *
*modified the scripts to utilize the various -RES spell actions. (This mod was made pre-TOB.)                                    *
*I have also added names to some of the creatures. KR didn't do this as the mod was made pre-                                    *
*IAP tech and was a grueling task at the time to distribute. I've made on other change to 2                                      *
*reward items for the above reason as well as removing a unique item duplication from the                                        *
*game. Enjoy! Bug reports to the Mod Resurrection forum at:                                                                      *
*  http://forums.forgottenwars.net/                                                                                              *
*                           -hlid.                                                                                               *
*                                                                                                                                *
**********************************************************************************************************************************


Fixes:

Version 2.2.4 (18 August 2009)
- Updated the German translation
- Changed to README-command
- Updated to WeiDU v211

Version 2.2.3 (19 June 2009)
- Zeroed effects offset in [DSoA\BrownDragon\cre\KRAIRSU2.cre]
- Zeroed effects offset in [DSoA\CopperC\cre\GUARD4.cre]
- Zeroed effects offset in [DSoA\CopperC\cre\GUARD5.cre]
- Zeroed effects offset in [DSoA\CopperC\cre\GUARD6.cre]
- Zeroed effects offset in [DSoA\CopperC\cre\GUARD7.cre]
- Zeroed effects offset in [DSoA\CopperC\cre\Korax.cre]
- Zeroed effects offset in [DSoA\Gnome\cre\KRFAM01.cre]
- Zeroed effects offset in [DSoA\Gnome\cre\KRFAM02.cre]
- Zeroed effects offset in [DSoA\Grothgar\cre\KRWYVER2.cre]
- Zeroed effects offset in [DSoA\Grothgar\cre\KRWYVERN.cre]
- Zeroed effects offset in [DSoA\ShadeLord\cre\KRSHADC.cre]
- Zeroed effects offset in [DSoA\ShadeLord\cre\KRSHADG.cre]
- Zeroed effects offset in [DSoA\ShadeLord\cre\KRSHADM2.cre]
- Zeroed effects offset in [DSoA\ShadeLord\cre\KRSHADM3.cre]
- Zeroed effects offset in [DSoA\ShadeLord\cre\KRSHADMI.cre]
- Zeroed effects offset in [DSoA\ShadeLord\cre\KRSHADMO.cre]
- Zeroed effects offset in [DSoA\ShadeLord\cre\KRSHADSK.cre]
- Zeroed effects offset in [DSoA\ShadeLord\cre\KRWERE.cre]

Version 2.2.2 (25 May 2009)
- Added Italian translation (thanks Stoneangel).
- Fix small bug in file DSoA\Grothgar\baf\Grothgar.baf
- Added VERSION flag
- Added WeiDU v210

Version 2.2.1 (8 May 2008)
- Added German translation (thanks Isil-zha) and Russian translation (thanks aerie.ru).

Version 2.2 (25 April 2007)
- Found the elusive Ghost Dragon dialog file. He shouldn't just sit there and stare at you anymore. ;)

Version 2.1
- Added an assignation of the area script to the area in crypt king component. Some modded games will have this already, (Like mine did.) some won't. Added to ensure everyone's on an even keel.
 


/////////////////////////////////////////////////////////////////////////
/* This is KR's original readme text. Ignore any installation type inconsistancies. */
/////////////////////////////////////////////////////////////////////////

Deeper Shadows of Amn. (some of Kensai Ryu's stuff in one package)  

The following creatures and AI were created by Kensai Ryu, with snippets taken from
some other IEEAIS council members scripts:

**--**--**--**--**--**--**--**--**--**--**--**--**--**--**--**--**--**-**--**--**--* 

Archlich battle to free Kangaxx

Improved Copper Coronet Script for Slaver Quest and Korax NPC

Improved Cyrpt King (and a bug fix for him)

Improved Kangaxx AI

Grothgar the Red dragon

Fighter/Illusionist with two familiars battle

The Ghost Shadow Dragon

The Curse of the Underground Shade Lord

**--**--**--**--**--**--**--**--**--**--**--**--**--**--**--**--**--**-**--**--**--* 

Details about each enhancement:

------------------------------------------------------------------------------------

Archlich battle to free Kangaxx.


If you visit the tomb of Kangaxx you will find a new guardian in the room above, the
Archlich. Hes a level 34/21 Cleric mage, and he has another lich with him and some 
guards he's brought. Their purpose is to kill Kangaxx and get his ring (If you 
already have the ring they do not  know this , they think Kangaxx is still alive 
and has it.) They will kill anyone whom they find snooping around his tomb. Its a
pretty tough fight so be prepared...(Actually its very tough) 

Files Included:

AR0330.bcs (The area script to spawn the creatures), ARCHLICH.cre (The Archlich,
who uses priest and mage spells.), ARCHLICH.bcs, (The script for him.), KRLICH2.cre,
(The second lich that mostly attacks.), KRLICH.bcs (The script for the second lich),
KRDWARF, (One of the Archlich's guards.), KRDUALWF.cre (Another guard for the
Archlich.) KRFIGHT.cre (The last guard for the Archlich.), KRFIGHT.bcs. (The script
for the guards.) and Rat01.cre. (This is an interesting Idea Kensai Ryu came up 
with for defeating spell turning, simply cast area of effect spells on a rat 
created near the object with spell turning, that way spells like Abi-dal-zims will
affect those protected by spell turning.) 

Location in game: In the room above Kangaxx's tomb in the Docks.

------------------------------------------------------------------------------------

Improved Kangaxx AI.


This AI is actually much more than just AI. The basic Kangaxx AI had nothing to work
with, it was only 2 pages long. So I added a bunch of spells and gave him the option
to work around some common used tactics that kill him. Try it out! I figured since 
hes a Demilich he should cast some interesting spell. (Note this is the oldest of
my files, made was I was still learning, but it improves the Kangaxx Battle much in
my opinion. Also Kangaxx takes the Improved mace of disruption if the party has it,
so Kangaxx will have a fighting chance instead of failing his save and dying in the
first round against that weapon.

Files Included:

DEMILICH.bcs Kangaxxs new AI in DemiLich form.

Location in game:

Same as normally found. Kangaxx's Tomb in the docks.

------------------------------------------------------------------------------------       

Grothgar the Red dragon. 


This is a dragon I made to make the game a little more interesting. He has more Hp
 than a normal dragon and uses some interesting spells. He is also smarter than a 
normal dragon and much more. It is a fun fight in my opinion, better than the other 
dragons in SOA no doubt about it :).

To include in game just unzip all files to your bg2 soa/tob override directory. If 
you want the custom loot he carries you will need the IEES or ISSP availiable from
Team Bg at www.teambg.com.

Files included:

Grothgar.cre (His creature file.), Grothgar.bcs (His script.), GrothGar.iap
(You only need to import the IAP if you want his custom loot.), DragClck.itm 
(His dragon immunities.), AR1402.bcs. (the script to spawn him.), KRWYVERN.cre a 
helper for him, KRWYVERN2.cre, second helper. KRWYVERN.bcs, the helpers' script. 
SPWI445 (a custom dimsional door spell that allows the cre some time to heal).
SPELL.ids. The list of spells the game uses to allow scripts to use in game spells.

Location in game:

You can find him in the lair of one of the dragons in SOA after you have killed it,
(Shadow Dragon's lair) a little over a day later. 

BTW hes immune to the ctrl y cheat also. : )

Now Updated with a much improved script, with less cheese and using Xyx Beholder's 
priority targeting, and cast and attack.

------------------------------------------------------------------------------------

Improved Copper Coronet Script for Slaver Quest and Npc Korax. 


This is a real simple script I did that adds more guards to the CC guard crew, when
they go hostile for the slaver quest. Why you ask? I think its alot fun to solo 
this quest and I found it too easy... 

Files Included:

AR0406.bcs The area script, modified to create more guards. AR0404.bcs. 
The area under the where CC I added some more guards and goblins, and where
Korax is spawned. HENDAK.bcs. Fixes a problem with too many guards causing 
Hendak to not move to fight Lehtinan. So hendak is moved to the spot near Lehtinan
to avoid this, when his cell is opened. 
GUARD4.cre. GUARD5.cre. GUARD6.cre. GUARD7.cre. More (custom) guards for the cc.
Korax.cre. The Ghoul himself. Korax.bcs. His script. InKill.bcs. Korax's script to
kill innocents. (hes evil remember?) Koraxnew.dlg. His small speech determining if
he joins the party or not. KoarxSP.SPL. His innate spell to call undead. KORAX_L.bmp
Korax's handsome picture. KORAX_S.bmp Another handsome picture of him.

Location in Game: Ar0406, The Copper Coronet Inn in the Slums. And underneath it.

*Note this file includes the bonus merchant for the CC as well. Thanks to Isham
for pointing out that mistake. Also fixed problem with guard dialogs. Some moving
of guards spawn location to cut down on them attacking Nalia (can you blame them?).

------------------------------------------------------------------------------------

Improved Crypt King.


You remember the Cyrpt King dont you? Of course you do, hes very easy to beat and 
he has some cool loot (good sword). This version fixes his script that is broken in
the game and also gives him a couple Skeleton minions, after all he is a king,
right? Also he locks the exit once you enter, so you cant leave till either you or
him die. :) He also calls for more backup every now and then. 

Files Included: BHCrypt.bcs. (His fixed script, trust me aint much there to look 
at!), AR0806.are. (The area he starts in, hex edited by Kensai Ryu to run an area 
script.), AR0806.bcs (The script used to lock the exits till the crypt king meets
his own cyrpt floor.) 

* Note in order for this to work you must not have visited his lair previously in 
the game, if you have then too bad it wont work right because the area info is 
saved on your savegame. If you have not been to his area in the current game, you 
are good to go. *


Location in game: Same, crypt in graveyard.

------------------------------------------------------------------------------------

Fighter/Illusionist with two familiars battle

This is something I did for the purpose of working on some AI for familiars. Its a
simple battle, not too hard Imo. The gnome fighter illusionist is looking for an
NPC, Valygar, and he will kill anyone in his way.

Files Included:

AR0326.bcs. Area Script to spawn the Mage and his 2 familiars. KRGNOME.cre The 
Fighter/ Illusionist. KRGNOME.bcs His script. KRGNONE.Dlg. His small dialog.
KRFAM01.cre The first familiar, a generic mage Imp. KRFAM01.Bcs The 1st familiars
script. KRFAM02.cre. A Necromancer specialist mage Imp, uses mostly necro spells.

Location in Game: Somewhere in the docks. (The mage is looking for Valygar, hint,
hint..)

------------------------------------------------------------------------------------

The Ghost Shadow Dragon 

This is a Shadow Dragon that is spectral. He has more hps and the same
special attacks as a shadow dragon, yet he uses a much improved script 
for better priority targeting (based off Xyx'x Smart beholder targeting).
He has a magic item also, and lots of money, if you can kill him. Also
has a couple shadow followers that follow him around. He is a hard 
fight so be prepared.

Files Included:

AR0418.bcs, Area script to spawn him and his followers. SHADEDRG.cre. 
The ghost shadow dragon. SHADEDRG.bcs. His script. SHADEDRG.dlg. A word 
or two from him. KRSHADOW.cre. His followers. KRSHADOW.bcs. The folowers script.    

Location in Game: The room with the minotaur that dies when you enter 
it, under the Copper Coronet. When player1 displays the text over 
his head that he feels uneasy then the dragon and his followers will 
spawn soon. (You should see that text as soon as all hostiles in room 
are dead, and so is the minotaur, Note: you may need to definately come
back for this battle much later in the game!)

------------------------------------------------------------------------------------

The Curse of the Underground Shade Lord 

A new Shade Lord has moved in to the tombs where the Book of Casa was 
once found. It has raised a curse, in some parts of town, for its 
shadow minions to rise and attack any priests openly practing their 
magic. (once the party is strong enough level and they cast priest 
spells the shades will appear.) The Shade Lord sits well protected 
behind a large number of his shadowy minions. Only his death will end 
the Curse!

*Note: this script checks the level of player1, and if a priest spell 
is cast by a pc.If you kill the shade lord before you become high enough
level, no shade monsters will spawn in the city, because the curse will
be lifted. (check is for at least level 13 on player 1 before monsters
are spawned, to avoid party being crushed.)*   

Files Included: 

KRSHDLD.bcs, His script, KRSHADLD.cre, The Shade lord, 
KRSHAD.dlg, His opening statements, KRSHADM.cre, A shadow mage, 
KRSHADM2.cre, Another Shadow Mage, KRSHADM3.cre, Another Shadow Mage,
KRSHADG.cre, A shade follower, KRSHADMI.cre, Another follower, 
KRSHADMO.cre, Another follower, KRWERE.cre  Another follower,
KRSHADF.cre, Another follower. AR0700.bcs, The area script to spawn 
some creatures when priest spells are cast, and the curse is on,
AR0802.bcs, The area script to create all the actors, KRSHAD.itm, The
spectral immunities, and KRSHADC.cre, Another follower.

Location in Game: 

Tombs under the city, 8 hours after you have been there and cleaned
out the undead mummies living there. If you have not been there 
previously, you must first kill the mummies and then wait 8 hours 
(game time, go sleep 1 time and you are good to go). If you have 
been there previously, and the mummies are already dead, you must
first enter the area, then leave and wait 8 hours, before the cres 
will spawn, since the new timer is not saved in your savegame. Rewards
include some magical items, and lots of money and a few good scrolls.

Note: This is also recommended for lvl 15+ parties, but you can try it
 at any level, after you have cleared out the mummies. Not as hard as 
some of the other stuff I have done, but still fun. 
     
------------------------------------------------------------------------------------
**--**--**--**--**--**--**--**--**--**--**--**--**--**--**--**--**--**--**--**--**--**--** 
 
Other Files included: None*

* Version 1.031 (A)

 Took out Dragon AI, as it is constantly being updated. Took out detectable spells for the 
 same reason. Took out Gminion, because I no longer include my Vampire AI.

____________________________________________________________________________________


All Files that are included:

AR0326.bcs, AR0330.bcs, AR0404.bcs, AR0406.bcs, AR0418.bcs, AR0806.are, AR0806.bcs,
AR1202.bcs, AR1402.bcs, ARCHLICH.bcs, ARCHLICH.cre, BHCrypt.bcs, Demilich.bcs,
Dragclck.itm, GrothG.dlg, GrothGar.bcs, GrothGar.cre, GrothGar.iap, GUARD4.cre,
GUARD5.cre, GUARD6.cre, GUARD7.cre, Hendak.bcs, Inkill.bcs, Korax.bcs, Korax.cre, 
KORAX_L.bmp, KORAX_S.bmp, KORAXNEW.dlg, KRDUALWF.cre, KRDWARF.cre, KRFAM01.bcs, 
KRFAM01.cre, KRFAM02.bcs, KRFAM02.cre, KRFIGHT.bcs, KRFIGHT.cre, KRGNOME.bcs,
KRGNOME.cre, KRGNOME.dlg, KRGUARD5.bcs, KRLICH.bcs, KRLICH2.cre, KRSHAD.itm, 
KRSHADOW.bcs, KRSHADOW.cre, KRWYVER2.cre, KRWYVERN.bcs, KRWYVERN.cre, Rat01.cre, 
Readme for deeper shadows.doc, SHADEDRG.cre, SHADEDRG.dlg, AR0318.bcs, SPIN684.spl,
SPIN686.spl, SPPR698.spl, SPPR950.spl, Spell.ids, Stat.ids, KRSHDLD.bcs, KRSHADLD.cre,
KRSHAD.dlg, KRSHADM.cre, KRSHADM2.cre, KRSHADM3.cre, KRSHADG.cre, KRSHADMI.cre, 
KRSHADMO.cre, KRWERE.cre, KRSHADF.cre, AR0700.bcs, AR0802.bcs, KRSHAD.itm, KRSHADC.cre, 
SPKORIN.spl.


Please Note:

*This Zip does not affect the dialog.tlk file at all, unless
you install Grothgar's custom treasure (Grothgar.iap).* 
  
*This zip contains 2 IDS files, Spell.ids and Stat.ids. If 
you have any custom Ids files with those names, you will need to 
either remove them from your override, or add your custom stuff to
mine in order for these to work.*

Any problems, comments, questions, etc, can be sent to Kensai Ryu at 
AstroBouncer@Aol.com.

Buges fixed from previuous verisons:

Numerous minor problems with the CC script, V1.028 had incomplete area 
script so the shade lord quest was not correct, and monsters spawned
at wrong time.  

Special thanks to Isham for bug reports and ideas : ) !! 

Special thanks to TeamBG for making this possible!!!

And finally, special thanks to all the IEEAIS Council members!

Hope you enjoy. More coming soon!

-Kensai Ryu
