FontMod v2.1
by Corvias

Description
-----------
This mod adds new,larger fonts to BGII:ToB, though could probably be used with any Infinity engine game. I informally released my first attempt at IE font making, but that attempt was too big, blocky and wide. This second attempt has come out much better, and I have refined the process. The new main game font (normal.bam) is a bit smaller than my original (which stil can be found in a thread I started in the IE moding help forum), with hinted edges to reduce aliasing. The Tooltip font is an even smaller version of normal.bam, and can even be used as an alternative to normal.bam if you think its still too big. The Float Text font needs a llittle work, IMO, but it's still pretty good. I will probably re-do it in the future. These fonts have been tested in both 2d and 3d mode, but there still could be character misalignments, or other glitches. Please post to my thread in the misc. mod forum at Spellhold Studios with a screenshot, and I'll get it fixed.

I originally created these fonts after using the bigg's Widescreen mod. While the widescreen mod makes BGII look great on modern high-res, it also makes the text extremely difficult to read for folks with visual impairments. And so the FontMod was born. All the fonts are based on the open source DejaVu fonts, though there should be no legal issues. Please feel free to change and study my work -- at some point I will write a tutorial on font creation for IE games (hint: it's tedious).

Install
-------
Just copy these fonts to your C:\Program Files\Black Isle\BGII - SoA\override folder.

Changelog
---------
1.0 - Initial Release of larger normal.bam.
2.0 - Revamped: Normal.bam bit smaller, with anti-aliasing with DejaVu Serif Condensed
    - New: Bigger floattxt.bam based on DejaVu Sans.
    - New: Bigger Toolfont.bam (basically a smaller version of my normal.bam.
2.1 - Raised the vertical alignment of all chars in floattxt.bam by 3 pixels in an attempt to get the text
      to not cover avatars. Unfortunatly,beyond 3px the top line of float text starts to get chopped.




