
                 ----------------------------------
                  BG1 Level Cap Reinstator for BGT

                                BLCR

                             Version 1.0
                 ----------------------------------



BLCR is a small mod for Baldur's Gate Trilogy that reinstates the
original experience cap of Baldur's Gate: Tales of the Sword Coast.

After installing this mod, your experience points will initially be
limited to 161 000 XP. This limitation only applies to the Baldur's
Gate 1 part of the game, and you will be free to advance further
after being transitioned to the Baldur's Gate 2 part.

The limitation affects all six party members.

This mod extends the BALDUR.BCS game script to achieve its goal.



Install:
--------

Extract all files to the BG2 install folder.
Run Setup-BLCR.exe and follow the prompt.

The level cap restriction will automatically be applied the next
time you start the game.



Version History:
----------------

v1.0: Initial Release



Credits:
--------

by Adul (adul@adul.net)



Thank you for downloading BLCR!