Mod PREGNANCY for BG1/BG2:EE/EET

Author: Lassal

Version 0.1

Description:
This mod requires Romantic Encouters to be installed.
To get pregnant player with both genders, female player or male player with Girdle of Gender must participate in some of sexual affairs with male characters from Romantic Encounters mod.
To have babies, main character also must be humanoid, giant humanoid, monster or animal (parameter General).
If player becomes pregnant, baby will be born after 9 mounths.
It's throught to be used in EET, because there are not so many players playing BG1 for 9 mounths.

It uses DPLAYER3.bcs script, so don't turn off AI.

To get pregnant, there is also a custom variable checked:
Global("Player1HadSexWithMale","GLOBAL",1)


