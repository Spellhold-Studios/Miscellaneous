Arrows Of Magic Missile - by Choix

-----------------------------

To install just copy and paste MMAROW.bam and MMAROW.ITM into
your Baldurs Gate 2 override folder.

-----------------------------

To get these arrows in game simply open up the command line with
ctrl + space and type: CLUA:ConsoleCreateItem('MMAROW')

If you want to spawn a quiver of 40 arrows just type this:
CLUA:ConsoleCreateItem('MMAROW',40)

-----------------------------

If you cannot get the command line to show then you must edit
your baldur.ini in your Baldurs Gate 2 install directory.

Just open the file in notepad and add the line "Debug Mode=1"
without quotes under the [Program Options] heading, save the
file and then try again.

Good luck.

-----------------------------

choixl2@hotmail.com