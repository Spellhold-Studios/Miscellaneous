Hi.

This is a Mod Shell that can be used to add your own soundsets with subtitles to BGEE, BG2EE and IWDEE.

This Mod Shell comes with one example soundset set up called "Ajantis" and a Blank template that you can adjust to what you need. 

The instructions below describe how to add a soundset for Ajantis.  Because an Ajantis soundset is already included with this mod you can look at the game files and compare the written steps to how it actually looks in the mod.

Here's what you'd need to know to add your own soundsets:

1. Gather the soundfiles and decide on a name.  This will determine how the soundset will show up in game (for example: "Ajantis")
2. Create a folder in the SND folder of this Mod Shell called "Ajantis".  In that new folder, create a folder called "sounds" and put your sound files in that folder.
3. In the ./SND/Ajantis folder, you must place a file called "Ajantis.tra".  
	* This file must be in a specific order to correctly display subtitles in game.  I've included a template, blank.tra with this mod.
	* This file is in a specific order and is documented with comments.  You may view blank.tra and Ajantis.tra for comparison purposes of what it looks like before and after.
		-  If you choose NOT to include a sound for a particular event you must still make a blank entry that references an empty string.  This way no sound will play in game and no text will be displayed but the mod will install correctly.  I find it better for a character to say nothing at all rather than say the wrong lines for a particular event.
		
		For example this would leave your guy without a sound for Battle Cry1:
			@0 = ~~
		
4. Edit your mod's .TP2 file to account for your soundset "Ajantis".  
	* The first section of the included TP2 file automates copying your sound files and initializes variables needed to put the sounds and subs in the game.  This section need not be changed (unless you are changing the mod name - see step 5).
	
	* Scroll down to about row 225 or search for s9_soundsetBEGIN to find the section that adds soundsets.  The TP2 included with this has an entry for Ajantis and a commented one for "blank".  
	
	* The entries for each soundset is mostly the same with only the first two lines needing to change to whatever your soundset name is ("Ajantis") to whatever you are adding.  To add an entry for "Spongebob" you could copy the block for Ajantis and change the two instances of Ajantis to Spongebob.
		BEGIN ~Spongebob~														 // Ajantis changed to Spongebob
			OUTER_SPRINT soundName ~Spongebob~									 // Ajantis changed to Spongebob
			LAUNCH_ACTION_FUNCTION s9copy END								     // this line is the same everytime
			INCLUDE ~S9SoundsetsVol0/baf/core.tpa~								 // this line is the same everytime
			
5.  If you change the path from S9SoundsetsVol0 to another name you must search and replace ALL instances of S9SoundsetsVol0 with your new path name in the following files:
      .\BAF\core.tpa
       setup-(yourmodname).tp2
	   
6. That's it! Install the mod and choose your soundset.  Soon adding soundsets with subtitles will be a snap.  


If you have any questions please contact myself or another helpful forum member at:
http://forum.baldursgate.com/discussion/37760/how-to-awesome-soundsets-vol-0-soundset-mod-shell#latest

Mark aka Smeagolheart
12/14/14

Version 1.2 15 Mar 2015
		- Added informational BG & IWD soundsets.xlsx provided by Buttercheese to docs folder.

Version 1.1 18 Dec 2014
		- Revised Blank.TPA (thanks to amyae@forums.baldursgate.com)
		- Added checks for each version of the game (BGEE, BG2EE, and IWDEE) so that ONLY sound files WITH subtitles are copied for that game (unfortunately this increased the header section of the TP2)
		- Added checks to ONLY copy over sound files if they exist.
		- Added Support for # file extension for IWDEE
		- Revised Readme.txt instructions
		- Renamed Mod
		
Version 1.0 Initial Release 14 Dec 2014