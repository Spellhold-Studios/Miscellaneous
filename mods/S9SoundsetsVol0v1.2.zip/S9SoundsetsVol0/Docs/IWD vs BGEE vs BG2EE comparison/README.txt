BG1EE, BG2EE, and IWDEE all have different charsnd.2da files which control what sounds a player controlled character have in the game.
The left size numbers refer to sndslot.ids.

For example the sounds in row 9 match up to 9 BATTLE_CRY1 which match up to XXXXXXXa.wav Battle Cry 1(e.g. "Go for the Eyes!" "Booyah!") of the soundset.

The games have a lot in common with slight variations.  See the tables.xlsx file for more detail.

Totals
-------
25 sounds possible in Bg1ee.  The default soundsets only use 15 sounds each.
29 sounds in BG2EE.
33 sounds in IWDEE with the default soundsets shipping with 25 enabled sounds.