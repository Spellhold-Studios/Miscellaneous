
                           ----------------
                             Jondalar Fix
                                v 1.0
                           ----------------

A small fix for Jonalar's bugged dialog triggers for Baldur's Gate
Trilogy.



Install:
--------

Extract all files to the folder BGII is installed to.
Run Setup-JondalarFix.exe and follow the prompt.



Description:
------------

As of BGT-Weidu version 1.10, Jondalar's dialog contains a trigger
error that allows for an exploit. This mod fixes that exploit.

Jondalar is a fighting instructor in Candlekeep. Normally you would
walk up and talk to him, and he would initiate a small training session
where you would engage in combat again him and his friend Erik.

However if you decide to attack Jondalar outright instead of talking to
him, his dialog triggers will fail to recognize the hit, and this
allows you to kill both him and Erik without penalties and recieve the
XP reward and items they were carrying.

This mod fixes the above behavior by adding an additional dialog lin
which triggers only when you attack Jondalar before talking to him.



Credits:
--------

by Adam Zsoldos
visit my website at http://adul.net/ for more info



Thanks for downloading!
