Tempest Kit
By: Arashi Kai

This kit is meant to be played with BG2:SoA and ToB installed, but hopefully you only need SoA. Give him two swords and watchh im go!

TEMPEST: The Tempests are group of warriors that have an innate ability to control lightning. Through their training, they specialize in fighting with two swords, strike hard and fast,learn devestating lightning based attacks, and are deadly foes when encountered. However, their fighting style only lets them wear studded leather armour, and the containment of their powers is taxing on their bodies.

Advantages:
-Shocking Grasp at levels 1, 5, and 10.
-Lightning Shield at levels 3, 8, and 13.
-Nova at levels 10, 15, and 19.
-Lightning Bolt at levels 11 and 16
-Lightning Blade at will at level 19.
--1 attack speed every 4 levels
-TWF penalties for the off-hand are reduced by 2.

Disadvantages:
-May only wear studded leather armour and lighter.
-May only put points in bladed weapons.
-May not Dual Class.
-May not be of lawful alignment.
--2 Constitution.


Lightning shield:
A Tempest is able to sheath himself in a field of lightning that protects him from harm and harms his enemies. The lightning deflects weapons and proectiles away like scale mail (AC 6) and gives electricity reistance of 25. It also gives a minor shock of 1d4 electricity damage to any who strik him in melee.

Nova:
At 10th level a Tempest can unleash a devastating nova from his body in all directions. This nova deals 1d6 electricity damage per level (max 15d6), with a save versus spells for half damage.

Lightning Blade:
At the apex of his powers, the Tempest can summon forth a blade made of pure lightning. This blade is treated as +6 to hit, has a +6 THAC0 bonus, and deals 1d8 + 6 slashing damage plus 6d6+4 electricity damage. The blade lasts for 1 turn or until dispelled.


Credits:
-Gibberlings3, for the tutorials and other how-to's, as well as their support and suggestions
-Wu Min, who created the J&S Kits and provided a basis on TWF bonuses
-TeamBG, for providing IEEP and WinBIFF, without these tools, I would not have made it
-Andy Bridges, who provided BAMWorkshop to work on some graphics
-Aaron O'Neil, who provided Shadowkeeper, something that anyone playing BG2 whould have
-Avenger, for DLTCEP, a powerful tool that diagnosed all of my errors and helped make spells
-Anyone who gave suggestions and feedback, it is very much appreciated.
-Anyone else I did not mention that helped or contributed, Thank you all!


Copyright:
This kit may be freely distributed to any modding site willing to host it, and you are welcome to change it, so long as the name is changed. When in doubt, JUST ASK ME! Otherwise, have fun!


Version 3.0:
	Custom HLA Table is complete. It contains two paths: a Swordmaster Path and a Lightning Path
	Slight ReadMe adjustment
Version 2.0:
	Some innate spells are exchanged for Custom abilities
	ReadMe is restructured
Version 1.0:
        Initial release! YAY!