BEGIN LRDJINN

IF ~True()~ THEN BEGIN INTRODUCTION
  SAY @0                         // Hello Switch. What do you require of me?
    ++ @2 + CHOOSEINCREASE       // Let me pick a skill to increase.
END

IF ~~ THEN BEGIN CHOOSEINCREASE
  SAY @4                         // Which skill do you wish to improve upon?
    ++ @7 + INCREASEPICK         // Improve my picking skills.
    ++ @8 + INCREASETRAP         // Improve my trapping skills.
    ++ @9 + INCREASESTEALTH      // Improve my stealth skills.
END

IF ~~ THEN BEGIN INCREASEPICK
  SAY @10                        // Very well, I will enhance your pick pockets and lock picks with a success rate of 10% each.
  IF ~~ 
  THEN DO 
        ~ApplySpellRES("LRSW003",LastSummonerOf(Myself))
         SetGlobal("LRSWPICKINCREASE","GLOBAL",1)
         CreateVisualEffectObject("SPFLSRIN",Myself)
         Wait(1)
         PlaySound("EFF_M38")
         CreateVisualEffectObject("SPFLESHS",Myself)
         DestroySelf()~ GOTO BYE
END

IF ~~ THEN BEGIN INCREASETRAP
  SAY @11                        // Very well, I will enhance your trap and illusion detection with a success rate of 10% each. In addition, I will also increase your trap setting success with 10%.
  IF ~~ 
  THEN DO 
        ~ApplySpellRES("LRSW004",LastSummonerOf(Myself))
         SetGlobal("LRSWTRAPINCREASE","GLOBAL",1)
         CreateVisualEffectObject("SPFLSRIN",Myself)
         Wait(1)
         PlaySound("EFF_M38")
         CreateVisualEffectObject("SPFLESHS",Myself)
         DestroySelf()~ GOTO BYE
END

IF ~~ THEN BEGIN INCREASESTEALTH
  SAY @12                       // Very well, I will enhance your stealth capabilities with a success rate of 10% each.
  IF ~~ 
  THEN DO 
        ~ApplySpellRES("LRSW005",LastSummonerOf(Myself))
         SetGlobal("LRSWSTEALTHINCREASE","GLOBAL",1)
         CreateVisualEffectObject("SPFLSRIN",Myself)
         Wait(1)
         PlaySound("EFF_M38")
         CreateVisualEffectObject("SPFLESHS",Myself)
         DestroySelf()~ GOTO BYE
END

IF ~~ THEN BEGIN BYE
  SAY @13                        // Goodbye.
  IF ~~ THEN EXIT
END
