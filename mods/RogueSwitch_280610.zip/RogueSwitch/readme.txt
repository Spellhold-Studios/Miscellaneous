Rogue Switch
A mod for Baldur's Gate 2, by lroumen

=== Introduction ===
One thing that I have always disliked about the game is that certain things are hard-coded for no apparent reason. A bard has thieving abilities but is limited to only picking pockets and is not able to pick any locks. Seems okay for the class itself, but it would have been nice if the developers (who noticed that the fanbase was high and saw that the amount of mods rising), would have allowed some more freedom for the modders. Similarly, monks can find traps, but then they cannot do anything with those traps. Sounds rather silly, because then you still need a thief to do the trap disabling or you can trip it in which case the monk doesn't even need to find it does he?

For this reason I have created a small bardkit that allows him to shapeshift into a thief and perform the other thieving abilities in that form. This makes the bardkit into a stand-alone character that can either be a thief or a bard, effectively negating the necessity for a thief in the party, but you still have a rogue in the party (knock and find traps is rather impractical).


=== General Content ===
This mod contains basically two interconverting kits: the "Bardic Switch" and the "Thief Switch". Each starts with an innate ability that allows them to change their class "temporarily" into the other. I say here temporarily because if you want to switch back, you will have to activate the innate ability again of that particular class.
It is pretty straightforward really.

As a Switch you level up as a normal rogue. The thief and bard XP levels are the same such that you will not run into problems that one class is ahead of the other. I coded in an ability that you will be given upon reaching each new bard level. It will summon the "Master Switch" who will aid you in giving you either picking, trapping or stealth bonuses. Thus artificially, you will gain thief bonuses if you do not level up as a thief but as a bard.

If you install the mod Lux way, then you also get other goodies: custom bardsong, custom weaponspell, custom Master Switch dialogue.


In a similar fashion, one can create interconverting kits for the paladin-ranger combination (turn undead and have stealth) and the Cleric-Monk (fight with your hands, have magic resistance and use cleric spells... though this provides problems when you switch since you gain all bonuses in the CLAB files again). I will try to make these things work at a later point in time. Anyway...  back to the bard-kit


=== Complications ===
Since this is a mod that bends the rules, there are several complications and fixes/workarounds, explained below. 

P1. Race limitations
S1. No problems here because all races can pick thief as a class, such that with the click of a button, your thief can become a bard, thus races are no longer limited by classes. If one looks at my baf script for the switch, one can figure out how to get past hard-coded class limitations quite easily (create a fighterkit that changes class after character creation... all races can pick the fighter class).

P2. Thieving skills
S2. Bards only get pick pocket bonuses, thieves can pick anything. I have made the Switch gain 20% thieving skills if you level up as a thief, and twice 10% thieving skills if you level up as a bard. The latter is performed by granting the Bardic Switch the ability to summon a Master Switch who will increase either your picking skills (10% bonus to pick pockets and pick locks), trapping skills (10% bonus to find traps and detect illusions) and stealth skills (10% bonus to hide in shadows and move silently).
If you start as a thief, take this into account if you level up later as a bard. If you level as a thief, you do not get the bardic bonuses, thus leveling out.

P3. Spell slots
S3. Bards gain spells per level, but thieves do not. If you leveled as a thief and go into Bard form you do not get the extra spell levels. This will be fixed if you cast restoration on yourself. I could code this in, but thinking it could result in cheating (use the level up to get rid of nastiness), I decided that this would be up to the player. Restoration scrolls can be bought and spells can be memorised easily.

P4. Weapon Proficiencies
S4. Since you will be Bard and Thief, the thief has been given all proficiencies similar to the bard. Bard and thief rate is the same. Weapons will not be usable in thief form of course, thus unequip if appropriate (will be fixed when you get the Use Any Item HLA). 

P5. Upon switching to the bard state you will be given the the message that you gained a bardsong ability.
S5. I can put this in as a level up ability through script, but decided not to. IF this floods your screen too much, please let me know and I can circumvent this by scripting it in the baf.
Note: all abilites are thus gained through script and not through the CLAB files. The reason is that when you switch class, you gain all bonuses from level 1 to the current level, even if you had already recieved those bonuses before. That means that if you switch a lot and have a +1AC in your CLAB, you can get as many bonuses to AC.

P6. Your trap setting skill is 100% from the start.
S6. Bards have a hidden trap setting modification that puts it to 100%, because otherwise they fail at setting the HLA traps. I decided that the Switch kit does not get trapping skills, but will be able to pick trapping HLAs. So basically, this has become a non-issue. If you want you can manage this by scripting the ability in and doing a one-time reduction of the trap setting bonus on the Bard, followed by a trap setting bonus upgradable per level by the Master Switch dialogue.  


=== Switch Kit Abilities per Level Description ===
- The switch levels up as any rogue 
- At level 1, if you start as human or half-elf, your avatar changes into a tiefling (fun to code). 
- At level 1, you will gain a custom bardsong, description below.
- At level 1, you will gain the ability to shapeshift into a thief or bard. Shifting back reenables this, thus it should be unlimited. 
- At level 1, the bard will have a custom weapon spell, the Switchblade. This upgrades four times with new bonuses, description below.
- Every time you level up as a bard, you will be given the ability to summon the Master Switch to increase a selection of thieving skills by 10%. This is iteratively, meaning that if you gain multiple levels, the bonuses come one at a time. After choosing which skill to increase, the summoning spell is removed again from your innate abilities.
- At level 1, your backstab modifier increases by 1. Thus, a Bardic Switch can backstab for a bonus of +1x the damage, whereas the Thief Switch can backstab at his own level+1.  

= Thieving skill increase =
You will have three choices. Picking, trapping or stealth skills. 

Picking skills:  10% bonus to Pick pockets     Pick locks
Trapping skills: 10% bonus to Detect traps     Detect illusions
Stealth skills:  10% bonus to Hide in shadows  Move silently


= Djinni talk = 
I have developed the Switch bardkit such that the tracking of the progression only works for ONE party member for now. I manage the progression talk by setting a global variable and tokens. I find that it becomes too much of a problem to code it in such a way that it will be allround for a multiple switch party... You don't need more than 1 switch in you party.
If somebody knows how to fix it, to make it party-friendly, I would be very interested (but do not just give me scraps of code unless you are certain that it works because I already have received lots of scraps that have failed, unfortunately).
The skill increases for a 6 Switch party will only work if your switches are the same level. You will probably all change class at the same time too... I advise you not to use more than one in your party or your play-through will be filled with bugs. 


=== Installation ===
The bardkit can be installed in two ways.

BluePrint
This allows the protagonist to start as either a thief or bard and switch to and fro. It does not contain checks to keep track of your upgrades, nor does it contain any other bonuses. Thus it will be moddable in accordance with your own wishes, examples are given in the baf-script.

Lux way
This allows the protagonist to start as either a thief or bard and switch to and fro. Contains custom bardsong, weapon spell, level up abilities and a minor Master Switch progression tracking dialogue.


I made separate installers because I wanted to put the mod out into the world rather than tweak the installer-tp2 a million times.


=== bugs ===
If you find any bugs, they can be directed at: lucroumen@hotmail.com



=== personal acknowledgements ===
Ardanis, Jarno Mikkola, Hoppy, Wisp, Kwiat_W and the bigg for some tips on the coding.


VERSION 1.3 Changes
- After level up from a thief and switching to a bard, yuo lose the ability to change into a thief. At the same time you delevel and relevel as a bard. After leveling up, you regain your switching ability. This necessity has been built in to provide the correct amount of spell slots for the bard.
- Removed HLAs from Thief form with regards to the previous point.
- Added MakeUnselectable to resolve the button bar.


VERSION 1.2 Changes
- Innate abilities have no casting speed to prevent interruption.
- Foldername change (used to be bardkit_finalised, currently RogueSwitch)
- BWL closed free access to forum. Mod uploaded to SHS Miscellaneous Mods.

VERSION 1.1 Fixes
- bardsong did not work properly and enhanced bardsong was overwritten when you switched classes. The enhanced bardsong has been removed and instead the normal bardsong upgrades to it at level 20.
- SPL LRSW009.spl has been fixed. LRSW010.spl and LRSW011.spl are now obsolete.
- Uploaded to BlackWyrmLair. Very greatful for the exposure.

VERSION 1.0
- Uploaded to BlackWyrmLair. Very greatful for the exposure.

VERSION 1.0 Files
-----------
readme.txt           this file
setup-bardkit.tp2    installation datafile
setup-bardkit.exe    installation executable

--- tra ---
English        LRdjinn.tra: Master Switch Lines
English        setup.tra:   Installation Lines

--- 2da ---
CLABSWI.2da    CLAB for Bardic Switch: lvl1: GA_LRsw014, AP_LRsw008
CLABSWJ.2da    CLAB for Thief  Switch: lvl1: GA_LRsw015
luSWI.2da      HLA  for Bardic Switch: Nothing Special, enhanced bardsong (I hope it works)
luSWJ.2da      HLA  for Thief  Switch: Nothing Special, enhanced bardsong (I hope it works)
CLABSWK.2da    CLAB for Bardic Switch: lvl1: GA_LRsw014   Reduced Installation
CLABSWL.2da    CLAB for Thief  Switch: lvl1: GA_LRsw015   Reduced Installation
luSWK.2da      HLA  for Bardic Switch: Nothing Special    Reduced Installation
luSWL.2da      HLA  for Thief  Switch: Nothing Special    Reduced Installation

--- cre ---
LRdjinn.cre    Master Switch (The Unconscious Orog)

--- dlg ---
LRdjinn.d      Master Switch Dialogue (uses LRdjinn.tra)

--- itm ---
LRswbld1.itm   Switch Blade 1: Rng2, Wsp1, Longsw+1, thac0+1, 1d8+1, ProfLsw1, Blurred, ProtBckstb, 10%heal1 , Att/Rnd=1.5
LRswbld2.itm   Switch Blade 2: Rng2, Wsp1, Longsw+2, thac0+2, 1d8+2, ProfLsw2  Blurred, ProtBckstb, 15%heal2 , Att/Rnd=2
LRswbld3.itm   Switch Blade 3: Rng2, Wsp1, Longsw+3, thac0+3, 1d8+3, ProfLsw3, Blurred, ProtBckstb, 20%heal5 , Att/Rnd=3
LRswbld4.itm   Switch Blade 4: Rng2, Wsp1, Longsw+4, thac0+4, 1d8+4, ProfLsw4, Blurred, ProtBckstb, 25%heal10, Att/Rnd=4

--- spl ---
LRsw001.spl    Give Innate LRsw002 to the Bardic Switch. 
LRsw002.spl    Innate: Spell that creates Magical Weapon (LRswbld1,2,3,4 : lvl cutoffs 1,7,13,19)
               Duration: 36,36,36,42,48,54,60,66,72,78,84,90,96,102,108,114,120,126,132,138
LRsw003.spl    +10% Open Locks
               +10% Pick Pockets
LRsw004.spl    +10% Find Traps
               +10% Detect Illusions
LRsw005.spl    +10% Hide in Shadows
               +10% Stealth (Move Silently)
LRsw006.spl    Backstab Bonus x1
LRsw008.spl    Change Bardsong to LRsw009.spl
LRsw009.spl    BardSong: Prot: Entangle, Web, Hold
                         Cure: Entangle, Web, Hold (works locally, does it work for other people?)
                         Dex+1 
LRsw010.spl    BardSong: Prot: Entangle, Web, Hold
                         Cure: Entangle, Web, Hold (works locally, does it work for other people?)
                         Dex+3
                         Invisibility
                         Attacks Per Round +1
LRsw011.spl    Change Bardsong to LRsw010.spl (HLA)
LRsw013.spl    Give Innate LRSW016 to the Bardic Switch.
LRsw014.spl    Innate: Switch to Thief. (Remove LRsw014.spl from Innates, SetGlobal LRFORM to 2)
LRsw015.spl    Innate: Switch to Bard.  (Remove LRsw015.spl from Innates, SetGlobal LRFORM to 2)
LRSW016.spl    Innate: Spell to summon the Master Switch (LRdjinn.cre)
LRSW017.spl    Remove Spell LRSW007.spl from Innates. // not needed
               Remove Spell LRSW016.spl from Innates.


--- baf ---
LRdjinn.baf    Master Switch Script to get the dialogue running immediately
LRswitch.baf   Switch Script to do everything for this mod

Globals:
= LRFORM                   1 = do not switch class
                           2 = switch class (if bard->thief, if thief->bard)   SETBY LRSW014/LRSW015
= LRSWPICKINCREASE         0 = Default
                           1 = Increase picking  level by 1 (and token by 1)   SETBYDLGWITH(LRSW003.spl)  CALLS LRSW199
= LRSWPICK                 X = Level of picking  bonuses
= LRSWTRAPINCREASE         0 = Default
                           1 = Increase trapping level by 1 (and token by 1)   SETBYDLGWITH(LRSW004.spl)  CALLS LRSW199
= LRSWTRAP                 X = Level of trapping bonuses
= LRSWSTEALTHINCREASE      0 = Default
                           1 = Increase stealth  level by 1 (and token by 1)   SETBYDLGWITH(LRSW005.spl)  CALLS LRSW199
= LRSWSTEALTH              X = Level of stealth  bonuses
= LRCHOSEN                 0 = Has not been a bard yet, use to skip Bardic Master Switch Summon Levels
                           1 = Default
                           2 = Master Switch Dialogue bonus has been Chosen                               CALLS LRSW013
= LRDJINNGAIN              X = Every increase is a Master Switch Summon Gained, but only if you are a Bard!
= LRLVL                    X = Your own level. Used to check whether to skip Bardic Master Switch Summon Levels
= LRAVATAR                 0 = No avatar change
                           1 = Avatar changed (if human, half-elf, then become tiefling)
= LRBLADEGAIN              0 = No Switchblade gained yet
                           1 = Switchblade gained                                                         CALLS LRSW001
= LRBACKSTABGAIN           0 = No backstab gained yet
                           1 = Backstab gained                                                            CALLS LRSW006


Tokens:        Necessary for Master Switch Dialogue. Only works well if 1 Switch has ever been in the party.
= LRSWTRAP     The amount of times trapping has been increased by the Master Switch, (same as the global)
= LRSWPICK     The amount of times picking  has been increased by the Master Switch, (same as the global)
= LRSWSTEALTH  The amount of times stealth  has been increased by the Master Switch, (same as the global)

