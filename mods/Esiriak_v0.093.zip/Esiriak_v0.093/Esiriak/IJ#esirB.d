//Barters with other NPCs

BEGIN IJ#esirB

//With Aerie

CHAIN
IF ~Global("EsiriakAerie","GLOBAL",0)
    InParty("IJ#esir")
    InParty("Aerie")
    See("IJ#esir")
    !StateCheck("IJ#Esir",CD_STATE_NOTVALID)~ THEN AERIEJ Aerie-Esiriak1
~E-Esiriak? That is your name? I-I have a que-~
DO ~SetGlobal("EsiriakAerie","GLOBAL",1)~
== IJ#esirB ~Haha! Your thoughts are amusing, girl. YOu would dare as about my heritige? Very well, you will hear it, and I think you will enjoy it.~
= ~My father was Erilias, my mother Nethiriak. Both led war parties for years against the Avariel. Yes, girl, I know what you are. Anyway, they enjoyed years of plucking the wings from those pigs and watching them crawl and die in the dust at their feet...~
== AERIEJ ~W-what? No, that is not what I asked! Stop!~
== IJ#esirB ~... Until one day they brought me along for the fun...~
== AERIEJ ~No! Stop! Do not!~
== IJ#esirB ~... But I will not tell you of that, dear elf. I fear you would strike out at me, and even though I would relish crushing your weak mind, a gap in the party would not be welcome.~
== AERIEJ ~One day you will pay for what you just said...~
== IJ#esirB ~Oh, silence yourself girl. The world is not as wonderful as Quayle portrayed it. No, do not speak, silence!~ EXIT
END

CHAIN
IF ~Global("EsiriakAerie","GLOBAL",1)
    InParty("Aerie")
    InParty("IJ#esir")
    See("Aerie")
    !StateCheck("Aerie",CD_STATE_NOTVALID)~ THEN IJ#esirB Aerie-Esiriak2
~So, "winged" elf. How did you feel when you lost your wings? I could easily find out, but I think it would be best if the rest of us heard.~
DO ~SetGlobal("EsiriakAerie","GLOBAL",2)~
== AERIEJ ~After out last conversation, I refuse to converse with you, Mind Flayer.~
== IJ#esirB ~Haha; you act as if I give you a choice! Very well.~
= ~Awww, poor little elf, locked in a cage. I see the bandits had their fun with you, haha...~
== AERIEJ ~No! Do not speak of it! Please!~
== IJ#esirB ~...Diseased and dirty. Always crying. Do you cast spells to replenish your tear ducts so the world will pity you? You are pathetically weak, Aerie, and I don't see why you are even here. But saving that human child... What a noble cause! Your mother would be so proud...~
== AERIEJ ~No! Shut up! SHUT UP!~
== IJ#esirB ~Temper, temper, elf. Hahahahaha....~ EXIT
END

CHAIN
IF ~Global("EsiriakAerie","GLOBAL",2)
    InParty("IJ#esir")
    InParty("Aerie")
    See("IJ#esir")
    !StateCheck(IJ#Esir,CD_STATE_NOTVALID)~ THEN AERIEJ Aerie-Esiriak3
~Esiriak, you are cruel and heartless. How do you sleep at night, knowing the suffering you cause to all around you? How many mothers cry themselves to sleep because you have taken away their sons and daughters?~
DO ~SetGlobal("EsiriakAerie","GLOBAL",3)~
== IJ#esirB "Quiet easily, actually. Only the strong survive in this world, elf, and the weak are nothing but tools to be used. The reason you are still alive has escaped me completely. A pity you didn�t kill yourself when you were caged."
== AERIEJ ~You are evil! You care of nothing but yourself! You�re nothing but a weak coward! I- AAAAAAAAAAAAHHHHHHHHHHHHHHH!~
== IJ#esirB ~Yes, scream! Scream for mercy, bitch! You dare challenge me? Very well! If it were not for <CHARNAME>, I would rip your very skull apart, whore!~
== AERIEJ ~Get out, get out! Leave here, fiend! Lest I-I h-hurt you... <CHARNAME>! HELP!~
++ ~Get out, Illithid, lest I tell the Order of your presence!~ EXTERN IJ#esirJ Aerie-Esi3.1
++ ~Aerie, just ignore him. We need him in the party.~ EXTERN AERIEJ Aerie-Esi3.2
++ ~Just settle down, I need you both on my side, against Irenicus.~ EXTERN AERIEJ Aerie-Esi3.3
END

APPEND IJ#esirB
IF ~~ THEN BEGIN Aerie-Esi3.1
SAY ~<CHARNAME>, you may be strong but I can still tear your mind apart; this bitch is mine.~
IF ~~ THEN DO ~~ EXIT
END

APPEND AERIEJ
IF ~~ THEN BEGIN Aerie-Esi3.2
SAY ~<CHARNAME>... You, value this, "thing" above me? How? I-I will leave, then...~
IF ~~ THEN DO ~~ EXTERN IJ#esirJ Aerie-Esi3.21
END

APPEND IJ#esirB
IF ~~ THEN BEGIN Aerie-Esi3.21
SAY ~Haha! The bitch realized, finally. What she had in her head, <CHARNAME>...~
IF ~~ THEN DO ~ActionOverride("Aerie",LeaveParty())~ EXIT
END

APPEND AERIEJ
IF ~~ THEN BEGIN Aerie-Esi3.3
SAY ~<CHARNAME>... I-ih, see nothing of value coming out of this "thing". And it insulted me!~
IF ~~ THEN DO ~~ EXTERN IJ#esirJ Aerie-Esi3.31
END

APPEND IJ#esirB
IF ~~ THEN BEGIN Aerie-Esi3.31
SAY ~Aah, a wicked idea indeed. Haha! <CHARNAME>, you are surly enjoining this.~ EXIT
END

//With Anomen

CHAIN
IF ~Global("EsiriakAnomen","GLOBAL",0)
    InParty("IJ#esir")
    InParty("Anomen")
    See("IJ#esir")
    !StateCheck("IJ#Esir",CD_STATE_NOTVALID)~ THEN ANOMENJ Anomen-Esiriak1
~I am curious, Esiriak, as of why you do not offer your services to the Order? One with your... abilities would be of great value in the fight against evil.~
DO ~SetGlobal("EsiriakAnomen","GLOBAL",1)~
== IJ#esirB ~Are you blind? Or just daft? I have the form of an Illithid, you fool! The Order would kill me on sight. I do not even wish to work with such dogs, anyway. Protectors of the weak, bah! Weak should be slaughtered to make way for the strong.~
== ANOMENJ ~Spoken like a true bastard. Bah, silence yourself, Illithid. I see now you are nothing but scum, as is all your race! <CHARNAME> protects you, but go too far and I will take matters into my own hands.~
== IJ#esirB ~Yes, do that, like you did when Saerk killed your pathetic sister.~
== ANOMENJ ~You dare!~
== IJ#esirB ~Yes, I dare, human! Now be silent or I'll tell more.~ EXIT
END

CHAIN
IF ~Global("EsiriakAnomen","GLOBAL",1)
	InParty("Anomen")
	InParty("IJ#esir")
	See("Anomen")
	!StateCheck("IJ#esir",CD_STATE_NOTVALID)~ ANOMENJ Anomen-Esiriak2
~Poking around in my head again, are you, Mind Flayer Keep out of my mind, as it is none of your concern.~
DO ~SetGlobal("EsiriakAnomen","GLOBAL",2)~
== IJ#esirB ~So sorry, paladin, but I was merely wondering how you survive with such a self-righteous imp turd filling your skull.~
== ANOMENJ ~I survive and protect others, monster!~
== IJ#esirB ~The weak, you mean.~
== ANOMENJ ~Yes, the weak, if that is what you call them! Now, silence! And stay OUT of my skull!~
== IJ#esirB ~Perhaps if you tried to block me it would be a moderate challenge.~ EXIT
END

CHAIN
IF ~Global("EsiriakAnomen","GLOBAL",2)
	InParty("IJ#esir")
	InParty("Anomen")
	See("Anomen")
	!StateCheck("Anomen",CD_STATE_NOTVALID)~ IJ#EsirB Esiriak-Anomen3
~That is a better attempt, Anomen. However, you lack the mental stamina to hold it out.~
DO ~SetGlobal("Esiriak-Anomen","GLOBAL",3)~
== ANOMENJ ~What are you talking of, Esiriak?~
== IJ#EsirB ~No offence to your choice of images, but <CHARNAME>'s big toe is not the most interesting things I have seen in your head.~
== ANOMENJ ~Er...~
== IJ#EsirB ~Harharhar...!~ EXIT
END

//Anomen, if he was Knighted.  

CHAIN
IF ~Global("AnomenIsKnight",GLOBAL,1)
	Global("EsiriakAnomenG","GLOBAL",0)
	InParty("Anomen")
	InParty("IJ#esir")
	See("Anomen")
	!StateCheck("Anomen",CD_STATE_NOTVALID)~ THEN IJ#esirB Esiriak-AnomenG1
~So, human. You wish to join the order, hmm? I wonder why you have yet to reveal my existence to them, or even turn me in! Haha! It would definitely grant you a place in their halls.~
DO ~SetGlobal("EsiriakAnomenN","GLOBAL",1)~
== ANOMENJ ~I will not be baited by you, demon. I know your psionic powers far surpass my own strength.~
== IJ#esirB ~Finally, one who admits I could destroy them. Refreshing.~ EXIT
END

CHAIN
IF ~Global("EsiriakAnomenG","GLOBAL",1)
	InParty("IJ#esir")
	InParty("Anomen")
	See("IJ#Esir")
	!StateCheck("IJ#esir",CD_STATE_NOTVALID)~ THEN ANOMENJ Esiriak-AnomenG2
~So, demon. How do you remain in this Realm? Why have your masters not summoned you back?~
DO ~SetGlobal("EsirialAnomenG","GLOBAL",2)~
== IJ#esirB ~Naive fool! I escaped that place, and the only reason I have not been caught is that my... lords, cannot pinpoint me. This is why I remain moving, with you, insufferable though you are.~
== ANOMENJ ~I should have known it was for your own reasons. Do you not care for our lives, if your Lords found you?~
== IJ#esirB ~No, I do not. Now shut your mouth, lest I rip those putrid skin flaps from your withered face.~ EXIT
END

CHAIN
IF ~Global("EsiriakAnomenG","GLOBAL",2)
	InParty("Anomen")
	InParty("IJ#esir")
	See("Anomen")
	!StateCheck("Anomen",CD_STATE_NOTVALID)~ THEN IJ#esirB Esiriak-AnomenG3
~Casting me looks again, hmm? Maybe your eyes be forfeit, so you quell that habit.~
DO ~SetGlobal("EsiriakAnomenG","GLOBAL",3)~
== ANOMENJ ~Oh, silence yourself, demon. I care not for your empty threats.~
== IJ#esirB ~Hah. The Abyss would destroy you in less than an hour, with your magic filled with reveration to distant and callous gods, nor your withered mace or even your tongue will save you. Maybe I will give some introductions, to the minor there.~
== ANOMENJ ~I said silence. Hurl all the insults you wish, I will not be drawn into this pointless argument.~
== IJ#esirB ~Go hug your dead mother, paladin-to-be, maybe her icy decaying cadaver will help you in this big, bad world...~
== ANOMENJ ~Silence!~ 
== IJ#esirB ~And if I don't?~
== ANOMENJ ~I'll smite you down just like any other of the hellhounds you are.~
== IJ#esirB ~Can you really do that?~
== ANOMEN ~<CHARNAME>, he is playing with me.~
END
++ ~Yes, that's obvious, but you can resist it, so you must.~ + IJ#esirB Anofight 
++ ~Well, if you can't take it, you are always welcomed to leave.~ + Anoend 

APPEND IJ#esirB
IF ~~ THEN Anofight 
~Really?~
++ ~Yes.~ THEN EXTERN ANOMENJ AnoFigh1
++ ~No.~ THEN EXTERN ANOMENJ AnoFigh2
END

APPEND ANOMENJ
IF ~~ THEN AnoFigh1
~Indeed I can, but I don't want to.~
DO ~SetGlobal("IJ#Command1","GLOBAL",1)~ EXIT
END

CHAIN
IF ~("IJ#Command1","GLOBAL",2)~ THEN IJ#esirB 
~Th-ha-ha.~
DO ~SetGlobal("IJ#Command1","GLOBAL",3)~
++ ~What the hell happened to him?~ + IJ#esirB Anodessin
END

APPEND IJ#esirB
IF ~~ THEN Anodessin
~His own rage consumed him, because he broke the promise in the eyes of his god, and sometimes that's the result.~ EXIT
END

APPEND ANOMENJ
IF ~~ THEN AnoFigh2
~But I can, and I'll show you, I can.~
++ ~Finnished?~ + ANOMENJ AnoFight3 
END

APPEND ANOMENJ
IF ~~ THEN AnoFigh3
~Yeah.~ EXIT
END

APPEND ANOMENJ
IF ~~ THEN Anoend
~Very well then, I'll leave.~
Do ~ActionOverride("Anomen",LeaveParty())~ EXIT
END

//Anomen, if he wasn't Knighted. 

CHAIN
IF ~Global("AnomenIsNotKnight",GLOBAL,1)
	Global("EsiriakAnomenE","GLOBAL",0)
	InParty("Anomen")
	InParty("IJ#esir")
	See("Anomen")
	!StateCheck("Anomen",CD_STATE_NOTVALID)~ THEN IJ#esirB Esiriak-AnomenE1
~Looks like your dead sister saved you. Do you always rely on the cold to rescue you from things you are too scared of to face?~
DO ~SetGlobal("EsiriakAnomenE","GLOBAL",1)~
== ANOMENJ ~Speak not of my sister, fiend. You are not worthy to allow her name to slip from your forked tongue.~
== IJ#esirB ~My question stands, churl.~
== ANOMENJ ~I do not understand. Explain what goes on in that demonic mind of yours!~
== IJ#esirB ~Your dead mother saved you from your father and placed you in the Order. Your dead sister saved you from the Order. Why did you not simply kill your father in the first place? Everything would be so much simpler.~
== ANOMENJ ~You are right for once, demon. But the damage is done, and my place is now with <CHARNAME>.~ 
== IJ#esirB ~Hmph.~ EXIT
END

CHAIN
IF ~Global("EsiriakAnomenE","GLOBAL",1)
	InParty("Anomen")
	InParty("IJ#esir")
	See("IJ#Esir")
	!StateCheck("IJ#Esir",CD_STATE_NOTVALID)~ THEN ANOMENJ Esiriak-AnomenE2
~So, Esiriak. How did you escape the Abyss, exactly?~
DO ~SetGlobal("EsirialAnomenE","GLOBAL",2)~
== IJ#esirB ~Fool. I never would share the secrets of my old realm with a mortal, least of all, you.~
== ANOMENJ ~I was merely curious. Answer or not, I care not.~
== IJ#esirB ~Ha, I can read your mind, remember? Ah the panic! Hm-mm. But if you say you do not care, then I will not answer. Begone, imbecile.~ EXIT
END

CHAIN
IF ~Global("EsiriakAnomenE","GLOBAL",2)
	InParty("Anomen")
	InParty("IJ#esir")
	See("Anomen")
	!StateCheck("Anomen",CD_STATE_NOTVALID)~ THEN ANOMENJ Esiriak-AnomenE3
~Well, Esiriak, if you refuse to indulge me in the tale of your escape, then at least tell me what life was like in the Abyss.~
DO ~SetGlobal("EsiriakAnomenE","GLOBAL",3)~
== IJ#esirB ~Bloody, dark, and hard.~
== ANOMENJ ~I must know.~
== IJ#esirB ~Why the sudden interest in the Abyss, black paladin?~
== ANOMENJ ~Oh, impulse. Most of my life is based upon it now.~
== IJ#esirB ~Impulse kills. A calculated plan always prevails.~
== ANOMENJ ~Sometimes there is no time to make a plan.~ 
== IJ#esirB ~You are not Tanar�ri. I can calculate risks in a millisecond with my mind.~ 
== ANOMENJ ~A useful tactic for the party, I am sure.~ 
== IJ#esirB ~Hmph. Maybe I should not reveal the next time a beast approaches from behind. It would be interesting to see how you impulse your way out of that.~ 
== ANOMENJ ~Excuse me for complimenting you, demon. I will remain silent from now on.~ 
== IJ#esirB ~Ugh, finally!~ EXIT
END

//With Cernd

CHAIN
IF ~Global("EsiriakCernd","GLOBAL",0)
	InParty("IJ#esir")
	InParty("Cernd")
	See("Cernd")
	!StateCheck("Cernd",CD_STATE_NOTVALID)~ THEN CerndJ Cernd-Esiriak1
~Like an ever blowing reed in the wind of darkness, you remain a mystery to even one as knowledgeable to even I.~
DO ~SetGlobal("EsiriakCernd","GLOBAL",1)~
== IJ#esirB ~And like the thickest oak in this realm you shall remain oblivious. Begone.~
== CerndJ ~Very well, Esiriak, I will trouble you over your past no longer.~ EXIT
END

CHAIN
IF ~Global("EsiriakCernd","GLOBAL",1)
	InParty("IJ#esir")
	InParty("Cernd")
	See("IJ#esir")
	!StateCheck("IJ#esir",CD_STATE_NOTVALID)~ THEN IJ#esirB Cernd-Esiriak2
~So, Cernd. In our last conversation you mention being knowledgeable. What do you know of my race?~
DO ~SetGlobal("EsiriakCernd","GLOBAL",2)~
== CerndJ ~I know that they are evil, and threaten the balance of nature. As long as they remain within the Abyss, I care not on what they do.~
== IJ#esirB ~And what of me?~
== CerndJ ~You have proven yourself to live up to be a stereotypical clone of the rest of the Tanar�ri. As long as <CHARNAME> accepts your presence, so do I.~
== IJ#esirB ~Mixed feelings, then. Very well.~ EXIT
END

CHAIN
IF ~Global("EsiriakCernd","GLOBAL",2)
	InParty("IJ#esir")
	InParty("Cernd")
	See("IJ#esir")
	!StateCheck("Cernd",CD_STATE_NOTVALID)~ THEN CerndJ Cernd-Esiriak3
~Well, Tanar�ri. What exactly, if I may ask, is the nature of the magic of your plane?~
DO ~SetGlobal("EsiriakCernd","GLOBAL",3)~
== IJ#esirB ~A druid, interested in the arts of dark magic? Should have seen it coming.~
== CerndJ ~Magic is not evil itself. It is how you use it.~
== IJ#esirB ~Or how it uses you. Magic in the Abyss is not clay, to be moulded to one�s personal use. You must petition it, and be extremely careful when using it, lest it kill you, or worse, posses you and walk the Abyss.~
== CerndJ ~Interesting. Very interesting. I will think on this. Thank you for your indulgence.~ EXIT
END

//With Edwin, after...

CHAIN
IF ~Global("EsiriakEdwin","GLOBAL",0)
	Global("EsiriakConfess","GLOBAL",1)
	InParty("IJ#esir")
	InParty("Edwin")
	See("IJ#esir")
	!StateCheck("IJ#Esir",CD_STATE_NOTVALID)~ THEN EDWINJ Edwin-Esiriak1
~So, you are not really an Illithid, then?~
DO ~SetGlobal("EsiriakEdwin","GLOBAL",1)~
== IJ#esirB ~No, Red Wizard, I am not. Speak, but do it quickly.~
== EDWINJ ~So, uh, are you the only other Tanar�ri to have escaped the Abyss? The only other mage, I mean.~
== IJ#esirB ~Your intentions are painfully obvious, and I don�t even need to read your mind to know them. If you ever did find another mage, he would most likely shoot you in the face with a fireball than offer you his knowledge of spellcraft.~
== EDWINJ ~Hmph.~ EXIT
END

CHAIN
IF ~Global("EsiriakEdwin","GLOBAL",1)
	InParty("IJ#esir")
	InParty("Edwin")
	See("Edwin")
	!StateCheck("Edwin",CD_STATE_NOTVALID)~ THEN IJ#esirB Edwin-Esiriak2
~So. Edwin.~
DO ~SetGlobal("EsiriakEdwin","GLOBAL",2)~
== EDWINJ ~What, demon monkey?~
== IJ#esirB ~Have you ever met another Tanar�ri? Or a Mind Flayer?~
== EDWINJ ~Other than those I have killed, no. I would be very interested in an interrigati- conversation with one, though.~
== IJ#esirB ~Seeking what you cannot have, Red Wizard? You should realise that you are not going to get your greedy hands on any *more* demonic magic.~
== EDWINJ ~Too bad you can only read minds and not tell the future, monkey.~
== IJ#esirB ~And call me a monkey again and you�ll spend the rest of your life hopping up and down in the street with a silly hat on and a matching vest, scratching your armpits and hurling poo at every drunken passerby who happens to stray within range. Understood?~
== EDWINJ ~But, you can't cast transmutation spells!~
== IJ#esirB ~Yeah, but YOU CAN.~
== EDWINJ ~Oh... (Monkey!)~
== IJ#esirB ~I heard that.~ EXIT
END

CHAIN
IF ~Global("EsiriakEdwin","GLOBAL",2)
	InParty("IJ#esir")
	InParty("Edwin")
	See("IJ#esir")
	!StateCheck("IJ#Esir",CD_STATE_NOTVALID)~ THEN EDWINJ Edwin-Esiriak3
~GAH! I cannot take it anymore! Esiriak, demon, MONKEY! Show me some powerful Tanar�ri magic! NOW!~
DO ~SetGlobal("EsiriakEdwin","GLOBAL",3)~
== IJ#esirB ~Oh, I�m sorry, did you say something, Edwin?~
== EDWINJ ~I can�t believe your making me say this, but, ugh! PLEASE!~
== IJ#esirB ~Threats to begging? Your really getting worked up over this, aren�t you?~
== EDWINJ ~And with good reason! You radiate wizardry, and I merely wish to bask in your glory and absorb some of your knowledge.~
== IJ#esirB ~And now its flattery? If this wasn�t immensely amusing you would be munching on a carrot and sniffing your own arse by now. Although that would be hilarious as well.~
== EDWINJ ~Stupid monkey! Bah! Sooner or later I�ll get it out of you.~
== IJ#esirB ~Hah! Good luck.~ EXIT
END

//With Haer'dalis, after...

CHAIN
IF ~Global("EsiriakHairdoll","GLOBAL",0)
	Global("EsiriakConfess","GLOBAL",1)
	InParty("IJ#esir")
	InParty("HaerDalis")
	See("IJ#esir")
	!StateCheck("IJ#Esir",CD_STATE_NOTVALID)~ THEN HAERDAJ Esiriak-Hairdoll1
~So, Esiriak. I understand you are from the Abyss, but what exactly do you know about Tieflings, hmmm?~
DO ~SetGlobal("EsiriakHairdoll","GLOBAL",1)~
== IJ#esirB ~I know that they are simple chunks of meat with a swift tongue and tasty brain. That�s all I need to know, and all I want to know.~
== HAERDAJ ~I did nothing to provoke such a response, loon, but I shall leave thy be.~ EXIT
END

CHAIN
IF ~Global("EsiriakHairdoll","GLOBAL",1)
	InParty("Aerie")
	InParty("IJ#esir")
	InParty("HaerDalis")
	See("IJ#esir")
	!StateCheck("IJ#Esir",CD_STATE_NOTVALID)~ THEN IJ#esirB Esiriak-Hairdoll2
~So, Tiefling. Why do you always name everyone after birds? I am sure nobody likes being referred to as a chunk of flesh and feathers.
DO ~SetGlobal("EsiriakHairdoll","GLOBAL",2)~
== AERIEJ ~I don�t mind...~
== HAERDAJ ~Oh, my morning dove, you sweet voice melts my heart and fills it with joy the moment it reaches my unworthy ears...~
== IJ#esirB ~Oh, get a room you two. Preferably a jail cell, or maybe a torture chamber. Either will suffice.~ EXIT
END

CHAIN
IF ~Global("EsiriakHairdoll","GLOBAL",1)
	!InParty("Aerie")
	InParty("IJ#esir")
	InParty("HaerDalis")
	See("IJ#esir")
	!StateCheck("IJ#Esir",CD_STATE_NOTVALID)~ THEN IJ#esirB Esiriak-Hairdoll3
~So, Tiefling. Why do you always name everyone after birds? I am sure nobody likes being referred to as a chunk of flesh and feathers.~
DO ~SetGlobal("EsiriakHairdoll","GLOBAL",2)~
== HAERDAJ ~Oh, because doesn't everyone wish to be free to soar the skies such as the birds?~
== IJ#esirB ~If it means getting away from you, then of course. And stop calling me that lousy bird you are thinking!~ EXIT
END

CHAIN
IF ~Global("EsiriakHairdoll","GLOBAL",2)
	Global("PlanarPrison","GLOBAL",1)  //done.
	InParty("IJ#esir")
	InParty("HaerDalis")
	See("IJ#esir")
	!StateCheck("IJ#Esir",CD_STATE_NOTVALID)~ THEN HAERDAJ Esiriak-Hairdoll4
~So, loon. How does the Abyss differ from my realm?~
DO ~SetGlobal("EsiriakHairdoll","GLOBAL",3)~
== IJ#esirB ~The Abyss is much... darker. And chaotic. And bloody.~
== HAERDAJ ~Ah, but then, my realm can be like that too. If only life was as serene and pure as the light wind that breezes against the newborn babies face...~
== IJ#esirB ~I�m having second thoughts about eating your brain, Tiefling. I wouldn�t want to suffer from some disease that would turn me into you.~ EXIT
END

CHAIN
IF ~Global("EsiriakHairdoll","GLOBAL",2)
	Global("PlanarPrison","GLOBAL",0)  //not done.
	InParty("IJ#esir")
	InParty("HaerDalis")
	See("IJ#esir")
	!StateCheck("IJ#Esir",CD_STATE_NOTVALID)~ THEN HAERDAJ Esiriak-Hairdoll5
~So, loon. How does the Abyss differ from my realm?~
DO ~SetGlobal("EsiriakHairdoll","GLOBAL",3)~
== IJ#esirB ~The Abyss is most likely much... darker. And chaotic. And bloody.~
== HAERDAJ ~Ah, but then, my realm can be like that too. If only life was as serene and pure as the light wind that breezes against the newborn babies face...~
== IJ#esirB ~I�m having second thoughts about eating your brain, Tiefling. I wouldn�t want to suffer from some disease that would turn me into you.~ EXIT
END

//With Imoen after her rescue

CHAIN
IF ~Global("EsiriakImoen","GLOBAL",0)
	InParty("IJ#esir")
	InParty("Imoen2")
	See("IJ#esir")
	!StateCheck("IJ#Esir",CD_STATE_NOTVALID)~ THEN IMOEN2J EsiriakImoen1
~E-Esiriak? I have a question...~
DO ~SetGlobal("EsiriakImoen","GLOBAL",1)~
== IJ#esirB ~Make it quick, girl.~
== IMOEN2J ~I was just wondering how you demons mates. The Tanar�ri... I mean.~
== IJ#esirB ~Hahahaha! You are a strange little child. Is that sort of thing appealing to you? The taint of Bhaal within you must be stronger than you think.~
== IMOEN2J ~No, I�m just...ah, curious.~
== IJ#esirB ~Well then, if you really wish to know...~
== IMOEN2J ~What are yo- oh my god... That�s disgusting! Stop it! STOP IT!~
== IJ#esirB ~You wanted to see, girl, and now you have. I never said it would be pleasant view.~ EXIT
END

CHAIN
IF ~Global("EsiriakImoen","GLOBAL",1)
	InParty("IJ#esir")
	InParty("Imoen2")
	See("Imoen2")
	!StateCheck("Imoen2",CD_STATE_NOTVALID)~ THEN IJ#esirB EsiriakImoen2
~E-Esiriak? I have a question...~
DO ~SetGlobal("EsiriakImoen","GLOBAL",2)~
== IMOEN2J ~Oh, no reason. I was just wondering... Who gave you that cloak? That shapechanged you into a Mind Flayer.~
== IJ#esirB ~And please explain to me why you wish to know?~
== IMOEN2J ~Just-~
== IJ#esirB ~-curious. Curiosity killed the cat, as the saying goes.~
== IMOEN2J ~Good thing I�m not a cat, then. So who-~
== IJ#esirB ~Well, you might just become to be a cat food, and soon if you keep asking me that. Now shut up, or I will make you to make yourself a mouse.~ EXIT
END

CHAIN
IF ~Global("EsiriakImoen","GLOBAL",2)
	InParty("IJ#esir")
	InParty("Imoen2")
	See("IJ#esir")
	!StateCheck("IJ#Esir",CD_STATE_NOTVALID)~ THEN IMOEN2J EsiriakImoen3
~Esiriak? Uh, that is your name, isn�t it?~
DO ~SetGlobal("EsiriakImoen","GLOBAL",3)~
== IJ#esirB ~It�s Esiriak, or master to you.~
== IMOEN2J ~Ok, then, Esiriak. How does it feel to see into peoples... minds? I have tried with my magic, but...~
== IJ#esirB ~It is very... Enlightening. Or boring. Depends who�s mind I am reading.~
== IMOEN2J ~Oh, okay then... What do you see when you look in my head?~
== IJ#esirB ~I see pain. Much of it. And I see... Love? For <CHARNAME>?~
== IMOEN2J ~That�s sibling love.~
== IJ#esirB ~Of course it is. You keep telling yourself that.~
== IMOEN2J ~This makes me wonder why I even talk to you.~
== IJ#esirB ~You took the words right out of my... Mind.~ EXIT
END

//With Jaheira

CHAIN
IF ~Global("EsiriakJaheira","GLOBAL",0)
	InParty("IJ#esir")
	InParty("jaheira")
	See("IJ#esir")
	!StateCheck("IJ#Esir",CD_STATE_NOTVALID)~ THEN JAHEIRAJ EsiriakJaheira1
~So, Esiriak. How exactly did you get trapped in that form? Was the cloak forced upon you, or where you stupid enough to put it on yourself without checking for curses?~
DO ~SetGlobal("EsiriakJaheira","GLOBAL",1)~
== IJ#esirB ~Perhaps you should change yourself into a dog, druid, as its body suits you, and as a bonus, I wouldn�t have to hear your voice.~
== JAHAIRAJ ~Oh, did I strike a chord? And besides...~
== IJ#esirB ~Hmph!~ EXIT
END

CHAIN
IF ~Global("EsiriakJaheira","GLOBAL",1)
	InParty("IJ#esir")
	InParty("jaheira")
	See("IJ#esir")
	!StateCheck("IJ#Esir",CD_STATE_NOTVALID)~ THEN JAHEIRAJ EsiriakJaheira2
~Get out of my head, unnatural beast!~
DO ~SetGlobal("EsiriakJaheira","GLOBAL",2)~
== IJ#esirB ~Mahaha. Uncovering certain unpleasant memories, am I?~
== JAHEIRAJ ~It isn�t any of your business regardless!~
== IJ#esirB ~Very well, but if you ever want to hear the dying screams of your parents as they were impaled by miserable peasants-
== JAHEIRAJ ~Last warning demon!~
== IJ#esirB ~-just let me know.~ EXIT
END

CHAIN 
IF ~InParty("IJ#esir") 
	InParty("jaheira") 
	!StateCheck(IJ#esir,CD_STATE_NOTVALID) 
	Global("EsiriakJaheiraB","GLOBAL",2)~ THEN IJ#esirB EsiriakJaheira3
~Tsk tsk tsk, Jaheria. I would have thought that you would have blocked out such thoughts whilst I am around to antagonize you about them, but it seems � for once � I was wrong.~
DO ~SetGlobal("EsiriakJaheiraB","GLOBAL",3)~
= IJ#esirB ~Ah, such happy memories... *sigh*~
== JAHEIRAJ ~I warn you. Cross the line � again � and not even <CHARNAME> shall protect you.~
== IJ#esirB ~Mehehe. We�ll see, half cast, now won�t we?~ Exit
END

//With Jans 

CHAIN 
IF ~InParty("IJ#esir") 
	InParty("Jan") 
	!StateCheck(IJ#esir,CD_STATE_NOTVALID) 
	Global("EsiriakJanBanter","GLOBAL",0)~ THEN IJ#esirB Es-Jan1
~So, gnome. I hear you are quiet an adept story teller, hmm? What tales are stored in your small mind concerning the Tanar�ri?~
DO ~SetGlobal("EsiriakJanBanter","GLOBAL",1)~ 
== BJAN ~Well, once, Uncle Spanky was making this turnip soup from these magical turnips he bought from a wandering mage. He was stirring and stirring, when suddenly the soup started turning itself! Faster and faster around the soup went, until suddenly a demon burst out of it! Uncle Spanky was always a quick thinker, so he whipped off his shoe and brought his hairy, diseased foot and stuck it right up the Tanar�ri�s nose. The demon let out a terrible shriek and dropped dead! That isn�t the first time Uncle Spanky�s feet have saved the day, or killed demons! I recall this other time-~
== IJ#esirB ~Oh god, stop. Stop!  Why did I even ask you!~
== BJAN ~Well, there are tales about Mind Flayers too. Once upon a time-~
== IJ#esirB ~GAH! Silence, gnome!~
== BJAN ~Hmph.~ EXIT
END

CHAIN 
IF ~InParty("IJ#esir") 
	InParty("Jan") 
	!StateCheck(IJ#esir,CD_STATE_NOTVALID) 
	Global("EsiriakJanBanter","GLOBAL",1)~ THEN BJAN Es-Jan2
~~
DO ~SetGlobal("EsiriakJanBanter","GLOBAL",2)~ 
== BJAN ~~
== IJ#esirB ~~
== BJAN ~~
== IJ#esirB ~~
== BJAN ~~
== IJ#esirB ~~
== BJAN ~~
== IJ#esirB ~~ EXIT
END

CHAIN 
IF ~InParty("IJ#esir") 
	InParty("Jan") 
	!StateCheck(IJ#esir,CD_STATE_NOTVALID) 
	Global("EsiriakJanBanter","GLOBAL",2)~ THEN BJAN Es-Jan3
~Esiriak...~
DO ~SetGlobal("EsiriakJanBanter","GLOBAL",3)~
== IJ#esirB ~No.~
== BJAN ~But!~
== IJ#esirB ~No.~
== BJAN ~If I could just-~
== IJ#esirB ~No!~
== BJAN ~What if I-~
== IJ#esirB ~NO!~
== BJAN ~Hmph.~ EXIT
END

//Wih Nalia

CHAIN
IF ~Global("EsiriakNalia","GLOBAL",1)
	InParty("nalia")
	InParty("IJ#esir")
	See("IJ#esir")
	!StateCheck("nalia",CD_STATE_NOTVALID)~ THEN naliaJ Esiriak-Nalia1
~Esiriak-~
DO ~SetGlobal("EsiriakNalia","GLOBAL",2)~
== IJ#esirB ~Ah, not again! Just take the darn scroll already.~
== naliaJ ~What?~
== IJ#esirB ~One of your highly irritant speaches about to poor and so forth... all the while you are trying to steal the peoples magic scrolls from them.~
== naliaJ ~Wha- What are you talking about?~
== IJ#esirB ~Just these, or where else would you get them...~
== naliaJ ~Ah-~
== IJ#esirB ~No, not even <Charname> can believe you while the truth is in my hand. Now, lets just move on, shall we?~
DO ~SetGlobal("IJ#Command2","GLOBAL",1)~ EXIT
END

CHAIN
IF ~Global("EsiriakNalia","GLOBAL",1)
	InParty("nalia")
	InParty("IJ#esir")
	See("nalia")
	!StateCheck("nalia",CD_STATE_NOTVALID)~ THEN IJ#esirB Esiriak-Nalia2
~Hmm, I have comed to the conclusion that you might want to learn something new Nalia.~
DO ~SetGlobal("EsiriakNalia","GLOBAL",2)~
== naliaJ ~Ah, and what would that be?~
== IJ#esirB ~It's a new spell I have tried to make improvice, but as I don't have a clue about transmutation spells, and how it actually should go, I have nothing besides this manuscript which seems to forby my magic, would you be willing to help, as I am not able to read it? ~
== naliaJ ~Of course, I'll be happy to. Now, let me see, ah that's certainly wrong, as it should be...~ 
DO ~SetGlobal("IJ#Command3","GLOBAL",1)~ EXIT 

CHAIN 
IF ~Global("IJ#Command3","GLOBAL",2)~ THEN IJ#esirB Esiriak-Nalia3
~Hih hih hih, funny, too funny!~
DO ~SetGlobal("EsiriakNalia","GLOBAL",3)~ EXIT
END