//PCs barters with Esiriak

BEGIN IJ#esirA

CHAIN
IF ~InParty("IJ#Esir")
    InParty(Player1)
    !ActuallyInCombat()
    Global("Esiriak-PC","GLOBAL",0)~ THEN IJ#esirA Esiriak-PC1
~I can see you have something in your mind, so speak out with it.~
DO ~SetGLOBAL("Esiriak-PC","GLOBAL",1)~
++ THEN REPLY ~So I was curious, how did it happen that you ended up in Mind Flayer form, Esiriak.~ + Esiriak-PC-1
++ THEN REPLY ~Never mind.~ + Esiriak-PC-2
++ THEN REPLY ~Ah, no. I don't want to know anything.~ + Esiriak-PC-3
END

CHAIN
IF ~~ THEN IJ#esirA Esiriak-PC-1
~Ahh, well I put this Robe on and puff, I became a Mind Flayer.~
++ THEN REPLY ~So, can't you just, ah well, change back to human form?~ + Esiriak-PC11 EXIT
END

CHAIN
IF ~~ THEN IJ#esirA Esiriak-PC-2
~Haha-ha.~ 
++ THEN REPLY ~No, stop poking in to my mind and stay out!~ + Esiriak-PC-4 EXIT
END

CHAIN
IF ~~ THEN IJ#esirA Esiriak-PC-3
~Well, in that case I might as well leave, bye.~ DO ~LeaveParty()~ EXIT
END

CHAIN
IF ~~ THEN IJ#esirA Esiriak-PC11
~Hey, I am an Abjurer, I resent that, but... no. But hmm, why would I even want to be a lowsy human? I am a Tanar'ri after all.~ 
DO ~SetGlobal("EsiriakConfess,"GLOBAL",1)~
++ THEN REPLY ~What, you are a demon?~ + Esiriak-PC-5 EXIT
END

CHAIN
IF ~~ THEN IJ#esirA Esiriak-PC-4
~But the poking is the most fun part to have in this form!~
++ THEN REPLY ~Form? You said form, so how did it happen a mage of your status ended up in this form, Esiriak?~ + Esiriak-PC-1 EXIT
END

CHAIN
IF ~~ THEN IJ#esirA Esiriak-PC-5
~Yes, a demon.~ 
++ THEN REPLY ~But...~ + Esiriak-PC-6 EXIT
END

CHAIN
IF ~~ THEN IJ#esirA Esiriak-PC-6
~Yes, good news, a demon can be a mage, and that's that. Now shall we go, or shall you just stand there and look me like an idiot, all day long? I could eat your brains you know, but confused brains just taste bad.~
END