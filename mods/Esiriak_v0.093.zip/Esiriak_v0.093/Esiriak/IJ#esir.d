BEGIN IJ#esir

IF ~NumTimesTalkedTo(0) !Global("Chapter","GLOBAL",8)~ THEN BEGIN Talk1
SAY ~Ah, to jump or not to jump, that's the question, mh-haa, but do I- indeed I do! Hmm. So what a thing like you, be doing here?~
IF ~~ THEN REPLY ~I'm <CHARNAME>, but, but aren't you a Mind Flayer?~ GOTO HiThere
IF ~~ THEN REPLY ~I'm sorry, but I don't talk to strangers, especially to Illithids.~ GOTO EndTalk
END

IF ~~ THEN BEGIN HiThere
SAY ~Not exactly. I'm Esiriak and I ah, was trapped into this robe that shifted my shape into what it now is. You seem some what capable adventurer, could I join your group?~
IF ~~ THEN REPLY ~Sure, why not?~ DO ~SetGlobalTimer("IJ#esiriakTimer","GLOBAL",THREE_DAYS) SetGlobal("EsiriakJoined","LOCALS",1) SetGlobal("Esiriak-PC","GLOBAL",1) JoinParty()~ EXIT
IF ~~ THEN REPLY ~I'm afraid, so I can't accept your offer. Perhaps later.~ EXIT
END

IF ~~ THEN BEGIN EndTalk
SAY ~A Tanar'ri actually, ahh well. Just come back if you don't change your mind, I'll be here.~ 
IF ~~ THEN EXIT
END

IF ~NumTimesTalkedToGT(0)~ THEN BEGIN Talk2
SAY ~You're back! Ah well, can I join now?~
IF ~~ THEN REPLY ~Sure, why not?~ DO ~SetGlobalTimer("IJ#esiriakTimer","GLOBAL",THREE_DAYS) SetGlobal("EsiriakJoined","LOCALS",1) SetGlobal("Esiriak-PC","GLOBAL",1) JoinParty()~ EXIT
IF ~~ THEN REPLY ~On second thought, I don't think that's a good idea at all.~ EXIT
END

//Chapter 8

IF ~NumTimesTalkedTo(0) Global("Chapter","GLOBAL",8)~ THEN BEGIN Talk3
SAY ~Ahh <CHARNAME>, finally you are here, I began to worry I had missed you.~
IF ~~ THEN REPLY ~Esiriak, what in the unheaven happened to you?~ GOTO HiThere2
IF ~~ THEN REPLY ~No, I don't want this bowl of eyes.~ GOTO EndTalk2
END

IF ~~ THEN BEGIN HiThere2
SAY ~What, you don't remember the accident! Wouw, well could I still join the party.~
IF ~~ THEN REPLY ~Yeah.~ DO ~SetGlobalTimer("IJ#esiriakTimer","GLOBAL",THREE_DAYS) SetGlobal("EsiriakJoined","LOCALS",1) SetGlobal("Esiriak-PC","GLOBAL",1) JoinParty()~ EXIT
IF ~~ THEN REPLY ~No, I'll be back to pick you up.~ GOTO EndTalk2
END

IF ~~ THEN BEGIN EndTalk2
SAY ~Ahh well. I'll be here, keeping eye on things.~
END

IF ~NumTimesTalkedToGT(0)~ THEN BEGIN Talk4
SAY ~You're back! Ah well, can I join now?~
IF ~~ THEN REPLY ~Sure, why not?~ DO ~SetGlobalTimer("IJ#esiriakTimer","GLOBAL",THREE_DAYS) SetGlobal("EsiriakJoined","LOCALS",1) SetGlobal("Esiriak-PC","GLOBAL",1) JoinParty()~ EXIT
IF ~~ THEN REPLY ~On second thought, I don't think that's a good idea at all.~ EXIT
END

BEGIN IJ#esirP

IF ~Global("EsiriakJoined","LOCALS",1)~ THEN BEGIN LeaveGroup
SAY ~What? You don't need me?~
IF ~~ THEN REPLY ~My mistake, please stay.~ DO ~JoinParty()~ EXIT
IF ~~ THEN REPLY ~You suck, and worst part is that it's my brain you are doing that. Bye.~ DO ~EscapeArea()~ EXIT
END
