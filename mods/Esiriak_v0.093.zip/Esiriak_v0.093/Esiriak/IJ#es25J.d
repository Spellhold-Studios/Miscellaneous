BEGIN IJ#es25J

EXTEND_BOTTOM FATESP 6

+ ~!Dead("IJ#esir") !InMyArea("IJ#esir") Global("EsiriakSummoned","GLOBAL",0)~ + ~Bring me Esiriak, the Tanar'ri Abjurer.~ 
    DO ~CreateVisualEffect("SPPORTAL",[1999.1228])
    Wait(2)
    CreateCreature("IJ#esi25",[1999.1228],0)
SetGlobal("EsiriakSummoned","GLOBAL",1)~ GOTO 8

END