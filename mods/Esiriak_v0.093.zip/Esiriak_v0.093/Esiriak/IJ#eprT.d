BEGIN IJ#eprT

IF ~NumTimesTalkedTo(0) Global("EsiriakExists","GLOBAL",2)~ THEN BEGIN PrTPC1 
SAY ~Excuse us, but we are occupied at the moment as we have a little trouble with one of our client, but you are welcomed to watch.~ 
IF ~~ THEN REPLY ~OK, we might as well be watching closelly.~ DO ~SetGlobal("EsiriakExists","GLOBAL",3)~ EXIT
IF ~~ THEN REPLY ~Sorry, but we are out of here.~ EXIT
END

CHAIN
IF ~Global("EsiriakExists","GLOBAL",4)~ THEN IJ#eprT PrTPC2
~Thanks for wating for me to count the money. So, now that I am here, what was I to help you with.~ 
DO ~SetGlobal("EsiriakExists","GLOBAL",5)~
== IJ#esir ~Finally! Now get this cloak off me.~ 
== IJ#eprT ~Hmp, ah yes, I'll try this.~ EXIT

CHAIN
IF ~Global("EsiriakExists","GLOBAL",6)~ THEN IJ#eprT PrTPC3 
~Uh, sir, y-you are a sir, right?~
DO ~SetGlobal("EsiriakExists","GLOBAL",7)~
== IJ#esir ~Yes I am! Get on with it, Gnome!~
== IJ#eprT ~Right, right. Uh, um. Well, we are sorry, but, there is a little problem. We, uh, I can�t seem to get that cloak off.~
== IJ#esir ~What do you mean?! I payed good gold for your temple�s services, Gnome!~
== IJ#eprT ~Yes, yes, we know, but still. The enchantments on your cloak are too-too powerful.~
== IJ#esir ~Damn you Gnome! You lie! You just want my gold!~
== IJ#eprT ~No, no! T-Talos� church has gold, plenty of it! We c-can�t do it, sir. I am sorry, but you must leave. You are scaring off potential priests.~
== IJ#esir ~Gnomish bastard! You will die, you snivelling imbecilic worm!~
== IJ#eprT ~N-no! I don�t wanna die! I-I am good priest! Good to Talos! T-Talos will protect me!~ EXIT

CHAIN
IF ~Global("EsiriakExists","GLOBAL",8)~ THEN IJ#eprT PrTPC4
~Durrr... Klemno forget why Klemno here. Strange place Klemno be in. K-Klemno has stamp collecting impulses. Klemno go light a fire. K-Klemno go now. Klemno.~
DO ~SetGlobal("EsiriakExists","GLOBAL",9)~ EXIT