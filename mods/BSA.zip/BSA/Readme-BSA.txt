Name: Bad Stats Away!
Version: 1.3
Date: 6/29/2011
Category: NPCs
Author(s): Cerest
Source: http://www.shsforums.net/index.php?app=downloads&showfile=962
Forum: http://www.shsforums.net/topic/50054-bad-stats-away/

Description
===========
Tired of limited character choices because of stats? Hate having Viconia on a GOOD-aligned party? This mod is for you. This mod buffs all stock NPCs to have the core stat sum of 75 (not including charisma). This makes NPCs that you may have never liked because of their stats now valuable! Is this cheating? Maybe. But it allows some of the heavy-story characters some use in any party.

"You can just do this on Shadow Keeper! Or Near Infinity!"

This mod is meant as a bulk editor... It also means you don't have to change stats for ALL the .cre files manually each time you reinstall @_@. It has a fairly easily to understand .tp2 which you can customize if you don't like my changes.

It also includes an easy to edit excel file to help plan stats.


Details
=======
Stat changes were carefully considered on each character. Certain rules were applied.

1. No stat decreases. This is because some personal items of characters (Xan's Moonblade for example) stupidly have stat requirements. Why a depressed Elven mage has 16 charisma, I'm not sure. Why his sword requires 16 charisma is even more questioning....
2. No stats lower than 11 were boosted. There are good reasons for characters to have low stats in areas... why would Minsc have 16 int?
3. Stats that are 11 or more were upgraded by one until the sum of str, dex, cons, int, and wis equaled 75.
4. Charisma was not picked because it has little effects in the game... and characters with high charisma were nerfed because they had high stats in a relatively useless stats. Inversely, characters with low charisma benefited greatly... I did not want to deal with that.
5. 75 is picked because statistically it represents a relatively common *high* roll (an average of 15 on 5 stats). This value was initially 90 but because the charisma problem.. was lowered to 75. 90 was also the sum of stats for Solaufein :)
6. One major issue some players will have with this is that i threw racial maximums out the window. If some of the in-game NPCs... Coran for example have stats, that are above the racial-maximum... why can't all the NPCs have it? Of course, NPCs with high stats in one category lack high stats in another.
7. I've put ALL changes in a Excel Sheet :) Look inside the file folder.
8. 

This is the Charisma problem...

Look at quayle, 

8
15
11
17
19
6

Lets say I use the 90 sum and the "no stats should be increased if they are below 11"

8
19
15
20
22
6

These are ridiculously high and OP. Look at Ajantis however.

17
13
16
12
13
17

Because of charisma, he is stuck with this,

18
14
16
12
13
17

Low charisma (less than 11) allows characters to become rather uber, rather high charisma allows them to become rather... weak :P

This is of course using the 90 rule. The 75 rule assumes that charisma is 15 while keeping the same statistical rolling ease. Keep in mind some characters without this mod have higher than 75 or already 75 sums... Keiria from DSotSC has 80(!), Valygar has 75... Sarevok has 79.

Some NPCs have Mega stats... (look at Shar-Teel) but are gimped at the same time by other stats (Shar-teel still has 9 cons because of rule 2).

9. The format of this mod's .tp2 is highly organized. If you are unhappy with my changes. open up the Setup-BSA.tp2.

Ctrl+F for the character you want to change... lets say Nathaniel. You should see this...

----------------------------------------------------------------


////////////////////////
BEGIN ~NPC Nathaniel~
////////////////////////

ACTION_FOR_EACH crefile IN nath07 nath08 nath10 nath25 BEGIN
        ACTION_IF FILE_EXISTS_IN_GAME "%crefile%.cre" BEGIN
        COPY_EXISTING "%crefile%.cre" ~override~
                PATCH_IF (SOURCE_SIZE > 0x2d3) THEN BEGIN 
			WRITE_BYTE 0x238 19
        		WRITE_BYTE 0x239 100
        		WRITE_BYTE 0x23a 13
        		WRITE_BYTE 0x23b 9
        		WRITE_BYTE 0x23c 19
        		WRITE_BYTE 0x23d 15
		END
	BUT_ONLY_IF_IT_CHANGES
	END 
END 

--------------------------------------------------------------

The only values you should change are the values 0x238, 0x239, 0x23a, 0x23b, 0x23c, 0x23d. These stand for Strength, strength bonus, intelligence, wisdom, dexterity and constitution. Note... this is NOT the order you see in-game. In-game you see Strength/Strength Bonus, Dexterity, Constitution, Intelligence, and Wisdom.

Edit these values as you see fit, for example... "0x23a 13" means 13 intelligence... "0x23b 9" means 9 wisdom and reinstall to apply the changes. Use the excel file to help you! Note... the strength proficiency should be 1-100 for characters with 18 str, but should be 100 for characters with 19 or more!

Currently, this mod edits the stats of...
ALL Default BG1, BG2, NPCs.
Nathaniel
Faren
TDD
DSotSC
Solaufein
Kelsey
Deheriana
Auren
Gavin
Iylos
Sarah
Valen
Xulaye
Yasraena

Finally, it is easy to add support for any NPC you pick up...

Copy and paste the Nathaniel section above to the bottom of the tp2. Rename the section! Open Near Infinity (http://www.idi.ntnu.no/~joh/ni/download.html) and search for the name of your character in the Cre/itm section. You should get a list of file names. Some of these file names will be needed, some are extras. Some mods have mutiple .cre of the same NPC at different levels. Some of your results will be these. Some of your results will be plain extras. Search for Jan for example and you'll get AJANtis in the mix too. After you have a good idea of what mods are your NPCs, delete the Nath07, nath08, nathwhatever and replace them with your own. Edit the stats and you are done!

After you RENAMED THE SECTION, and edit values to what you like and put in the appropriated names... reinstall.

Installation
===============

This is in Weidu Format... Come on -_-

Even if you do not have the mod (Nathaniel for example), you can safely install it. You can install the Aerie Stats mod in a BG1 game.... the installer won't fail... it just won't do anything. Thus, after you've looked at the excel I gave you... (you have looked at it right?) you can just choose to install every component. I recommended that you choose to install all... and if you are unhappy with some stats... to change it in the .tp2 rather than sitting and manually sifting through all 59 components of this mod @_@

Incompatibility
===============

Compatible with ALL mods. You can install this over the BWP installation if you would like. Feel free to post components of NPCs you have made in the forum so I can add it to the main download!

Known Issues or Bugs
====================
@_@ Tell me please.

History
=======

6/21/2011 - 1.0
*Initial release

6/21/2011 - 1.1
*Recoded so it actually works :P

6/24/2011 - 1.2
*Added NPCs

6/29/2011 - 1.3
*Recoded :O


Contact
=======
Cerest @ Spell Hold Studios

Credits
=======
the Bigg and Westley Weimer for Weidu
Jon Olav Hauglid for Near Infinity
Wisp for answering a stooopid question of mine
Thank you berelinde for pointing out my error...
And thank you cmorgan for suggesting a better code @_@
My mother for giving birth to me
My father for donating his valuable swimmers
My mother's mother...
My mother's father...
My father's mother...
.............
......
...
.

Tools Used
==========
7-Zip - http://www.tesnexus.com/downloads/file.php?id=15579
Readme Generator - http://HammondsLegacy.com/obmm/tools_readme_generator1.asp

Licensing/Legal
===============
You can do whatever you want with this mod but don't complain to me if it
doesn't work or your PC blows up or you get a terrible sexually transmitted disease.