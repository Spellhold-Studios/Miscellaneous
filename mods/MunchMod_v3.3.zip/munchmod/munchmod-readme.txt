// Weidu version compiled by hlidskialf.
// Report bugs to hlidskialf
// at http://forums.forgottenwars.net/index.php?s=483ae7e6e34f897b616e5389742eb0bc&showforum=127.
// I'll try to fix 'em. Note: Game balance issues are NOT bugs. Heh. Cheers. ;)


Mod was made by Sigwald, who also helped alot with bugfixing TDD.

Main changes:

Arkvisti the Peddler. A wandering old elf that travels around Faerun,
Arkvisti has many wares to offer to rich customers.
His artefacts do not come cheap, but they are unique and worth the price!

Trademeet blacksmith is looking for rare components in order to forge the fabled Spear of the Phoenix and
Mithril Defender. 

Cromwell can forge a new item, Deathbringer.

Affected creatures:
Qilue, Drow Priestess
Glaicas, d'Arnise Commander
Maevar, Renegade Shadow Thief
Lea'Liyl, Demon of the Planar Sphere
Shade Lord, Temple Ruins
Adratha, rakkasha hunted by Djinns
Vithal, imprisoned mage in the Underdark

Affected quests:
Saving Raelis and Haer'dalis from Planar prison
Investigation of the Beholder Cult
Finding the Lanthorn
Lathander/Talos temple conflict
Rescuing the Svirfneblin child
Helping the Svirfneblin village
Saving Garren's child
Druid grove challenge
Helping Vithal in the Portals quest
Destroying the Slavers
Escaping the Asylum prison
Infiltrating Deirex's tower
End the Sagauhin village's conflict
Drow encounter in the Underdark

Affected stores:
Various Drow shopkeepers in the Underdark
Trademeet blacksmith
Caravan merchant in Trademeet
Fael the Umar hill bookseller
Galoomp in Waukeen Promenade
Brynnlaw equipment storekeeper


// Note: as of v2.1 the mod will ADD to the stores, not overwrite existing ones.

v2.5 contains several bits of altered/improved code as well as solving the Vithal-crash bug.
(Mage imprisoned in the underdark.)

V2.6 With Spanish translation. Much thanks to Clan REO!
(Sorry for the delay on this gang, but I hate working with .tra files.)

v2.7 (08 June 2009 by Leomar)
- Added BGT compatibility in sbaldur.baf (thanks to White Agnus)
- Deleted English line in Spanish LANGUAGE command
- Added VERSION-flag
- Updated to WeiDU v210

v2.8 (05 November 2009 by White Agnus and Leomar)
- Improved cre and store patching
- Added AR2210.are script assigntment
- Changed REPLACE to EXTEND in dialogues
- BGT variable is not needed anymore
- Changed to README command
- Updated to WeiDU v211

v2.9 (30 November 2009 by White Agnus and Leomar)
- Compatibility fixes for NeJ, CtB Chores, TS-BP, RoT, Saerileth NPC and Tales of Anegh
- Fixed DeathVariable for Elminster
- Updated to WeiDU v212

v3.0 (11 January 2010 by Leomar)
- Added Russian translation by aVoddle & aerie.ru updated by Prowler
- Updated to WeiDU v213

v3.1 (18 March 2010 by Leomar)
- Wisp's Cromwell dialog fix - snip/sAR0334.BAF and dlg/Crommy.D
  (http://www.shsforums.net/topic/44247-cromwell-dialog-broken-doesnt-detect-all-items)
- Lollorian's monk boots usability fix - SGBOOT2.ITM
  (http://www.shsforums.net/topic/44268-bug-in-munchmod/page__view__findpost__p__477762)
- Added Spanish translation by Ancalagon el Negro

v3.2 (20 March 2010 by Leomar)
- Lollorian's CtB compatibility check fix - setup-munchmod.tp2
  (http://www.shsforums.net/topic/33489-new-resurrected-mod-updates/page__view__findpost__p__482148)

v3.3 (01 April 2010 by Leomar)
- Added Polish translation and readme by cuttooth
- Updated to WeiDU v215
