

REPLACE_SAY ~TRMER04~ 7 @0

EXTEND_BOTTOM ~TRMER04~ 7
 IF~~THEN REPLY @1 GOTO Old_7
  IF ~Global("SGshieldforged","GLOBAL",0)
Global("SGspearforged","GLOBAL",0)~ THEN REPLY @2  GOTO MM8
  IF ~Global("SGshieldforged","GLOBAL",1)
Global("SGspearforged","GLOBAL",0)~ THEN REPLY @2 GOTO MM15
  IF ~Global("SGshieldforged","GLOBAL",0)
Global("SGspearforged","GLOBAL",1)~ THEN REPLY @2  GOTO MM16
END

APPEND TRMER04

IF ~~ THEN BEGIN MM8 // from: 7.2
  SAY @3 /* #74374 */
  IF ~PartyHasItem("SHLD27")
PartyHasItem("SGMISC1")
Global("SGshieldforged","GLOBAL",0)~ THEN REPLY @4  GOTO MM9
  IF ~PartyHasItem("SGMISC2")
PartyHasItem("SGMISC3")
Global("SGspearforged","GLOBAL",0)~ THEN REPLY @5  GOTO MM12
  IF ~~ THEN REPLY @6  EXIT
END

IF ~~ THEN BEGIN MM9 // from: 16.0 8.0
  SAY @7 
  IF ~PartyGoldGT(7499)~ THEN REPLY @8  DO ~TakePartyGold(7500)
DestroyGold(7500)
~ GOTO MM10
IF ~PartyGoldLT(7500)~ THEN REPLY @9 EXIT
  IF ~~ THEN REPLY @10  EXTERN ~TRMERC04~ 5
END

IF ~~ THEN BEGIN MM10 // from: 9.0
  SAY @11 
  IF ~~ THEN DO ~TakePartyItem("SHLD27")
DestroyItem("SHLD27")
TakePartyItem("SGMISC1")
DestroyItem("SGMISC1")
GiveItemCreate("SGSHLD1",LastTalkedToBy,1,0,0)
SetGlobal("SGshieldforged","GLOBAL",1) ~ GOTO MM13
END

IF ~~ THEN BEGIN MM11 // from: 12.0
  SAY @11 
  IF ~~ THEN DO ~~ GOTO MM14
END

IF ~~ THEN BEGIN MM12 // from: 15.0 8.1
  SAY @7 
  IF ~PartyGoldGT(7499)~ THEN REPLY @8  DO ~TakePartyGold(7500)
DestroyGold(7500)~ GOTO MM11
IF ~PartyGoldLT(7500)~ THEN REPLY @9 EXIT
  IF ~~ THEN REPLY @10  EXIT
END

IF ~~ THEN BEGIN MM13 // from: 10.0
  SAY @12 
  IF ~~ THEN EXIT
END

IF ~~ THEN BEGIN MM14 // from: 11.0
  SAY @13 
  IF ~~ THEN EXIT
END

IF ~~ THEN BEGIN MM15 // from: 7.3
  SAY @14 /* #74379 */
  IF ~~ THEN REPLY @5  GOTO MM12
  IF ~~ THEN REPLY @10  EXIT
END

IF ~~ THEN BEGIN MM16 // from: 7.4
  SAY @15 /* #74380 */
  IF ~~ THEN REPLY @4  GOTO MM9
  IF ~~ THEN REPLY @10  EXIT
END

  IF ~~ THEN BEGIN Old_7
    SAY @16
    COPY_TRANS TRMER04 7
  END
END