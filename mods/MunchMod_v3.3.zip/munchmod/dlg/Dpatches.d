
REPLACE_ACTION_TEXT BHARVAL ~GiveGoldForce(8000)~ ~GiveGoldForce(8000)
GiveItemCreate("SGAMU2",LastTalkedToBy,0,0,0)~


REPLACE_ACTION_TEXT BHNALLA ~GiveGoldForce(7000)~ ~GiveGoldForce(7000)
GiveItemCreate("SGAMU3",LastTalkedToBy,0,0,0)~


REPLACE_ACTION_TEXT BHOISIG ~GiveGoldForce(8000)~ ~GiveGoldForce(8000)
GiveItemCreate("SGAMU4",LastTalkedToBy,0,0,0)~


REPLACE_ACTION_TEXT C6ELHAN2 ~EraseJournalEntry(57914)~ ~EraseJournalEntry(57914)
GiveItemCreate("SGLEAT1",Player1,0,0,0)~


REPLACE_ACTION_TEXT CECHALLE ~GiveItemCreate("STAF13",LastTalkedToBy,0,25,25)~ ~GiveItemCreate("STAF13",LastTalkedToBy,0,25,25)
GiveItemCreate("SGLEAT2",LastTalkedToBy,0,0,0)~


REPLACE_ACTION_TEXT GARREN ~SetGlobal("NoXpRepeat","LOCALS",1)~ ~SetGlobal("NoXpRepeat","LOCALS",1)
GiveItemCreate("SGMISC1",LastTalkedToBy,0,0,0)~


REPLACE_ACTION_TEXT RAELIS ~EraseJournalEntry(46851)~ ~EraseJournalEntry(46851)
GiveItemCreate("SGAMU1",LastTalkedToBy,0,0,0)~


REPLACE_ACTION_TEXT SCSAIN ~TakePartyItem("RING38")~ ~TakePartyItem("RING38")
GiveItemCreate("SGCLCK3",LastTalkedToBy,2,3,0)~


REPLACE_ACTION_TEXT SCYARRYL ~TakePartyItem("RING38")~ ~TakePartyItem("RING38")
GiveItemCreate("SGCLCK3",LastTalkedToBy,2,3,0)~


REPLACE_ACTION_TEXT UDSVIR03 ~GiveItemCreate("blun18",LastTalkedToBy,1,1,1)~ ~GiveItemCreate("blun18",LastTalkedToBy,1,1,1)
GiveItemCreate("SGHAMM1",LastTalkedToBy,0,0,0)~


REPLACE_ACTION_TEXT UDSVIR05 ~GiveItemCreate("brac14",LastTalkedToBy,1,1,1)~ ~GiveItemCreate("brac14",LastTalkedToBy,1,1,1)
GiveItemCreate("SGAXE1",LastTalkedToBy,0,2,0)~ 


REPLACE_ACTION_TEXT UDVITH ~SetGlobal("udMind","GLOBAL",41)~ ~SetGlobal("udMind","GLOBAL",41)
GiveItemCreate("SGHELM2",LastTalkedToBy,0,0,0)~

