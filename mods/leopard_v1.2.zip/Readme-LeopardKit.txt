
                    ---------------------------
                     Animal Companion: Leopard
                            version 1.2
                    ---------------------------

Bonus Ranger Kit for Baldur's Gate II: Throne of Bhaal.

NB: This kit is not intended to be played in single-player games. The
proper usage is to create a multi-player game and create a Leopard
character in one or more of the character slots (although NEVER in the
first character slot.)



Install:
--------

Extract all files to the folder BGII is installed to.
Run Setup-HeartwarderKit.exe and follow the prompt.

In-game, in order to create a Leopard during character creation,
select your preferred gender, then the human race, then the ranger
class, and then the Leopard kit.



Description:
------------

The leopard is one of the big cats and a powerful predator. Strong,
agile and highly intelligent, the leopard is a common animal companion
for druids and rangers everywhere.

Advantages:
- +1 to strength, +3 to dexterity
- Can gain mastery in natural weapon proficiencies
- +1 bonus to hit and damage at 1st level, gains an additional
    +1 every 6 levels
- +5 bonus to AC at 1st level, gains an additional +1 at
    levels 2, 3, 5, 7, 10, 13, 16, 20, and every 5 levels afterwards
- Can backstab foes for double damage (triple damage from level 8)
- Infravision
- +6 to movement rate, gains an additional +1 every 5 levels
    (up to level 20)

Disadvantages:
- -2 to constitution, -4 to intelligence
- Cannot initiate dialog
- Cannot use items of ANY type
- Can only carry one item at a time in inventory
- Cannot cast spells

ATTACKS: The leopard uses club proficiency for claw attacks and dagger
proficiency for bite attacks. Its attacks always count as fighting
with two weapons.



Known issues:
-------------

Although not restricted in alignment like other rangers are, the
Leopard will still become a fallen ranger when the party's reputation
drops too low. However, once the party's reputation is restored to a
value of 10 or more, the Leopard will regain its class and abilities.
[For this the Party AI option must be turned on.]

The leopard may lose its "placeholder" items or special attacks after
being resurrected, or at the beginning of Baldur's Gate II. However,
the items will be restored instantly should this happen. [In order for
the items to be restored the Party AI option must be turned on.]



Version History:
----------------

v1.0: Initial release
v1.1: Added infravision
      Greatly improved stability by enhancing the way natural weapons
        are applied
v1.2: Fixed a bug that prevented the leopard from leveling up



Portrait and Sound:
-------------------

Character Portrait: Goldenwolf (look up her amazingly creative gallery
  on DeviantArt)
Character sounds: Gathered from JungleWalk.com



Credits:
--------

by Adul (adul@adul.net)

Special thanks to Miloch, AG, and Icendoan at SHS forums for helping
  my work with their suggestions.



Thanks for downloading!
