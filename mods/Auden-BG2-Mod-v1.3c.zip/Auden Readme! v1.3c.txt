BG2: The Auden NPC Mod. v1.3b, dated 8/22/11.

CHANGELOG:
v1.3c
 - Numerous bugfixes, mostly relating to interjection code causing nasty errors (permanent hostility, etc.).
 - A new PC / Auden banter.
 - Several new NPC / Auden banters. Aerie, Yoshimo, and Minsc. Still working on more.


v1.3b (so named because it contains only bugfixes and no new content, aside from music)
 - Added "custom music". Should work without clashing w/ existing music, but let me know if anything weird happens. It will fire whenever a PC/Auden banter starts.
 - Fixed a problem with all of Auden's PC-NPC banters "cascading" all at once.
 - Reupholstered the entire coding apparatus to a more efficient and workable concept (much obliged to mr. Zyraen for the assist) and left NPC/NPC banters to the whim of the native BG2 banter engine. Less hassle, and more natural-feeling, at least it should be.
 - Fixed some typos in variable placement causing the Auden-Yoshimo initial banter to repeat ad nauseam. Check your work kids!

v1.3
 - A few new Jaheira banters.
 - A few new PC-Auden banters, one of which will only trigger after the last Jaheira banter.
 - Adjusted banter timers to make them a bit longer. Should fire every ~40 minutes.
 - Added a couple of new "innate abilities" to the character, to be added once certain banter increments have been reached (and Auden's level hits a certain number, where appropriate). The abilities are functionally identical to the Mirror Image / Oracle / Minor Spell Deflection mage spells, usable once per day. Many thanks to Zyraen at Spellhold Studios for the coding direction on that one.

v1.2
 - Edited / tidied up dialogs / banters.
 - Whole boatload of interjections added, in conversations right up through Suldenesslar (spent a good night combing through the CREs with Infinity Explorer, looking for good spots).
 - First banters w/ Aerie, Viconia, and Jan added. All banters should fire - unwittingly used a 9 character name with the 8 character naming convention and that caused a few stutters with Minsc, but they've been smoothed out, at least if debug mode is to be believed.
 - Added ~InParty(name)~ conditions to the baf banter code. Now the Auden-NPC banter timers will start only when either the Bio CNPC or Auden joins the party, whichever comes first.
 - Fixed interjection bug causing Auden to hijack Lord Firkraag's script, thus causing him to drop out of the party and disappear, and Firkraag to stand in place and yell out to the PC for all eternity. Just bumped it up a few lines, so it's out of sync with everybody else in the party who comments, but it still makes sense. I discovered how to fix this without moving the interject but I'm frankly too lazy to bother.

v1.1
 - Edited / tidied up existing dialogs.
 - First two PC-Auden banters implemented and tested. They won't make much sense if you pick Auden up after making the Spellhold run, but I'll cross that bridge when everything else has been done.
 - First banters with Minsc / Jaheira / Yoshimo added. CTRL+I causes them to fire, but beyond that they are untested.
 - A handful of interjections have been thrown in, no reason why they shouldn't work. There are a few related to the slaver eradication quest in the Slums, one when meeting Lord Fierkraag in the Copper Coronet, plus one when starting up Renal Bloodscalp's quest, and a random interject with a beggar (at this point I'm going for interjections on par with or slightly more frequently than standard CNPCs).

v1.0b
 - After many hours of labor, found the error in my code causing the kickout / rejoin dialogs to mess up. Big ups to vilkacis over at SA for pointing out the initial flaw - turns out the naming convention I used was one letter too long.
 - Changed the names (and contents, where appropriate) of every relevant file to reflect the new, non-conflicting author prefix (BJ#, because why not).
 - BJ#Auden.baf scripting error fixed, prefixes corrected.
 - Dialogue editing and text cleanup, particularly re: The joining dialogue. More opportunities to opt out of conversation, a more "evil" (read: Dickish) way of starting it, and  few more places where you can solicit his joining.
 - First PC-Auden banter written and implemented. Should fire about 12 minutes after joining!


__________________

KNOWN ISSUES (as of v1.3):
 - Not sure if I should keep the Jaheira / Auden "conflict" banters. I'm not the best judge of my own rusty writing, so I need feedback as to whether it works, flows together, makes sense, or if it's even a serviceable idea in the first place.
 - Some editing probably needs to be done on the later banters and the second / third / fourth Jaheira banters.
 - Some of the banters haven't been tested "in the wild", that is, without CTRL+I debug testing. So all the coding will allow for them to work, theoretically, but who knows.

_________________

A FEW WORDS FROM ME

Hello,

If you are reading this, congratulations, you are about to bear witness to the culmination of nearly a week's worth of work by yours truly, Pop, or thepopstalinist, or however it you know me, if you know me (hopefully you do, if you've nicked a copy of this at such an early stage in the process).

So I've always wanted to make a BG2 NPC mod, for a few reasons. One is that I still remember how my mind was blown by experiencing Bioware's seemingly random system of intraparty interaction for the first time, and I feel as though it has yet to be topped by anything they've done since (not just for arbitrary "first cut is the deepest" reasons either! Bioware's design philosophy changed drastically and for the worse from NWN1 on). The other is that I found myself not particularly enjoying many of the NPC mods currently available. Two things are to blame, in my estimation - the Forgotten Realms setting and romances. Neither of these are anyone's fault, really. The classic knock against FR is that it's packed fully of epic Mary Sues (oh hey Drizzt), which is pretty valid (or was, before the 4th edition shakeup, which has its own faults!). A lot of NPC mods fall into the trap of going overboard making their additions interesting, and with the level of background noise (so to speak) in the setting you've got to get pretty loud with your ideas to seem unique. Again, nobody's fault. Romances, on the other hand, just don't lend themselves to the RPG gaming format, in my personal opinion. I've never really liked them in any capacity.

I've always loved the concept of monks, and I was surprised that none of the even halfway-high profile NPC mods introduced one to the game. So instead of complaining, I'm doing it myself. Auden (I realized I was one letter away from "Auren" far too late. Sorry Kat Bella.) was originally going to have a fairly exotic backstory involving a blinding industrial accident and the pursuit of monastic life as physical and mental reparative therapy, but I soon realized that was falling into the Mary Sue trap and there was no way I was gonna fit in all that info gracefully via banters and the like. So he was scaled back to "former soldier traveling through Amn". 

Why is Auden a monk? Why is he in Amn? Who knows! I do, but I'm not telling (unless you ask). I've decided to release what I have because I finally got my WeiDU package to work (good feeling!) and I figured I'd get a bit of feedback on what little I've done so far. 

*WHERE THINGS ARE NOW*
The SoA portion of the Auden mod is nearly complete! I just have to do a lot of writing / coding for more party banters, which shouldn't be too hard. I would like to institute some light quest / cutscene stuff for the latter part of the game, but I'm not yet sure of how to accomplish that, and it may make more sense in ToB anyway. There are also some "innate abilities" Auden should organically accrue. I was originally just going to implement this on a level-by-level basis but figured it might make more sense woven into the PC banter coding. I'm contemplating adding more variety dependent on interactions and maybe different party configurations (stuck with Keldorn? Auden gains +2 strength, etc.) but this could potentially be cheesed and it's probably overkill anyway. Note to self: Possible cheese / non-cheese versions of same mod?

__________________

IF THAT WAS TL;DR, THIS IS WHAT YOU NEED TO KNOW:

 - Includes Auden, a LN monk, mid-8th level I believe, in the Copper Coronet, tucked away in the opium den down the hall from the slave pens next to the secret sewer passage. Get the pass from Lehtinan and track him down. If you don't want him to join you, there are some things about Athkatla you can idly ask him about. When joined he has a custom innate ability that is the equivalent of a Faith of Armor spell, just for kicks.
 - Portrait and soundset are nicked from IWD2 (red-robed tattoo guy and m_HOW2, respectively), though the portrait is slightly altered. I am only good enough with paint to swap out the colors of the guy's eye tat. If anybody wants to give me a hand tweaking the image a little more (maybe changing his cowl color to white or blue), please let me know!
 - Banters! Interjections!
 - Almost done!

------

If you've got any suggestions, critiques, complaints, whatever, hit me up at thepopstalinist@gmail.com, I'll do whatever I can for you.

Whatever,
Pop / thepopstalinist / Danzig! / KvP