@echo off
del override\BJ#Song.wav
del override\BJ#Song.ogg