BEGIN BJ#AudeJ

INTERJECT_COPY_TRANS FIRKRA01 1 BJ#AudenFirk
== BJ#AudeJ IF ~InParty("BJ#Auden") InMyArea("BJ#Auden")~ THEN
~There is something about this man... I have not seen him here before, but he exhibits none of the latent anxiety that the hedonistic nobles here do. Odd.~
END

INTERJECT_COPY_TRANS RENAL 22 BJ#AudenRenal
== BJ#AudeJ IF ~InParty("BJ#Auden") InMyArea("BJ#Auden")~ THEN
~Rooting out subterfuge in the guild of thieves. How ironic.~
END


INTERJECT_COPY_TRANS ARAN 49 BJ#AudenAran1
== BJ#AudeJ IF ~InParty("BJ#Auden") InMyArea("BJ#Auden")~ THEN
~Hmph. Promises make debts, and from debts spring promises. No doubt this payoff is the first favor among many.~
END

INTERJECT_COPY_TRANS BEELOO 1 BJ#AudenBeeloo1
== BJ#AudeJ IF ~InParty("BJ#Auden") InMyArea("BJ#Auden")~ THEN
~More of them. Wonderful.~
END

INTERJECT_COPY_TRANS2 HAEGAN 1 BJ#AudenSlaver1
== BJ#AudeJ IF ~InParty("BJ#Auden") InMyArea("BJ#Auden")~ THEN
~Be resigned to death, scum. Even the vermin shall repulse from your corpse.~
END

INTERJECT_COPY_TRANS2 HAEGAN 2 BJ#AudenSlaver2
== BJ#AudeJ IF ~InParty("BJ#Auden") InMyArea("BJ#Auden")~ THEN
~Be resigned to death, scum. Even the vermin shall repulse from your corpse.~
END

INTERJECT_COPY_TRANS2 HAEGAN 3 BJ#AudenSlaver3
== BJ#AudeJ IF ~InParty("BJ#Auden") InMyArea("BJ#Auden")~ THEN
~Be resigned to death, scum. Even the vermin shall repulse from your corpse.~
END

INTERJECT_COPY_TRANS2 HAEGAN 5 BJ#AudenSlaver4
== BJ#AudeJ IF ~InParty("BJ#Auden") InMyArea("BJ#Auden")~ THEN
~Be resigned to death, scum. Even the vermin shall repulse from your corpse.~
END

INTERJECT_COPY_TRANS HENDAK 19 BJ#AudenHendak1
== BJ#AudeJ IF ~InParty("BJ#Auden") InMyArea("BJ#Auden")~ THEN
~There is no greater blight on civilization than slavery. We should bring justice to these people with all haste.~
END

INTERJECT_COPY_TRANS2 RUFPAL2 5 BJ#RUFPAL2-1
== BJ#AudeJ IF ~InParty("BJ#Auden") InMyArea("BJ#Auden")~ THEN ~As dull as these louts are, the ringleader seems rather sure of himself. I hope you know what you're doing, <CHARNAME>.~
END

INTERJECT_COPY_TRANS KALAH2 7 BJ#KALAH2-1
== BJ#AudeJ IF ~InParty("BJ#Auden") InMyArea("BJ#Auden")~ THEN ~Hmph. Hard as others may have been towards him, it was his desire for their affirmation that led him to this point. What a sorry soul.~
END
INTERJECT_COPY_TRANS KALAH2 8 BJ#KALAH2-1
== BJ#AudeJ IF ~InParty("BJ#Auden") InMyArea("BJ#Auden")~ THEN ~Hmph. Hard as others may have been towards him, it was his desire for their affirmation that led him to this point. What a sorry soul.~
END

INTERJECT_COPY_TRANS KALAH2 9 BJ#KALAH2-1
== BJ#AudeJ IF ~InParty("BJ#Auden") InMyArea("BJ#Auden")~ THEN ~Hmph. Hard as others may have been towards him, it was his desire for their affirmation that led him to this point. What a sorry soul.~
END

INTERJECT_COPY_TRANS2 HENDAK 1 BJ#HENDAK1
== BJ#AudeJ IF ~InParty("BJ#Auden") InMyArea("BJ#Auden")~ THEN ~The proprietor of this place does not see fit to hire skilled guardsmen... Were we to free these men I have no doubt they would gain the upper hand quickly. I would encourage you to aid this man's escape, but I leave the choice to you.~
END

INTERJECT_COPY_TRANS2 SEWERM1 23 BJ#SEWERM1-23
== BJ#AudeJ IF ~InParty("BJ#Auden") InMyArea("BJ#Auden")~ THEN ~Fascinating... What spirit would possess a man for so long in such a state?~
END

INTERJECT_COPY_TRANS2 VICONI 2 BJ#VICONI2
== BJ#AudeJ IF ~InParty("BJ#Auden") InMyArea("BJ#Auden")~ THEN ~If you trust this woman, <CHARNAME>, I am unopposed to her traveling with us. She certainly wouldn't make the group any stranger than it already is.~
END

INTERJECT_COPY_TRANS2 TOLGER 75 BJ#TOLGER7
== BJ#AudeJ IF ~InParty("BJ#Auden") InMyArea("BJ#Auden")~ THEN ~The veneer of respect for law and order this man wears is parchment-thin. If he does not respect you enough to fairly establish an agreement, then he cannot have any intention of keeping to it.~
END

INTERJECT_COPY_TRANS2 INSPECT 13 BJ#INSPECT13
== BJ#AudeJ IF ~InParty("BJ#Auden") InMyArea("BJ#Auden")~ THEN ~Perhaps the question to ask is why the murderer doesn't target merchants, or nobles... Such crimes would surely bring much greater attention. There is sense in this senselessness. Be wary, <CHARNAME>. I suspect we are witnessing something much more sinister than simple bloodlust.~
END

INTERJECT_COPY_TRANS2 FIRKRA02 21 BJ#FIRKRA02-21
== BJ#AudeJ IF ~InParty("BJ#Auden") InMyArea("BJ#Auden")~ THEN ~Much as I imagine you might want to reject this invitation, I would remind you that discretion is the better part of valor... We should at least rest and prepare if we are to take on such a formidable task as slaying this wyrm.~
END

INTERJECT_COPY_TRANS2 RYLOCK 24 BJ#RYLOCK24
== BJ#AudeJ IF ~InParty("BJ#Auden") InMyArea("BJ#Auden")~ THEN ~It seems one cannot engage in a good deed without being mired in drudgery. Let's get this over with, shall we?~
END

INTERJECT_COPY_TRANS2 LUSETTE 11 BJ#LUSETTE11
== BJ#AudeJ IF ~InParty("BJ#Auden") InMyArea("BJ#Auden")~ THEN ~That was an awfully great amount of scheming for a killing I'm sure we would have gladly provided had we been asked.~
END

INTERJECT_COPY_TRANS2 EDWIN 8 BJ#EDWIN8
== BJ#AudeJ IF ~InParty("BJ#Auden") InMyArea("BJ#Auden")~ THEN ~Attacking a mage in his own home is... not the smartest plan. But we're going to accomplish much more difficult things in the future, I imagine. I suggest you take this opportunity to prepare against whatever spells he may employ.~
END

INTERJECT_COPY_TRANS2 EMBARL 6 BJ#EMBARL6
== BJ#AudeJ IF ~InParty("BJ#Auden") InMyArea("BJ#Auden")~ THEN ~Perhaps not the choice I would have made, but I'm sure it will suit our ends in any event.~
END

INTERJECT_COPY_TRANS2 EDWIN 26 BJ#EDWIN26
== BJ#AudeJ IF ~InParty("BJ#Auden") InMyArea("BJ#Auden")~ THEN ~Thayan loyalty, in all its splendor.~
END

INTERJECT_COPY_TRANS2 EDWIN 30 BJ#EDWIN30
== BJ#AudeJ IF ~InParty("BJ#Auden") InMyArea("BJ#Auden")~ THEN ~I recognize that a Thayan spellcaster would be useful to the group, but you should be cognizant of potential conflicts within it. Things may become... heated.~
END

INTERJECT_COPY_TRANS2 RIFTG03 7 BJ#RIFTG03-7
== BJ#AudeJ IF ~InParty("BJ#Auden") InMyArea("BJ#Auden")~ THEN ~I imagine if one were to live forever they would be well disposed to shy away from such eternal oaths. They assume a... state of suspension that is unlikely to hold.~
END

INTERJECT_COPY_TRANS2 GAAL 23 BJ#GAAL23
== BJ#AudeJ IF ~InParty("BJ#Auden") InMyArea("BJ#Auden")~ THEN ~You have gambled and lost. Accept your fate, fool.~
END

INTERJECT_COPY_TRANS2 GAAL 4 BJ#GAAL4
== BJ#AudeJ IF ~InParty("BJ#Auden") InMyArea("BJ#Auden")~ THEN ~What purpose would accruing a cult in Athkatla hold, for a beholder? Surely it must realize the attention it would attract from those who oppose it.~
END

INTERJECT_COPY_TRANS2 GAELAN 66 BJ#GAELAN66
== BJ#AudeJ IF ~InParty("BJ#Auden") InMyArea("BJ#Auden")~ THEN ~This thief may be slippery, but I do not doubt his words... If we are to find Imoen and Irenicus, we will need to leverage the influence of the Shadow Thieves.~
END

INTERJECT_COPY_TRANS2 PPSAEM 59 BJ#PPSAEM59
== BJ#AudeJ IF ~InParty("BJ#Auden") InMyArea("BJ#Auden")~ THEN ~You would make deals with these creatures? You truly are a fool.~
END

INTERJECT_COPY_TRANS2 PPCOWLED 1 BJ#PPCOWLED1
== BJ#AudeJ IF ~InParty("BJ#Auden") InMyArea("BJ#Auden")~ THEN ~There is something wrong with this man... Steel yourself, this may be another trap.~
END

INTERJECT_COPY_TRANS2 PPAPHRIL 4 BJ#PPAPHRIL4
== BJ#AudeJ IF ~InParty("BJ#Auden") InMyArea("BJ#Auden")~ THEN ~To see through the planes, and unable to turn away... I can only imagine the terror she must feel.~
END

INTERJECT_COPY_TRANS2 PPAPHRIL 5 BJ#PPAPHRIL5
== BJ#AudeJ IF ~InParty("BJ#Auden") InMyArea("BJ#Auden")~ THEN ~To see through the planes, and unable to turn away... I can only imagine the terror she must feel.~
END

INTERJECT_COPY_TRANS2 PPAPHRIL 6 BJ#PPAPHRIL6
== BJ#AudeJ IF ~InParty("BJ#Auden") InMyArea("BJ#Auden")~ THEN ~To see through the planes, and unable to turn away... I can only imagine the terror she must feel.~
END

INTERJECT_COPY_TRANS2 YOSHJ 113 BJ#YOSHJ13
== BJ#AudeJ IF ~InParty("BJ#Auden") InMyArea("BJ#Auden")~ THEN ~We called you friend, Yoshimo... There is no baser treachery. We shall not forget.~
END

INTERJECT_COPY_TRANS2 PPSAEM2 19 BJ#PPSAEM2-19
== BJ#AudeJ IF ~InParty("BJ#Auden") InMyArea("BJ#Auden")~ THEN ~Whether or not you wish to rely on this fool is your choice, but know that if he so readily betrayed us before, he will be quick to do so again.~
END

INTERJECT_COPY_TRANS2 PPSAEM3 1 BJ#PPSAEM3-1
== BJ#AudeJ IF ~InParty("BJ#Auden") InMyArea("BJ#Auden")~ THEN ~Villainy that was asked for, no doubt.~
END

INTERJECT_COPY_TRANS2 SCSARLES 11 BJ#SCSARLES11
== BJ#AudeJ IF ~InParty("BJ#Auden") InMyArea("BJ#Auden")~ THEN ~Hmph. One would think that there be better uses for our time than to facilitate such decadence.~
END

INTERJECT_COPY_TRANS2 DELCIA 1 BJ#DELCIA1
== BJ#AudeJ IF ~InParty("BJ#Auden") InMyArea("BJ#Auden")~ THEN ~There is a refreshing lack of such entitled fools where I come from. It's enough to make me wonder why I left. Momentarily, at least.~
END

INTERJECT_COPY_TRANS2 DELCIA 3 BJ#DELCIA3
== BJ#AudeJ IF ~InParty("BJ#Auden") InMyArea("BJ#Auden")~ THEN ~There is a refreshing lack of such entitled fools where I come from. It's enough to make me wonder why I left. Momentarily, at least.~
END

INTERJECT_COPY_TRANS2 DELCIA 4 BJ#DELCIA4
== BJ#AudeJ IF ~InParty("BJ#Auden") InMyArea("BJ#Auden")~ THEN ~There is a refreshing lack of such entitled fools where I come from. It's enough to make me wonder why I left. Momentarily, at least.~
END

INTERJECT_COPY_TRANS2 DELCIA 7 BJ#DELCIA7
== BJ#AudeJ IF ~InParty("BJ#Auden") InMyArea("BJ#Auden")~ THEN ~There is a refreshing lack of such entitled fools where I come from. It's enough to make me wonder why I left. Momentarily, at least.~
END

INTERJECT_COPY_TRANS2 DELCIA 2 BJ#DELCIA2
== BJ#AudeJ IF ~InParty("BJ#Auden") InMyArea("BJ#Auden")~ THEN ~There is a refreshing lack of such entitled fools where I come from. It's enough to make me wonder why I left. Momentarily, at least.~
END

INTERJECT_COPY_TRANS2 KAYL2 10 BJ#KAYL2-10
== BJ#AudeJ IF ~InParty("BJ#Auden") InMyArea("BJ#Auden")~ THEN ~As it should be, I would think... If a life of sworn discipline and piety is to serve anyone or anything, it must demand absolutely from its adherents.~
END

INTERJECT_COPY_TRANS2 RAELIS 2 BJ#RAELIS2
== BJ#AudeJ IF ~InParty("BJ#Auden") InMyArea("BJ#Auden")~ THEN ~Amn finds markets even from the planes, it seems.~
END

INTERJECT_COPY_TRANS ILBEGG01 4 BJ#AudenBeggar1
== BJ#AudeJ IF ~InParty("BJ#Auden") InMyArea("BJ#Auden")~ THEN
~That was a benevolent gesture, but a gesture nonetheless. There are better ways to provide for the disadvantaged, even if they are less direct.~
END

INTERJECT_COPY_TRANS BHOISIG 19 BJ#AudenHoisig
== BJ#AudeJ IF ~InParty("BJ#Auden") InMyArea("BJ#Auden")~ THEN
~Practitioners of many faiths undergo rites of endurance... But to permanently blind oneself to prove devotion? We should use caution, <CHARNAME>. These people are clearly beyond sanity.~
END

INTERJECT_COPY_TRANS BHARVAL 17 BJ#AudenArval
== BJ#AudeJ IF ~InParty("BJ#Auden") InMyArea("BJ#Auden")~ THEN
~Practitioners of many faiths undergo rites of endurance... But to permanently blind oneself to prove devotion? We should use caution, <CHARNAME>. These people are clearly beyond sanity.~
END

INTERJECT_COPY_TRANS BHNALLA 16 BJ#BHNALLA16
== BJ#AudeJ IF ~InParty("BJ#Auden") InMyArea("BJ#Auden")~ THEN
~Practitioners of many faiths undergo rites of endurance... But to permanently blind oneself to prove devotion? We should use caution, <CHARNAME>. These people are clearly beyond sanity.~
END

INTERJECT_COPY_TRANS BHNALLA 16 BJ#AudenNalla
== BJ#AudeJ IF ~InParty("BJ#Auden") InMyArea("BJ#Auden")~ THEN
~Practitioners of many faiths undergo rites of endurance... But to permanently blind oneself to prove devotion? We should use caution, <CHARNAME>. These people are clearly beyond sanity.~
END

INTERJECT_COPY_TRANS C6REGIS1 2 BJ#AudenDrizzt
== BJ#AudeJ IF ~InParty("BJ#Auden") InMyArea("BJ#Auden")~ THEN
~We have found ourselves in the presence of Drizzt Do'Urden, <CHARNAME>... Unless there is another scimitar-wielding drow that I am unaware of.~
END

INTERJECT_COPY_TRANS VICG1 4 BJ#AudenVicBurn
== BJ#AudeJ IF ~InParty("BJ#Auden") InMyArea("BJ#Auden")~ THEN
~Such vigilantism is... vulgar, to say the least. If you intend to rescue this drow, you best do it quickly, and prepare to fight these madmen.~
END

INTERJECT_COPY_TRANS SEWSW 4 BJ#AudenSewPuz
== BJ#AudeJ IF ~InParty("BJ#Auden") InMyArea("BJ#Auden")~ THEN
~Hm, had I known there were such oddities so close to the Copper Coronet, I would have made the trip myself.~
END

INTERJECT_COPY_TRANS SUAVATAR 5 BJ#AudenSuldYak2
== BJ#AudeJ IF ~InParty("BJ#Auden") InMyArea("BJ#Auden")~ THEN
~He seeks to... <CHARNAME>, this cannot be allowed. We must end this, even if it takes our dying breath to do so.~
END

INTERJECT_COPY_TRANS SUDEMIN 11 BJ#AudenSuldYak1
== BJ#AudeJ IF ~InParty("BJ#Auden") InMyArea("BJ#Auden")~ THEN
~That is an understatement. Extinguishing his life would avenge countless wrongs, it seems.~
END

INTERJECT_COPY_TRANS UHMAY01 18 BJ#AudenUHInt1
== BJ#AudeJ IF ~InParty("BJ#Auden") InMyArea("BJ#Auden")~ THEN
~Ogres are not known for their subtlety... That there is any mystery here at all casts doubt upon the prospect of their complicity.~
END

INTERJECT_COPY_TRANS UHOGRE01 10 BJ#AudenUHInt2
== BJ#AudeJ IF ~InParty("BJ#Auden") InMyArea("BJ#Auden")~ THEN
~This creature has wilfully turned from its violent nature - I think that is deserving of consideration. But it is your choice.~
END

INTERJECT_COPY_TRANS HELLJON 7 BJ#AudenEndGame
== BJ#AudeJ IF ~InParty("BJ#Auden") InMyArea("BJ#Auden")~ THEN
~We have labored long enough for this reckoning. There is one life left for us to take. Come, Jon Irenicus. The Abyss awaits you!~
END

INTERJECT_COPY_TRANS HELLJON 8 BJ#AudenEndGame
== BJ#AudeJ IF ~InParty("BJ#Auden") InMyArea("BJ#Auden")~ THEN
~We have labored long enough for this reckoning. There is one life left for us to take. Come, Jon Irenicus. The Abyss awaits you!~
END

INTERJECT_COPY_TRANS HELLJON 9 BJ#AudenEndGame
== BJ#AudeJ IF ~InParty("BJ#Auden") InMyArea("BJ#Auden")~ THEN
~We have labored long enough for this reckoning. There is one life left for us to take. Come, Jon Irenicus. The Abyss awaits you!~
END

INTERJECT_COPY_TRANS HELLJON 10 BJ#AudenEndGame
== BJ#AudeJ IF ~InParty("BJ#Auden") InMyArea("BJ#Auden")~ THEN
~We have labored long enough for this reckoning. There is one life left for us to take. Come, Jon Irenicus. The Abyss awaits you!~
END

INTERJECT_COPY_TRANS UDARDUL 14 BJ#AudenUndD1
== BJ#AudeJ IF ~InParty("BJ#Auden") InMyArea("BJ#Auden")~ THEN
~Truly, we are naught but instruments to these drow. The sooner we slaughter these monsters, the sooner we shall be free from this woman's cruel whims.~
END

INTERJECT PLAYER1 33 BJ#AudenTreeOfLife

== PLAYER1 IF ~IsValidForPartyDialog("BJ#Auden") Global("BJ#AudenSpy","GLOBAL",2)~ THEN
~Auden, calm and reserved, the Aglarondan spy sent to investigate you and your kin. He seems to have thrown his lot in with yours, despite the risk. He meets your gaze and nods.~
END
++ ~Auden, you have a family waiting for you back in Aglarond. If you come with me, there is no guarantee you will return.~ EXTERN BJ#AudeJ Option1
++ ~Are you ready for this?~ EXTERN BJ#AudeJ Option2
APPEND BJ#AudeJ
IF ~~ THEN BEGIN Option1
SAY ~I expect no guarantees from you, <CHARNAME>. The only certainty is death. I have lived a long life, and I do not fear it.~
= ~That said, I'll do my best to ensure that if anyone meets their end today, it will be Irenicus.~ COPY_TRANS PLAYER1 33
END

IF ~~ THEN BEGIN Option2
SAY ~Of course. I am ready when you are.~
= ~We will take back what is yours by right.~ COPY_TRANS PLAYER1 33
END
END

///INTERJECT_COPY_TRANS2 DELCIA 1 BJ#DELCIA1
///== BJ#AudeJ IF ~InParty("BJ#Auden") InMyArea("BJ#Auden")~ THEN ~~
///END
