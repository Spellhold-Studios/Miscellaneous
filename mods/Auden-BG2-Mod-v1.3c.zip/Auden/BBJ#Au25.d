CHAIN
IF ~InParty("BJ#Auden")
InParty(Player1)
!StateCheck("BJ#Auden",CD_STATE_NOTVALID)
!StateCheck(Player1,CD_STATE_NOTVALID)
Global("BJ#AudenTalk25","GLOBAL",2)~
THEN BBJ#Au25 BJ#25Ba1
~I have been contemplating this revelation of your purpose, <CHARNAME>. I wish to ask you about it, if you would indulge me.~
DO ~SetGlobal("BJ#AudenTalk25","GLOBAL",3)~
END
++ ~What do you wish to know?~ + BJ#25Ba1-1
++ ~I do not wish to hear it. Leave me be.~ + BJ#25Ex1-1

CHAIN
IF ~~ THEN BBJ#Au25 BJ#25Ba1-1
~It is evident that your life's journey is largely tied to your heritage as a progeny of Bhaal. As I'm sure you realize, this is as much opportunity as it is curse.~
= ~So, <CHARNAME>, what is it that you intend to accomplish?~
END
++ ~My life has been nothing but ceaseless death. I wish to be rid of it, once and for all. And if I can bring some benevolence to this world in so doing, I will.~ + BJ#25Ba1-2
++ ~I only want to live a life of my own choosing. I tire of fate pressing down upon me. Perhaps perserverance will bring my freedom.~ + BJ#25Ba1-3
++ ~I strive to fulfill my fate. What good is this cursed blood if I refuse its divinity? To achieve Godhead... I will have greater than mortal legend, acquired greater treasure than the whole of Toril can offer.~ + BJ#25Ba1-4
++ ~Leave me alone, Auden. I do not desire to speak of such things, not now.~ + BJ#25Ex1-1

CHAIN
IF ~~ THEN BBJ#Au25 BJ#25Ba1-2
~Because of your profession and because of your blood, senseless violence hounds you. How would you ensure a... positive net gain, so to speak?~
END
++ ~That seems to be the question, does it not? But no, I am confident that I can bring right to this world. I will balance it, in time.~ + BJ#25Ba1-5
++ ~My father tips the scales even in death, but "I" am no beacon of evil. The blood of Bhaal cannot restrain my righteousness. I refuse it.~ + BJ#25Ba1-6
++ ~Can we just focus on the task at hand, right now?~ + BJ#25Ex1-1

CHAIN
IF ~~ THEN BBJ#Au25 BJ#25Ba1-3
~Is that even possible? Violence is infused into your very essence.~
END
++ ~I have to believe it is. If I am going to weather this gauntlet, the power to do so will have come from within me.~ + BJ#25Ba1-7
++ ~Stranger things have happened, no? Gods have been foiled before. I have to try.~ + BJ#25Ba1-6
++ ~We shouldn't distract ourselves with talk like this. Let's get back to our journey.~ + BJ#25Ex1-1

CHAIN
IF ~~ THEN BBJ#Au25 BJ#25Ba1-4
~Ah, but there is much risk in this path. What if fate does not hold Godhood in your future? What if you lose all you hold dear? What if you are destroyed utterly?~
END
++ ~Nothing ventured, nothing gained, friend. Would you not strive for the same rarefied prize?~ + BJ#25Ba1-8
++ ~Everything is worth sacrificing for this. There is no greater reward in all the realms.~ + BJ#25Ba1-9
++ ~Forget this. I'm finished talking.~ + BJ#25Ex1-1

CHAIN
IF ~~ THEN BBJ#Au25 BJ#25Ba1-5
~Hmm, I see. Keep to that confidence and perhaps you will. It may take longer than you realize, however. There is much to answer for.~
END
++ ~What do you mean, "answer for"? I have asked for none of this. You know that as well as I, Auden.~ + BJ#25Ba1-10
++ ~However long it takes, that's how long I'll labor. It is only right.~ + BJ#25Ba1-6
++ ~Forget this. We have more pressing matters to attend to.~ + BJ#25Ex1-1

CHAIN
IF ~~ THEN BBJ#Au25 BJ#25Ba1-6
~Hmm, perhaps. That you seek to counterbalance the influence your father is good, at least.~
END
++ ~As well I should! In a way I do not feel that my life truly reflects upon me. I have been thrust into this life. I lack the autonomy that would make me truly responsible for all this.~ + BJ#25Ba1-10
++ ~Relax, Auden. We'll handle whatever's waiting for us as best we can.~ + BJ#25Ex1-3

CHAIN
IF ~~ THEN BBJ#Au25 BJ#25Ba1-7
~That much is true, I suppose. And it is good, I think, that you recognize your... latent power as an unfit tool to that end. Embrace of your heritage will only lead you further down this path.~
END
++ ~Why would that be?~ + BJ#25Ex1-2

CHAIN
IF ~~ THEN BBJ#Au25 BJ#25Ba1-8
~I cannot say, as I am not in your position. But you should be cognizant of the risks you are running. More people than you know have their lives in your hands.~
END
++ ~I believe the reward will be worth it. Whatever losses I incur, the power I gain will be enough to protect more. Exponentially more.~ + BJ#25Ba1-11
++ ~Hmph, if they lack the strength to take control of their own lives, then they are as good as forfeit. It is no matter.~ + BJ#25Ba1-9

CHAIN
IF ~~ THEN BBJ#Au25 BJ#25Ba1-9
~Do not be so cavalier about the lives of your comrades. They would lay down their lives for you, I'm sure. One ought to pay reverence to that loyalty.~
END
++ ~No one is stopping them from walking away.~ + BJ#25Ex1-3
++ ~Perhaps. But if I play my cards right, I should be able to make few, if any, sacrifices.~ + BJ#25Ex1-4

CHAIN
IF ~~ THEN BBJ#Au25 BJ#25Ba1-10
~Does it matter? Your hand, <CHARNAME>, is the one that strikes, and if the incidental violence itself is not your responsibility, the ways in which it affects the world are yours to control, ultimately.~
= ~You will do no good in denying your complicity, forced as it may be. Neither will you do good in letting guilt paralyze you. The time to take stock is not now, perhaps, but I would keep it in mind, were I you.~
END
++ ~Perhaps you are right, Auden. But I don't have to wait until this is over. As you say, the ultimate effects of my actions are mine to control. There are yet ways to steer my destiny.~ + BJ#25Ex1-5
++ ~You are speaking nonsense. I had no intent to cause the harm I have and to blame me is to go beyond all reason.~ + BJ#25Ex1-6
++ ~To be perfectly honest, by the time I'm through I don't imagine I'll be in a position to worry about some potential rebuke from my past.~ + BJ#25Ex1-12

CHAIN
IF ~~ THEN BBJ#Au25 BJ#25Ba1-11
~I do not believe it truly wise to... bet against future earnings, as they would say in this land. Your comrades are not commodities to be expended in pursuit of your goals, they are ends in themselves. Their loss would not so easily be alleviated.~
END
++ ~No, that is true. I simply mean to imply that the potential benefits of taking my father's power are exceedingly great. Who's to say that such power could defy even death?~ + BJ#25Ex1-7
++ ~Pah! They would use me for their own devices. Many have before. Why would I extend to them the courtesy they refuse me?~ + BJ#25Ex1-8
++ ~Forget I said anything. Let's go.~ + BJ#25Ex1-1

CHAIN
IF ~~ THEN BBJ#Au25 BJ#25Ex1-1
~As you say. Come then.~
END
++ ~~ EXIT

CHAIN
IF ~~ THEN BBJ#Au25 BJ#25Ex1-2
~Well, the temptation to use destructive power against itself is a strong one, but it is no more effective than fighting fire with fire.~
= ~If you plan on extricating yourself from this mess, <CHARNAME>, then you will have to forsake your... promise. Eventually.~
END
++ ~If that is what I must do, then so be it.~ + BJ#25Ex1-1

CHAIN
IF ~~ THEN BBJ#Au25 BJ#25Ex1-3
~Ah, but that does not mean they have brought some debt to you in their decision not to leave.~
END
++ ~Maybe not. I will have to think on your words.~ +BJ#25Ex1-1
++ ~Hmph, so you say. I tire of this, let's focus ourselves on something else.~ + BJ#25Ex1-1

CHAIN
IF ~~ THEN BBJ#Au25 BJ#25Ex1-4
~I do not think that will be possible. If you truly desire your father's power, then those around you will suffer. This is unavoidable.~
= ~If that is your intent, you'd best ensure that they find your cause as worthwhile as you do.~
END
++ ~They know me, I'm sure they will. We have been through much.~ + BJ#25Ex1-11
++ ~Would you find it worthwhile?~ + BJ#25Ex1-10

CHAIN
IF ~~ THEN BBJ#Au25 BJ#25Ex1-5
~I agree, to an extent. You keep a heartening perspective on this. Perhaps this will work out for the best.~
END
++ ~Perhaps so. But we should return to our task. We have talked enough.~ + BJ#25Ex1-1

CHAIN
IF ~~ THEN BBJ#Au25 BJ#25Ex1-6
~I do not think you are hearing me. But... it is no matter. What comes will come and I will aid you as I can. I only hope you come to realize the meaning in what I have said, <CHARNAME>.~
END
++ ~I wouldn't rule anything out, but I maintain that you have the wrong perspective on this. We'll talk more later, I'm sure.~ + BJ#25Ex1-1
++ ~You are entirely too morose about everything, Auden. Things will not be so bad, you'll see.~ + BJ#25Ex1-1

CHAIN
IF ~~ THEN BBJ#Au25 BJ#25Ex1-7
~There are rules even the Gods must follow. As I said, it is unwise to assume that divinity would render you capable of anything. There are things that cannot be undone.~
END
++ ~I suppose you are right about that. I'll do my best not to take these things too lightly.~ + BJ#25Ex1-1
++ ~I understand, but there's no use handwringing over these things. If we fall, we fall.~ + BJ#25Ex1-1

CHAIN
IF ~~ THEN BBJ#Au25 BJ#25Ex1-8
~Ah, but we are your friends, are we not? We may have asked your aid from time to time, but we have repaid those debts in service, many times over. It is not so cruel an arrangement as you suggest.~
END
++ ~Hmph, if you say so. We'll see if you all are still behind me when things become truly difficult.~ + BJ#25Ex1-11
++ ~This is always the way it has always been. I keep you all around because it suits me, that's all.~ + BJ#25Ex1-12

CHAIN
IF ~~ THEN BBJ#Au25 BJ#25Ex1-10
~I know full well what I have brought myself into. I have made a decision and shall see it through to the end.~
END
++ ~I appreciate that, Auden. We will accomplish much, just you wait.~ + BJ#25Ex1-1
++ ~Good. I'm glad SOMEONE around here knows their place.~ + BJ#25Ex1-1

CHAIN
IF ~~ THEN BBJ#Au25 BJ#25Ex1-11
~Indeed, we shall see.~
END
++ ~~ EXIT

CHAIN
IF ~~ THEN BBJ#Au25 BJ#25Ex1-12
~Indeed? Expect this to be a difficult path, then.~
END
++ ~~ EXIT