// creator  : weidu (version 185)
// argument : AR#REWMA.DLG
// game     : .
// source   : AR#REWMA.DLG
// dialog   : ./dialog.tlk
// dialogF  : (none)

BEGIN ~AR#REWMA~

IF ~True()~ THEN BEGIN ar0 // from:
  SAY ~Greetings, I shall give you the gifts you earn for completing the Arena challenges.~
  IF ~Global("AR_R2_M1","GLOBAL",1)
  !Global("AR_R1_GIVEN","GLOBAL",1)~ THEN REPLY ~I have completed round one.~ GOTO ar1
  IF ~Global("AR_R3_M1","GLOBAL",1)
  !Global("AR_R2_GIVEN","GLOBAL",1)~ THEN REPLY ~I have completed round two.~ GOTO ar2
  IF ~Global("AR_R4_M1","GLOBAL",1)
  !Global("AR_R3_GIVEN","GLOBAL",1)~ THEN REPLY ~I have completed round three.~ GOTO ar3
  IF ~Global("AR_R5_M1","GLOBAL",1)
  !Global("AR_R4_GIVEN","GLOBAL",1)~ THEN REPLY ~I have completed round four.~ GOTO ar4
  IF ~Global("AR_R6_M1","GLOBAL",1)
  !Global("AR_R5_GIVEN","GLOBAL",1)~ THEN REPLY ~I have completed round five.~ GOTO ar5
  IF ~Global("AR_R6_M1","GLOBAL",1)
  !Global("AR_R5_GIVEN","GLOBAL",1)~ THEN REPLY ~I have completed round six.~ GOTO ar6
  IF ~~ THEN REPLY ~Nevermind.~ EXIT
END

IF ~~ THEN BEGIN ar1 
  SAY ~Ah, The first challenge is complete Grats!~
  IF ~~ THEN REPLY ~Thank you.~ DO ~GiveItemCreate("AR#R1",Player1,1,1,1)
  SetGlobal("AR_R1_GIVEN","GLOBAL",1)~ EXIT
END

IF ~~ THEN BEGIN ar2 
  SAY ~Ah, The second challenge is complete Grats!~
  IF ~~ THEN REPLY ~Thank you.~ DO ~GiveItemCreate("AR#R2",Player1,1,1,1)
  SetGlobal("AR_R2_GIVEN","GLOBAL",1)~ EXIT
END

IF ~~ THEN BEGIN ar3 
  SAY ~Ah, The third challenge is complete Grats!~
  IF ~~ THEN REPLY ~Thank you.~ DO ~GiveItemCreate("AR#R3",Player1,1,1,1)
  SetGlobal("AR_R3_GIVEN","GLOBAL",1)~ EXIT
END

IF ~~ THEN BEGIN ar4 
  SAY ~Ah, The fourth challenge is complete Grats!~
  IF ~~ THEN REPLY ~Thank you.~ DO ~GiveItemCreate("AR#R4",Player1,1,1,1)
  SetGlobal("AR_R4_GIVEN","GLOBAL",1)~ EXIT
END

IF ~~ THEN BEGIN ar5 
  SAY ~Ah, The fifth challenge is complete Grats!~
  IF ~~ THEN REPLY ~Thank you.~ DO ~GiveItemCreate("AR#R5",Player1,1,1,1)
  SetGlobal("AR_R5_GIVEN","GLOBAL",1)~ EXIT
END

IF ~~ THEN BEGIN ar6 
  SAY ~Ah, The fifth challenge is complete Grats!~
  IF ~~ THEN REPLY ~Thank you.~ DO ~GiveItemCreate("AR#R6",Player1,1,1,1)
  SetGlobal("AR_R6_GIVEN","GLOBAL",1)~ EXIT
END