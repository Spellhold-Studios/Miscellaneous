// creator  : weidu (version 185)
// argument : 123456.DLG
// game     : .
// source   : ./override/123456.DLG
// dialog   : ./dialog.tlk
// dialogF  : (none)

BEGIN ~AR#AREMA~

IF ~NumTimesTalkedTo(0)~ THEN BEGIN 0 
  SAY ~Welcome, I am the Arena Master.~
  IF ~~ THEN REPLY ~What exactly is your purpose?~ GOTO 2
  IF ~~ THEN REPLY ~Uhhh.... BYE!~ DO ~SetNumTimesTalkedTo(0)~ EXIT
END

IF ~~ THEN BEGIN 2 
  SAY ~I am here to tone your skills, further your knowledge in combat, and  finally provide you with more resources.. *IF* you are able.~
  IF ~~ THEN REPLY ~Very well then. Let us begin.~ DO ~SetGlobal("ARENA_INTRO","GLOBAL",1)~ GOTO 4
  IF ~~ THEN REPLY ~I value your interest in me. But uh I'm not interested.~ DO ~SetNumTimesTalkedTo(0)~ EXIT
END

IF ~Global("ARENA_INTRO","GLOBAL",1)~ THEN BEGIN 4 
  SAY ~Okay, now that you know who I am, and what I do, please let us begin. Oh, there is one more thing.. You must of completed your plane's first challenge in the door to your left.~
  IF ~Global("GavePocketPlane","GLOBAL",1)~ THEN REPLY ~Yes, please let's begin.~ GOTO 5
  IF ~~ THEN REPLY ~Uhh.. Nevermind, I just remembered I have something else to attend to.~ DO ~SetGlobal("ARENA_INTRO","GLOBAL",1)~ EXIT
  IF ~!Global("GavePocketPlane","GLOBAL",1)~ THEN REPLY ~I must first do this challenge.~ EXIT
END

IF ~~ THEN BEGIN 5 
  SAY ~Very well, Here is a list of availible matches to you. Please be aware this is not an illusion. You will be doing battle with real fiends. If you die, your body with decay here in this abyssal plane.~
  IF ~~ THEN REPLY ~First tier matches~ GOTO 6
  IF ~Global("AR_R2_M1","GLOBAL",1)~ THEN REPLY ~Second tier matches.~ GOTO 7
  IF ~Global("AR_R3_M1","GLOBAL",1)~ THEN REPLY ~Third tier matches.~ GOTO 8
  IF ~Global("AR_R4_M1","GLOBAL",1)~ THEN REPLY ~Fourth tier matches.~ GOTO 9
  IF ~Global("AR_R5_M1","GLOBAL",1)~ THEN REPLY ~Fifth tier matches.~ GOTO 10
  IF ~Global("AR_R6_M1","GLOBAL",1)~ THEN REPLY ~Sixth tier matches.~ GOTO 11
  IF ~~ THEN REPLY ~Nevermnd.~ EXIT
END

IF ~~ THEN BEGIN 6 
  SAY ~Here are the matches from tier one.~
  IF ~~ THEN REPLY ~Round One~ DO ~SetGlobal("AR_R1_M1","GLOBAL",1)
  StartCutSceneMode()
  StartCutScene("ar#r1m1")~ EXIT
  IF ~Global("AR_R1_M1","GLOBAL",1)~ THEN REPLY ~Round Two~ DO ~SetGlobal("AR_R1_M2","GLOBAL",1)
  StartCutSceneMode()
  StartCutScene("ar#r1m2")~ EXIT
  IF ~Global("AR_R1_M2","GLOBAL",1)~ THEN REPLY ~Round Three~ DO ~SetGlobal("AR_R1_M3","GLOBAL",1)
  StartCutSceneMode()
  StartCutScene("ar#r1m3")~ EXIT
  IF ~Global("AR_R1_M3","GLOBAL",1)~ THEN REPLY ~Round Four~ DO ~SetGlobal("AR_R1_M4","GLOBAL",1)
  StartCutSceneMode()
  StartCutScene("ar#r1m4")~ EXIT
  IF ~Global("AR_R1_M4","GLOBAL",1)~ THEN REPLY ~Round Five~ DO ~SetGlobal("AR_R2_M1","GLOBAL",1)
  StartCutSceneMode()
  StartCutScene("ar#r1m5")~ EXIT
  IF ~~ THEN REPLY ~Nevermind.~ EXIT
END

IF ~~ THEN BEGIN 7 
  SAY ~Here are the matches from tier two.~
  IF ~~ THEN REPLY ~Round One~ DO ~SetGlobal("AR_R2_M1","GLOBAL",1)
  StartCutSceneMode()
  StartCutScene("ar#r2m1")~ EXIT
  IF ~Global("AR_R2_M1","GLOBAL",1)~ THEN REPLY ~Round Two~ DO ~SetGlobal("AR_R2_M2","GLOBAL",1)
  StartCutSceneMode()
  StartCutScene("ar#r2m2")~ EXIT
  IF ~Global("AR_R2_M2","GLOBAL",1)~ THEN REPLY ~Round Three~ DO ~SetGlobal("AR_R2_M3","GLOBAL",1)
  StartCutSceneMode()
  StartCutScene("ar#r2m3")~ EXIT
  IF ~Global("AR_R2_M3","GLOBAL",1)~ THEN REPLY ~Round Four~ DO ~SetGlobal("AR_R2_M4","GLOBAL",1)
  StartCutSceneMode()
  StartCutScene("ar#r2m4")~ EXIT
  IF ~Global("AR_R2_M4","GLOBAL",1)~ THEN REPLY ~Round Five~ DO ~SetGlobal("AR_R3_M1","GLOBAL",1)
  StartCutSceneMode()
  StartCutScene("ar#r2m5")~ EXIT
  IF ~~ THEN REPLY ~Nevermind.~ EXIT
END

IF ~~ THEN BEGIN 8 
  SAY ~Here are the matches from tier three.~
  IF ~~ THEN REPLY ~Round One~ DO ~SetGlobal("AR_R3_M1","GLOBAL",1)
  StartCutSceneMode()
  StartCutScene("ar#r3m1")~ EXIT
  IF ~Global("AR_R3_M1","GLOBAL",1)~ THEN REPLY ~Round Two~ DO ~SetGlobal("AR_R3_M2","GLOBAL",1)
  StartCutSceneMode()
  StartCutScene("ar#r3m2")~ EXIT
  IF ~Global("AR_R3_M2","GLOBAL",1)~ THEN REPLY ~Round Three~ DO ~SetGlobal("AR_R3_M3","GLOBAL",1)
  StartCutSceneMode()
  StartCutScene("ar#r3m3")~ EXIT
  IF ~Global("AR_R3_M3","GLOBAL",1)~ THEN REPLY ~Round Four~ DO ~SetGlobal("AR_R3_M4","GLOBAL",1)
  StartCutSceneMode()
  StartCutScene("ar#r3m4")~ EXIT
  IF ~Global("AR_R3_M4","GLOBAL",1)~ THEN REPLY ~Round Five~ DO ~SetGlobal("AR_R4_M1","GLOBAL",1)
  StartCutSceneMode()
  StartCutScene("ar#r3m5")~ EXIT
  IF ~~ THEN REPLY ~Nevermind.~ EXIT
END

IF ~~ THEN BEGIN 9 
  SAY ~Here are the matches from tier four.~
  IF ~~ THEN REPLY ~Round One~ DO ~SetGlobal("AR_R4_M1","GLOBAL",1)
  StartCutSceneMode()
  StartCutScene("ar#r4m1")~ EXIT
  IF ~Global("AR_R4_M1","GLOBAL",1)~ THEN REPLY ~Round Two~ DO ~SetGlobal("AR_R4_M2","GLOBAL",1)
  StartCutSceneMode()
  StartCutScene("ar#r4m2")~ EXIT
  IF ~Global("AR_R4_M2","GLOBAL",1)~ THEN REPLY ~Round Three~ DO ~SetGlobal("AR_R4_M3","GLOBAL",1)
  StartCutSceneMode()
  StartCutScene("ar#r4m3")~ EXIT
  IF ~Global("AR_R4_M3","GLOBAL",1)~ THEN REPLY ~Round Four~ DO ~SetGlobal("AR_R4_M4","GLOBAL",1)
  StartCutSceneMode()
  StartCutScene("ar#r4m4")~ EXIT
  IF ~Global("AR_R4_M4","GLOBAL",1)~ THEN REPLY ~Round Five~ DO ~SetGlobal("AR_R5_M1","GLOBAL",1)
  StartCutSceneMode()
  StartCutScene("ar#r4m5")~ EXIT
  IF ~~ THEN REPLY ~Nevermind.~ EXIT
END

IF ~~ THEN BEGIN 10 
  SAY ~Here are the matches from tier five.~
  IF ~~ THEN REPLY ~Round One~ DO ~SetGlobal("AR_R6_M1","GLOBAL",1)
  StartCutSceneMode()
  StartCutScene("ar#r5m1")~ EXIT
  IF ~~ THEN REPLY ~Nevermind.~ EXIT
END

IF ~~ THEN BEGIN 11 
  SAY ~Here are the matches from tier six.~
  IF ~~ THEN REPLY ~Round One~ DO ~SetGlobal("AR_R7_M1","GLOBAL",1)
  StartCutSceneMode()
  StartCutScene("ar#r6m1")~ EXIT
  IF ~~ THEN REPLY ~Nevermind.~ EXIT
END