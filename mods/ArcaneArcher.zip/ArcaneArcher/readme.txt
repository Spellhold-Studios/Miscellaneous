	Arcane Archer mod for Baldur's Gate II
	by Doug Piranha (barakudaxx@gmail.com)

------------
Introduction
------------

This little mod adapts Arcane Archer prestige class from Dungeons & Dragons 3rd edition (and above) game as a fighter kit for Baldur's Gate II.

-----------
Instalation
-----------

Latest BG2 patch should be applied before installing any mods. BG2Fixpack is also recommended.

To install the mod extract the content of ArcaneArcher.zip to your game folder (usually C:\Program Files\Black Isle\BGII - SoA for Baldur's Gate II: SoA and ToB). Run setup-ArcaneArcher.exe and follow onscreen instructions.

To uninstall or reinstall run setup-ArcaneArcher.exe again.

Although not tested, this mod should be compatible with Baldur's Gate Tutu and Baldur's Gate Trilogy.

-------
Content
-------

Here is description of the kit. It is available only to elves and half-elves.

ARCANE ARCHER: These elven warriors use innate magic talent to supplement their deadly marksmanship. Arcane archers can create special arrows and with them achieve what ordinary fighter cannot.

Advantages:
- +1 to hit, and +1 to damage with any missile weapon for every 4 levels of experience.
- May create imbued arrow once per day at 3rd level. This arrow creates deadly fireball on impact.
- May create seeking arrow once per day at 6th level. This arrow seeks it's target and almost never misses.
- May create phase arrow once per day at 9th level. This arrow passes through target, dealing magical damage and slowing the opponent.
- May deliver a hail of arrows once per day, making two extra attacks per round for a short amount of time.
- May create arrow of death once per day at 15th level. This arrow is capable of instantly slaying the target.
- Arrows created by arcane archer retain their potency for 4 turns.

Disadvantages:
- Can only become proficient (one point) in non-bow weapons.
- Cannot wear any metal armor.

-------
Credits
-------

Created by Doug Piranha (that's me!)

Tools and tutorials used:
WeiDU 			http://www.weidu.org/
DLTCEP 			http://www.gibberlings3.net/tools/dltcep.php
Infinity Explorer 	http://infexp.sourceforge.net/
GIMP			http://www.gimp.org/
Item Graphics Converter	http://www.teambg.org/forum/index.php/topic,185.0.html
IESDP 			http://iesdp.gibberlings3.net/
BAM Tutorial 1.0	http://forums.blackwyrmlair.net/index.php?showtopic=4731
BG2 Kit Creation	http://forums.gibberlings3.net/index.php?showtopic=584

SRD Arcane Archer prestige class description:
http://www.d20srd.org/srd/prestigeClasses/arcaneArcher.htm

--------
End note
--------

This mod can be redistributed freely as long as author is credited and notified.

Questions? Comments? Suggestions? Bug reports? E-mail me at barakudaxx@gmail.com.