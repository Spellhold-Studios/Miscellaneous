Convenience Script Mod
For BG or IWD series games

This script provides basic attack functionality as well as a hotkey to allow quick buffing out of combat.

Characters with levels of a warrior class will approach enemies and attack.  Non-warriors will attack enemies in range, but will not approach distant enemies.

Hotkeys:
"B" - Gives selected characters instant casting with no recovery time for 6 seconds, for your prebuffing convenience.
