Author: Tapio Kivikkola

The Magnificient Magic Store

Version 6
ToB only!

3rd of 7nd 2009


___________________________________________________________________

* The only ones totally free are the mentally ill. They can jump off a roof totally believing they can fly...
* ...but then, there's always gravity...
___________________________________________________________________


Section list:

1. Installation and uninstallation.

2. Mod description

3. Mod technical notes & random data

4. Mod item list

5. Waves of insanity

6. Known bugs

7. FAQ

8. Thanks

9. Mod update notes

10. Version history


___________________________________________________________________


Section 1: Installation and Uninstallation


Installation:

1. Unzip to Baldur's Gate 2 : Throne of Bhaal main directory.
 * NOTE: Use the "Folder names" option.
2. Run Setup-Tzshop01.exe


Uninstallation:

1. Run Setup-Tzshop01.exe and choose Uninstall from the menu.
2. Delete folder Tzshop01
3. Delete program Setup-Tzshop01.exe
4. Delete files Readme-Tzshop01.txt and Setup-Tzshop01.tp2


Updating:
1. Uninstall the older Tzshop01 mod and Install the new Tzshop01 mod.
 * NOTE: A new version number indicates that a new .sto file is used.
 *       A new .sto file destroys all sold items and gives all mod items.

 * NOTE: A in-version update (from version 2.01 to 2.02) indicates that
 *       items are being updated, or similiar changes. If new items are
 *       added, it means that getting them will require cheating or
 *       starting a new game. See section X for such items.


___________________________________________________________________


2. Mod description

A shop mod, this is.
It adds some great items.
Adds a store conjuring item and 3 new stores.
Adds over 20 items.

This mod was originally designed to add some L33T items to my games,
but it is currently used as a shop mod that adds powerful and expensive
items to the game.

Any suggestions are welcome to my e-mail, and i am often at the 
sorcerers.net boards.

The mod seems to be missing something, anyone finding it please mail it to me.


___________________________________________________________________


3. Mod technical notes & Random data

Programs used:

WeiDU
IEEP
Notepad
ConTEXT
ShadowKeeper
Near Infinity

The mod version updates are done by renaming the store files, so
the save game has not saved it.


___________________________________________________________________


4. Item list

Name				Type		Shop



Book of Store Conjuring		Book		The Magnificient Magic Store

Vampire's Bane			Amulet		The Magnificient Magic Store

Assasin's Cloak			Cloak		The Magnificient Magic Store

Survivor's Ring			Ring		The Magnificient Magic Store

Elven Chainmail +1		Chain mail	The Magnificient Magic Store

Dwarven Mithril Chain		Chain mail	The Magnificient Magic Store

Wise man's plate		Full Plate Mail	The Magnificient Magic Store

Guard's Sword			Longsword	The Magnificient Magic Store

Forest Scimitar			Scimitar	The Magnificient Magic Store

Spear of Dragonbreath		Spear		The Magnificient Magic Store



Amulet of Mirrors		Amulet		The Magnificient Magic Shop

Bracers of Genius		Bracers		The Magnificient Magic Shop

Magnet Bracers			Bracers		The Magnificient Magic Shop

Ring of Speed			Ring		The Magnificient Magic Shop

Icewall				Shield		The Magnificient Magic Shop

Club of Giants			Club		The Magnificient Magic Shop

Rage of Souls			Katana		The Magnificient Magic Shop

Nature's Revenge		Longsword	The Magnificient Magic Shop

Burglar's Sword			Short sword	The Magnificient Magic Shop

Trollspear			Spear		The Magnificient Magic Shop



Amulet of Vecna			Amulet		The Magnificient Magic Store - ToB

Improved Boots of Speed		Boots		The Magnificient Magic Store - ToB

Ring of Vecna			Ring		The Magnificient Magic Store - ToB

Katana of Gods			Katana		The Magnificient Magic Store - ToB

Storm Scimitar			Scimitar	The Magnificient Magic Store - ToB


___________________________________________________________________


5. Waves of insanity & Echoes of the God's voice



One has lots of time for reflection while waiting for the ENDLESS WAVES OF BAD DOGGIE WEREWOLF MONSTERS THAT CHEW YOUR TOES WHILE YOU SLEEP!!


Many many pretties... piled high beyond the sky. (sigh) 


Ooo!  Shiny ones!!


"I once knew a Red Mage of Thay
 Who dreamed of lichdom some day.
 He said he knew how to do it
 But he still managed to screw it
 up in the funniest way"


"Hmmm...  find someone rich, and kill them.  Find someone richer, and kill them, too!  Hack and slash your way to fortune!  Woo-hoo!!"



Tiax fails to see how this will aid in his ascension!

When Tiax rules, breeches shall not ride up so wedge-like!

Night would DARE hamper the sight of Tiax?!

The day comes when TIAX will point and click!


___________________________________________________________________


6. Known bugs:

Tried to fix 'em all


___________________________________________________________________


7. FAQ

Q: Why does it not install?

A: I don't know, but me guesses that you do not have the folder tzshop01 in your
   BG2 folder. If there is, check that inside the tzshop01 folder is the "backup"
   folder. Those 2 reasons have caused 2/3 of problems and 100% of install problems
   in my mod's history.

A2: You have ToB, right? 'Cause i have no idea about non-ToB using.

A3: Do you have anything in the BG2 folder write-protected?


___________________________________________________________________


8. Thanks

Westley Weimer - for the main tool

Jason Compton  - for some VERY important install help
(and because of Kelsey, of course)

Ghreyfain      - for the great WeiDU tutorial
(which did though cause most bugs in v.1.01)


___________________________________________________________________


9. Mod update notes


This section is just notes for keeping track of the bigger updates.
Unless you are helping me to build te mod, i guess it will not benefit you much.


Added a lot of items

The mod works for people with no "TutorialNPC" folder in their BG2 folder.
(A Micro$oft class bug)

Added the Conjurable Stores upgrade to the mod.

Divided the items into 3 shops.

Maked sure the unzipping process with WinZip would create the backup folder.
(A Micro$oft class bug)

Updated the Conjurable stores to support Arcana Archieves.
Updated the Conjurable stores to check if you freed the slaves
to open the special Copper Coronet. (There was the first good global)

Writed a whole new readme


___________________________________________________________________


10. Version history

1.00: The first alfa version. Did not work so well.

1.01: The fixed version, with fixed items.

2.00: Added a lot of items. Made a lot of items cursed.

2.01: Removed some not-so-well working items, as a monk-only armor.

2.02: Re-balancing some items.
      Removing the color change from the Assasin's Cloak
      Removing the "Cursed" attribute from a lot of items.
      (it began to annoy me VERY seriously)
      Updating to WeiDU 105

2.03: Added ToB Storekeeper.
      Added Conjurable stores.

3.00: Divided the items to 3 separate shops.
      Un-rebalancing some items due the split.
      Added the total insanity section.
      Fixed the Club of Giants.

3.01: Added the Arcana Archieves to the Conjurable Stores.
      Removed the ability to access special Copper Coronet
      without freeing the slaves.
      Writed a whole new Readme. Much cleaner now.
      The old readme is at tzshop01 folder at the name of Readme_old

4.00: Traified the mod
      Added Polish translation by Alvarez

5.00: Added German translation by Rumpelstilz
      Added Russian translation by aerie.ru
      Added README command in TP2
      Added VERSION-flag in TP2
      Added WeiDU v211

6.00: Added Italian translation by Ilot
      Removed "lite version note READ ME FIRST.txt"
