Author Tapio Kivikkola <zap@mad.scientist.com>
The Magnificient Magic Store V. 3 (3.01) (with rebalanced items).
ToB ONLY!


Ooooh kaaaay. This readme is a mess. Well, i like it that way. Maybe someday i will clean it. Not today. Today Taza sleeps.


----------------------------------------------------
Programs used (in order of usage): ConTEXT, WeiDU,
IEEP Store Maker/Item Maker, ShadowKeeper.
----------------------------------------------------




Installation: 
1.Unzip to BG2 main directory (WITH "FOLDER NAMES" OPTION TURNED ON)
2.Run Setup-Tzshop01.exe.


Uninstallation: 
1.Run Setup-Tzshop01.exe and choose "uninstall". 
2.Delete directory Tzshop01 and files Setup-Tzshop01.tp2, SetupTzshop01.exe and Readme-TZShop01.txt (this file).


Updating from an older version:
Uninstall the older mod and install this version.
*Problem: Some items are duplicating and all sold items will disappear.
*This is because i wanted to make it combatible with the older mod and saves with the older mod.
*BG2 saves the .sto file in the savegame. So, i took a new name for this .sto file.
*The older shop IS in the save file, the dialogue does just not start it.



NOTE!!! THE VERSION NUMBER CHANGE INDICATES NON-COMBATILITY.
(2.01-2.02 are combatible, 1.01-2.01 are not.)
(A side note= you can not get the portable store in a save from version 2.01/2.02)
(A solution= Create item "StoreBag")
The combatility means that you can just install it and you get the benefits
without starting a new game.


-------------------------------------------------------


The mod adds a new shop near adventurer's mart (And in ToB private plane. Just added feature). This shop sells different kinds of overpowered items (currently *i am too lazy to count them, over 20 anyway*).

Feedback/new item requests/item ideas are welcome. I am not so creative.


---------------------------------------------------------


New versions data: (This is what gets bigger in new versions)


********************************************************************


A new version. With a huge bug amount, i guess. Just like Microsoft.

* A REAL BUGFIX: I had a bug in directory names because of the Ghreyfain's
* great tutorial... and i was lazy...
* Now my mod works on those people who do not have a directory called tutorialnpc
* in their bg2 folder...



Added the Conjurable Store. You can access to stores through a book.



HA! A new version. And up there shows i was right. Just like Micro$oft.

A backup folder was not created for users of WinZip. A bad zipping program, that.

There are now three separate stores, which do open at chapter 1, chapter 6 and chapter 8.

Planning to add soon a support to the Lazarus shop...
Done...

*******************************************************************

A temporary wave of total insanity (Long live NearInfinity!):


One has lots of time for reflection while waiting for the ENDLESS WAVES OF BAD DOGGIE WEREWOLF MONSTERS THAT CHEW YOUR TOES WHILE YOU SLEEP!!


Many many pretties... piled high beyond the sky. (sigh) 


Ooo!  Shiny ones!!


"I once knew a Red Mage of Thay
 Who dreamed of lichdom some day.
 He said he knew how to do it
 But he still managed to screw it
 up in the funniest way"


"Hmmm...  find someone rich, and kill them.  Find someone richer, and kill them, too!  Hack and slash your way to fortune!  Woo-hoo!!"


Tiax fails to see how this will aid in his ascension!

When Tiax rules, breeches shall not ride up so wedge-like!

Night would DARE hamper the sight of Tiax?!

The day comes when TIAX will point and click!


********************************************************************


---------------------------------------------------------


FAQ:
Q: Why are these items so expensive?
A: To balance the fact that some are overpowered.
BTW: Any party can have over 400.000 gp before leaving Waukeen's promenade.


Q: How can any party have over 400.000 gp before leaving Waukeen's promenade?
A: Get Yoshimo in to the party or be a thief yourself. Minimum Pickpocket score 45.
(Doing the circus quest gives Yoshimo the needed EXP to gain a level, and then he
can raise his score to 45) Buy 2 potions of master thievery and 2 potions of perception.
Wait until night and go see Jayce (thief in far right). Drink the potion's and steal the
Martial Staff. Sell it back and resteal it. When you have enough money go buy a more
expensive item (49.000 for the plate of balduran, you gain 10.500 per steal/sell round.)
Continue until you have enough money.

45 pickpocketing + 2 master thievery potions + 2 potions of perception =
165 pickpocketing. Enough to steal 99% unnoticed. (In practice)

220 pickpocketing = 0.01% error ratio. (About)



Q: How many pirates were involved in the making of The Magnificient Magic Store? 
Were any of them harmed?
A:Go check Kelsey:Tob FAQ.


Q: Does the Magnificient Magic Shop sell Baseball bats?
A: No, if you do not count the Club of Giants as one. And no, that has
nothing to do with baseball.


---------------------------------------------------------


Known Bugs:
The Club of Giants seems unequipable. Don't know which causes this.
Help needed.
Testing that...
Done. Got bored in it, and found out that my version of IEEP is buggy.

---------------------------------------------------------


Help Notes (the place where the thanks come)

(Not thanking Westley Weimer here, it should be obvious that this project uses his work)

Idea for the conjurable shop was stolen from the Bag of Holding section in BG1-Ease.


---------------------------------------------------------

22th of 2nd 2003
Tapio Kivikkola

* The only ones totally free are the mentally ill. They can jump off a roof totally believing they can fly...
* ...but then, there's always gravity...

----------------------------------------------------------


Version history


1.00 First one.


1.01 Fixed some items after testing.


2.00 Adding a lot of items(19). Making Survivor's ring cursed.


2.01 Removing some items.


2.02 Re-Balancing Ring of Vecna and Katana of Gods.
Removing the color change made by the Assasin's Cloak.
Removing the attribute "cursed" from a lot of items (still keeping the Survivor's ring).
Upgraded to Weidu Version 105


2.03 Added ToB Storekeeper. Made this mod ToB-only.
Added "Conjurable Stores" item, which lets you open some shops.
(Meaning= you can open Adventurer's Mart from ToB!)
Added a lot of free space to the readme. Minor bugfixes.


3.00 Divided the items to 3 separate shops. (ToB, Chapter 6, Original)
Un-rebalancing the Katana of Gods. It doesn't need that in ToB.
Added more free space in the readme.
Added the total insanity section.
Fixed the Club of Giants

3.01 Added Arcana Archieves to shop list. Made that you could not enter
the better copper coronet trough the conjurable stores book without freeing
the slaves in the slave ship.
