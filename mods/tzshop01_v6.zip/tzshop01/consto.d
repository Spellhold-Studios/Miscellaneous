BEGIN TZCONSTO

IF ~True()~ THEN BEGIN Shops
SAY @0
IF ~~ THEN REPLY @1 GOTO Advmart
IF ~GlobalGT("Chapter","Global",5)
PartyGoldGT(49)~ THEN REPLY @2 GOTO Advmarts
IF ~GlobalGT("FreeSlaves","Global",0)~ THEN REPLY @3 GOTO Coppsto
IF ~~ THEN REPLY @4 GOTO Magnisto
IF ~GlobalGT("Chapter","Global",5)~ THEN REPLY @5 GOTO Magstoc5
IF ~GlobalGT("Chapter","Global",7)~ THEN REPLY @6 GOTO Magstoc7
IF ~GlobalGT("lazarus","global",2)~ THEN REPLY @7 GOTO Arcana1
IF ~~ THEN REPLY @8 GOTO Perboh
IF ~~ THEN REPLY @9 GOTO Outshop
END

IF ~~ THEN BEGIN Arcana1
SAY @10
IF ~~ THEN DO ~StartStore("25spell",Player1)~ EXIT
END

IF ~~ THEN BEGIN Magstoc5
SAY @10
IF ~~ THEN DO ~StartStore("tzshop20",Player1)~ EXIT
END

IF ~~ THEN BEGIN Magstoc7
SAY @10
IF ~~ THEN DO ~StartStore("tzshop40",Player1)~ EXIT
END

IF ~~ THEN BEGIN Advmart
SAY @10
IF ~~ THEN DO ~StartStore("Ribald",Player1)~ EXIT
END

IF ~~ THEN BEGIN Advmarts
SAY @10
IF ~~ THEN DO ~StartStore("Ribald3",LastTalkedToBy(Myself))
TakePartyGold(50)~ EXIT
END

IF ~~ THEN BEGIN Coppsto
SAY @10
IF ~~ THEN DO ~StartStore("Bernard2",LastTalkedToBy(Myself))~ EXIT
END

IF ~~ THEN BEGIN Magnisto
SAY @10
IF ~~ THEN DO ~StartStore("tzshop03",LastTalkedToBy(Myself))~ EXIT
END

IF ~~ THEN BEGIN Perboh
SAY @10
IF ~~ THEN DO ~StartStore("perboh",LastTalkedToBy(Myself))~ EXIT
END

IF ~~ THEN BEGIN Outshop
SAY @11
IF ~~ THEN DO ~DestroySelf()~ EXIT
END
