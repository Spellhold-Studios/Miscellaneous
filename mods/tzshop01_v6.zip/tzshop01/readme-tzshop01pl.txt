Autor: Tapio Kivikkola
T�umacz: Alvarez

Magiczne Rozmaito�ci

Modyfikacja dla Baldur's Gate II: Tron Bhaala
(wi�cej w pliku Readme-TZShop01.txt)

Wszelkie pytania dotycz�ce tej modyfikacji mo�esz zada� tutaj:
http://forum.cob.netarteria.pl/viewforum.php?f=81
Polskie centrum moddingu i t�umacze� mod�w do Sagi Baldur's Gate
Klan Children of Bhaal