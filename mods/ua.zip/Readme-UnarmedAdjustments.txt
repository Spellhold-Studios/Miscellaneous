
                        ---------------------
                         Unarmed Adjustments
                        ---------------------

Unarmed weapon tweaks for Baldur's Gate II: Throne of Bhaal.



Install:
--------

Extract all files to the folder BGII is installed to.
Run Setup-UnarmedAdjustments.exe and follow the prompt.



Description:
------------

This mod has two components, one affecting monk attacks, the other
werewolf claw attacks of the shapeshifter druid kit.

Monk: The monk's fists are now considered magical (+1) from level 6
instead of level 9. I've made this change because in Baldur's Gate
Trilogy monks usually have a hard time getting to level 9 without being
able to hit foes who are immune to normal weapons.

Shapeshifter: The werewolf claws now deal slashing damage instead of
piercing. Furthermore, the Greater Werewolf's claws are now considered
+4 instead of +2. I've made this latter change because shapeshifters
often become less useful in the Throne of Bhaal where a large number of
foes are immune to weapons of weaker enchantments.



Credits:
--------

mod by Adul (adul@adul.net)



Thanks for downloading!
