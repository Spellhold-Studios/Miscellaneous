BEGIN RBARMOR

IF ~NumTimesTalkedTo(0)~ THEN BEGIN FirstMeeting
SAY ~Good day to thee. Come to see my wares have you?~
IF ~~ THEN REPLY ~Well, yes I'll see what you have.~ GOTO BuyStuff
IF ~~ THEN REPLY ~No, good day.~ GOTO GoodBye
IF ~~ THEN REPLY ~Hmmmm, you look rich, mind if I kill you?~ GOTO BackOff
END

IF ~~ THEN BEGIN BuyStuff
SAY ~Very well then, I'm quite sure you will not be dissapointed.~
IF ~~ THEN DO ~StartStore("rbarmor",LastTalkedToBy())~ EXIT
END

IF ~~ THEN BEGIN GoodBye
SAY ~Very well then, I will still be here.~ 
END

IF ~~ THEN BEGIN BackOff
SAY ~I wouldn't even think so if I were you. My fighting skills would slay you within an instant.~
IF ~~ THEN REPLY ~Very well I shall see what you have.~ DO ~StartStore("rbarmor",LastTalkedToBy())~ EXIT
END

IF ~NumTimesTalkedToGT(0)~ THEN BEGIN HiAgain
SAY ~Hello again friend, come to view my wares.~
IF ~~ THEN REPLY ~Yes~ DO ~StartStore("rbarmor",LastTalkedToBy())~ EXIT
IF ~~ THEN REPLY ~No, good day.~ EXIT
END