BEGIN w_msword

IF ~Global("w_moonblade","AR0602",1)
 InParty("Worgas")
!Dead("Worgas") 
!StateCheck("Worgas",STATE_SLEEPING)~ THEN BEGIN moontalk
SAY ~Worgas, I choose you as the current worthy bearer of myself due to my former owner Joneleth's chosen path.~
IF ~~ THEN GOTO moontalk01
END

IF ~~ THEN BEGIN moontalk01
SAY ~May your choices be wise and pure and thus shall I stand by your side.~
IF ~~ THEN DO ~SetGlobal("w_moonblade","AR0602",2)
ActionOverride("w_sword",DestroySelf())~ EXIT
END

IF ~Global("w_moonleave","GLOBAL",1)~ THEN BEGIN moonleave
SAY ~The actions of this group force me to leave in disgust.~
IF ~~ THEN DO ~SetGlobal("w_moonleave","GLOBAL",2)
CreateVisualEffectObject("ICMAGICH",Myself)
ActionOverride("w_sword",DestroySelf())~ EXIT
END

