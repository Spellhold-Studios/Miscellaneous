BEGIN w_med

IF 
~Global("w_medusaspawn","AR1700",1)
InParty("Worgas")
!StateCheck("Worgas",STATE_SLEEPING)~ THEN BEGIN 0
SAY ~So I found you at last! Hand over the ring or I�ll turn your heart into stone.~ 
IF ~~ THEN DO ~Enemy()
SetGlobal("w_medusaspawn","AR1700",2)~ EXIT
END

