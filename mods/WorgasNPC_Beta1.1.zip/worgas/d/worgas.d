I_C_T YOSHIMO 0 Worgas1
 == WORGASJ   IF ~InParty("Worgas")
!StateCheck("Worgas",CD_STATE_NOTVALID)~ THEN ~Bounty Hunter, bad dog away with you, BAD DOG!~ [PPDRAD01]
== YOSHIMO IF ~InParty("Worgas")~ THEN ~Calm down, elven one. I have no hostile intentions towards you.~
END

I_C_T YOSHIMO 12 Worgas2
== WORGASJ   IF ~InParty("Worgas")
!StateCheck("Worgas",CD_STATE_NOTVALID) ~ THEN ~Pretties piled two things discovered to help us escape. Number one, Kill you! Number two, Kill you!~
== YOSHIMO IF ~InParty("Worgas")~ THEN ~Lower your hands elf, I am a man of truth. As I said I am in the same boat as you, imprisoned in this unholy place.~
END

I_C_T C6ELHAN2 1 Worgas3
== WORGASJ  IF ~InParty("Worgas")
!StateCheck("Worgas",CD_STATE_NOTVALID) ~ THEN ~Umm, my pretties...~
== C6ELHAN2 IF ~InParty("Worgas")~ THEN ~Worgas, is that you? By Rillifane, I didn�t expect to see you here. I heard horrible tales of your fate.~
== WORGASJ  IF ~InParty("Worgas")~ THEN ~There where the pretties were hidden...All the experiments. Bad dogs, BAD DOGS!~
== C6ELHAN2 IF ~InParty("Worgas")~ THEN ~You must have experienced things far too uncanny to imagine.~
== WORGASJ   IF ~InParty("Worgas")~ THEN ~Far too high they where piled and now <CHARNAME> is ensnared in our destiny.~
== C6ELHAN2 IF ~InParty("Worgas")~ THEN ~I sense that you are unbalanced Worgas, but your words about <CHARNAME> radiate truth.~
END

I_C_T C6ELHAN2 2 Worgas4
 == WORGASJ  IF ~InParty("Worgas")
!StateCheck("Worgas",CD_STATE_NOTVALID) ~ THEN ~Umm, my pretties...~
 == C6ELHAN2 IF ~InParty("Worgas")~ THEN ~Worgas is that you? By Rillifane, I didn�t expect to see you here. I heard horrible tales of your fate.~
== WORGASJ   IF ~InParty("Worgas")~ THEN ~There where pretties were hidden...All the experiments. Bad dogs, BAD DOGS!~
  == "C6ELHAN2" IF ~InParty("Worgas")~ THEN ~You must have experienced things far too uncanny to imagine.~
  == WORGASJ   IF ~InParty("Worgas")~ THEN ~Far too high they where piled and now <CHARNAME> is ensnared in our destiny.~
  == C6ELHAN2 IF ~InParty("Worgas")~ THEN ~I sense that you are unbalanced Worgas, but your words about <CHARNAME> radiate truth.~
END

I_C_T C6ELHAN2 3 Worgas5
  == WORGASJ   IF ~InParty("Worgas")
!StateCheck("Worgas",CD_STATE_NOTVALID) ~ THEN ~Umm, my pretties...~
  == C6ELHAN2 IF ~InParty("Worgas")~ THEN ~Worgas, is that you? By Rillifane, I didn�t expect to see you here. I heard horrible tales of your fate.~
  == WORGASJ   IF ~InParty("Worgas")~ THEN ~There were pretties hidden...All the experiments. Bad dogs, BAD DOGS!~
== C6ELHAN2 IF ~InParty("Worgas")~ THEN ~You must have gone through things far too uncanny to imagine.~
== WORGASJ   IF ~InParty("Worgas")~ THEN ~Far too high they where piled and now <CHARNAME> is ensnared in our destiny.~
  == C6ELHAN2 IF ~InParty("Worgas")~ THEN ~I sense that you are unbalanced Worgas but your words about <CHARNAME> radiate truth.~
END

I_C_T C6ELHAN2 4 Worgas6
  == WORGASJ   IF ~InParty("Worgas")
!StateCheck("Worgas",CD_STATE_NOTVALID) ~ THEN ~Umm, my pretties...~
  == C6ELHAN2 IF ~InParty("Worgas")~ THEN ~Worgas is that you? By Rillifane, I didn�t expect to see you here. I heard horrible tales of your destiny.~
  == WORGASJ   IF ~InParty("Worgas")~ THEN ~There where pretties hidden...All the experiments. Bad dogs, BAD DOGS!~
  == C6ELHAN2 IF ~InParty("Worgas")~ THEN ~You must have gone through things far too uncanny to imagine.~
  == WORGASJ   IF ~InParty("Worgas")~ THEN ~Far too high they where piled and now <CHARNAME> is ensnared in our outcome.~
  == C6ELHAN2 IF ~InParty("Worgas")~ THEN ~I sense that you are unbalanced Worgas but your words about <CHARNAME> radiates truth.~
END

I_C_T C6ELHAN2 5 Worgas7
  == WORGASJ   IF ~InParty("Worgas")
!StateCheck("Worgas",CD_STATE_NOTVALID) ~ THEN ~Umm, my pretties...~
  == C6ELHAN2 IF ~InParty("Worgas")~ THEN ~Worgas is that you? By Rillifane, I didn�t expect to see you here. I heard horrible tales of your destiny.~
  == WORGASJ   IF ~InParty("Worgas")~ THEN ~There where pretties hidden...All the experiments. Bad dogs, BAD DOGS!~
  == C6ELHAN2 IF ~InParty("Worgas")~ THEN ~You must have gone through things far too uncanny to imagine.~
  == WORGASJ   IF ~InParty("Worgas")~ THEN ~Far too high they where piled and now <CHARNAME> is ensnared in our outcome.~
  == C6ELHAN2 IF ~InParty("Worgas")~ THEN ~I sense that you are unbalanced Worgas but your words about <CHARNAME> radiates truth.~
END

I_C_T W_COW02 0 Worgas8
  == WORGASJ   IF ~InParty("Worgas")
!StateCheck("Worgas",CD_STATE_NOTVALID) ~ THEN ~Yiaaaaii!, Don�t listen to the evil ones of manipulation!~ [PPNALJ03]
 == W_COW02 IF ~InParty("Worgas")~ THEN ~You will come with us!~
END

I_C_T PLAYER1 33 Worgas9
  == WORGASJ   IF ~InParty("Worgas")
!StateCheck("Worgas",CD_STATE_NOTVALID) ~ THEN ~Umm, my pretties...lay your worries to the side, Worgas in fear will not hide.~ [PPNALJ01] 
  == PLAYER1 IF ~InParty("Worgas")~ THEN ~Worgas: The elf, aside from sharing your battles also has fought his own inner battle of twisted emotions. The tormented feelings he carries is something you can relate to.~
  == WORGASJ   IF ~InParty("Worgas")~ THEN ~There were pretties hidden now piled by your side.~
  == PLAYER1 IF ~InParty("Worgas")~ THEN ~Worgas, this battle is mine to fight alone. You are free to move on and hopefully find rest for yourself.~
  == WORGASJ   IF ~InParty("Worgas")~ THEN ~Yaaaaii!, The rest is for Irenicus to have. An eternal rest that suits him best. You may stay but I will move on and put Irenicus out of the way!~ [PPNALJ03] 
END

I_C_T PLAYER1 25 Worgas10
  == WORGASJ   IF ~InParty("Worgas")
!StateCheck("Worgas",CD_STATE_NOTVALID) ~ THEN ~All dogs go to heaven! Worgas goes to hell where all the pretties fell.~ [PPDRAD03] 
END

I_C_T PLAYER1 16 Worgas11
  == WORGASJ   IF ~InParty("Worgas")
!StateCheck("Worgas",CD_STATE_NOTVALID) ~ THEN ~Many, many pretties piled high above the sky and so will Irenicus die.~ [PPNALJ09] 
END

I_C_T PLAYER1 3 Worgas12
  == WORGASJ   IF ~InParty("Worgas")
!StateCheck("Worgas",CD_STATE_NOTVALID) ~ THEN ~You! Do I know you? No I do not know anyone! Back, bad dog, PIG!.~ [PPDRAD02] 
END

I_C_T PLAYER1 5 Worgas13
  == WORGASJ   IF ~InParty("Worgas")
!StateCheck("Worgas",CD_STATE_NOTVALID) ~ THEN ~Down to the dogs, BAD DOG!~ [PPDRAD14] 
END

I_C_T VICG1 1 Worgas14
  == WORGASJ   IF ~InParty("Worgas")
!StateCheck("Worgas",CD_STATE_NOTVALID) ~ THEN ~Yiaaaaii!! Burn evil being of madness from the pits of badness, BURN!~ [PPNALJ03] 
END

I_C_T VICONI 10 Worgas15
  == WORGASJ   IF ~InParty("Worgas")
!StateCheck("Worgas",CD_STATE_NOTVALID) ~ THEN ~No <CHARNAME>, bad dog the drow, BAD DOG!~ [PPDRAD01]
  == VICONI IF ~InParty("Worgas")~ THEN ~Lil alurl! For Shar! <CHARNAME> I beg you!~ [VICONI10]
  == WORGASJ   IF ~InParty("Worgas")~ THEN ~IiiaaAAARGH! Burn to ashes like the being sprung from trashes!~ [XZARR39] 
  == VICONI IF ~InParty("Worgas")~ THEN ~Foul elf! You take the part of humans whom defile the forest your people dwell in.~
  == WORGASJ   IF ~InParty("Worgas")~ THEN ~Defile and not to be piled high, likewise you must die!~
END

I_C_T VICONI 2 Worgas16
  == WORGASJ   IF ~InParty("Worgas")
!StateCheck("Worgas",CD_STATE_NOTVALID) ~ THEN ~Bad dog, away with you, BAD DOG! Foul tongue spitting words of evil and decay!~ [PPDRAD01]
  == VICONI IF ~InParty("Worgas")~ THEN ~Elf, if it weren't for <CHARNAME> your throat would have been quickly slit.~
  == WORGASJ   IF ~InParty("Worgas")~ THEN ~IiiaaAAARGH! Keep her away from my pretties <CHARNAME>!~ [XZARR39] 
END

I_C_T VICONI 15 Worgas17
  == WORGASJ   IF ~InParty("Worgas")
!StateCheck("Worgas",CD_STATE_NOTVALID) ~ THEN ~Bad dog, away with you, BAD DOG!~ [PPDRAD01]
END

I_C_T KGENIE1 3 Worgas18
  == WORGASJ   IF ~InParty("Worgas")
!StateCheck("Worgas",CD_STATE_NOTVALID) ~ THEN ~Mmmm, me pretties, Worgas thinks high the bad dog prince 30 and the prettie princess 40.~ [PPNALJ01]
END

I_C_T RIFTG01 0 Worgas19
  == WORGASJ   IF ~InParty("Worgas")
!StateCheck("Worgas",CD_STATE_NOTVALID) ~ THEN ~Mmmm, me pretties, Worgas thinks high the Life.~ [PPNALJ01]
END

I_C_T RIFTG01 12 Worgas20
  == WORGASJ   IF ~InParty("Worgas")
!StateCheck("Worgas",CD_STATE_NOTVALID) ~ THEN ~Mmmm, me pretties, Worgas thinks high the Time.~ [PPNALJ01]
END

I_C_T RIFTG01 26 Worgas21
  == WORGASJ   IF ~InParty("Worgas")
!StateCheck("Worgas",CD_STATE_NOTVALID) ~ THEN ~Mmmm, me pretties, Worgas thinks high the Current one.~ [PPNALJ01]
END

I_C_T SHAAVA01 0 Worgas22
  == WORGASJ   IF ~InParty("Worgas")
!StateCheck("Worgas",CD_STATE_NOTVALID) ~ THEN ~Say a prayer to the light my pretties.~ [PPNALJ01]
END

I_C_T SHAAVA01 1 Worgas23
  == WORGASJ   IF ~InParty("Worgas")
!StateCheck("Worgas",CD_STATE_NOTVALID) ~ THEN ~Hold the Holy Book high my pretties and the sun might bless it.~ [PPNALJ01]
END

I_C_T SHAAVA01 2 Worgas24
  == WORGASJ   IF ~InParty("Worgas")
!StateCheck("Worgas",CD_STATE_NOTVALID) ~ THEN ~Light conquers the Dark my pretties.~ [PPNALJ01]
END

I_C_T SHAAVA01 7 Worgas25
  == WORGASJ   IF ~InParty("Worgas")
!StateCheck("Worgas",CD_STATE_NOTVALID) ~ THEN ~Sing a hymn my pretties.~ [PPNALJ01]
END

I_C_T SHAAVA01 8 Worgas26
  == WORGASJ   IF ~InParty("Worgas")
!StateCheck("Worgas",CD_STATE_NOTVALID) ~ THEN ~Raise hands to the light my pretties.~ [PPNALJ01]
END

I_C_T SHAAVA01 9 Worgas27
  == WORGASJ   IF ~InParty("Worgas")
!StateCheck("Worgas",CD_STATE_NOTVALID) ~ THEN ~Rejoice the dominance of the light my pretties.~ [PPNALJ01]
END

I_C_T SHAAVA01 14 Worgas28
  == WORGASJ   IF ~InParty("Worgas")
!StateCheck("Worgas",CD_STATE_NOTVALID) ~ THEN ~Recite the Tenets of the Faith my pretties.~ [PPNALJ01]
END

I_C_T SHAAVA01 15 Worgas29
  == WORGASJ   IF ~InParty("Worgas")
!StateCheck("Worgas",CD_STATE_NOTVALID) ~ THEN ~Children held high to see the sun. Pretties piled high beyond the sky.~ [PPNALJ01]
END

I_C_T SHAAVA01 16 Worgas30
  == WORGASJ   IF ~InParty("Worgas")
!StateCheck("Worgas",CD_STATE_NOTVALID) ~ THEN ~Yiaaaaii!! Mourn the Sun giving way to the onslaught of night. Many, many pretties.~ [PPNALJ03]
END

I_C_T FINSOL01 27 Worgas31
  == WORGASJ   IF ~InParty("Worgas")
!StateCheck("Worgas",CD_STATE_NOTVALID) ~ THEN ~Many, many pretties...piled high beyond the sky. (sigh) Amongst those you should choose to stand by.~ [PPNALJ09]
END

I_C_T SAREV25A 3 Worgas32
  == WORGASJ   IF ~InParty("Worgas")
!StateCheck("Worgas",CD_STATE_NOTVALID) ~ THEN ~No! You speak too much of what can be seen. I wish to only see my pretties again. I won't look too far, I promise.~ [PPNALJ10]
  == SAREV25A IF ~InParty("Worgas")~ THEN ~Silence! You riddle talking mad elf!~
  == WORGASJ   IF ~InParty("Worgas")~ THEN ~IiiaaAAARGH! Mad, mad!? Think us out from here <CHARNAME>...I won't look too far...~ [XZARR39] 
END

I_C_T UDSILVER 53 Worgas33
  == "WORGASJ"   IF ~InParty("Worgas")
!StateCheck("Worgas",CD_STATE_NOTVALID) ~ THEN ~Yiaaaaii!! Nau! inbau ol tir uns'aa!~ [PPNALJ03] 
END

I_C_T UDSILVER 36 Worgas34
  == WORGASJ   IF ~InParty("Worgas")
!StateCheck("Worgas",CD_STATE_NOTVALID) ~ THEN ~YiaAAArgh! Ol flamgran! szithrelen d' inlul verin aterrucen harl ussta waess!~ [XZARR39] 
END

I_C_T HELLJON 1 Worgas35
  == WORGASJ   IF ~InParty("Worgas")
!StateCheck("Worgas",CD_STATE_NOTVALID) ~ THEN ~YiaAAArgh! Joneleth to death!~ [XZARR39] 
== HELLJON IF ~InParty("Worgas")~ THEN ~Worgas, I won't even bother to destroy you since your inner demons has already accomplished that.~
END

I_C_T 25SPELL 13 Worgas36
  == WORGASJ   IF ~InParty("Worgas")
!StateCheck("Worgas",CD_STATE_NOTVALID) ~ THEN ~Many, many pretties...piled high beyond the sky (sigh).~ [PPNALJ09]
  == 25SPELL  IF ~InParty("Worgas")~ THEN ~What?~ 
  == WORGASJ   IF ~InParty("Worgas")~ THEN ~I used to have me pretties. Some are hidden...only I can see. You want to see?~ [PPNALJ07] 
  == 25SPELL  IF ~InParty("Worgas")~ THEN ~To hear such riddles of madness surely caused from magical energy makes me rethink the sanity of my involvement in this business.~
  == WORGASJ   IF ~InParty("Worgas")~ THEN ~Yiaaaaii!!~ [PPNALJ03]
  == 25SPELL IF  ~InParty("Worgas")~ THEN ~You are lost within your inner maze...never mind that now, <CHARNAME> will you aid me?~
END

I_C_T JAN 1 Worgas37
 == WORGASJ   IF ~InParty("Worgas")
!StateCheck("Worgas",CD_STATE_NOTVALID) ~ THEN ~Mmmm, me pretties.~ [PPNALJ01] 
== JAN IF ~InParty("Worgas")~ THEN ~They could be yours for a small fee. Turnips are known for their curative power against mental instability, not to say that you need it though, dear elven customer.~
END

I_C_T JAN 10 Worgas38
  == WORGASJ   IF ~InParty("Worgas")
!StateCheck("Worgas",CD_STATE_NOTVALID) ~ THEN ~Mmmm, me pretties~ [PPNALJ01] 
== JAN IF ~InParty("Worgas")~ THEN ~Indeed pretties they are, these fine turnips. And don�t forget about their curative effects against mental illness, my elven friend.~
END

I_C_T GORMAD1 0  Worgas39
  == WORGASJ   IF ~InParty("Worgas")
!StateCheck("Worgas",CD_STATE_NOTVALID) ~ THEN ~Yiaaaaii!! Yak to be replaced by Mad! <CHARNAME>, this elf is mad! I, Worgas, am far too intelligent to be bothered by madmen!~ [PPNALJ03] 
END

I_C_T GORMAD1 1  Worgas40
  == WORGASJ   IF ~InParty("Worgas")
!StateCheck("Worgas",CD_STATE_NOTVALID) ~ THEN ~Bad dog away with you!~ [PPDRAD01] 
END

I_C_T GORMAD1 3  Worgas41
  == WORGASJ   IF ~InParty("Worgas")
!StateCheck("Worgas",CD_STATE_NOTVALID) ~ THEN ~Bad dog away with you!~ [PPDRAD01] 
END

I_C_T GORMAD1 4  Worgas42
  == WORGASJ   IF ~InParty("Worgas")
!StateCheck("Worgas",CD_STATE_NOTVALID) ~ THEN ~Bad dog away with you!~ [PPDRAD01] 
END

I_C_T GORMAD1 5  Worgas43
  == WORGASJ   IF ~InParty("Worgas")
!StateCheck("Worgas",CD_STATE_NOTVALID) ~ THEN ~Bad dog away with you!~ [PPDRAD01] 
END

I_C_T GAAL 0 Worgas44
  == WORGASJ   IF ~InParty("Worgas")
!StateCheck("Worgas",CD_STATE_NOTVALID) ~ THEN ~Yiaaaaii!! You are inflicted with madness. My levitating eye is the only worthy eye!~ [PPNALJ03]
  == GAAL  IF ~InParty("Worgas")~ THEN ~How dare you trespass and defile the one and only God!?~ 
  == WORGASJ   IF ~InParty("Worgas")~ THEN ~Bad dog away with you! I fail to see how any unseeing source, thing, mind can possess any higher knowledge than my levitating "seeing" eye.~ [PPDRAD01] 
  == GAAL  IF ~InParty("Worgas")~ THEN ~I warn you, the Unseeing Eye has vast and terrible power!~
END

I_C_T PPNALJ 2 Worgas45
  == WORGASJ   IF ~InParty("Worgas")
!StateCheck("Worgas",CD_STATE_NOTVALID) ~ THEN ~*Squawk*~ [CHICK07] 
== PPNALJ IF ~InParty("Worgas")~ THEN ~Yiaaaaii! That chicken! Not prettie! Reminds me of Worgas, stole my voice he did, stole my pretties!~ [PPNALJ03]
END

I_C_T PPNALJ 4 Worgas46
  == WORGASJ   IF ~InParty("Worgas")
!StateCheck("Worgas",CD_STATE_NOTVALID) ~ THEN ~*Squawk*~ [CHICK07] 
== PPNALJ IF ~InParty("Worgas")~ THEN ~Yiaaaaii! That chicken! Not prettie! Reminds me of Worgas, stole my voice he did, stole my pretties!~ [PPNALJ03]
END

I_C_T PPNALJ 5 Worgas47
  == WORGASJ   IF ~InParty("Worgas")
!StateCheck("Worgas",CD_STATE_NOTVALID) ~ THEN ~*Squawk*~ [CHICK07] 
== PPNALJ IF ~InParty("Worgas")~ THEN ~Yiaaaaii! That chicken! Not prettie! Reminds me of Worgas, stole my voice he did, stole my pretties!~ [PPNALJ03]
END

I_C_T PPDRADEE 2 Worgas48
  == WORGASJ   IF ~InParty("Worgas")
!StateCheck("Worgas",CD_STATE_NOTVALID) ~ THEN ~*Squawk*~ [CHICK07] 
== PPDRADEE IF ~InParty("Worgas")~ THEN ~Bad doggy chicken! Away with you! Smells like Worgas, stealer of our voices!~ [PPDRAD01]
END

I_C_T GORDEMO 1 Worgas49
  == WORGASJ   IF ~InParty("Worgas")
!StateCheck("Worgas",CD_STATE_NOTVALID) ~ THEN ~YiaaAArrGH! Run away! Far far away! Demons, bad dogs, BAD DOGS!~ [XZARR39] 
END

I_C_T GORCAR 0 Worgas50
  == WORGASJ   IF ~InParty("Worgas")
!StateCheck("Worgas",CD_STATE_NOTVALID) ~ THEN ~Mmmmm me pretties...there are many pretties hidden within this madman's guarded machine <CHARNAME>~ [PPNALJ01] 
== GORCAR IF ~InParty("Worgas")~ THEN ~What, what, WHAT!?!~ [GORCAR01]
END

I_C_T PPIRENI2 32 Worgas51
  == WORGASJ   IF ~InParty("Worgas")
!StateCheck("Worgas",CD_STATE_NOTVALID) ~ THEN ~YiaaAArrGH! Joneleth now defiled but once piled high today you die!~ [XZARR39] 
  == PPIRENI2 IF ~InParty("Worgas")~ THEN ~How dare you speak that name! Oh...isn�t it Worgas...How amusing that such a mad creature is here to represent the elves.~
  == WORGASJ   IF ~InParty("Worgas")~ THEN ~Bad dog away with you!~ [PPDARD01]
  == PPIRENI2 IF ~InParty("Worgas")~ THEN ~I will make sure that all of your kind will end their  existence once I am done with <CHARNAME>.~
  == WORGASJ   IF ~InParty("Worgas")~ THEN ~Yiaaaaii!! DIE!!~ [PPNALJ03]
 END

I_C_T PPIRENI2 30 Worgas52
  == WORGASJ   IF ~InParty("Worgas")
!StateCheck("Worgas",CD_STATE_NOTVALID) ~ THEN ~YiaaAArrGH! Joneleth now defiled but once piled high today you die!~ [XZARR39] 
  == PPIRENI2 IF ~InParty("Worgas")~ THEN ~How dare you speak that name! Oh...isn�t it Worgas...How amusing that such a mad creature is here to represent the elves.~
  == WORGASJ   IF ~InParty("Worgas")~ THEN ~Bad dog away with you!~ [PPDARD01]
  == PPIRENI2 IF ~InParty("Worgas")~ THEN ~I will make sure that all of your kind will end their existence once I am done with <CHARNAME>.~
  == WORGASJ   IF ~InParty("Worgas")~ THEN ~Yiaaaaii!! DIE!!~ [PPNALJ03]
 END

I_C_T TOLGER2 0 Worgas53
  == WORGASJ   IF ~InParty("Worgas")
!StateCheck("Worgas",CD_STATE_NOTVALID) ~ THEN ~YiaaaAARGH!! Cowled one!~ [XZARR39]
== TOLGER2 IF ~InParty("Worgas")~ THEN ~Worgas! Fugitive of Spellhold, how many times must you die before ending your existence!?~
== WORGASJ IF ~InParty("Worgas")~ THEN ~Yiaaaaii!! No Cowleds here to witness when I will make you die!~ [PPNALJ03]
== TOLGER2 IF ~InParty("Worgas")~ THEN ~You are naturally mad to think that such an unstable being like yourself can hinder me from conquering this planar sphere.~
== WORGASJ IF ~InParty("Worgas")~ THEN ~It�s mine, all mine, you can�t have it!~ [PPWANE03]
== TOLGER2 IF ~InParty("Worgas")~ THEN ~Fool! You and your comrads can say farewell to life!~
END

I_C_T TOLGER2 2 Worgas54
  == WORGASJ   IF ~InParty("Worgas")
!StateCheck("Worgas",CD_STATE_NOTVALID) ~ THEN ~YiaaaAARGH!! Cowled one!~ [XZARR39]
== TOLGER2 IF ~InParty("Worgas")~ THEN ~Worgas! Fugitive of Spellhold, how many times must you die before ending your existence!?~
== WORGASJ IF ~InParty("Worgas")~ THEN ~Yiaaaaii!! No Cowleds here to witness when I will make you die!~ [PPNALJ03]
== TOLGER2 IF ~InParty("Worgas")~ THEN ~You are naturally mad to think that such an unstable being like yourself can hinder me from conquering this planar sphere.~
== WORGASJ IF ~InParty("Worgas")~ THEN ~It�s mine, all mine, you can�t have it!~ [PPWANE03]
== TOLGER2 IF ~InParty("Worgas")~ THEN ~Fool! You and your comrads can say farewell to life!~
END

I_C_T TOLGER2 4 Worgas55
  == WORGASJ   IF ~InParty("Worgas")
!StateCheck("Worgas",CD_STATE_NOTVALID) ~ THEN ~YiaaaAARGH!! Cowled one!~ [XZARR39]
== TOLGER2 IF ~InParty("Worgas")~ THEN ~Worgas! Fugitive of Spellhold, how many times must you die before ending your existence!?~
== WORGASJ IF ~InParty("Worgas")~ THEN ~Yiaaaaii!! No Cowleds here to witness when I will make you die!~ [PPNALJ03]
== TOLGER2 IF ~InParty("Worgas")~ THEN ~You are naturally mad to think that such an unstable being like yourself can hinder me from conquering this planar sphere.~
== WORGASJ IF ~InParty("Worgas")~ THEN ~It�s mine all mine, you can�t have it!~ [PPWANE03]
== TOLGER2 IF ~InParty("Worgas")~ THEN ~Fool! You and your comrads can say farewell to life!~
END

I_C_T TOLGER2 5 Worgas56
  == WORGASJ   IF ~InParty("Worgas")
!StateCheck("Worgas",CD_STATE_NOTVALID) ~ THEN ~YiaaaAARGH!! Cowled one!~ [XZARR39]
== TOLGER2 IF ~InParty("Worgas")~ THEN ~Worgas! Fugitive of Spellhold, how many times must you die before ending your existence!?~
== WORGASJ IF ~InParty("Worgas")~ THEN ~Yiaaaaii!! No Cowleds here to witness when I will make you die!~ [PPNALJ03]
== TOLGER2 IF ~InParty("Worgas")~ THEN ~You are naturally mad to think that such an unstable being like yourself can hinder me from conquering this planar sphere.~
== WORGASJ IF ~InParty("Worgas")~ THEN ~It�s mine, all mine, you can�t have it!~ [PPWANE03]
== TOLGER2 IF ~InParty("Worgas")~ THEN ~Fool! You and your comrads can say farewell to life!~
END

I_C_T W_MED 0 Worgas57
  == WORGASJ   IF ~InParty("Worgas")
!StateCheck("Worgas",CD_STATE_NOTVALID) ~ THEN ~It�s mine, all mine, you can�t have it!~ [PPWANE03]
 == W_MED IF ~InParty("Worgas")~ THEN ~Wrong answer, Worgas the Dead!~
 == WORGASJ IF ~InParty("Worgas")~ THEN ~Yiaaaaii!! Protect me <CHARNAME>!~ [PPNALJ03]
 == W_MED IF ~InParty("Worgas")~ THEN ~How pathetic!~
END

I_C_T BAZEYE01 0 Worgas58
  == WORGASJ   IF ~InParty("Worgas")
!StateCheck("Worgas",CD_STATE_NOTVALID) ~ THEN ~Mmmmm my pretties. Many, many levitating eyeballs, a wonderous sight.~ [PPNALJ01]
== BAZEYE01 IF ~InParty("Worgas")~ THEN ~So you admire my creations do you?~
== WORGASJ IF ~InParty("Worgas")~ THEN ~Yiaaaaii!! Admire? I worship pretties piled high beyond the sky!~ [PPNALJ03]
== BAZEYE01 IF ~InParty("Worgas")~ THEN ~Rare it is to stumble upon an equal minded being as myself.~
== WORGASJ IF ~InParty("Worgas")~ THEN ~It�s mine, all mine, you can�t have it!~ [PPWANE03]
== BAZEYE01 IF ~InParty("Worgas")~ THEN ~Say what?~
== WORGASJ IF ~InParty("Worgas")~ THEN ~Yiaaaaii!! Add eyeballs to my collection of pretties!~ [PPNALJ03]
== BAZEYE01 IF ~InParty("Worgas")~ THEN ~Hold it! Keep your hands away from my experiments!~
== WORGASJ IF ~InParty("Worgas")~ THEN ~YiaAAAArRgh!~ [XZARR39]
== BAZEYE01 IF ~InParty("Worgas")~ THEN ~Enough! Who are you all to trespass here anyway!?~
END

I_C_T W_RUNE 0 Worgas59
  == WORGASJ   IF ~InParty("Worgas")
!StateCheck("Worgas",CD_STATE_NOTVALID) ~ THEN ~Bad dog away with you!~ [PPDRAD01]
 == W_RUNE IF ~InParty("Worgas")~ THEN ~UhehahaHAHA!~ [DEMO02]
 == WORGASJ IF ~InParty("Worgas")~ THEN ~YiaaaAARGH!! Make him vanish <CHARNAME>!~ [XZARR39]
END

I_C_T C6DRIZZ1 47 Worgas60
  == WORGASJ   IF ~InParty("Worgas")
!StateCheck("Worgas",CD_STATE_NOTVALID) ~ THEN ~Yiaaaaii!! <CHARNAME> say no, I and my pretties see nothing familiar with the hellish drowish being.~ [PPNALJ03]
 == C6DRIZZ1 IF ~InParty("Worgas")~ THEN ~Do not be so quick in judgment, elf, due to what you see with your eyes might not always be the truth.~
 == WORGASJ IF ~InParty("Worgas")~ THEN ~YiaaaAARGH!! The drow speaks in foul riddles masking his evil intentions!~ [XZARR39]
END

I_C_T C6DRIZZ1 1 Worgas61
  == WORGASJ   IF ~InParty("Worgas")
!StateCheck("Worgas",CD_STATE_NOTVALID) ~ THEN ~Yiaaaaii!! Drow of evil spitting tongue calling us bandits!? That is your title to carry!~ [PPNALJ03]
 == C6DRIZZ1 IF ~InParty("Worgas")~ THEN ~Your mentality is more than unbalanced, elf, and that must be the only reason for you to travel with this bandit.~
 == WORGASJ IF ~InParty("Worgas")~ THEN ~Bad dog away with you!~ [PPDRAD01]
END

I_C_T HGNYA01 6 Worgas62
  == WORGASJ   IF ~InParty("Worgas")
!StateCheck("Worgas",CD_STATE_NOTVALID) ~ THEN ~Yiaaaaii!! Don�t listen to her forked tongue <CHARNAME>!~ [PPNALJ03]
 == HGNYA01 IF ~InParty("Worgas")~ THEN ~Silence, elf! My words are for the spawn-child.~
 == WORGASJ IF ~InParty("Worgas")~ THEN ~Bad dog away with you!~ [PPDRAD01]
END

I_C_T BODHI 6 Worgas63
  == WORGASJ   IF ~InParty("Worgas")
!StateCheck("Worgas",CD_STATE_NOTVALID) ~ THEN ~Yiaaaaii!! Creature of the dark we are far too prettie to be enslaved under your command!~ [PPNALJ03]
 == BODHI IF ~InParty("Worgas")~ THEN ~Elf, you are already a slave to your unbalanced mentality.~
 == WORGASJ IF ~InParty("Worgas")~ THEN ~Bad dog away with you!~ [PPDRAD01]
END

I_C_T BODHI 1 Worgas64
  == WORGASJ   IF ~InParty("Worgas")
!StateCheck("Worgas",CD_STATE_NOTVALID) ~ THEN ~Yiaaaaii!! This is a creature of the dark <CHARNAME>. Witness a former prettie defiled into such a creature!~ [PPNALJ03]
 == BODHI IF ~InParty("Worgas")~ THEN ~Elf, your mind is truly corrupted by madness so silence yourself. I am sure <CHARNAME> is clever enough to hear me out.~
 == WORGASJ IF ~InParty("Worgas")~ THEN ~Bad dog away with you!~ [PPDRAD01]
END

I_C_T BODHI 34 Worgas65
  == WORGASJ   IF ~InParty("Worgas")
!StateCheck("Worgas",CD_STATE_NOTVALID) ~ THEN ~Yiaaaaii!! When the time of battle is ahead the ground with your head will be fed.~ [PPNALJ03]
 == BODHI IF ~InParty("Worgas")~ THEN ~I am sure it will take more than your shattered mentality to back up those words, soon to be dead elf.~
 == WORGASJ IF ~InParty("Worgas")~ THEN ~Bad dog away with you!~ [PPDRAD01]
END

I_C_T SUJON 0 Worgas66
  == WORGASJ   IF ~InParty("Worgas")
!StateCheck("Worgas",CD_STATE_NOTVALID) ~ THEN ~Yiaaaaii!! Die!.~ [PPNALJ03]
== SUJON IF ~InParty("Worgas")~ THEN ~Worgas, is there no end for you to disturb me with your insanity!?~
END


I_C_T SAHBEH01 0 Worgas67
  == WORGASJ   IF ~InParty("Worgas")
!StateCheck("Worgas",CD_STATE_NOTVALID) ~ THEN ~Mmmm my pretties, a grand levitating eyeball full of words. Imprisoned in loneliness you are...~ [PPNALJ01]
== SAHBEH01 IF ~InParty("Worgas")~ THEN ~You see far beyond elven mageling sage. I long to share words of higher insight and wisdom.~
== WORGASJ IF ~InParty("Worgas")~ THEN ~Look into your present time and do not dwell in your past nor into the future. It is only here and now you can act my pretties.~ 
== SAHBEH01 IF ~InParty("Worgas")~ THEN ~A wise insight often hard to follow for a carrier of a high intellect as myself.~
END

BEGIN worgas

IF WEIGHT #1
~NumTimesTalkedTo(0)~ THEN BEGIN 0
	SAY ~Hello then...hello, I need some help here. I accidently ended up in this fine crafted cage and lost my levitating pretty eyeball. Have you seen it?~
	IF ~~ THEN REPLY ~That rather mad description of yours is something I haven�t seen.~ GOTO 1
	IF ~~ THEN REPLY ~A levitating eyeball? If it exists I guess even such a thing wouldn�t stay in a place like this as I don�t intend to either.~ GOTO 2
END

IF ~~ THEN BEGIN 1
	SAY ~By the Madman's Eye!~ = ~No time for conversations for my pretties!~
	= ~Yaaaaii! Oh, I am the one conversing now and wasting time!~ [PPNALJ03]
	IF ~~ THEN REPLY ~Calm down, all that screaming will not improve the odds of finding whatever you said you searched for.~ GOTO 3
END

IF ~~ THEN BEGIN 2
	SAY ~No matter what place, my pretties never leaves my side.~
	IF ~~ THEN GOTO 3
END

IF ~~ THEN BEGIN 3
	SAY ~I, Worgas, long for my pretties and need my levitating eyeball with many eyes on it.~

IF ~~ THEN REPLY ~I think this place has twisted your mind.~ GOTO 6
END

IF ~~ THEN BEGIN 6
	SAY ~Do not anger my pretties!~
	IF ~~ THEN REPLY
	~I didn�t have that intention, just a fact that I noticed, that's all. If this eyeball exists then mayhaps our captor has taken it.~ GOTO 7
END

IF ~~ THEN BEGIN 7
	SAY ~Yiaaaaii! If so then he dies, NOW!~ [PPNALJ03]
	= ~Help me find the pretties and I can join your search for your captor and bury my hand deep in his head.~

IF ~~ THEN REPLY ~I am in a situation where I might need aid. Though I still doubt if you are stable and trusty enough. But since you are imprisoned like me then I guess we share the same eagerness to get out of here.~ GOTO 9
IF ~~ THEN REPLY ~I can not dedicate myself to such madness.~ GOTO 8
END

IF ~~ THEN BEGIN 8
	SAY ~Humanoid skullsuckers! Mad is what you are and no value equal to the pretties.~ [XVART01]
	IF ~~ THEN DO ~SetGlobal("WorgasNotJoin","GLOBAL",1)~ EXIT
END

IF ~~ THEN BEGIN 9
	SAY ~Many many pretties...piled high beyond the sky (sigh). My pretties should be close.~ [PPNALJ09]
	IF ~~ THEN DO ~SetGlobal("WorgasInParty","GLOBAL",1)
JoinParty()~ EXIT
END

IF 
~Global("WorgasNotJoin","GLOBAL",1)~ THEN BEGIN 10
	SAY ~You again, have you returned to see me, my pretties?~
	IF ~~ THEN REPLY ~So I have, let us try to locate this thing and in return I will accept your offer in aiding my task. The use of magic might be handy.~ GOTO 9
      IF ~~ THEN REPLY ~I have other burdens to carry than to worry about your senses.~ GOTO 8
END

BEGIN worgasp

IF ~Global("WorgasInParty","GLOBAL",1)~ THEN BEGIN KickOut
SAY ~What, are you losing your mind? You will be smashed like the tiny fly without pretties at your side.~
IF ~~ THEN REPLY ~I wouldn�t describe it in that way. Even though your magic tends to be unstable, you still hold powers that might be useful.~ DO ~JoinParty()~ EXIT
IF ~~ THEN REPLY ~I can manage from here on. You can always head on to Copper Coronet and rest with an ale or two and mayhaps I can meet up with you there in the near future.~ DO ~SetGlobal("WorgasInParty","GLOBAL",0)
EscapeAreaMove("AR0406",947,1206,2)
ActionOverride("zarix",EscapeAreaMove("AR0406",929,1190,2)
~ EXIT
END

IF ~Global("WorgasInParty","GLOBAL",0)~ THEN BEGIN Rejoin
SAY ~So we meet again, pretties needed I presume. Shiny facts of pretties.~
IF ~~ THEN REPLY ~I would like to have you by my side even though it is high gambling of the outcome.~ DO ~SetGlobal("WorgasInParty","GLOBAL",1)
JoinParty()~ EXIT
IF ~~ THEN REPLY ~I am in no need of another companion at this moment.~ EXIT
END

BEGIN worgasj

IF 
~Global("ZarixMet","GLOBAL",0)
Global("ZarixInParty","GLOBAL",1)
!Global("WorgasMatch","GLOBAL",1)
!StateCheck("Worgas",CD_STATE_NOTVALID) ~ THEN BEGIN 1
	SAY ~My pretties Zarix! Never put such stress into my skull again!~
	IF ~~ THEN DO ~SetGlobal("ZarixMet","GLOBAL",1)
SetGlobal("ZarixJumpOn","GLOBAL",1)~ EXIT
END

IF 
~Global("WorgasPostSpeak","AR0700",1)
InParty("Worgas")
!StateCheck("Worgas",CD_STATE_NOTVALID) ~ THEN BEGIN 2
	SAY ~No! to look at him is to see too far. I cannot look at him.~ [PPNALJ11] 
IF ~~ THEN DO~  SetGlobal("WorgasPostSpeak","AR0700",2)
~ EXIT
END

IF 
~Global("w_gotospellhold","AR1500",1)
InParty("Worgas")
!StateCheck("Worgas",CD_STATE_NOTVALID) ~ THEN BEGIN 3
	SAY ~Yiaaaaii!, Noooo! Not here <CHARNAME>, bad dogs!~ [PPNALJ03] 
IF ~~ THEN REPLY ~Cease your screaming, Worgas.~ GOTO SPELLHOLD
END

IF ~~ THEN SPELLHOLD
	SAY ~AiaaaAAAIii!! I cannot go in as I, must hide under another skin from which I can look out from within.~ [XZARR39] 
IF ~~ THEN DO ~SetGlobal("w_gotospellhold","AR1500",2)
~ EXIT
END

IF 
~Global("w_worgasdrow","AR2200",1)
InParty("Worgas")
!StateCheck("Worgas",CD_STATE_NOTVALID) ~ THEN BEGIN 4
SAY ~Yiaaaaii!! Thrityh! Elgg mina jal!~ [PPNALJ03] 
IF ~~ THEN DO ~SetGlobal("w_worgasdrow","AR2200",2)~ EXIT
END

IF 
~Global("WorgasUnderdark","AR2100",1)
InParty("Worgas")
!StateCheck("Worgas",CD_STATE_NOTVALID) ~ THEN BEGIN 5
SAY ~Yiaaaaii!! Haunted realm deep under! Hurry <CHARNAME> get us out from here, NOW!~ [PPNALJ03] 
IF ~~ THEN DO ~SetGlobal("WorgasUnderdark","AR2100",2)
~ EXIT
END

IF 
~Global("WorgasMallet","LOCALS",1)
InParty("Worgas")
!StateCheck("Worgas",CD_STATE_NOTVALID) ~ THEN BEGIN 5
SAY ~Yiaaaaii!! We have the mallet! Go and strike the glass Six Times <CHARNAME>! Six Times and the pretties belongs to us!~ [PPNALJ03] 
IF ~~ THEN DO ~ SetGlobal("WorgasMallet","LOCALS",2)~ EXIT
END

IF 
~Global("WorgasEyeArea","AR0205",1)
InParty("Worgas")
!StateCheck("Worgas",CD_STATE_NOTVALID) ~ THEN BEGIN 6
SAY ~Yiaaaaii!! A realm of levitating eyeballs! This is a wonderous thing <CHARNAME>!~ [PPNALJ03] 
IF ~~ THEN DO ~SetGlobal("WorgasEyeArea","AR0205",2)~ EXIT
END

IF 
~Global("WorgasEyeStalk","LOCALS",1)
InParty("Worgas")
!StateCheck("Worgas",CD_STATE_NOTVALID) ~ THEN BEGIN 7
SAY ~It�s mine, all mine, you can�t have it! Give me the eyestalk and I will create something prettie from it. Though we must rest before the prettie can be used.~ [PPWANE03] 
IF ~~ THEN DO ~ SetGlobal("WorgasEyeStalk","LOCALS",2)
ActionOverride(Player1,DestroyItem("MISCA8")
ActionOverride(Player2,DestroyItem("MISCA8")
ActionOverride(Player3,DestroyItem("MISCA8")
ActionOverride(Player4,DestroyItem("MISCA8")
ActionOverride(Player5,DestroyItem("MISCA8")
ActionOverride(Player6,DestroyItem("MISCA8")
GiveItemCreate("w_eyebom","Worgas",0,0,0)
CreateVisualEffectObject("SPCRTWPN","Worgas")
PlaySound("CAS_P06")~ EXIT
END

IF 
~Global("WorgasSphere","AR0411",1)
InParty("Worgas")
!StateCheck("Worgas",CD_STATE_NOTVALID) ~ THEN BEGIN 8
SAY ~Mmmmm my pretties... Magical energy in each and every corner from realms all over.~ [PPNALJ01] 
IF ~~ THEN DO ~SetGlobal("WorgasSphere","AR0411",2)~ EXIT
END

IF 
~Global("WorgasManyEyes","AR6003",1)
InParty("Worgas")
!StateCheck("Worgas",CD_STATE_NOTVALID) ~ THEN BEGIN 9
SAY ~Yiaaaii!! Eyeballs! Levitating wonderous beings!~ [PPNALJ03] 
IF ~~ THEN DO ~SetGlobal("WorgasManyEyes","AR6003",2)~ EXIT
END

CHAIN
IF
~Global("WorgasMinsc","LOCALS",1)
  GlobalTimerExpired("WorgasMinscTalk","GLOBAL")~ THEN  Worgasj WorgasDistressed
~Mmmm my pretties.~ [PPNALJ01]
DO ~SetGlobal("WorgasMinsc","LOCALS",2)~
== MINSCJ ~Keep your staring and hands away from Boo, elven friend. Boo says you make him nervous.~
== WORGASJ ~Nervous of Worgas, the prettie loving pet friend? Maybe my levitating eyeball would enjoy playing with Boo?~
== MINSCJ ~Boo says whaaat? A levitating eyeball doesn�t know how to play the hamster way.~ [MINSC26]
== WORGASJ ~YiaarAAArgh! Too raw and furry anyway!~ [XZARR39] 
EXIT

CHAIN IF
~Global("WorgasViconia","LOCALS",1)
  GlobalTimerExpired("WorgasViconiaTalk","GLOBAL")~ THEN Worgasj WorgasDistressed2
~YiaarAAArgh! Keep your evil eyeball far, far away!~ [XZARR39]
DO ~SetGlobal("WorgasViconia","LOCALS",2)~
== VICONIJ ~I am beginning to tire of spending my time with fools.~ [VICONI05]
== WORGASJ ~Yiaaaaii!! Fools?! Rather the tools made to end the existence of fools like the drow who drools!~ [PPNALJ03]
== VICONIJ
~I have no desire to remain in the company of the witless madness but I will bear this only for you <CHARNAME>.~ [VICONI06]
== WORGASJ ~Bad dog! Away with you!~ [PPDRAD01] 
EXIT

CHAIN IF
~Global("WorgasMinsc","LOCALS",3)
  GlobalTimerExpired("WorgasMinscSecond","GLOBAL")~ THEN Worgasj WorgasDistressed3
~YiaarAAArgh!~ [XZARR39]
DO ~SetGlobal("WorgasMinsc","LOCALS",4)~
== MINSCJ ~I told you to keep your hands away from Boo, elven mageling. He wouldn�t have bitten you like that otherwise.~
== WORGASJ ~Yiaaaii!! I need healing for my prettie invaluable finger.~ [PPNALJ03]
== MINSCJ ~Boo says whaaat? That is just a tiny cut and nothing to whine about.~ [MINSC26]
== WORGASJ ~YiaarAAArgh! Furry evil creature!~ [XZARR39] 
EXIT

CHAIN IF
~Global("WorgasViconia","LOCALS",3)
  GlobalTimerExpired("WorgasViconiaSecond","GLOBAL")~ THEN Worgasj WorgasDistressed4
~YiaarAAArgh!! Her eyes <CHARNAME>! There is no trust in her drowish eyes!~ [XZARR39]
DO ~SetGlobal("WorgasViconia","LOCALS",4)~
== VICONIJ ~Trust is for the foolish...and the dead.~ [VICONI27]
== WORGASJ ~Yiaaaaii!! Hear the words of the forked tongue spitting out from her <CHARNAME>!~ [PPNALJ03]
== VICONIJ ~Surface dwellers can be so stupid.~ [VICONI04]
== WORGASJ ~Bad dog! Away with you!~ [PPDRAD01] 
EXIT

CHAIN IF
~Global("WorgasJan","LOCALS",1)
  GlobalTimerExpired("WorgasJanTalk","GLOBAL")~ THEN Worgasj WorgasDistressed5
~Mmmm my pretties.~ [PPNALJ01]
DO ~SetGlobal("WorgasJan","LOCALS",2)~
== JANJ ~Got it, these turnips are pretties to the eye and not to mention the taste. Have a bite , Worgas the Wild.~ [JANJAN29]
== WORGASJ ~YiaarAAArgh! It buuuurns! BUUUURNS!~ [XZARR39] 
== JANJ ~Pardon. Turnip reflex... I gave you the enchanted one with spices I picked up from a vacation with Uncle Quayle in the Elemental planes of Fire.~ [JANJAN23]
== WORGASJ ~Bad dog! Away with you!~ [PPDRAD01] 
EXIT

CHAIN IF
~Global("WorgasJaheira","LOCALS",1)
  GlobalTimerExpired("WorgasJaheiraTalk","GLOBAL")~ THEN WORGASJ WorgasDistressed6
~Mmmm my pretties.~ [PPNALJ01]
DO ~SetGlobal("WorgasJaheira","LOCALS",2)~
== JAHEIRAJ ~Speak your mind, Worgas.~ [JAHEIR26]
== WORGASJ ~Mmmm my pretties....Jaheira~ [PPNALJ01]
== JAHEIRAJ ~Yes?~ [JAHEIR23]
== WORGASJ ~Mmmm my pretties.~ [PPNALJ01] 
== JAHEIRAJ ~I will not tolerate this waste of time! Let's get moving, we have much to do.~ [JAHEIR69]
== WORGASJ ~Yiaaaaii!!~ [PPNALJ03] 
EXIT

CHAIN IF
~Global("WorgasAerie","LOCALS",1)
  GlobalTimerExpired("WorgasAerieTalk","GLOBAL")~ THEN Worgasj WorgasDistressed7
~Mmmm my pretties.~ [PPNALJ01]
DO ~SetGlobal("WorgasAerie","LOCALS",2)~
== AERIEJ ~Y-yes?~ [AERIE21]
== WORGASJ ~Many many pretties...piled high beyond the sky (sigh). I used to have pretties as you had prettie wings.~ [PPNALJ09]
== AERIEJ ~Mmm?~ [AERIE25]
== WORGASJ ~I can recreate the ability of your former pretties.~ 
== AERIEJ ~Y-yes? What, recreate my wings? But...but that is impossible...~ [AERIE21]
== WORGASJ ~Yiaaaaii!! Impossible for Worgas, the one and only worthy eye!?~ [PPNALJ03] 
== AERIEJ ~Even the stongest magical energy wouldn�t be able to do such a thing. My wings are forever gone...~ 
== WORGASJ ~Yiiaaaai!! I can make you fly higher than any levitating eye. The wings can be created by illusions my pretties.~ [PPNALJ03]  
== AERIEJ ~You...you could make me fly again? I would give away my left hand to be able to see the realm from the sky once again.~ 
== WORGASJ ~Mmmmm my pretties, so let it be done by Worgas the ruler of levitating pretties.~ [PPNALJ01]  
EXIT

CHAIN IF
~Global("WorgasAerie","LOCALS",4)
  GlobalTimerExpired("WorgasAerieSecond","GLOBAL")~ THEN Worgasj WorgasDistressed8
~Mmmm my pretties.~ [PPNALJ01]
DO ~SetGlobal("WorgasAerie","LOCALS",5)~
== AERIEJ ~Worgas...I am forever grateful to you for giving me the ability to fly once again even though I still lack the visual beauty of my former wings.~ 
== WORGASJ ~Many many pretties...piled high beyond the sky (sigh). For you my prettie Worgas could die.~ [PPNALJ09]
== AERIEJ ~I wish I could do something in return for you. There is so much good within you yet our Worgas wanders with a tormented soul.~
== WORGASJ ~Yiaaaaii! The experiments!~ [PPNALJ03]  
== AERIEJ ~Calm down my elven friend, I am here by your side.~
== WORGASJ ~Mmmm.. my pretties.~ [PPNALJ01] 
EXIT


CHAIN IF ~Global("WorgasKorgan","LOCALS",1)
  GlobalTimerExpired("WorgasKorganTalk","GLOBAL")~ THEN WORGASJ WorgasDistressed9
~Bad dog away with you! BAD DOG!~ [PPDRAD01]
DO ~SetGlobal("WorgasKorgan","LOCALS",2)~
== KORGANJ ~What do ye want, groundling!?~ [KORGAN22]
== WORGASJ ~Yiaaaaii!! The bearded midget gives me the evil eye, <CHARNAME>!~ [PPNALJ03]
== KORGANJ ~Bloody forests. Bloody tree huggers an� daisy-eaters! Burn�em all...~ [KORGAN16]
== WORGASJ ~YiaaaAArgh! Stay away from me, you ale breath, greasy bearded midget!~ [XZARR39] 
== KORGANJ ~Let�s see what yer guts be lookin� like Worgas!~ [KORGAN10]
== WORGASJ ~Yiaaaaii!!~ [PPNALJ03] 
EXIT

CHAIN IF ~Global("WorgasEdwin","LOCALS",1)
  GlobalTimerExpired("WorgasEdwinTalk","GLOBAL")~ THEN WORGASJ WorgasDistressed10
~I used to have me pretties...some are hidden. Only I can see...do you want to see?~ [PPNALJ07]
DO ~SetGlobal("WorgasEdwin","LOCALS",2)~
== EDWINJ ~I�m busy ok, I�m busy!~ [EDWIN24]
== WORGASJ ~Yiaaaaii!! Busy for the pretties? You should learn to embrace the levitating pretties and holders of the highest magical energy!~ [PPNALJ03] 
== EDWINJ ~A waste of my time.~ [EDWIN32]
== WORGASJ ~YiaaaAArgh!! Unworthy blood red robed human!~ [XZARR39] 
EXIT
