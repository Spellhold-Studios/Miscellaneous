I_C_T PLAYER1 25 W_DRIZZJ1
  == W_DRIZZJ   IF ~InParty("w_drizz")
!StateCheck("w_drizz",CD_STATE_NOTVALID)~ THEN ~I have sparred with demons in the Nine Hells before. Though I didn�t think that I would be back so soon.~
END

I_C_T PLAYER1 33 W_DRIZZJ2
  == W_DRIZZJ   IF ~InParty("w_drizz")
!StateCheck("w_drizz",CD_STATE_NOTVALID)~ THEN ~So the final confrontation is near, we have done well friends. Let us wrap up this task.~ 
  == PLAYER1 IF ~InParty("w_drizz")~ THEN ~Drizzt: The drow hero that aided you in defeating Bodhi still stands by your side giving a high morale to your group.~
  == W_DRIZZJ   IF ~InParty("w_drizz")~ THEN ~So <CHARNAME>, are you ready?~
  == PLAYER1 IF ~InParty("w_drizz")~ THEN ~Drizzt, it has been an honour to stand by your side but this battle is mine...~
  == W_DRIZZJ   IF ~InParty("w_drizz")~ THEN ~You have a lot of courage but this fight is now a task of mine as well. Come now and let us be done with it.~
END

I_C_T HELLJON 1 W_DRIZZJ3
  == W_DRIZZJ   IF ~InParty("w_drizz")
!StateCheck("w_drizz",CD_STATE_NOTVALID)~ THEN ~Your saga ends here, mage, as my Twinkle will give you the final dance.~ 
== HELLJON IF ~InParty("w_drizz")~ THEN ~Wrong, you won't leave the Nine Hells alive this time, Drizzt.~
END

I_C_T PLAYER1 16 W_DRIZZJ4
  == W_DRIZZJ   IF ~InParty("w_drizz")
!StateCheck("w_drizz",CD_STATE_NOTVALID)~ THEN ~The evil is slain, once again we have done well, friends.~ 
END

I_C_T SUJON 0 W_DRIZZJ5
  == W_DRIZZJ   IF ~InParty("w_drizz")
!StateCheck("w_drizz",CD_STATE_NOTVALID)~ THEN ~Drizzt dares, your show is over, mage. The final chapter will be written by my Twinkle.~ 
== SUJON IF ~InParty("w_drizz")~ THEN ~Drizzt!?~
END

I_C_T C6ELHAN2 66 W_DRIZZJ6
  == W_DRIZZJ   IF ~InParty("w_drizz")
!StateCheck("w_drizz",CD_STATE_NOTVALID)~ THEN ~What you feel is not enough in this matter. I would like to have more information on what all this is about.~  
  == C6ELHAN2 IF ~InParty("w_drizz")~ THEN ~A drow amongst us, wait.. is it...?~
  == W_DRIZZJ   IF ~InParty("w_drizz")~ THEN ~Drizzt to the aid, fear not, I have faced challenges far worse than what I suspect lies ahead of us.~
  == C6ELHAN2 IF ~InParty("w_drizz")~ THEN ~I am surprised to see you here, though more than glad. How did you come to be involved in this?~
  == W_DRIZZJ   IF ~InParty("w_drizz")~ THEN ~I met up with <CHARNAME> when <PRO_HESHE> was on <PRO_HISHER> way to battle vampires.~
  == C6ELHAN2 IF ~InParty("w_drizz")~ THEN ~With you by <CHARNAME>'s side, I am sure that Bodhi did not stand a chance.~
END

I_C_T W_ART 0 W_DRIZZJ7
  == W_DRIZZJ   IF ~InParty("w_drizz")
!StateCheck("w_drizz",CD_STATE_NOTVALID)~ THEN ~Drizzt never hides, especially not from filth like yourself, Artemis.~
 == W_ART IF ~InParty("w_drizz")~ THEN ~I would expect you to use more sophisticated words being the gentleman you claim to be.~
 == W_DRIZZJ IF ~InParty("w_drizz")~ THEN ~Such words are wasted in this situation. Enough talking, we both know where this will lead to anyway.~ 
 == W_ART IF ~InParty("w_drizz")~ THEN ~Fair enough, you won't escape me this time.~
END

BEGIN w_drizzj

IF  ~Global("w_DrizztPC","LOCALS",1)
  GlobalTimerExpired("w_DrizztTalk","GLOBAL")~ THEN BEGIN Leaving
SAY ~Well <CHARNAME> it has been interesting to journey with you. But I have to find my way back to Ten Towns now where my friends await. Good speed to you.~
IF ~~ THEN DO ~SetGlobal("w_DrizztPC","GLOBAL",2)
ActionOverride(Player1,DestroyItem("w_drsw1")
ActionOverride(Player2,DestroyItem("w_drsw1")
ActionOverride(Player3,DestroyItem("w_drsw1")
ActionOverride(Player4,DestroyItem("w_drsw1")
ActionOverride(Player5,DestroyItem("w_drsw1")
ActionOverride(Player6,DestroyItem("w_drsw1")
ActionOverride(Player1,DestroyItem("w_drsw2")
ActionOverride(Player2,DestroyItem("w_drsw2")
ActionOverride(Player3,DestroyItem("w_drsw2")
ActionOverride(Player4,DestroyItem("w_drsw2")
ActionOverride(Player5,DestroyItem("w_drsw2")
ActionOverride(Player6,DestroyItem("w_drsw2")
ActionOverride(Player1,DestroyItem("w_panth")
ActionOverride(Player2,DestroyItem("w_panth")
ActionOverride(Player3,DestroyItem("w_panth")
ActionOverride(Player4,DestroyItem("w_panth")
ActionOverride(Player5,DestroyItem("w_panth")
ActionOverride(Player6,DestroyItem("w_panth")
ActionOverride(Player1,DestroyItem("w_drarm")
ActionOverride(Player2,DestroyItem("w_drarm")
ActionOverride(Player3,DestroyItem("w_drarm")
ActionOverride(Player4,DestroyItem("w_drarm")
ActionOverride(Player5,DestroyItem("w_drarm")
ActionOverride(Player6,DestroyItem("w_drarm")
ActionOverride(Player1,DestroyItem("w_dboot")
ActionOverride(Player2,DestroyItem("w_dboot")
ActionOverride(Player3,DestroyItem("w_dboot")
ActionOverride(Player4,DestroyItem("w_dboot")
ActionOverride(Player5,DestroyItem("w_dboot")
ActionOverride(Player6,DestroyItem("w_dboot")
ActionOverride(Player1,DestroyItem("w_dramu")
ActionOverride(Player2,DestroyItem("w_dramu")
ActionOverride(Player3,DestroyItem("w_dramu")
ActionOverride(Player4,DestroyItem("w_dramu")
ActionOverride(Player5,DestroyItem("w_dramu")
ActionOverride(Player6,DestroyItem("w_dramu")
LeaveParty()
EscapeArea()~ EXIT
END

IF 
~Global("w_drizztrep","GLOBAL",1)~ THEN BEGIN Misspleased
SAY ~Your actions are of the lowest and nothing I stand for. You are not worthy of my aid.~
IF ~~ THEN DO ~SetGlobal("w_drizztrep","GLOBAL",2)
ActionOverride(Player1,DestroyItem("w_drsw1")
ActionOverride(Player2,DestroyItem("w_drsw1")
ActionOverride(Player3,DestroyItem("w_drsw1")
ActionOverride(Player4,DestroyItem("w_drsw1")
ActionOverride(Player5,DestroyItem("w_drsw1")
ActionOverride(Player6,DestroyItem("w_drsw1")
ActionOverride(Player1,DestroyItem("w_drsw2")
ActionOverride(Player2,DestroyItem("w_drsw2")
ActionOverride(Player3,DestroyItem("w_drsw2")
ActionOverride(Player4,DestroyItem("w_drsw2")
ActionOverride(Player5,DestroyItem("w_drsw2")
ActionOverride(Player6,DestroyItem("w_drsw2")
ActionOverride(Player1,DestroyItem("w_panth")
ActionOverride(Player2,DestroyItem("w_panth")
ActionOverride(Player3,DestroyItem("w_panth")
ActionOverride(Player4,DestroyItem("w_panth")
ActionOverride(Player5,DestroyItem("w_panth")
ActionOverride(Player6,DestroyItem("w_panth")
ActionOverride(Player1,DestroyItem("w_drarm")
ActionOverride(Player2,DestroyItem("w_drarm")
ActionOverride(Player3,DestroyItem("w_drarm")
ActionOverride(Player4,DestroyItem("w_drarm")
ActionOverride(Player5,DestroyItem("w_drarm")
ActionOverride(Player6,DestroyItem("w_drarm")
ActionOverride(Player1,DestroyItem("w_dboot")
ActionOverride(Player2,DestroyItem("w_dboot")
ActionOverride(Player3,DestroyItem("w_dboot")
ActionOverride(Player4,DestroyItem("w_dboot")
ActionOverride(Player5,DestroyItem("w_dboot")
ActionOverride(Player6,DestroyItem("w_dboot")
ActionOverride(Player1,DestroyItem("w_dramu")
ActionOverride(Player2,DestroyItem("w_dramu")
ActionOverride(Player3,DestroyItem("w_dramu")
ActionOverride(Player4,DestroyItem("w_dramu")
ActionOverride(Player5,DestroyItem("w_dramu")
ActionOverride(Player6,DestroyItem("w_dramu")
LeaveParty()
EscapeArea()~ EXIT
END


IF ~Global("w_drizztTob","GLOBAL",1)~ THEN BEGIN ToBDrizzt
SAY ~Well <CHARNAME> it has been interesting to journey with you. But I have to find my way to Ten Towns now where my friends await. Good speed to you.~
IF ~~ THEN DO ~SetGlobal("w_drizztTob","GLOBAL",2)
LeaveParty()
EscapeArea()~ EXIT
END

IF ~Global("AttackedDrizzt","GLOBAL",1)~ THEN BEGIN 2
SAY ~What?!  The fool <CHARNAME> attacks me even as I aid <PRO_HIMHER>?!  I will leave you to your fate, then!!~
IF ~~ THEN DO ~LeaveParty()
EscapeArea()
ActionOverride(Player1,DestroyItem("w_drsw1")
ActionOverride(Player2,DestroyItem("w_drsw1")
ActionOverride(Player3,DestroyItem("w_drsw1")
ActionOverride(Player4,DestroyItem("w_drsw1")
ActionOverride(Player5,DestroyItem("w_drsw1")
ActionOverride(Player6,DestroyItem("w_drsw1")
ActionOverride(Player1,DestroyItem("w_drsw2")
ActionOverride(Player2,DestroyItem("w_drsw2")
ActionOverride(Player3,DestroyItem("w_drsw2")
ActionOverride(Player4,DestroyItem("w_drsw2")
ActionOverride(Player5,DestroyItem("w_drsw2")
ActionOverride(Player6,DestroyItem("w_drsw2")
ActionOverride(Player1,DestroyItem("w_panth")
ActionOverride(Player2,DestroyItem("w_panth")
ActionOverride(Player3,DestroyItem("w_panth")
ActionOverride(Player4,DestroyItem("w_panth")
ActionOverride(Player5,DestroyItem("w_panth")
ActionOverride(Player6,DestroyItem("w_panth")
ActionOverride(Player1,DestroyItem("w_drarm")
ActionOverride(Player2,DestroyItem("w_drarm")
ActionOverride(Player3,DestroyItem("w_drarm")
ActionOverride(Player4,DestroyItem("w_drarm")
ActionOverride(Player5,DestroyItem("w_drarm")
ActionOverride(Player6,DestroyItem("w_drarm")
ActionOverride(Player1,DestroyItem("w_dboot")
ActionOverride(Player2,DestroyItem("w_dboot")
ActionOverride(Player3,DestroyItem("w_dboot")
ActionOverride(Player4,DestroyItem("w_dboot")
ActionOverride(Player5,DestroyItem("w_dboot")
ActionOverride(Player6,DestroyItem("w_dboot")
ActionOverride(Player1,DestroyItem("w_dramu")
ActionOverride(Player2,DestroyItem("w_dramu")
ActionOverride(Player3,DestroyItem("w_dramu")
ActionOverride(Player4,DestroyItem("w_dramu")
ActionOverride(Player5,DestroyItem("w_dramu")
ActionOverride(Player6,DestroyItem("w_dramu")~ EXIT
END

BEGIN w_drizzp

IF ~Global("W_DrizztInParty","GLOBAL",1)~ THEN BEGIN KickOut
SAY ~So are you capable of facing your future destiny on your own now?~
IF ~~ THEN REPLY ~I am still in need of your guidance, Drizzt, due to an evil of major proportions that lies ahead.~ DO ~JoinParty()~ EXIT
IF ~~ THEN REPLY ~I can manage from here on. It has been an honour to journey by your side.~ DO ~SetGlobal("W_DrizztInParty","GLOBAL",2)
LeaveParty()
EscapeArea()
ActionOverride(Player1,DestroyItem("w_drsw1")
ActionOverride(Player2,DestroyItem("w_drsw1")
ActionOverride(Player3,DestroyItem("w_drsw1")
ActionOverride(Player4,DestroyItem("w_drsw1")
ActionOverride(Player5,DestroyItem("w_drsw1")
ActionOverride(Player6,DestroyItem("w_drsw1")
ActionOverride(Player1,DestroyItem("w_drsw2")
ActionOverride(Player2,DestroyItem("w_drsw2")
ActionOverride(Player3,DestroyItem("w_drsw2")
ActionOverride(Player4,DestroyItem("w_drsw2")
ActionOverride(Player5,DestroyItem("w_drsw2")
ActionOverride(Player6,DestroyItem("w_drsw2")
ActionOverride(Player1,DestroyItem("w_panth")
ActionOverride(Player2,DestroyItem("w_panth")
ActionOverride(Player3,DestroyItem("w_panth")
ActionOverride(Player4,DestroyItem("w_panth")
ActionOverride(Player5,DestroyItem("w_panth")
ActionOverride(Player6,DestroyItem("w_panth")
ActionOverride(Player1,DestroyItem("w_drarm")
ActionOverride(Player2,DestroyItem("w_drarm")
ActionOverride(Player3,DestroyItem("w_drarm")
ActionOverride(Player4,DestroyItem("w_drarm")
ActionOverride(Player5,DestroyItem("w_drarm")
ActionOverride(Player6,DestroyItem("w_drarm")
ActionOverride(Player1,DestroyItem("w_dboot")
ActionOverride(Player2,DestroyItem("w_dboot")
ActionOverride(Player3,DestroyItem("w_dboot")
ActionOverride(Player4,DestroyItem("w_dboot")
ActionOverride(Player5,DestroyItem("w_dboot")
ActionOverride(Player6,DestroyItem("w_dboot")
ActionOverride(Player1,DestroyItem("w_dramu")
ActionOverride(Player2,DestroyItem("w_dramu")
ActionOverride(Player3,DestroyItem("w_dramu")
ActionOverride(Player4,DestroyItem("w_dramu")
ActionOverride(Player5,DestroyItem("w_dramu")
ActionOverride(Player6,DestroyItem("w_dramu")~ EXIT
END
