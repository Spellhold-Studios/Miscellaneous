I_C_T C6BODHI 0 W_DRIZZ1
  == W_DRIZZ   IF ~InParty("w_drizz")
!StateCheck("w_drizz",CD_STATE_NOTVALID)~ THEN ~You should have hidden vampire filth, because my Twinkle will end your existence here and now!~ 
== C6BODHI IF ~InParty("w_drizz")~ THEN ~Well, isn�t it the drow hero from Ten Towns. Such a shame that <CHARNAME> can�t handle this on <PRO_HISHER> own.~
== W_DRIZZ IF ~InParty("w_drizz")~ THEN ~Enough talking, let this end now!~
== C6BODHI IF ~InParty("w_drizz")~ THEN ~So eager to die are you? Poor <CHARNAME>, thinking that Drizzt would save <PRO_HIMHER>.~
END


BEGIN w_drizz

IF ~Global("W_BodhiDead","AR0809",1)
!StateCheck("w_drizz",CD_STATE_NOTVALID)~ THEN BEGIN 0
SAY ~So it ends. The evil is slain. You have done well, friend. I bid you fair journey!~ [DRIZZT09]
IF ~~ THEN REPLY ~Wait, the evil isn�t truly slain yet. A man named Irenicus that Bodhi was in league with still exists. His plans are a threat to the whole realm.~ DO ~SetGlobal("W_BodhiDead","AR0809",2)~ GOTO 1
IF ~~ THEN REPLY ~I thank you for aiding me and wish you a fair journey as well.~ DO ~SetGlobal("W_BodhiDead","AR0809",2)
EscapeArea()
DestroySelf()~ EXIT
END

IF ~~ THEN BEGIN 1
SAY ~So it seems that your destiny holds more than I suspected <CHARNAME>. Very well, I shall journey by your side for a while but friends in Ten Towns await.~
IF ~~ THEN REPLY ~It is an honour to have you by my side, Drizzt.~ DO ~SetGlobal("W_DrizztInParty","GLOBAL",1)
SetGlobalTimer("CompanionDrizzt","GLOBAL",THREE_DAYS)
JoinParty()~ EXIT
END


