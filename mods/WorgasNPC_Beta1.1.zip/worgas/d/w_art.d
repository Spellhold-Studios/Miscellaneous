BEGIN w_art

IF ~Global("w_artVSdrizzt","GLOBAL",1)
InParty("w_drizz")
!StateCheck("w_drizz",STATE_SLEEPING)~ THEN BEGIN 0
SAY ~Drizzt, finally I have tracked you down! You have been hiding since our last encounter.~ 
IF ~~ THEN DO ~Enemy()
 SetGlobal("w_artVSdrizzt","GLOBAL",2)
ReallyForceSpell(Myself,WIZARD_HASTE)
ReallyForceSpell(Myself,ROGUE_EVASION)
ReallyForceSpell(Myself,ROGUE_ASSASINATION)
ReallyForceSpell(Myself,WIZARD_NON_DETECTION)
ReallyForceSpell(Myself,WIZARD_INVISIBILITY)
CreateCreature("w_arta1",[1191.932],0)
CreateCreature("w_arta1",[1012.635],0)
CreateCreature("w_arta1",[1491.836],0)
CreateCreature("w_arta1",[1251.493],0)
AttackReevaluate("w_drizz",30)~ EXIT
END


