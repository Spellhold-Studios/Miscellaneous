BEGIN ~w_boo~

IF ~CombatCounter(0)
Name("Minsc",LastTalkedToBy)~
THEN BEGIN 1
SAY ~*Squeek*~ [RAT02]
IF ~~ THEN REPLY ~Great fun hehe, right Boo?~ DO ~PlaySound("MINSC12")~ GOTO 2
END

IF ~~ THEN BEGIN 2
SAY ~*Squeek*~ [RAT02]
IF ~~ THEN REPLY ~You point, I punch!~ DO ~PlaySound("MINSC21")~ EXIT
END

IF ~CombatCounter(0)
!Name("Minsc",LastTalkedToBy)~
THEN BEGIN 1
SAY ~*Squeek*~ [RAT02]
IF ~~ THEN REPLY ~Hello Boo.~ EXIT
END



