BEGIN ~zarix~

IF ~CombatCounter(0)
Name("Worgas",LastTalkedToBy)~
THEN BEGIN 1
	SAY ~(Zarix's eye stares in every direction with thousands of expressions.)~ 
	IF ~~ THEN REPLY ~Mmmm.. my prettie.. send one of your eyeballs to scout the area.~ GOTO 2
IF ~~ THEN REPLY ~Onward, my pretty.~ EXIT
END

IF ~~ THEN BEGIN 2
	SAY ~(One of Zarix's many wizard eyes pops out and Worgas smiles with delight.)~ 
IF ~~ THEN DO ~ActionOverride("zarix",UseItem("w_eyesum","zarix")
~ EXIT
END

IF ~CombatCounter(0)
!Name("Worgas",LastTalkedToBy)~
THEN BEGIN 1
	SAY ~*Grhuaarrrr*~ [BEHOLS01]
	IF ~~ THEN REPLY ~Hello Zarix.~ EXIT
END


