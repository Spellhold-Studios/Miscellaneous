BEGIN w_cow02

IF ~Global("w_cowledchase","AR0700",2)
InParty("Worgas")
!StateCheck("Worgas",STATE_SLEEPING)~ THEN BEGIN 0
SAY ~Hand over that elf, he is a fugitive from Spellhold and responsible for the murder of two cowled wizards!~ 
IF ~~ THEN REPLY ~You may take him in but only if I get Imoen in return.~ DO ~SetGlobal("w_cowledchase","AR0700",3)~ GOTO 1
IF ~~ THEN REPLY ~Your words mean nothing to me, bring Imoen back or feel my wrath!~ DO ~SetGlobal("w_cowledchase","AR0700",3)~ GOTO 2
END

IF ~~ THEN BEGIN 1
SAY ~A choice is no option for you, Imoen is responsible for illegal use of magical energy. Last chance, hand over the elf.~
IF ~~ THEN REPLY ~If he is that murderer you speak of then I want no part of him. But I will confront you later on and demand you release Imoen because she is a victim of circumstance.~ GOTO 3
IF ~~ THEN REPLY ~Your words aren't enough evidence, I cannot let you take him as well.~ DO ~ActionOverride("w_cow01",Enemy()
ActionOverride("w_cow02",Enemy()
ActionOverride("Worgas",DisplayStringHead(Myself,60355))~ EXIT
END

IF ~~ THEN BEGIN 2
SAY ~You have no options in this matter, cease your hostility or we will have to act with force.~
IF ~~ THEN REPLY ~Very well, take him in but I am not done with you.~ GOTO 3 
IF ~~ THEN REPLY ~Bring it on!~ DO ~ActionOverride("w_cow01",Enemy()
ActionOverride("w_cow02",Enemy()
ActionOverride("Worgas",DisplayStringHead(Myself,60355))~ EXIT
END

IF ~~ THEN BEGIN 3
SAY ~A wise choice.~
IF ~~ THEN DO ~ActionOverride("w_cow01",ReallyForceSpell(Myself,DRYAD_TELEPORT)
ActionOverride("w_cow02",ReallyForceSpell(Myself,DRYAD_TELEPORT)
ActionOverride("w_cow01",ReallyForceSpell("Worgas",DRYAD_TELEPORT)
ActionOverride("w_cow01",ReallyForceSpell("Zarix",DRYAD_TELEPORT)
ActionOverride("w_cow01",DestroySelf()
ActionOverride("w_cow02",DestroySelf()
ActionOverride("Worgas",LeaveParty()
ActionOverride("Worgas",DestroySelf()
ActionOverride("Zarix",DestroySelf()
PlaySound("PPNALJ03")~ EXIT
END

