BEGIN w_rune

IF 
~Global("w_runehood","AR2900",1)
InParty("Worgas")
!StateCheck("Worgas",STATE_SLEEPING)~ THEN BEGIN 0
SAY ~Muahahaha! So the ring has finally found its way to us.~ [DEMO07]
IF ~~ THEN DO ~ActionOverride("w_rune",Enemy()
SetGlobal("w_runehood","AR2900",2)~ EXIT
END

