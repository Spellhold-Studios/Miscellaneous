Worgas   author:flysoup

Worgas the NPC:
Worgas is an elven chaotic emotionally shattered wildmage with high intelligence which is hidden behind his neurotic behaviour.

Often speaks in riddles impossible to understand.

He restlessly wanders with, as he call it, a levitating eyeball with many eyes on it also named as his pretties among others.

Worgas has two unique abilities called Wail of Insanity and Biting Eye.

Wail of Insanity: A scream of ten thousands maniacs is shouted out loud and, if failing the save, the enemy will be stunned and inflicted with fear. 

Biting Eye:
A biting eyeball is summoned which follows Worgas and instantly goes for the eyes of Worgas' nearest enemy causing serious wounds.  Also blinds enemies in the area with its blinding light strike.

Zarix:
A gauth familiar of Worgas (the levitating eyeball as mentioned above).
He can release one of his eyeballs to scout the area but only if Worgas asks him. Zarix attacks with one magic missile bolt.
Zarix also has a chain contingency of protection.

The attack and chain contingency will improve when ToB starts.
If Zarix is killed he will be gone forever. He protects Worgas as a priority but if Worgas is killed then he follows the protagonist.

Minsc and Boo:
Minsc will now be able to release Boo from the backpack. 
Boo goes for the eyes and the victim gets blinded for a duration of time.

Boo responds differently if talked to by Minsc than by any other party member.

Drizzt:
Drizzt can be asked to join the final fight against Irenicus (if he was asked to join the Bodhi battle and survives of course).
Any other Drizzt mods won't work well with the Worgas mod or mods with Artemis in them. Spoilers, but important to note before installing Worgas. (I might put the Drizzt content as an optional install in the future if people want it.)

Drizzt will only stay for a limited time due to friends waiting in Ten Towns. He also has interjections in the final parts of SoA.

Installation:
Extract Worgas_NPC.rar to your BG-SOA folder.
Run Setup-worgas.exe and choose yes to install.

Uninstall:
Run Setup-worgas.exe and choose Uninstall.

Requirements:
ToB and start a new SoA game. (A good idea is always to have a fresh install)
You need to start a new game.

Compatibility:
Should work with all other weidu mods if they haven�t got the same w_  prefix followed with exactly the same filenames as in the Worgas mod, or if having the script names Worgas and Zarix for a creature.

I myself have played Worgas with all the major weidu mods and npc mods without any conflicts.

Questions, spoilers, tactics or content:
Email me for those at 08.54022473@telia.com or flysoups@hotmail.com

Banters with:
Aerie, Minsc, Viconia, Jan, Korgan, Jaheira and Edwin.

Many interjections with non joinable npcs throughout SoA and ToB. (Especially when it comes to the Drow and Spellhold issues, spoiler hint, hehe)

Encounters and other area happenings based on having Worgas in the party.

Item creation based on having Worgas in the party.

Again, email me for further and a more detailed content description.

Have fun!

Best regards,
flysoup



VERSION-HISTORY

Beta v1
- First release

Beta v1.1
- Added BGT compatibility
- Added component "Boo as Familar"
- Added component "Drizzt"
- Added VERSION flag
- Updated to WeiDU v211
