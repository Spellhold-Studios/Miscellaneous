	-------------------------------------------------------
	*** *** *** Way Of The Fist Kit, Version 1.0 *** *** ***
	-------------------------------------------------------

I N D E X :

1. Introduction - [int]
2. Installation - [inst]
3. Kit description - [kdesc]
4. Components list and Install Order - [compl]
5. Compatibility issues [ciss]
6. Credits and Acknowledgements [cack]
7. Version notes - [version]

---------------------------------------------------------------------------------------------
1. Introduction - [int]

This mod introduce a new kit under the monk class.
I always loved the monk class and plaid it in Baldur's gate and Never Winter Nights, but it wasn't the class i always dreamed of.
I always wanted to play as a martial artist, something close to those found in wuxia/xian xia stories (if you are into those kind of stories, please do yourself a favor and read "The Breaker" manhwa).

6 months ago i sat down and created the first version of the mod, and what will eventually become Way Of The Fist kit.
The first version was nice and had lot's of passive abilities that gave it an edge RP wise, but it had the same flaws of any other melee kit in the game, it was somewhat dull and boring.
What made it even more boring, was the fact that i couldn't use any magical items.
So i sat once more and rewrote the old kit in a way that made it much more engaging for me to play with.
Today i am sharing this kit with you, with the hope of making someone smile, and getting some feedback's and maybe some new ideas.

The new version is much more engaging:
	1) you can use any ability without any pauses.
	2) It introduces a new game mechanic called Ki Pool which fuels your abilities, whenever you use an ability it subtracts number of ki points from that pool.
	   for example, casting Quivering Palm will subtract 5 ki points.
	   one need to be cautious though, using an ability which requires 3 ki points while having only 1 ki point will drain the user life force to fuel the ability, 1 ki point equals to 15HP.
	3) It introduces new abilities and passives.
	4) for more information, read the in game kit description or the KIT_DESCRIPTION.txt

I hope you'll like this kit as i do, and if you have any feedback or questions you can mail me at yowavegamer@gmail.com

---------------------------------------------------------------------------------------------
2.	*** INSTALLATION *** - [inst]

You should note that the mod comes in ZIP format. Most versions of windows should be able to extract the file.
Winzip can be used if you can't extract the files using windows built in zip extractor: http://www.winzip.com/win/en/prod_down.html

Instructions:

1) Place the zip file in your root Baldur's Gate 1/2 directory (where baldur.exe is), right click and select Extract Here. Then move the zip file to another location.

2) Open your Baldur's Gate 1/2 folder, and double-click 'setup-WayOfTheFist.exe'. If there is no setup-WayOfTheFist.exe in this directory, you have extracted it to the wrong place.

3) The core component of the mod can be installed safely before or after any other mod.
   The Magical Items Restriction should be installed AFTER any mod that adds new items to the game!

If you want to uninstall the mod, just double-click again 'setup-WayOfTheFist.exe' and press 'U' for uninstall.

Note, do not delete therefore the WayOfTheFist folder (this goes for any WeiDU installed mod) otherwise you cannot uninstall.

---------------------------------------------------------------------------------------------
3.	*** Kit description *** - [kdesc]

You can find the kit description in the installation directory WayOfTheFist/KIT_DESCRIPTION.txt


---------------------------------------------------------------------------------------------
4.	*** Components list and Install Order *** - [compl]

0 - Way Of The Fist Core: will install the main files for the kit.
	Should be installed before any tweak and ai mods, for example aTweaks, Scales of Balance, Sword Coast Stratagems, etc...

1 - Way Of The Fist Magical Items Restriction: will make it so Way Of The Fist kit won't be able to use any magical items.
	Should be installed last, specifically after any mod that adds items to the game.

---------------------------------------------------------------------------------------------
5.	*** Compatibility issues *** - [ciss]

The mod should work with BG2:EE and BG1:EE.

Steam/GOG SOD dlc:
You can install it after merging SOD with BG1:EE installation.
Can find instructions here:
https://forums.beamdog.com/discussion/50441/modmerge-merge-your-steam-gog-zip-based-dlc-into-something-weidu-nearinfinity-dltcep-can-use/p1

Beamdog SOD:
No idea, if someone knows how to install this on Beamdog version please mail me the instructions.

---------------------------------------------------------------------------------------------
6.	*** Credits and Acknowledgements *** - [cack]

I would like to thank the creators of the tools I used in the writing of this mod:
1. WeiDu, by Westley Weimer, the bigg and Wisp
2. Near Infinity, by Jon Hauglid and Argent77
4. fl-add_kit_ee, by FredrikLindgren
3. NotePad++, by Don Ho

---------------------------------------------------------------------------------------------
7.	*** Version notes *** - [version]

Version 1.3 - 05/12/2016
	* Core - fixed remove abilities on level 3 and 4.
		 On level up gained abilities should be removed untill rest.
	* README - Added information about install order.

Version 1.2 - 30/11/2016
	* Core - BG:EE - Added MFIST8 and MFIST4
	* Core - Fists are named instead of setting string references
	* Items Restrictions - Checking that item type is not hand to hand
	* Fixed allowed weapon proficiency

Version 1.1 - 28/11/2016:
	* Fixed some typos in kit description
	* Fixed Ki Coat description, it stated that it gives -3 to saving throws at level 15, while in reality it gives -2 to saving throws.

Version 1.0 - 27/11/2016:
	* First public release