BEGIN MGLDG00

IF ~ReputationLT(Protagonist,5)~ THEN BEGIN Halt

 SAY @1

 IF ~Reputation(Protagonist,4) /* REPUTATION IS 4 */

     OR(6)
      CheckStatGT(Player1,15,CHR) /* CHARISMA IS 16 OR HIGHER */
      CheckStatGT(Player2,15,CHR)
      CheckStatGT(Player3,15,CHR)
      CheckStatGT(Player4,15,CHR)
      CheckStatGT(Player5,15,CHR)
      CheckStatGT(Player6,15,CHR)

     PartyGoldGT(24)~ /* PARTY HAS AT LEAST 25 GOLD */

 THEN REPLY @2 GOTO Bribe25

 IF ~Reputation(Protagonist,3) /* REPUTATION IS 3 */

     OR(6)
      CheckStatGT(Player1,16,CHR) /* CHARISMA IS 17 OR HIGHER */
      CheckStatGT(Player2,16,CHR)
      CheckStatGT(Player3,16,CHR)
      CheckStatGT(Player4,16,CHR)
      CheckStatGT(Player5,16,CHR)
      CheckStatGT(Player6,16,CHR)

     PartyGoldGT(49)~ /* PARTY HAS AT LEAST 50 GOLD */

 THEN REPLY @3 GOTO Bribe50

 IF ~Reputation(Protagonist,2) /* REPUTATION IS 2 */

     OR(6)
      CheckStatGT(Player1,17,CHR) /* CHARISMA IS 18 OR HIGHER */
      CheckStatGT(Player2,17,CHR)
      CheckStatGT(Player3,17,CHR)
      CheckStatGT(Player4,17,CHR)
      CheckStatGT(Player5,17,CHR)
      CheckStatGT(Player6,17,CHR)

     PartyGoldGT(74)~ /* PARTY HAS AT LEAST 75 GOLD */

 THEN REPLY @4 GOTO Bribe75

 IF ~Reputation(Protagonist,1) /* REPUTATION IS 1 */

     OR(6)
      CheckStatGT(Player1,18,CHR) /* CHARISMA IS 19 OR HIGHER */
      CheckStatGT(Player2,18,CHR)
      CheckStatGT(Player3,18,CHR)
      CheckStatGT(Player4,18,CHR)
      CheckStatGT(Player5,18,CHR)
      CheckStatGT(Player6,18,CHR)

     PartyGoldGT(99)~ /* PARTY HAS AT LEAST 100 GOLD */

 THEN REPLY @5 GOTO Bribe100

 IF ~~ THEN REPLY @6 GOTO Fight /* ALWAYS AVAILABLE */

 IF ~Reputation(Protagonist,4) /* REPUTATION IS 4 */

     PartyGoldGT(249)~ /* PARTY HAS AT LEAST 250 GOLD */

 THEN REPLY @7 GOTO Pay250

 IF ~Reputation(Protagonist,3) /* REPUTATION IS 3 */

     PartyGoldGT(499)~ /* PARTY HAS AT LEAST 500 GOLD */

 THEN REPLY @8 GOTO Pay500

 IF ~Reputation(Protagonist,2) /* REPUTATION IS 2 */

     PartyGoldGT(749)~ /* PARTY HAS AT LEAST 750 GOLD */

 THEN REPLY @9 GOTO Pay750

 IF ~Reputation(Protagonist,1) /* REPUTATION IS 1 */

     PartyGoldGT(999)~ /* PARTY HAS AT LEAST 1000 GOLD */

 THEN REPLY @10 GOTO Pay1000

END /* Halt */


IF ~~ THEN BEGIN Bribe25

 SAY @11

 IF ~~ THEN DO ~TakePartyGold(25)
                SetGlobal("MGGuardsEscape","GLOBAL",1)~ EXIT

END /* Bribe25 */


IF ~~ THEN BEGIN Bribe50

 SAY @11

 IF ~~ THEN DO ~TakePartyGold(50)
                SetGlobal("MGGuardsEscape","GLOBAL",1)~ EXIT

END /* Bribe50 */


IF ~~ THEN BEGIN Bribe75

 SAY @11

 IF ~~ THEN DO ~TakePartyGold(75)
                SetGlobal("MGGuardsEscape","GLOBAL",1)~ EXIT

END /* Bribe75 */


IF ~~ THEN BEGIN Bribe100

 SAY @11

 IF ~~ THEN DO ~TakePartyGold(100)
                SetGlobal("MGGuardsEscape","GLOBAL",1)~ EXIT

END /* Bribe100 */


IF ~~ THEN BEGIN Fight

 SAY @12

 IF ~~ THEN DO ~SetGlobal("MGGuardsEnemy","GLOBAL",1)~ EXIT

END /* Fight */


IF ~~ THEN BEGIN Pay250

 SAY @13

 IF ~~ THEN DO ~TakePartyGold(250)
                ReputationSet(5)
                SetGlobal("MGGuardsEscape","GLOBAL",1)~ EXIT

END /* Pay250 */


IF ~~ THEN BEGIN Pay500

 SAY @13

 IF ~~ THEN DO ~TakePartyGold(500)
                ReputationSet(5)
                SetGlobal("MGGuardsEscape","GLOBAL",1)~ EXIT

END /* Pay500 */


IF ~~ THEN BEGIN Pay750

 SAY @13

 IF ~~ THEN DO ~TakePartyGold(750)
                ReputationSet(5)
                SetGlobal("MGGuardsEscape","GLOBAL",1)~ EXIT

END /* Pay750 */


IF ~~ THEN BEGIN Pay1000

 SAY @13

 IF ~~ THEN DO ~TakePartyGold(1000)
                ReputationSet(5)
                SetGlobal("MGGuardsEscape","GLOBAL",1)~ EXIT

END /* Pay1000 */
