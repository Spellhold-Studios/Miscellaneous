BEGIN MGSLVA0

IF ~True()~ THEN BEGIN Slave
 SAY @204
 IF ~~ THEN REPLY @205 GOTO Ravish
 IF ~~ THEN REPLY @206 EXIT
END /* Slave */

IF ~~ THEN BEGIN Ravish
 SAY @207
 IF ~~ THEN DO ~RestParty()
                DisplayStringNoName(Protagonist,@208)~ EXIT
END /* Ravish */
