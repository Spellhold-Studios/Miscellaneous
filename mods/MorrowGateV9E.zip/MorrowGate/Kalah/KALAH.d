BEGIN KALAH

IF ~NumTimesTalkedTo(0)
    InParty("Aerie")
    !StateCheck("Aerie",STATE_DEAD)
    !Dead("KalahIllusion")~ THEN BEGIN 0
 SAY #20296
 IF ~~ THEN EXTERN AERIEJ 1
END /* 0 */


IF ~~ THEN BEGIN 1
 SAY #20298
 IF ~~ THEN EXTERN AERIEJ 2
END /* 1 */


IF ~~ THEN BEGIN 2
 SAY #20300
 IF ~~ THEN REPLY @1 DO ~Enemy()
                         TriggerActivation("TRAN0605",FALSE)
                         TriggerActivation("ILLUSIONDOOR",TRUE)~ EXIT
 IF ~Alignment(Protagonist,MASK_EVIL)~ THEN REPLY @2 EXTERN AERIEJ MGProtest
END /* 2 */


IF ~NumTimesTalkedTo(0)
    !Dead("KalahIllusion")~ THEN BEGIN 3
 SAY #20301
 IF ~~ THEN GOTO 4
END /* 3 */


IF ~~ THEN BEGIN 4
 SAY #20302
 IF ~~ THEN REPLY @1 DO ~Enemy()
                         TriggerActivation("TRAN0605",FALSE)
                         TriggerActivation("ILLUSIONDOOR",TRUE)~ EXIT
 IF ~Alignment(Protagonist,MASK_EVIL)~ THEN REPLY @7 GOTO MGLaugh
END /* 4 */


IF ~~ THEN BEGIN MGTrade
 SAY @4 = @5 = @6
 IF ~~ THEN DO ~SetGlobal("KalahPact","GLOBAL",1)
                SetGlobal("PermanentTower","GLOBAL",1)
                SetGlobal("SlaveAerie","GLOBAL",1)
                AddAreaType(CANRESTOTHER)
                GiveItemCreate("MGRING1",Protagonist,1,1,0)
                ClearActions("Aerie")
                ActionOverride("Aerie",LeaveParty())
                AddexperienceParty(27000)~ EXIT
END /* MGTrade */


IF ~~ THEN BEGIN MGLaugh
 SAY @8 = @5 = @6
 IF ~~ THEN DO ~SetGlobal("KalahPact","GLOBAL",1)
                SetGlobal("PermanentTower","GLOBAL",1)
                AddAreaType(CANRESTOTHER)
                GiveItemCreate("MGRING1",Protagonist,1,1,0)
                AddexperienceParty(18000)~ EXIT
END /* MGLaugh */


IF ~Global("PermanentTower","GLOBAL",1)
    Global("GivenGuardianQuest","LOCALS",0)~ THEN BEGIN MGQuest1
 SAY @20
 IF ~~ THEN REPLY @21 GOTO MGAccept1
 IF ~~ THEN REPLY @22 GOTO MGDecline
END /* MGQuest1 */


IF ~~ THEN BEGIN MGAccept1
 SAY @23 = @24
 IF ~~ THEN DO ~SetGlobal("GivenGuardianQuest","LOCALS",1)
                RevealAreaOnMap("AR1100")
                RevealAreaOnMap("AR1404")
                GiveItemCreate("MGSPBIND",Protagonist,1,0,0)~ EXIT
END /* MGAccept1 */


IF ~~ THEN BEGIN MGDecline
 SAY @25
 IF ~~ THEN EXIT
END /* MGDecline */


IF ~Global("PermanentTower","GLOBAL",1)
    Global("GivenGuardianQuest","LOCALS",1)
    Global("ShadowDragonGuardian","GLOBAL",1)~ THEN BEGIN MGComplete1
 SAY @26
 IF ~~ THEN DO ~SetGlobal("PermanentTower","GLOBAL",2)
                TakePartyItem("MGSPBIND")
                DestroyItem("MGSPBIND")
                GiveItemCreate("MGARMOR1",Protagonist,1,0,0)
                AddexperienceParty(22000)~ EXIT
END /* MGComplete1 */


IF ~NumTimesTalkedToGT(0)
    GlobalGT("KalahPact","GLOBAL",0)~ THEN BEGIN MGFriend
 SAY @9
 IF ~~ THEN EXIT
END /* MGFriend */


/* --------- Aerie Interjections --------- */

APPEND AERIEJ

IF ~~ THEN BEGIN MGProtest
 SAY @3
 IF ~~ THEN EXTERN KALAH MGTrade
END /* MGProtest */

END /* APPEND */


/* --------- Aerie LeaveParty Dialogue --------- */

APPEND AERIEP

IF WEIGHT #-1 ~GlobalGT("PermanentTower","GLOBAL",0)
               Global("SlaveAerie","GLOBAL",1)~ THEN BEGIN MGAERIEP1
 SAY @10
 IF ~~ THEN DO ~ChangeAIScript("MGSLVA0",OVERRIDE)
                SetDialogue("MGSLVA0")
                MoveToPointNoInterrupt([392.419])
                Face(14)
                Polymorph(SIRINE)~ EXIT
END /* MGAERIEP1 */

IF WEIGHT #-1 ~GlobalGT("PermanentTower","GLOBAL",0)
               Global("SlaveAerie","GLOBAL",0)~ THEN BEGIN MGAERIEP2
 SAY @11
 IF ~~ THEN DO ~Enemy()~ EXIT
END /* MGAERIEP2 */

END /* APPEND */


/* --------- Quayle (Slime Form) Dialogue --------- */

APPEND QUAYLEM

IF WEIGHT #-1 ~GlobalGT("PermanentTower","GLOBAL",0)~ THEN BEGIN MGQUAYLEM
 SAY @12
 IF ~~ THEN EXIT
END /* MGQUAYLEM */

END /* APPEND */


/* --------- Pleasure Slave Dialogue --------- */

APPEND KSLAVE01

IF WEIGHT #-1 ~GlobalGT("PermanentTower","GLOBAL",0)~ THEN BEGIN MGKSLAVE01
 SAY @13
 IF ~~ THEN REPLY @14 EXIT
END /* MGKSLAVE01 */

END /* APPEND */


/* --------- Hannah (Mother of Giran; Spider Form) Dialogue --------- */

APPEND KFTOWN01

IF WEIGHT #-1 ~GlobalGT("PermanentTower","GLOBAL",0)~ THEN BEGIN MGKFTOWN01
 SAY @13
 IF ~~ THEN REPLY @14 EXIT
END /* MGKFTOWN01 */

END /* APPEND */


/* --------- Circus Guard Dialogue --------- */

APPEND CIRCG1

IF WEIGHT #-1 ~GlobalGT("PermanentTower","GLOBAL",0)~ THEN BEGIN MGCIRCG1
 SAY @15
 IF ~~ THEN EXIT
END /* MGCIRCG1 */

END /* APPEND */


/* --------- Giran (Son of Hannah) Dialogue --------- */

APPEND BOY1

IF WEIGHT #-1 ~GlobalGT("PermanentTower","GLOBAL",0)~ THEN BEGIN MGBOY1
 SAY @16
 IF ~~ THEN EXIT
END /* MGBOY1 */

END /* APPEND */


/* --------- Thaxll'ssillyia (Shadow Dragon) Dialogue --------- */

APPEND SHADRA01

IF WEIGHT #-1 ~Global("SurrenderTalk","LOCALS",1)~ THEN BEGIN MGSurrender1
 SAY @17
 IF ~~ THEN REPLY @18 GOTO MGSurrender2
END /* MGSurrender1 */

IF ~~ THEN BEGIN MGSurrender2
 SAY @19
 IF~~ THEN DO ~SetGlobal("ShadowDragonGuardian","GLOBAL",1)
               EscapeAreaDestroy(30)~ EXIT
END /* MGSurrender2 */

END /* APPEND */
