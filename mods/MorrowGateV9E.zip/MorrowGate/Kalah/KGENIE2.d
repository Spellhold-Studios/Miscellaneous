BEGIN KGENIE2

IF ~NumberOfTimesTalkedTo(0)~ THEN BEGIN MGRest
 SAY @203
 IF ~~ THEN DO ~AddAreaType(CANRESTOTHER)
                ForceSpell(Myself,DRYAD_TELEPORT)~ EXIT
END /* MGRest */
