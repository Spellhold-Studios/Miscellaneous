/-------------------------------------------------
------ XXX Morrow Gate 0.9E XXX ------
\-------------------------------------------------

Morrow Gate is designed for systems having BGII - SOA and TOB, the official TOB patch 26498, and either the Baldurdash fixpack OR the G3 Fixpack installed.  It should be compatible with most other WeiDU mods.

It is likely best to install Morrow Gate AFTER all other mods, or as close to last in the install order as possible (as is the case with most tweak packs).

Please direct any questions or comments to:  aWoundedLion@yahoo.com


/-------------------------------------------------
--- COMBINABLE PROTECTION ITEMS ---
\-------------------------------------------------

This component allows 'protection items' to be used together in any combination and with magical armors.


/-------------------------------------------------
--- TRUECLASS RANGER ALIGNMENT REVISIONS ---
\-------------------------------------------------

This component allows players to create trueclass Rangers of any alignment (this does not extend to Ranger kits).  Fallen Rangers now retain and continue to gain abilities.


/-------------------------------------------------
--- FALLEN RANGER NAME REVISION ---
\-------------------------------------------------

This component renames Fallen Rangers to either Rangers or Dark Rangers (player choice). 


/-------------------------------------------------
--- REVISED ITEM PRICING IN STORES ---
\-------------------------------------------------

This component nullifies the effect of reputation on item prices.  To clarify, reputation does *NOT* affect the price of items in shops under this component.  Item pricing becomes a function of Charisma.

STANDARD SCALE:

CHARISMA	DISCOUNT
   11		   5%
   12		  10%
   13		  15%
   14		  20%
   15		  25%
   16		  30%
   17		  35%
   18		  40%
   19		  45%
   20		  50%
   21		  55%
   22		  60%
   23		  65%
   24		  70%
   25		  75%

DIFFICULT SCALE:

CHARISMA	DISCOUNT
   13		   1%
   14		   3%
   15		   5%
   16		   7%
   17		   9%
   18		  11%
   19		  13%
   20		  15%
   21		  17%
   22		  19%
   23		  21%
   24		  23%
   25		  25%


/-------------------------------------------------
--- REVISED RING OF HUMAN INFLUENCE ---
\-------------------------------------------------

The Ring of Human Influence renders the Charisma attribute almost non-functional in BG2 by allowing essentially any character that wishes to complete the relatively short and easy Circus quest to have a Charisma of 18.  This component revises the RoHI to grant a +5 bonus to Charisma, simultaneously reducing its 'cheat value' and rendering the item useful to characters already possessing a Charisma of 18.  Neat, huh?


/-------------------------------------------------
--- CURE SPELL REVISIONS ---
\-------------------------------------------------

This component revises cure spells to scale with caster level.

Cure Light Wounds (Lv1)
Lv1: 8 HP
Lv8: 16 HP
Lv16: 24 HP

Good Berries (Lv2)
Lv1: 1 handful of berries
Lv8: 2 handful of berries
Lv16: 3 handful of berries
*Each handful of berries heals 12 HP

Cure Medium Wounds (Lv3)
Lv1: 16 HP
Lv8: 24 HP
Lv16: 32 HP

Cure Serious Wounds (Lv4)
Lv1: 24 HP
Lv8: 32 HP
Lv16: 40 HP

Cure Critical Wounds (Lv5)
Lv1: 32 HP
Lv8: 40 HP
Lv16: 48 HP


/-------------------------------------------------
--- BREACH AND IRON SKINS REVISIONS ---
\-------------------------------------------------

This component allows Breach to remove Iron Skins and affect Rakshasa creatures.

If you are using Sword Coast Stategems II, install its similar component instead.


/-------------------------------------------------
--- COMPOSITE LONG BOW STRENGTH REQUIREMENT REVISION ---
\-------------------------------------------------

This component reduces the minimum strength required to use composite long bows (including those added by mods) from 18 to 15.

Strong Arm +2 is unaffected and retains its strength requirement of 19.


/-------------------------------------------------
--- CLERIC REVISION: GOOD-ALIGNED CLERICS FALL AT LOW REPUTATIONS ---
\-------------------------------------------------

Under this component, Good-aligned Clerics will fall at a reputation of eight.  All spellcasting and divine abilites are lost.


/-------------------------------------------------
--- TRUECLASS PALADIN ALIGNMENT REVISIONS ---
\-------------------------------------------------

This component allows players to create trueclass Paladins of any alignment (this does not extend to Paladin kits).  Fallen Paladins now retain and continue to gain abilities.

Note:  A character must commit an evil act (theft, murder, etc) to become a Fallen Paladin.


/-------------------------------------------------
--- FALLEN PALADINS GAIN OPPOSITE ABILITIES ---
\-------------------------------------------------

* SPELLS COURTESY OF CAMDAWG AND DIVINE REMIX * 

This component causes Fallen Paladins to gain Detect Good instead of Detect Evil and to gain Protection From Good instead of Protection From Evil.  Three new spells (Detect Good, Protection From Good, and Protection From Good 10' Radius) are added to Fallen Paladins' spellbooks.

Note:  A character must commit an evil act (theft, murder, etc) to become a Fallen Paladin and gain the new spells.

Note:  Visit http://www.gibberlings3.net/ -> The home of Divine Remix and other great mods!


/-------------------------------------------------
--- FALLEN PALADIN NAME REVISION ---
\-------------------------------------------------

This component renames Fallen Paladins to Paladins, Dark Paladins, or Blackguards (player choice).

Note:  A character must commit an evil act (theft, murder, etc) to become a Fallen Paladin.


/-------------------------------------------------
--- EXPANDED WEAPON PROFICIENCIES FOR MONKS ---
\-------------------------------------------------

This component allows Monks to use bastard swords, axes, warhammers, flails, and maces.  Monks are now able to place up to five proficiency points into any allowed weapon.  Monks now begin with four proficiency points at the first level and gain additional proficiency points every three levels.  Monks are now able to place up to two proficiency points into Single Weapon Style.  Monks now roll D10 for hit points instead of D8.


/-------------------------------------------------
--- SHAPESHIFTER REBALANCING REBALANCED ---
\-------------------------------------------------

SRR is an altered version of Westley Weimer's Shapeshifter Rebalancing (available in Ease of Use and  BG2 Tweaks).  This component is based on code shamelessly stolen from BG2 Tweaks (available at http://www.gibberlings3.net/).

Adjustments:
- Both paw items now use a wolf paw icon instead of a bear claw icon.
- Immunity to normal weapons has been removed from lesser werewolf paw item.
- The greater werewolf paw item has been moved from Lv13 to Lv15
- Regeneration has been reduced from 3 HP per second to 1 HP per second for the greater werewolf paw item.
- Damage has been reduced from 1D12 to 1D10 for the lesser werewolf paw item.
- Damage has been reduced from 2D8 to 2D6 for the greater werewolf paw item.
- Elemental resistances have been reduced from 50% to 25% for the greater werewolf paw item.
- The annoying form-change animation has been removed from both paw items.
- The Shapeshifter kit description is updated to reflect SRR changes (SR did not update the description)
- A bug in the stolen G3 code has been fixed; the description for Conjure Animals is now applied to the correct offset.

90% credit: Westley Weimer, creator of the original SR
5% credit: G3, for slightly modernized code
5% credit: Me, for fixing the bug in the G3 code and adjusting SR for playability

I doubt that anyone should mind my appropriating this component.  However, if someone wishes to voice any such complaints to me, or to report bugs with this component (bug reports for SRR go to me, NOT Weimer, NOT G3), feel free to e-mail me (awoundedlion@yahoo.com).

SRR shapeshifters are (despite my adjustments) very powerful but (hopefully) somewhat more balanced.


/-------------------------------------------------
--- ARCANE ARCHER FIGHTER KIT ---
\-------------------------------------------------

The Arcane Archer is a warrior skilled in using magic to supplement his or her combat prowess.  Master of the bow and student of magic, the Archer is an arrowsmith of the highest calibur.  The Archer's sharp eyes and enhanced vision are not easily decieved by hostile illusions.

ADVANTAGES

+1 DEX

Called Shot at Lv4, Lv8, and Lv12

Spells (once per day):

Lv1   Infravision
Lv2   Armor
Lv5   Detect Illusion
Lv6   Protection From Normal Missiles
Lv9   Oracle
Lv10  Breach
Lv13  True Sight
Lv14  Physical Mirror

Craft Arrows (once per day):

Lv1   10 Arrows
Lv3   10 Arrows of Ice
Lv4   10 Arrows of Fire
Lv6   10 Arrows +1
Lv7   10 Arrows of Acid
Lv9    3 Arrows of Dispelling
Lv11  10 Arrows +2
Lv13   3 Arrows of Detonation
Lv15  10 Arrows +3
Lv17   1 Arrow of Slaying (Humanoid)

DISADVANTAGES

May not wear armor greater than studded leather

May not place more than one proficiency point into any melee weapon


/-------------------------------------------------
--- HELLION FIGHTER KIT ---
\-------------------------------------------------

The Hellion is a fierce warrior who honors the Dark Prince of the Hells.  He or she respects strength, power, and cunning above all else.  The Hellion is a student of the Black Arts and may summon Fiends to his side in battle (though these are apt to turn on the Hellion if he or she has not cast protective magics).

ADVANTAGES

Immune to Death Magic

May cast Protection From Evil 10' Radius once per day per level

May cast Banish once per day every four levels starting at Lv4

Lv12  May cast Death Spell once per day
Lv14  May cast Cacofiend once per day
Lv16  May cast Summon Fiend once per day
Lv18  May cast Gate once per day
Lv20  May cast Summon Dark Planetar once per day

DISADVANTAGES

May not be of a Good alignment

May not Dual-Class except to Mage or Thief

May not place more than three proficiency points into any bladed weapon

May not place more than one proficiency point into any non-bladed weapon

NOTES

Banish

Level: Special
Range: 50
Duration: Instant
Casting Time: 1
Area of Effect: 1 Summoned Fiend
Saving Throw: None

This spell banishes a summoned Fiend back to the Lower Planes.


/-------------------------------------------------
--- NATURAL SELECTION: DARKFRIEND DRUID KIT ---
\-------------------------------------------------

The Darkfriend Druid kit is fully compatible with Divine Remix (regardless of install order).

DARKFRIEND: Darkfriends are Druids that have a special connection with creatures that most people think of as monsters.  To a Darkfriend, a wyvern is just as natural as a wolf.  Darkfriends often have poor repuations among cities, towns, and villages and are most at home in the deep woods.

Some Darkfriends attempt to minimize conflict between certain monsters and civilization and to promote peaceful coexistence.  Others work to preserve balance by stopping Great Hunts called against wyverns or spiders.  Some aggressive Darkfriends promote the destruction of civilization and society and organize monsters to raze villages and towns.

ADVANTAGES

The following spells are added to the Darkfriend's spellbook:

Charm Monsters at Lv5
Summon Spiders at Lv7
Wyvern Call at Lv9

DISADVANTAGES

No Shapeshifting Abilities


/-------------------------------------------------
--- NATURAL SELECTION: DRUID ALIGNMENT REVISIONS ---
\-------------------------------------------------

Druids (and all Druid kits including those added by mods) may choose Neutral Good, Lawful Neutral, True Neutral, Chaotic Neutral, or Neutral Evil as their alignment.


/-------------------------------------------------
--- NATURAL SELECTION: DRUID WEAPON PROFICIENCY REVISIONS ---
\-------------------------------------------------

Druids (and all Druid kits including those added by mods) may place one proficiency slot in both Shortbows and Longbows and up to two proficiency slots in Two Handed Style.  Druids begin the game with one proficiency slot in Two Handed Style.


/-------------------------------------------------
--- NATURAL SELECTION: DRUIDS GAIN LV27 NATURE'S BLESSING WISDOM BONUS ---
\-------------------------------------------------

Druids (and all Druid kits including those added by mods) gain Nature's Blessing (+2 Wisdom bonus) at Level 27.


/-------------------------------------------------
--- NATURAL SELECTION: NEW DRUID SPELLS ---
\-------------------------------------------------

Druids (and all Druid kits including those added by mods) gain two restoration spells that render the class a viable alternative to the Cleric.  Also, two improved charm spells strengthen the Druid's arsenal ('Charm Person or Mammal' is WEAK).


/-------------------------------------------------
--- CLERICS AND DRUIDS GAIN BREACH SPELL ---
\-------------------------------------------------

This component adds Breach to the spellbook of trueclass Clerics and Druids, Cleric kits, and Druid kits.


/-------------------------------------------------
--- DRUIDS AND RANGERS GAIN FIND FAMILIAR ABILITY ---
\-------------------------------------------------

This component adds the Find Familiar ability to trueclass Druids and Rangers, Druid kits, and Ranger kits.


/-------------------------------------------------
--- REVISED AMNIAN GUARDSMEN ---
\-------------------------------------------------

Under a default game installation, Amnian guardsmen (triggered by proximity traps in the Docks, Slums, Bridge District, and Waukeen's Promenade areas) attempt to execute the player party when its reputation reaches 3.  The player party has no choice but to fight.

Under this component, Amnian guardsmen (via the same proximity traps) detain the player party when its reputation reaches 4.  The player party can bribe, fight, or pay a restitution fee to the guardsmen.  A bribe buys the party freedom from harassment for at least one day.  A restitution fee restores the party's reputation to 5.

REPUTATION	RESTITUTION FEE		CHARISMA & GOLD TO BRIBE
   4		   250 Gold		   16 CHR +  25 Gold
   3		   500 Gold		   17 CHR +  50 Gold
   2		   750 Gold		   18 CHR +  75 Gold
   1		  1000 Gold		   19 CHR + 100 Gold


/-------------------------------------------------
--- (BETA) BETTER BUSINESS: KALAH ---
\-------------------------------------------------

Kalah's Tower Stronghold for Evil Protagonists + Tower Guardian Stronghold Quest
