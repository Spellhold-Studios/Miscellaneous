/-------------------------------------------------
------ XXX Morrow Gate 0.9E XXX ------
\-------------------------------------------------

Morrow Gate est compatible avec les syst�mes disposant de BG2 - SOA et TOB, du patch officiel TOB 26498, et du Fixpack Baldurdash ou du Fixpack G3. Il devrait aussi �tre compatible avec la plupart des autre mods WeiDU.

Il est pr�f�rable d'installer Morrow Gate apr�s tous les autres mods, ou aussi pr�s que possible de la fin de l'ordre d'installation (comme c'est le cas pour la plupart des tweak packs).

Si vous avez des questions ou commentaires, adressez-les � : aWoundedLion@yahoo.com


/-------------------------------------------------
--- OBJETS DE PROTECTION COMBINABLES ---
\-------------------------------------------------

Ce composant permet de combiner librement les "objets de protection" entre eux et avec les armures magiques.


/-------------------------------------------------
--- ALIGNEMENT DE LA CLASSE PURE DE R�DEUR REVU ---
\-------------------------------------------------

Ce composant permet aux joueurs de cr�er des personnages de classe pure R�deur de n'importe quel alignement (ceci ne s'applique pas aux kits de R�deur). Les R�deurs d�chus conservent maintenant leurs capacit�s et peuvent continuer � en gagner.


/-------------------------------------------------
--- NOM DU R�DEUR DECHU REVU ---
\-------------------------------------------------

Ce composant renomme les R�deurs d�chus en R�deurs ou R�deurs sombres (au choix du joueur)


/-------------------------------------------------
--- PRIX DES OBJETS EN MAGASIN REVUS ---
\-------------------------------------------------

Ce composant annule l'effet de la r�putation sur le prix des objets dans les magasins. Pour �tre pr�cis, la r�putation n'affecte *PAS* le prix des objets dans les magasins avec ce composant. Le prix des objets d�pend maintenant du charisme.

�CHELLE NORMALE :

CHARISME	REDUCTION
   11		   5%
   12		  10%
   13		  15%
   14		  20%
   15		  25%
   16		  30%
   17		  35%
   18		  40%
   19		  45%
   20		  50%
   21		  55%
   22		  60%
   23		  65%
   24		  70%
   25		  75%

�CHELLE DIFFICILE :

CHARISME	REDUCTION
   13		   1%
   14		   3%
   15		   5%
   16		   7%
   17		   9%
   18		  11%
   19		  13%
   20		  15%
   21		  17%
   22		  19%
   23		  21%
   24		  23%
   25		  25%


/-------------------------------------------------
--- ANNEAU D'INFLUENCE HUMAINE REVU ---
\-------------------------------------------------

L'anneau d'influence humaine rend la caract�ristique Charisme inint�ressante dans BG2 en permettant � n'importe quel personnage ayant accompli la courte qu�te du Cirque d'obtenir un charisme de 18. Ce composant modifie l'AdIH pour qu'il ne donne qu'un +5 en Charisme, r�duisant ainsi son aspect "cheat�" tout en le rendant utile pour les personnages ayant d�j� un charisme �lev�. Pas mal, non?


/-------------------------------------------------
--- SORTS DE SOIN REVUS ---
\-------------------------------------------------

Ce composant modifie les sorts de soin pour qu'ils s'adaptent au niveau du lanceur de sorts.

Soins des blessures l�g�res (Niveau 1)
Niveau 1 : 8 PV
Niveau 8 : 16 PV
Niveau 16 : 24 PV

Baies magiques (Niveau 2)
Niveau 1 : 1 poign�e de baies
Niveau 8 : 2 poign�es de baies
Niveau 16 : 3 poign�es de baies
*Chaque poign�e de baies soigne 12 PV

Soins des blessures moyennes (Niveau 3)
Niveau 1 : 16 PV
Niveau 8 : 24 PV
Niveau 16 : 32 PV

Soins des blessures graves (Niveau 4)
Niveau 1 : 24 PV
Niveau 8 : 32 PV
Niveau 16 : 40 PV

Soins des blessures critiques (Niveau 5)
Niveau 1 : 32 PV
Niveau 8 : 40 PV
Niveau 16 : 48 PV


/-------------------------------------------------
--- BRECHE ET PEAU DE FER REVUS ---
\-------------------------------------------------

Ce composant permet au sort Br�che de retirer Peau de fer et d'affecter les cr�atures Rakshasa.

Si vous utilisez Sword Coast Stratagems, installez plut�t son composant �quivalent.


/-------------------------------------------------
--- FORCE NECESSAIRE POUR LES ARCS COMPOSITES REVUE ---
\-------------------------------------------------

Ce composant r�duit la force minimum requise pour l'utilisation d'arcs longs composites (en incluant ceux introduits par des mods) de 18 � 15

Bras Puissant +2 n'est pas affect� et conserve son pr�-requis en Force de 19.


/-------------------------------------------------
--- CLERC REVU : LES PR�TRES D'ALIGNEMENT BON SONT DECHUS A FAIBLE REPUTATION ---
\-------------------------------------------------

Gr�ce � ce composant, les Clercs d'alignement bon seront d�chus si leur r�putation descend au dessous de 8. Tout les sorts et capacit�s divines seront perdues.


/-------------------------------------------------
--- ALIGNEMENT DE LA CLASSE PURE DE PALADIN REVU ---
\-------------------------------------------------

Ce composant permet aux joueurs de cr�er des paladins purs de n'importe quel alignement. (ceci ne s'applique pas aux kits de paladins). Les paladins d�chus pourront d�sormais conserver et continuer � gagner des capacit�s.

NB : Un personnage doit commettre un acte mauvais pour devenir un Paladin d�chu (vol, meurtre, etc).


/-------------------------------------------------
--- LES PALADINS DECHUS OBTIENNENT DES CAPACITES OPPOSEES ---
\-------------------------------------------------

* SORTS INCLUS AVEC L'AIMABLE AUTORISATION DE CAMDAWG ET DIVINE REMIX * 

Ce composant fait en sorte que les Paladins d�chus obtiennent D�tection du Bien au lieu de D�tection du Mal, et Protection contre le Bien au lieu de Protection contre le Mal. Ces trois nouveaux sorts (D�tection du Bien, Protection contre le Bien, et Protection contre le Bien de 3 m�tres de rayon) sont ajout�s au livre de sorts des Paladins d�chus.

NB : Un personnage doit commettre un acte mauvais (vol, meurtre, etc) pour devenir un Paladin d�chu et d�bloquer les nouveaux sorts.

NB : Rendez vous sur http://www.gibberlings3.net/ -> La page de Divine Remix et autres super mods !


/-------------------------------------------------
--- NOM DU PALADIN DECHU REVU ---
\-------------------------------------------------

Ce composant change le nom Paladin d�chu en Paladin, Paladin de l'ombre ou Chevalier Noir (au choix du joueur).

NB : Un personnage doit commettre un acte mauvais pour devenir un Paladin d�chu (vol, meurtre, etc).


/-------------------------------------------------
--- COMPETENCES MARTIALES �LARGIES POUR LES MOINES ---
\-------------------------------------------------

Ce composant permet aux Moines d'utiliser les �p�es b�tardes, haches, fl�aux d'armes et masses. Les moines peuvent d�sormais placer jusqu'� 5 points de comp�tence sur les armes autoris�es. Les Moines d�marrent maintenant le jeu avec 4 points de comp�tence d'armes et gagnent des points suppl�mentaires tout les trois niveaux. Les moines peuvent maintenant placer jusqu'� 2 points de comp�tence dans le style Arme � 1 main. Les moines lancent d�sormais 1d10 au lieu d'1d8 pour le calcul de leurs points de vie.


/-------------------------------------------------
--- �QUILIBRAGE DU M�TAMORPHE R��QUILIBR� ---
\-------------------------------------------------

Il s'agit d'une version modifi�e de la version du r��quilibrage du M�tamorphe de Westley Weimer (pr�sent dans Ease of use et BG2 Tweaks). Ce composant s'appuie effront�ment sur du code vol� � BG2 Tweaks (disponible sur http://www.gibberlings3.net/).

Ajustements :

- Les deux objets de "patte" utilisent maintenant une ic�ne de patte de loup, au lieu d'une griffe d'ours.
- La patte de Loup-Garou ne conf�re plus Immunit� aux armes normales.
- La patte de Loup-Garou majeur a �t� d�plac�e du niveau 13 au niveau 15.
- La r�g�n�ration conf�r�e par la patte de Loup-Garou majeur a �t� r�duite de 3 PV par seconde � 1 PV par seconde.
- Les d�g�ts de la patte de Loup-Garou ont �t� r�duits de 1D12 � 1D10.
- Les d�g�ts de la patte de Loup-Garou majeur ont �t� r�duits de 2D8 � 2D6.
- Les r�sistances �l�mentaires conf�r�es par la patte de Loup-Garou majeur ont �t� r�duites de 50% � 25%.
- La d�sagr�able animation associ�e aux m�tamorphoses a �t� retir�e des deux pattes.
- La description du Kit du M�tamorphe a �t� mise � jour pour refl�ter les changements du composant (Ease of Use et BG2 Tweaks ne mettait pas � jour cette description).
- Un bug contenu dans le code vol� � G3 a �t� corrig� ; la description de Invocation d'animaux est maintenant appliqu�e au bon emplacement.

90% du m�rite revient � Westley Weimer, les cr�ateur du r��quilibrage original.
5% � G3, qui a l�g�rement modernis� le code.
5% � votre serviteur, qui a corrig� le bug du code G3 et proc�d� � quelques ajustements de jouabilit�.

Je doute que quiconque soit d�rang� par mon appropriation du code. Cependant, si quelqu'un souhaite me faire part d'une plainte, ou rapporter des bugs li�s � ce composant (les rapports de bugs concernant ce composant vont chez moi, pas chez Weimer ni G3), qu'il n'h�site pas � m'envoyer un e-mail � l'adresse suivante : awoundedlion@yahoo.com

Les M�tamorphes r��quilibr�s sont tr�s puissants  (m�me avec mes ajustements), mais (je l'esp�re) un peu mieux �quilibr�s.


/-------------------------------------------------
--- KIT DE GUERRIER ARCHER ARCANIQUE ---
\-------------------------------------------------

L'Archer Arcanique est un combattant capable d'utiliser la magie pour compl�ter ses comp�tences martiales. Ma�tre de l'arc et apprenti magicien, l'archer figure parmi les meilleurs fabricants de fl�ches. Ses yeux per�ants et sa vision am�lior�e font que l'Archer est difficilement tromp� par les illusions hostiles.

Avantages :
- Dext�rit� +1.
- Coup ajust� au niveau 4, 8 et 12.
- Sorts (une fois par jour) :

Niveau 1   Infravision
Niveau 2   Armure
Niveau 5   D�tection des illusions
Niveau 6   Protection contre les projectiles non-magiques
Niveau 9   Oracle
Niveau 10  Br�che
Niveau 13  Vision v�ritable
Niveau 14  Miroir physique

- Fabrication de fl�ches (une fois par jour) :

Niveau 1   10 fl�ches
Niveau 3   10 fl�ches de glace
Niveau 4   10 fl�ches de feu
Niveau 6   10 fl�ches +1
Niveau 7   10 fl�ches d'acide
Niveau 9    3 fl�ches de dissipation de la magie
Niveau 11  10 fl�ches +2
Niveau 13   3 fl�ches explosives
Niveau 15  10 fl�ches +3
Niveau 17   1 fl�che tueuse (Humano�de)

D�savantages :
- Ne peut pas porter d'armure sup�rieure � la besantine.
- Ne peut pas mettre plus d'un point dans les comp�tences d'arme de corps � corps.


/-------------------------------------------------
--- KIT DE GUERRIR HELLION ---
\-------------------------------------------------

L'Hellion est un f�roce guerrier qui honore le Sombre Prince des Enfers. Il respecte avant tout la force, le pouvoir et la ruse. L'Hellion �tudie les arts noirs et peut invoquer des d�mons qui l'aideront au combat (cependant, ces derniers peuvent se retourner contre lui s'il n'a pas utilis� de magie protectrice).

Avantages :
- Immunis� � la magie de la mort.
- Peut lancer Protection contre le mal, rayon de 3 m�tres une fois par jour et par niveau.
- Peut lancer Bannissement une fois par jour, tous les 4 niveaux, � partir du niveau 4.

Niveau 12  Peut lancer Sort de mort une fois par jour
Niveau 14  Peut lancer Cacofi�lon une fois par jour
Niveau 16  Peut lancer Convocation d'un Fi�lon une fois par jour
Niveau 18  Peut lancer Portail une fois par jour
Niveau 20  Peut lancer Convocation de Plan�taire d�chu une fois par jour

D�savantages :
- Ne peut pas �tre d'alignement bon.
- Ne peut pas se jumeler sauf pour devenir mage ou voleur.
- Ne peut pas placer plus de 3 points de comp�tence dans n'importe quel type d'arme comportant une lame.
- Ne peut pas placer plus de 1 point de comp�tence dans n'importe quel type d'arme ne comportant pas de lame.

Remarques :

Bannissement

Niveau : Sp�cial
Port�e : 50
Dur�e : instantan�e
Temps d'incantation : 1
Zone d'effet : un d�mon invoqu�
Jet de sauvegarde : aucun

Ce sort renvoie un d�mon convoqu� vers les Plans Inf�rieurs.


/-------------------------------------------------
--- S�LECTION NATURELLE : KIT DE DRUIDE SOMBRELIEN ---
\-------------------------------------------------

Le kit du Druide Sombrelien est totalement compatible avec Divine remix (peu importe l'ordre d'installation).

Les Sombreliens sont des druides ayant une connexion privil�gi�e avec des cr�atures que la plupart des gens consid�rent comme des monstres. Pour un Sombrelien une wiverne est tout aussi naturelle qu'un loup. Ces druides ont g�n�ralement mauvaise r�putation dans les cit�s, villes et villages et se sentent plus chez eux au fond des bois.

Certains Sombreliens s'efforcent de minimiser l'antagonisme entre certains monstres et la civilisation afin de promouvoir une coexistence pacifique. D'autres cherchent � pr�server l'�quilibre en contrecarrant les grandes chasses lanc�es � l'encontre des wivernes et autres araign�es. Certains Sombreliens agressifs aspirent � la destruction de la civilisation et de la soci�t�, et organisent des monstres afin de raser villes et villages.

Avantages :
- Les sorts suivants sont ajout�s au livre de sorts du Sombrelien :

Charme-monstres au niveau 5
Convocation d'araign�es au niveau 7
Appel de wivernes au niveau 9

D�savantages :
- Aucune capacit� de m�tamorphose.


/-------------------------------------------------
--- S�LECTION NATURELLE: MODIFICATIONS DE L'ALIGNEMENT DU DRUIDE ---
\-------------------------------------------------

Les Druides (et tous les kits de druides, en incluant ceux ajout�s par des mods) peuvent maintenant choisir les alignements Neutre Bon, Loyal Neutre, Neutre Strict, Chaotique Neutre ou Neutre Mauvais.


/-------------------------------------------------
--- S�LECTION NATURELLE : MODIFICATION DES COMPETENCES MARTIALES DU DRUIDE ---
\-------------------------------------------------

Les Druides (et tous les kits de druides, en incluant ceux ajout�s par des mods) peuvent attribuer un point de comp�tence dans les arcs courts et arcs longs, et jusqu'� deux points dans les armes � deux mains. Les Druides commencent le jeu avec un point de comp�tence dans le style Armes � deux mains.


/-------------------------------------------------
--- S�LECTION NATURELLE : LES DRUIDES OBTIENNENT LE BONUS DE SAGESSE "B�N�DICTION DE LA NATURE" AU NIVEAU 27 ---
\-------------------------------------------------

Les Druides (et tous les kits de druides, en incluant ceux ajout�s par des mods) obtiennent B�n�diction de la Nature (bonus de +2 en sagesse) au niveau 27


/-------------------------------------------------
--- S�LECTION NATURELLE : NOUVEAUX SORTS DE DRUIDE ---
\-------------------------------------------------

Les Druides (et tous les kits de druides, en incluant ceux ajout�s par des mods) obtiennent deux sorts de restauration qui font de cette classe une alternative viable au clerc. De plus, deux sorts de Charme am�lior�s viennent renforcer l'arsenal du Druide ('Charme-personne ou mammif�re' est faiblard).


/-------------------------------------------------
--- LES CLERCS ET LES DRUIDES OBTIENNENT LE SORT BR�CHE ---
\-------------------------------------------------

Ce composant ajoute Br�che au livre de sort des Clercs et Druides purs, et aux kits de Clercs et Druides.


/-------------------------------------------------
--- LES DRUIDES ET R�DEURS OBTIENNENT LA CAPACIT� FAMILIER ---
\-------------------------------------------------

Ce composant ajoute la capacit� Familier aux classes de Druide et R�deur pures, et aux kits de Druides et R�deurs.


/-------------------------------------------------
--- MODIFICATION DES GARDES AMNIENS ---
\-------------------------------------------------

Dans le cadre d'une installation par d�faut, des Gardes Amniens (d�clench�s par des pi�ges de proximit� dans les Docks, les Bas-fonds, le District du Pont et la Promenade de Waukyne) tentent d'ex�cuter le groupe du joueur lorsque sa r�putation atteint 3. Le groupe du joueur n'a pas d'autre choix que de combattre.

Avec ce composant, les Gardes Amniens (d�clench�s par les m�mes pi�ges) retiennent le groupe du joueur lorsque sa r�putation atteint 4. Le groupe peut alors corrompre ou combattre les gardes, ou encore payer une caution. Le pot-de-vin �vite au groupe d'�tre � nouveau harcel� pendant un jour, tandis que la caution restaure la r�putation du groupe � 5.


REPUTATION         CAUTION           CHARISME & CO�T DE CORRUPTION
    4          250 Pi�ces d'or         16 CHR +  25 Pi�ces d'or
    3          500 Pi�ces d'or         17 CHR +  50 Pi�ces d'or
    2          750 Pi�ces d'or         18 CHR +  75 Pi�ces d'or
    1         1000 Pi�ces d'or         19 CHR + 100 Pi�ces d'or


/-------------------------------------------------
--- (BETA) AU PLUS OFFRANT : KALAH ---
\-------------------------------------------------

La Tour fortifi�e de Kalah pour les personnages mauvais + la Qu�te de la Place-forte du Gardien de la Tour
