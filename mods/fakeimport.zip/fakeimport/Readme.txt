Author: Almateria (Call Now)
Contact: sylwiabukato@gmail.com

Fake Import Mod

This mod simulates importing a character from BG1.
1. Illyich gets the chainmail +3 instead of his regular one.
2. The PC gets the additional XP.
3. The golden pantaloons and the tomes of stat bonuses are behind the portrait.
4. You can choose if you killed Drizzt because there's this one person who didn't and he's very cross right now
Have fun!