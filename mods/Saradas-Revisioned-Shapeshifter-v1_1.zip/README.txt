***************************************************
        Saradas Revisioned Shapeshifter
***************************************************
WHAT'S THIS MOD?

This mod is a slight rebalancing of the shapeshifter's skills. I've always thought this wonderful kit didn't express its full potential, due to some bugs and
a limited design.
What bugged me the most was the lack of progression. First of all, the Shapeshifter's level was almost pointless to determining the strength of the Werewolf forms...
And some features were never implemented (immunity to normal weapons, regeneration....)
So, beside adding some new features, I slightly improved the two forms in order to keep them useful and competitive in the late parts of SoA and ToB without resulting overpowered.

This mod improves the synergy between class level and shapeshifting power. When the druid reaches a certain level, his werewolf form becomes stronger.
Let's see how in the tables below:


WEREWOLF FORM:
------------------

LV 1                 LV 13                 LV 15                 LV 20

Claw +2 1d8          Claw +2 1d8+1         Claw +3 1d8+2         Claw +3 1d8+3 / Poison on hit
STR +2               STR +2                STR +2                STR +3
DEX +2               DEX +2                DEX +2                DEX +3
CON +2               CON +2                CON +2                CON +3
APR +1               APR +1                APR +2                APR +2
HP +10               HP +20                HP +30                HP +30
M RES: +20           M RES: +30            M RES: +40            M RES: 40
BASE AC: 3           BASE AC: 2            BASE AC: 1            BASE AC:0
Thac0: +1            Thac0: +2             Thac0: +3             Thac0: +3
Hasted               ELEM RES: +10         ELEM RES: +20         ELEM RES: +30
                     PHYS RES: +10         PHYS RES: +20         PHYS RES: +25
                     REG: 3HP/round        REG: 3HP/round        REG: 3HP/round
                     Hasted                IMM POISON & DIS      IMM POISON & DIS
                                           IMM NORM WEAPON       IMM NORM WEAPON
                                           Hasted                Hasted


GREATER WEREWOLF FORM:
---------------------------

LV 13                           LV 17                                   LV 20

Claw +3 2d6/ Poison on hit      Claw +4 2d6+1 / Poison on hit           Claw +5 2d6+2 / Poison on hit + Knock Back
STR +3                          STR +4                                  STR +4
DEX +3                          DEX +4                                  DEX +4
CON +4                          CON +5                                  CON +5
APR +2                          APR +2                                  APR +2
HP +30                          HP +40                                  HP +50
M RES: +40                      M RES: +50                              M RES: +50
BASE AC: 0                      BASE AC: -1                             BASE AC: -1
Thac0: +4                       Thac0: +5                               Thac0: +6
ELEM RES: +50                   ELEM RES: +50                           ELEM RES: +50
PHYS RES: +33                   PHYS RES: +35                           PHYS RES: +35
IMM POISON & DIS                IMM POISON & DIS                        IMM POISON & DIS
IMM NORM WEAPON                 IMM NORM WEAPON                         IMM NORM WEAPON
REG: 6HP/round                  REG: 6HP/round                          REG: 6HP/round
Hasted                          Hasted                                  Hasted




HOW TO INSTALL:
--------------------------

Take the folder "Saradas_Revisioned_Shapeshifter" and "Setup-Saradas_Revisioned_Shapeshifter.exe" from the zip file, and put them inside "C:\BG2EE\Data\00783".
Now go to "C:\BG2EE\Data\00783" and execute the exe file we just moved.
Follow the instructions and enjoy.

HOW TO UNINSTALL:
--------------------------

Simply execute "Setup-Saradas_Revisioned_Shapeshifter.exe" and follow the instructions.



NOTES:
--------------------------

The mod will only (obviously) conflict with other similar mods. You can install/uninstall it no matter the progression of your gameplay.




CHANGELOG:
--------------------------
V_1.1:

Rebalanced some values in Werewolf form and Greater Werewolf form:
- In Werewolf form now the druid regenerates 3HP/round (1HP/2s) starting from level 13. It was 1HP/s before.
- Greater Werewolf form now has 0 base AC at level 13, -1 at level 17 and 20. (Before was -6, ending up at -16 AC...my mistake. Now it's much more reasonable.)
- Greater Werewolf form now has +4 thac0 bonus at level 13, before it was +3.
- In Greater Werewolf form now the druid regenerates 6HP/round (1HP/s). Before it was 2HP/s and considering the GWW's high resistances and low AC, the results were overpowered.
- The "Regenerating" status icon now correctly appears during Werewolf form, starting from level 13.

