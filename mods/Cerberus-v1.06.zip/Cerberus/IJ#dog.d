BEGIN IJ#dog

IF ~AreaCheck("ar0602") Global("IJ#dogEx","ar0602",1)~ THEN BEGIN Talk1
SAY @1
IF ~~ THEN REPLY @2 DO ~SetGlobal("IJ#dog","GLOBAL",1) SetGlobal("IJ#cer1","GLOBAL",1)~ EXIT
IF ~~ THEN REPLY @3 DO ~SetGlobal("IJ#dog","GLOBAL",2)~ EXIT
END

IF ~AreaCheck("ar1513") Global("IJ#dogEx","ar1513",1)~ THEN BEGIN Talk2
SAY @1
IF ~~ THEN REPLY @4 DO ~SetGlobal("IJ#dog","GLOBAL",1) SetGlobal("IJ#cer2","GLOBAL",1)~ EXIT
IF ~~ THEN REPLY @5 DO ~SetGlobal("IJ#dog","GLOBAL",2)~ EXIT
END

IF ~AreaCheck("ar2900") Global("IJ#dogEx","ar2900",1)~ THEN BEGIN Talk3
SAY @1
IF ~~ THEN REPLY @6 DO ~SetGlobal("IJ#dog","GLOBAL",1) SetGlobal("IJ#cer3","GLOBAL",1)~ EXIT
IF ~~ THEN REPLY @7 DO ~SetGlobal("IJ#dog","GLOBAL",2)~ EXIT
END

IF ~Global("IJ#dog2","GLOBAL",1)~ THEN BEGIN Talk4
SAY @8
IF ~~ THEN DO ~SetGlobal("IJ#dog","GLOBAL",2) SetGlobal("IJ#dog2","GLOBAL",2)~ EXIT
END
