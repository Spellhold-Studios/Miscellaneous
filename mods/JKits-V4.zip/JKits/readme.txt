JKits
V4
Creator: Joshua Rutherford
Language: English
Contact: joshuar9476@gmail.com

--------------------------------------------------------
Kenshei

Overview:
The kenshei are considered to be held at a high standard of perfection with their weapon. And even though they tend to travel alone and keep to themselves, the kenshei name is an honorary title given to warriors of legendary skill in swordsmanship.

Advantages:
: Grand Mastery in single and two weapon styles
: +2 to maximum dexterity
: Immunity to backstabbing
: +1 bonus to hit and damage at level 1 and then every 5 levels up to level 20
: -2 to Armor Class at level 1 and then -1 every 5th level up to level 20
: -1 to weapon speed at level 1 and then -1 every 5th level up to level 20
: +10% slashing and piercing resistance at level 1 and an additional +10% at level 15
: Gains Disarm ability at levels 6, 12 and 18. Has a 50% chance to make opponent drop their weapon.
: Gains Precision Strike ability at levels 7, 14 and 21. Grants a +3 THAC0 bonus for three rounds, does 1d10 damage to target, and has a 25% chance to stun target.

Disadvantages:
: May not wear helmets, armor, or gauntlets
: May only place points in single handed swords, single weapon style and two weapon style
: Requires: 15 dexterity
: -2 to maxium charisma

--------------------------------------------------------
UNdead Eliminator

Overview:
The Eliminator of the Undead spend their life seeking out and destroying mummies, vampires, ghouls, and any other undead.

Advantages:
: +3 to hit and damage vs. undead creatures
: Immunity to hold
: Immunity to level drain, Vampire Fear, and Domination at level 5
: Can cast the Priest spell "False Dawn" at level 10, 15 and 20

Disadvantages:
: Must be good aligned
: May only place points in piercing and crushing weapons
: May not place points in missle weapons
: Can not wear full plate or plate mail armor
: May only dual to a Cleric


Thanks
The fine fellas and gals over at SHS and G3 for answering my constant questions
Drizzt1180 for creating the Blade Master kit for which parts of i used in this mod
The Revised Battles Bastard kit for the immunity to backstab spl
The creators of The Darkest Day for the Vindicator kit which i used the energy and level drain parts of
Wes Weimer for WeiDU
Jon Olav Hauglid for Near Infinity

Copyright
This mod is copyright 2011 by Joshua Rutherford. I am not employed or affiliated with Bioware in any way.

History
V1
Initial creation

V2
Extensive modification to the Undead Eliminator kit

V3
I forgot what I did for V3. It was a long time ago

V4
Made the mod work with BGEE 1.3 and beyond. 