
                           ----------------
                            Retaliator Kit
                                v 1.3
                           ----------------

Bonus Fighter Kit for Baldur's Gate II: Throne of Bhaal.



Install:
--------

Extract all files to the folder BGII is installed to.
Run Setup-RetaliatorKit.exe and follow the prompt.



Description:
------------

Judge and executioner in one being, the retaliator has committed
himself to the cause of those who are no longer in the position to
carry out justice for themselves. The core tenet of retaliation is
that the end always justifies the means.

Advantages:
-  Bonus +2 to damage
-  Bonus -4 to speed factor
-  Immune to fear and morale failure
-  When camouflaged, the Retaliator can  backstab foes for double
   damage, and triple damage from 10th level onwards
-  Smoke Bomb once each turn (twice from 8th level, three times from
   15th level): blinds nearby creatures and provides brief camouflage
-  Fire Breath once a day for every 6 levels (every 10 levels from
   18th level onward): spit flaming oil at foes to cause them fire
   damage and set them on fire for a short period of time

Disadvantages:
-  May not wear armor greater than studded leather
-  May not achieve mastery with ranged weapons



Version history:
----------------

v 1.0: Initial release
v 1.1: Tweaked the ability distribution among levels
       Added more Fire Breath uses at higher levels
v 1.2: Increased initial damage output on the Fire Breath ability
       Now Fire Breath pauses the caster for less time
       Fire Breath is no longer affected by magic resistance
       Made minor changes to the Fire Breath projectile
v 1.3: Added text which notifies the player of Smoke Bomb's recharge



Credits:
--------

by Adul (adul@adul.net)

Special thanks to Jarno Mikkola at SHS forums for suggestions.



Thanks for downloading!
