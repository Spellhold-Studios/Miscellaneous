BEGIN ~L-SINK~

IF ~Global("L-ImNotACheater","GLOBAL",0)~ THEN BEGIN 0
SAY ~You've went through some incredibly harsh stuff recently, and yet, somehow, you don't seem to remember anything from your brief stay in Hell. Queen Ellesime gave you this artifact of enormous power, capable of refreshing even the cloudiest minds.~
++ ~Time to come clean about your past.~ + 0-1
++ ~No need to hurry, Hell probably wan't a nice place.~ + 0-2
END

IF ~~ THEN BEGIN 0-1
SAY ~You begin to wash your hands, and suddenly memories come back to you. Despite being in Abyss, you've remained a paragon of society. Or maybe you took it as an excuse to let your darker side go hog wild? You don't know yet. You probably can begin to guess, though.~
=
~The trial of pride. You were tasked to kill a creature for the sin of existing, and for you, the only sensible choice was to...~
++ ~Kill it, of course. There's only so much times you can handle other things being alive.~ DO ~SetGlobal("L-PrideEvil","GLOBAL",1)~ + pridedone
++ ~Bug a demon with relentless questions about the nature of being. Sure seemed sensible at the time.~ DO ~SetGlobal("L-PrideGood","GLOBAL",1)~ + pridedone
END

IF ~~ THEN BEGIN pridedone
SAY ~Definitely. Now, the trial of fear. The demon offered you a snazzy cloak made from freshly flayed nymph skin. You...~
++ ~Decided that you can't ever have too many flayed skin clothing. It's pretty big in Tethyr this year.~ DO ~SetGlobal("L-FearEvil","GLOBAL",1)~ + feardone
++ ~Thought that it would the freakiest thing you've ever seen, if not for Rejiek, and refused.~ DO ~SetGlobal("L-FearGood","GLOBAL",1)~ + feardone
END

IF ~~ THEN BEGIN feardone
SAY ~All in all, a good decision that benefited you. Next, Selfish the selfish demon summoned some poor shmuck and threatened to kill him, if you didn't sacrifice some of your well-being. The choice was obvious.~
++ ~You left him for dead. He can bootstrap his way to the top if he works hard enough as a Lemure.~ DO ~SetGlobal("L-SelfishnessEvil","GLOBAL",1)~ + selfdone
++ ~You sacrificed some of your dexterity to save them. Now you can't do anything about that itchy spot.~ DO ~SetGlobal("L-SelfishnessGood","GLOBAL",1)~ + selfdone
END

IF ~~ THEN BEGIN selfdone
SAY ~They will gossip about that for centuries, debating if it was the moral thing to do. After that, Greed dumped a cool black sword on you and asked to kill a dude. Who was an eternally burning genie, and you knew what they do to Genies in those parts.~ 
++ ~They kill them. What's a little mercy killing between evil friends?~ DO ~SetGlobal("L-GreedEvil","GLOBAL",1)~ + greedone
++ ~They set them free by giving them a Blackrazor. Easy come, easy go.~ DO ~SetGlobal("L-GreedGood","GLOBAL",1)~ + greedone
END

IF ~~ THEN BEGIN greedone
SAY ~Now, the final test was to endure 10 seconds in the same room with the ghost of one of your countless brothers, Sarevok. In this time, you managed to...~
++ ~Whoop his ass and kill him again. He was dead already, though, so you probably dispersed his soul for a while. Or destroyed it. Whatever the mechanics are, it's not likely that he'll appear ever again, right?~ DO ~SetGlobal("L-WrathEvil","GLOBAL",1)~ + wratdone
++ ~You pitied the fool. He's dead and a jerk! You are alive and compassionate!~ DO ~SetGlobal("L-WrathGood","GLOBAL",1)~ + wratdone
END

IF ~~ THEN BEGIN wratdone
SAY ~That was it. Then you murdered Irenicus, but that you can remember pretty well. The sink has proven useful. You look down at your body, and see that it's not the way you remember. Maybe you just held onto memories of being normal hard enough to disregard the truth.~
IF ~Global("L-PrideGood","GLOBAL",1)~ + prideresultgood
IF ~Global("L-PrideEvil","GLOBAL",1)~ + prideresultevil
END

IF ~~ THEN BEGIN prideresultgood
SAY ~The rain doesn't feel so cold anymore. Neither do the other elements. You have obtained 20% resistance to Fire, Ice and Electricity.~
IF ~Global("L-FearGood","GLOBAL",1)~ DO ~ApplySpell(Player1,HELL_PRIDE_GOOD)~ + fearresultgood
IF ~Global("L-FearEvil","GLOBAL",1)~ DO ~ApplySpell(Player1,HELL_PRIDE_GOOD)~ + fearresultevil
END

IF ~~ THEN BEGIN prideresultevil
SAY ~You suddenly feel more experienced. That's it. And now, probably a bit cheated.~
IF ~Global("L-FearGood","GLOBAL",1)~ DO ~ApplySpell(Player1,HELL_PRIDE_EVIL)~ + fearresultgood
IF ~Global("L-FearEvil","GLOBAL",1)~ DO ~ApplySpell(Player1,HELL_PRIDE_EVIL)~ + fearresultevil
END

IF ~~ THEN BEGIN fearresultgood
SAY ~Neither normal, nor slightly enchanted weapons can't hurt you anymore. You've gained immunity to weapons worse than +2.~
IF ~Global("L-SelfishnessGood","GLOBAL",1)~ DO ~ApplySpell(Player1,HELL_FEAR_GOOD)~ + selfresultgood
IF ~Global("L-SelfishnessEvil","GLOBAL",1)~ DO ~ApplySpell(Player1,HELL_FEAR_GOOD)~ + selfresultevil
END

IF ~~ THEN BEGIN fearresultevil
SAY ~You feel way more physically able than before. You could probably make a hundred loops around this forest without breaking a sweat. You've gained 2 points of Constitution.~
IF ~Global("L-SelfishnessGood","GLOBAL",1)~ DO ~ApplySpell(Player1,HELL_FEAR_EVIL)~ + selfresultgood
IF ~Global("L-SelfishnessEvil","GLOBAL",1)~ DO ~ApplySpell(Player1,HELL_FEAR_EVIL)~ + selfresultevil
END

IF ~~ THEN BEGIN selfresultgood
SAY ~Sure, you lost the point of dexterity, but you feel a bit more magic resistant. 10% more, to be exact.~
IF ~Global("L-GreedGood","GLOBAL",1)~ DO ~ApplySpell(Player1,HELL_LOSE_DEX)
Wait(1)
ApplySpell(Player1,HELL_SELFISH_GOOD)~ + greedresultgood
IF ~Global("L-GreedEvil","GLOBAL",1)~ DO ~ApplySpell(Player1,HELL_LOSE_DEX)
Wait(1)
ApplySpell(Player1,HELL_SELFISH_GOOD)~ + greedresultevil
END

IF ~~ THEN BEGIN selfresultevil
SAY ~The enemies can't, in fact, "touch this" anymore. You've gained two points of armor class.~
IF ~Global("L-GreedGood","GLOBAL",1)~ DO ~ApplySpell(Player1,HELL_SELFISH_EVIL)~ + greedresultgood
IF ~Global("L-GreedEvil","GLOBAL",1)~ DO ~ApplySpell(Player1,HELL_SELFISH_EVIL)~ + greedresultevil
END

IF ~~ THEN BEGIN greedresultgood
SAY ~You traded a sword for +2 to all your saving throws. It was well worth it.~
IF ~Global("L-WrathGood","GLOBAL",1)~ DO ~ApplySpell(Player1,HELL_GREED_GOOD)~ + wrathresultgood
IF ~Global("L-WrathEvil","GLOBAL",1)~ DO ~ApplySpell(Player1,HELL_GREED_GOOD)~ + wrathresultevil
END

IF ~~ THEN BEGIN greedresultevil
SAY ~You can withstand that one final hit that would kill you before. You've gained 15 Hit Points.~
IF ~Global("L-WrathGood","GLOBAL",1)~ DO ~ApplySpell(Player1,HELL_GREED_EVIL)~ + wrathresultgood
IF ~Global("L-WrathEvil","GLOBAL",1)~ DO ~ApplySpell(Player1,HELL_GREED_EVIL)~ + wrathresultevil
END

IF ~~ THEN BEGIN wrathresultgood
SAY ~Talking down your brother's ghost not only entitles you to be more smug, but now other people believe the smugness is well-deserved. You've gained 1 point of Wisdom and Charisma each.~
IF ~~ DO ~ApplySpell(Player1,HELL_WRATH_GOOD)~ + ending
END

IF ~~ THEN BEGIN wrathresultevil
SAY ~Killing an incredibly buff ghost warrior made you stronger. It's like the Bhaal essence transfer, except with muscle. You've gained 2 points of Strength.~
IF ~~ DO ~ApplySpell(Player1,HELL_WRATH_EVIL)~ + ending
END

IF ~~ THEN BEGIN ending
SAY ~Startled by the changes, you drop the utensil. It quickly sinks into the ground, leaving no trace of it ever existing. Perhaps for the better.~ IF ~~ THEN DO ~SetGlobal("L-ImNotACheater","GLOBAL",1)
TakePartyItem("L-SINK")
Wait(3)
DestroySelf()~ EXIT
END

IF ~~ THEN BEGIN 0-2
SAY ~You put the sink back in your pack, free of horrible imagery for some more time.~ IF ~~ THEN DO ~Wait(3)
DestroySelf()~ EXIT
END

IF ~Global("L-ImNotACheater","GLOBAL",1)~ THEN BEGIN shameful
SAY ~You aren't a nice person, and therefore can't touch the water coming out of the spigot, much like Dumbledore couldn't touch the water containing Voldemort's locket.~ IF ~~ THEN DO ~SetGlobal("L-ImNotACheater","GLOBAL",1)
TakePartyItem("L-SINK")
Wait(3)
DestroySelf()~ EXIT
END