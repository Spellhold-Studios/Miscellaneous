command_path=${0%/*}
cd "$command_path"
./setup-hellrec
