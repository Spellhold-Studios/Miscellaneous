# Bigger fonts for Baldur's Gate 2

Luc J. Bourhis
June 29, 2014

Delfosse made nicer and bigger fonts, coming in three different sizes for Baldur's Gate (see the [announcement](http://www.shsforums.net/topic/56710-bigger-fonts-for-baldurs-gate/) for screenshots, including comparison to other bigger font modes, and a download link). This mod is just a Weidu wrapper for those fonts. Thus all the credits go to Delfosse for his original work, as well as to Ghostdog for the CHU hack that prevents the new font to be used for the GUI (Inventory, Character Record, etc) as it is too big and causes a lot of glitches. That CHU hack is borrowed from Ghostdog's own bigger font mod, that is also link from Delfosse announcement.

For screen width of 1024 pixels, size 16px look the best but your mileage may vary.
