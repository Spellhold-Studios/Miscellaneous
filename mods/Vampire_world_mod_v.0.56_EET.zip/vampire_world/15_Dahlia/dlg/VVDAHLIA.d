BEGIN VVDAHLIA





IF ~Global("DahliaAttack1","LOCALS",1)~ THEN BEGIN  vampAttackD
  SAY ~(You sleep in your coffin. And suddenly a terrible cramp jerks your body. You open your eyes in disarray. Your vision clears up... and you see Dahlia over yourself.)~
  =
  ~(In her hand she holds a silver dagger. And from it drops a black blood. Your blood!)~
  =
  ~I tried to make it while you slept, <CHARNAME>. I am sorry, but there will be more pain and suffering.~
  IF ~~ THEN REPLY ~Stop Dahlia, stop, please, stop!~ GOTO dampAttack1
  IF ~~ THEN REPLY ~You have betrayed me!~ GOTO dampAttack2
  IF ~Gender(Player1,MALE)~ THEN REPLY ~Damned bitch! I curse you!~ GOTO dampAttack3M
  IF ~!Gender(Player1,MALE)~ THEN REPLY ~Damned bitch! I curse you!~ GOTO dampAttack3F
END

IF ~~ dampAttack1
  SAY ~I no longer can stop, <CHARNAME>. I made a move, and now I will kill you. Or it will do you with me.~ 
  IF ~~ THEN REPLY ~I throught you was my bodyguard!~ GOTO dampAttack11
  IF ~~ THEN REPLY ~What I did to deserve this?~ GOTO dampAttack12
  IF ~!Gender(Player1,MALE)~ THEN REPLY ~I liked you, Dahlia.~ DO ~IncrementGlobal("Player1Likeness","LOCALS",1)~ GOTO dampAttack13F
  IF ~Gender(Player1,MALE)~ THEN REPLY ~I liked you, Dahlia.~ DO ~IncrementGlobal("Player1Likeness","LOCALS",1)~ GOTO dampAttack13M
  IF ~Gender(Player1,MALE)~ THEN REPLY ~Damned bitch! I curse you!~ GOTO dampAttack3M
  IF ~!Gender(Player1,MALE)~ THEN REPLY ~Damned bitch! I curse you!~ GOTO dampAttack3F  
END

IF ~~ dampAttack2
  SAY ~Sorry, but that was inevitable.~ 
  IF ~~ THEN REPLY ~I throught you was my bodyguard!~ GOTO dampAttack11
  IF ~~ THEN REPLY ~What I did to deserve this?~ GOTO dampAttack12
  IF ~!Gender(Player1,MALE)~ THEN REPLY ~I liked you, Dahlia.~ DO ~IncrementGlobal("Player1Likeness","LOCALS",1)~ GOTO dampAttack13F
  IF ~Gender(Player1,MALE)~ THEN REPLY ~I liked you, Dahlia.~ DO ~IncrementGlobal("Player1Likeness","LOCALS",1)~ GOTO dampAttack13M
    IF ~Gender(Player1,MALE)~ THEN REPLY ~Damned bitch! I curse you!~ GOTO dampAttack3M
  IF ~!Gender(Player1,MALE)~ THEN REPLY ~Damned bitch! I curse you!~ GOTO dampAttack3F
END

IF ~~ dampAttack13F
  SAY ~It's not a feeling for me. You just wanted to have my body and me to please your desires.~
  IF ~~ THEN REPLY ~Maybe you are right. But I am not only a vampire, but also a girl and I feel attraction for your body. From the first time I saw you naked.~ DO ~IncrementGlobal("Player1Likeness","GLOBAL",1)~ GOTO dampAttack14FM
  IF ~~ THEN REPLY ~From the first time I heard your voice and saw you, I fell in love for you.~ DO ~IncrementGlobal("Player1Likeness","GLOBAL",1)~ GOTO dampAttack15FM
  IF ~~ THEN REPLY ~I wanted a wild intercourses with you, and that's all. But you betrayed me and now I will have no mercy on you.~  GOTO dampAttack16FM
  IF ~!Gender(Player1,MALE)~ THEN REPLY ~Damned bitch! I curse you!~ GOTO dampAttack3F
END

IF ~~ dampAttack13M
  SAY ~You are beeing guided by that thing in your pants. I know you think only to discontinue my virginity and please your primitive instincts.~
  IF ~~ THEN REPLY ~Maybe you are right. From the first time I saw you naked I want to own you.~ DO ~IncrementGlobal("Player1Likeness","LOCALS",1)~ GOTO dampAttack14FM
  IF ~~ THEN REPLY ~From the first time I heard your voice and saw you, I fell in love for you.~ DO ~IncrementGlobal("Player1Likeness","LOCALS",1)~ GOTO dampAttack15FM
  IF ~~ THEN REPLY ~I wanted a wild intercourses with you, and that's all. But you betrayed me and now I will have no mercy on you.~ GOTO dampAttack16FM
  IF ~!Gender(Player1,MALE)~ THEN REPLY ~Damned bitch! I curse you!~ GOTO dampAttack3F
END

IF ~~ dampAttack14FM
  SAY ~I am all wet from lust.~ 
  =
  ~No, haha!~
  IF ~~ THEN GOTO dampAttack15FM
END

IF ~~ dampAttack15FM
  SAY ~Love from the first sight? I don't believe in pulp fiction books.~
  ~There is no way I will stop now, <CHARNAME>. I know you just try to talk my teeth and wait for ooportunity to strike on me.~
  IF ~~ THEN REPLY ~Dahlia, you say terrible things. But why you are doing this to me?~ GOTO dampAttack12
  IF ~!Gender(Player1,MALE)~ THEN REPLY ~Damned bitch! I curse you!~ GOTO dampAttack3F
END


IF ~~ dampAttack12
  SAY ~Naive, it has nothing to do with you personally.~ 
  IF ~~ DO ~~ GOTO dampAttack11
END

IF ~~ dampAttack11
  SAY ~It was my plan all alone. I visited library at Candlekeep and read a rare manuscript about my kind.~
  =
  ~It was said, that if damphire eats a heart of the vampire, which contains a significant part of a soul, damphire can become a sterling vampire.~
  =
  ~I bet you now see why I asked to become your bodyguard and wanted to guard your coffin while you sleep.~
  =
  ~Most of vampires are said to be paranoid. You are a pure example of fledgling one. You yet can trust others blindly because of yours infantility.~
  =
  ~You must be proud - you will not die completely, your part will become a part of me and will live futher.~
  IF ~~ THEN REPLY ~Calm down, Dahlia. You need a heart of vampire - will we get one. I swear to you. Just put down your dagger.~ GOTO dampAttack111
      IF ~Gender(Player1,MALE)~ THEN REPLY ~Haha, you will not become immortal. You will become ugly old hag and then you will die and goto worms.~ GOTO dampAttack3M
  IF ~!Gender(Player1,MALE)~ THEN REPLY ~Haha, you will not become immortal. You will become ugly old hag and then you will die and goto worms.~ GOTO dampAttack3F  
    IF ~Gender(Player1,MALE)~ THEN REPLY ~Damned bitch! I curse you!~ GOTO dampAttack3M
  IF ~!Gender(Player1,MALE)~ THEN REPLY ~Damned bitch! I curse you!~ GOTO dampAttack3F  
  END

IF ~~ dampAttack16FM
  SAY ~I think you forgot who is holding who.~
  ~(Dahlia makes a move and your body again is paralyzed with unimaginable pain.)~
  =
  ~(She hits you with a silver knife several times.)~
  =
  ~(All your senses go away and only darkness surrounds you.)~
  IF ~~ THEN DO ~Kill(Player1)~ EXIT
END

IF ~~ dampAttack3M
  SAY ~Wrong answer, moron.~
  ~(Dahlia makes a move and your body again is paralyzed with unimaginable pain.)~
  =
  ~(She hits you with a silver knife several times.)~
  =
  ~(All your senses go away and only darkness surrounds you.)~
  IF ~~ THEN DO ~Kill(Player1)~ EXIT
END

IF ~~ dampAttack3F
  SAY ~Wrong answer, bitch.~
  ~(Dahlia makes a move and your body again is paralyzed with unimaginable pain.)~
  =
  ~(She hits you with a silver knife several times.)~
  =
  ~(All your senses go away and only darkness surrounds you.)~
  IF ~~ THEN DO ~Kill(Player1)~ EXIT
END

IF ~~ dampAttack111
  SAY ~A word of a vampire? What nonsense!~
  IF ~~ THEN REPLY ~Dahlia, we have common goals. I want to help you preserve your body, because I want you youthful and beautiful.~ DO ~IncrementGlobal("Player1Likeness","LOCALS",1)~ GOTO dampAttack1112
  IF ~~ THEN REPLY ~Dahlia, this time I am absolutely serious. I will help you preserve your body, if you will serve me from now on.~ GOTO dampAttack1113
  IF ~~ THEN REPLY ~Dahlia, I will help you preserve your body.~ DO ~IncrementGlobal("Player1Likeness","LOCALS",1)~ GOTO dampAttack1112
    IF ~Gender(Player1,MALE)~ THEN REPLY ~Damned bitch! I curse you!~ GOTO dampAttack3M
  IF ~!Gender(Player1,MALE)~ THEN REPLY ~Damned bitch! I curse you!~ GOTO dampAttack3F 
END


IF ~~ dampAttack1112
  SAY ~Really?~
  =
  ~(Dahlia leans close to you, looking in your eyes.)~
  =
  ~(You feel your right hand is freed from weigth of her body.)~
  IF ~~ THEN REPLY ~(Quickly strike by your free hand claws to the side of her abdomen.)~ GOTO dampAttack11121
  IF ~~ THEN REPLY ~(Grab her by her throat.)~ GOTO dampAttack11122
  IF ~~ THEN REPLY ~(Confidently take her by the shoulder.)~ DO ~IncrementGlobal("Player1Likeness","LOCALS",1)~ GOTO dampAttack11123
  IF ~~ THEN REPLY ~(Gently pat her cheek.)~ DO ~IncrementGlobal("Player1Likeness","LOCALS",1)~ GOTO dampAttack11123
  IF  ~Gender(Player1,MALE)~ THEN REPLY ~Damned bitch! I hate you!~ GOTO dampAttack3M
  IF ~!Gender(Player1,MALE)~ THEN REPLY ~Damned bitch! I hate you!~ GOTO dampAttack3F 
END

IF ~~ dampAttack11121
  SAY ~(Dahlia shrieks. From her wound blood begins to flow out, her entrails start to fall out.)~
  =
  ~(Dahlia makes a move and your body again is paralyzed with unimaginable pain.)~
  =
  ~(She hits you with a silver knife several times.)~
  =
  ~(All your senses go away and only darkness surrounds you. You both die.)~
  IF ~~ THEN DO ~Kill(Player1)
Kill(Myself)~ EXIT
END

IF ~~ dampAttack11122
 SAY ~(Dahlia evades and your body again is paralyzed with unimaginable pain.)~
  =
  ~(She cuts off your palm and hits you with a silver knife several times.)~
  =
  ~(All your senses go away and only darkness surrounds you.)~
  IF ~~ THEN DO ~Kill(Player1)~ EXIT
END


IF ~~ dampAttack1113
  SAY ~Serve you? I am not a maid or a slave, and I will not serve you, turkey.~
  =
  ~It's time to end your life and start mine.~
  IF ~~ DO ~Kill(Player1)~ EXIT
END

IF ~~ dampAttack11123
  SAY ~You are free? I am done!~
  IF ~GlobalGT("Player1Likeness","LOCALS",1)~ THEN REPLY ~Dahlia, put down your dagger and listen. I will help you to gain immortality. I gained it for myself, and I will manage to gain it for you. Just wait. We are in a middle of a long jorney. I am sure we will visit many places and meet more vampires, and even those who deserve to be killed.~ GOTO finalChoice1
  IF ~GlobalLT("Player1Likeness","LOCALS",1)~ THEN REPLY ~Dahlia, put down your dagger and listen. I will help you to gain immortality. I gained it for myself, and I will manage to gain it for you. Just wait. We are in a middle of a long jorney. I am sure we will visit many places and meet more vampires, and even those who deserve to be killed.~ GOTO finalChoice4
  IF ~GlobalGT("Player1Likeness","LOCALS",2)~ THEN REPLY ~I like you, Dahlia and I want to be with you. I will help you to gain immortality. But you don't need to betray me for this. We will find you another vampire.~ GOTO finalChoice2
    IF ~Global("Player1Likeness","LOCALS",2)
	~ THEN REPLY ~I like you, Dahlia and I want to be with you. I will help you to gain immortality. But you don't need to betray me for this. We will find you another vampire.~ GOTO finalChoice3
    IF ~Global("Player1Likeness","LOCALS",1)
	~ THEN REPLY ~I like you, Dahlia and I want to be with you. I will help you to gain immortality. But you don't need to betray me for this. We will find you another vampire.~ GOTO finalChoice4
END

IF ~~ finalChoice1
  SAY ~(Dahlia drops her dagger, stands up and leaves your coffin and you alive.)~
  IF ~~ THEN DO ~SetGlobal("DahliaRomance","GLOBAL",1)
  SetGlobal("DahliaAttack1","LOCALS",2)~ EXIT
END

IF ~~ finalChoice2
  SAY ~(Dahlia smiles to you with tears, drops her dagger, stands up and leaves your coffin and you alive.)~
  IF ~~ THEN DO ~SetGlobal("DahliaRomance","GLOBAL",2)
  SetGlobal("DahliaAttack1","LOCALS",2)~ EXIT
END


IF ~~ finalChoice3
  SAY ~(Dahlia drops her dagger, stands up and leaves your coffin and you alive.)~
  IF ~~ THEN DO ~SetGlobal("DahliaRomance","GLOBAL",1)
  SetGlobal("DahliaAttack1","LOCALS",2)~ EXIT
END

IF ~~ finalChoice4
  SAY ~I feel, that you lie. Goodbye, <CHARNAME>.~
  ~(Dahlia makes a move and your body again is paralyzed with unimaginable pain.)~
  =
  ~(She hits you with a silver knife several times.)~
  =
  ~(All your senses go away and only darkness surrounds you.)~
  IF ~~ THEN DO ~Kill(Player1)~ EXIT
END


IF ~Global("DahliaTalk2","LOCALS",1)~ THEN BEGIN  vampTalk2D
  SAY ~I must open to you, <CHARNAME>. There is a way for damphire to become a vampire and gain immortality.~
  IF ~~ THEN REPLY ~I don't interested in it.~ GOTO dampTalk2D1
  IF ~~ THEN REPLY ~Tell me immediately what is this way?!~ GOTO dampTalk2D2
  IF ~~ THEN REPLY ~This is surely just another superstition.~ GOTO dampTalk2D1
END

IF ~~ dampTalk2D1
  SAY ~Maybe you are not interested in it, but I do. And you must listen about it and give me a promise to help me.~
  IF ~~ THEN REPLY ~Well, well, calm down, I am listening.~ GOTO dampTalk2Way
  IF ~~ THEN REPLY ~No way I will listen to thess ramblings.~ GOTO firstDie 
END

IF ~~ dampTalk2D2
  SAY ~Well, I am glad to hear that. You must promise me that we will help each other in becoming vampires.~
  IF ~~ THEN REPLY ~Tell about the way already, Dahlia!~ GOTO dampTalk2Way
  IF ~~ THEN REPLY ~No way I will listen to thess ramblings.~ GOTO firstDie 
END

IF ~~ dampTalk2Way
 SAY ~I have visited Candlekeep and found some ancient text in their library.~
 =
 ~The one way of becoming a vampire is to kill a vampire and eat his heart.~
 =
 ~There is a chance that after eating vampire's heart damphire will die.~
 =
 ~But I am ready to take a chance.~
 =
 ~Promise me, that if you'll find a vampire, you will kill him and give his heart to me!~
 IF ~~ THEN REPLY ~I promise.~ GOTO dampTalk2Way1
 IF ~~ THEN REPLY ~I will not promise you anything.~ GOTO dampTalk2Way2
END

IF ~~ dampTalk2Way1
  SAY ~Excellent! Continue our travels, <CHARNAME>.~
  IF ~~ THEN DO ~SetGlobal("DahliaTalk2","LOCALS",2)~ EXIT
END

IF ~~ dampTalk2Way2
  SAY ~Then I am leaving right now, <CHARNAME>. I don't want to waste more time on you.~
  IF ~~ THEN REPLY ~Stay, Dahlia. If I'll find you an appropriate vampire and we could win over him, I will give you his heart.~ GOTO  dampTalk2Way3
  IF ~~ THEN REPLY ~Farever, Dahlia, and good luck in your searches.~ GOTO dampTalk2Way4
  IF ~~ THEN REPLY ~Noone leaves my party without my permission~ GOTO firstDie
END

IF ~~ dampTalk2Way3
  SAY ~Don't try to trick me, <CHARNAME>.~
  IF ~~ THEN DO ~SetGlobal("DahliaTalk2","LOCALS",2)~ EXIT
END


IF ~~ dampTalk2Way4
  SAY ~Farewell, <CHARNAME>.~
  IF ~~ THEN DO ~LeaveParty()
EscapeArea()~ EXIT
END


IF ~Global("DahliaTalk1","LOCALS",1)
Race(Player1,VAMPYRE)~ THEN BEGIN  vampTalk1D
  SAY ~Say, <CHARNAME>, are you happy beeing a damphire?~
  IF ~~ THEN REPLY ~No, of cause. I am a monster and a danger to people.~ GOTO dampTalk1
  IF ~~ THEN REPLY ~I fear death and getting old.~ GOTO dampTalk2
  IF ~~ THEN REPLY ~It's better that beeing vampire. I can still eat food and drink alcohol. And I don't have to hide from the sun.~ GOTO dampTalk3
   IF ~~ THEN REPLY ~Dahlia, I got no time on your idiotic questions.~ DO ~SetGlobal("VampireBehaviour","LOCALS",4)~ GOTO vampTalk5 
END

IF ~Global("DahliaTalk1","LOCALS",1)
Race(Player1,VAMPIRE)~ THEN BEGIN  vampTalk1V
  SAY ~Say, <CHARNAME>, how do you feel beeing a vampire?~
  IF ~~ THEN REPLY ~It is a scaring thing. I feel constant hunger and fear people.~ DO ~SetGlobal("VampireBehaviour","LOCALS",1)~ GOTO vampTalk2
  IF ~~ THEN REPLY ~I like a taste of blood. It makes me feel so fantastic. And potentially I can do it forever.~ DO ~SetGlobal("VampireBehaviour","LOCALS",2)~ GOTO vampTalkV
  IF ~~ THEN REPLY ~I am evil monster and sometimes I think I am better off dead.~ DO ~SetGlobal("VampireBehaviour","LOCALS",3)~ GOTO vampTalk4
  IF ~~ THEN REPLY ~Dahlia, I got no time on your idiotic questions.~ DO ~SetGlobal("VampireBehaviour","LOCALS",4)~ GOTO vampTalk5
END

IF ~~ dampTalk1
  SAY ~Why do you think of people? They will burn you alive if they got you. But I think I understand some of your grief. You also lost your chance of becoming immortal.~ 
  IF ~~ THEN REPLY ~Most of living are mortals and they got to live through it.~ GOTO vampTalk3
  IF ~~ THEN REPLY ~Poor Dahlia, let me comfort you...~ GOTO vampTalk7
END

IF ~~ dampTalk2
  SAY ~Oh, I understand you. You also lost your chance of becoming immortal.~ 
  IF ~~ THEN REPLY ~Most of living are mortals and they got to live through it.~ GOTO vampTalk3
  IF ~~ THEN REPLY ~Poor Dahlia, let me comfort you...~ GOTO vampTalk7
END


IF ~~ dampTalk3
  SAY ~One can live without food, alcohol or sun. But cannot live if becames sick, weak and finally dead. You also lost your chance of becoming immortal and try to lie to yourself about pros in your existance.~ 
  IF ~~ THEN REPLY ~Most of living are mortals and they got to live through it.~ GOTO vampTalk3
  IF ~~ THEN REPLY ~Poor Dahlia, let me comfort you...~ GOTO vampTalk7
END

IF ~~ vampTalkV
  SAY ~Gods know how I envy you, <CHARNAME>. You are a lucky person.~
  IF ~~ THEN REPLY ~Most of living are mortals and they got to live through it.~ GOTO vampTalk3
  IF ~~ THEN REPLY ~Poor Dahlia, let me comfort you...~ GOTO vampTalk7
END

IF ~~ vampTalk4
  SAY ~I'll remember this. You got a gift of eternity and you don't like it. World is not fair...~
  IF ~~ THEN REPLY ~Most of living are mortals and they got to live through it.~ GOTO vampTalk3
  IF ~~ THEN REPLY ~Poor Dahlia, let me comfort you...~ GOTO vampTalk7
END

IF ~~ vampTalk5
  SAY ~Dahlia clenches her fists in fury and turns away.~
  IF ~!Race(Player1,VAMPIRE)~ THEN DO ~SetGlobal("DahliaTalk1","LOCALS",2)
  IncrementGlobal("Happiness","LOCALS",-500)~ EXIT
  IF ~Race(Player1,VAMPIRE)~ THEN DO ~SetGlobal("DahliaTalk1","LOCALS",2)
  SetGlobalTimer("DahliaAttack1Timer","GLOBAL",THREE_DAYS)~ EXIT
END

IF ~~ vampTalk2
  SAY ~It's almost the same with me. But you got immortality and great powers. And I got nothing except 
 of it - except bloodlust.~
  IF ~~ THEN REPLY ~Most of living are mortals and they got to live through it.~ GOTO vampTalk3
  IF ~~ THEN REPLY ~Poor Dahlia, let me comfort you...~ GOTO vampTalk7
END

IF ~~ vampTalk3
  SAY ~Listen, <CHARNAME>. I am not one of them, you hear me?~
  IF ~~ THEN DO ~~ GOTO vampTalkDahlia
END

IF ~~ vampTalk7
  SAY ~Idiot, stop this flirting. I am gravely serious.~
  IF ~~ THEN DO ~~ GOTO vampTalkDahlia
END


IF ~~ vampTalkDahlia
  SAY ~I got the chance to became vampire. And to get rid of aging, turning to ugly old hag.~
  =
  ~And what's happened with me? I become an excuse of a vampire, this cursed damphire.~
  =
  ~I cannot properly hunt for blood, because I was a quiet girl and there were no hunters or warriors in my family.~
  =
  ~I am a failure. I almost hear how wrinkles appear on me. It's terrifying.~
  =
  ~Let's finish this talk.~
  IF ~!Race(Player1,VAMPIRE)~ THEN DO ~SetGlobal("DahliaTalk1","LOCALS",2)
  SetGlobalTimer("DahliaTalk2Timer","GLOBAL",TWO_DAYS)~ EXIT
  IF ~Race(Player1,VAMPIRE)~ THEN DO ~SetGlobal("DahliaTalk1","LOCALS",2)
  SetGlobalTimer("DahliaAttack1Timer","GLOBAL",THREE_DAYS)~ EXIT
END



  


IF ~!See([ENEMY])
AreaCheck("DSC014")
See(Player1)
NumTimesTalkedTo(0)
~ THEN BEGIN startInitTalk
  SAY ~(You see a naked girl, who wipes his hair with a towel. A drops of water flash on her pale skin.)~
  =
  ~(She is standing near water bath, which is warmed up by a pile of coal.)~
  IF ~~ THEN REPLY ~(Cough.)~ GOTO firstReaction1
  IF ~Gender(Player1,MALE)~ THEN REPLY ~(Stand silent and look at her body.)~ GOTO firstReaction2M
  IF ~!Gender(Player1,MALE)~ THEN REPLY ~(Stand silent and look at her body.)~ GOTO firstReaction2F
  IF ~Global("VampireStronghold","GLOBAL",1)~ THEN REPLY ~Hey, what you doing in my bath?!~ GOTO firstReaction1
END

IF ~~ firstReaction2M
  SAY ~(She is an albino. Her hair is of white color.)~
  =
  ~(She slowly wipes her hair and begins to wipe her arms.)~
  =
  ~(Then she gracefully begins to wipe her breasts. They are so...)~
  =
  ~(You sense tension and accidentally drop the weapon.)~
  IF ~~ THEN DO ~~ GOTO firstReaction1
END

IF ~~ firstReaction2F
  SAY ~(She is an albino. Her hair is of white color.)~
  =
  ~(She slowly wipes her hair and begins to wipe her arms.)~
  =
  ~(Then she gracefully begins to wipe her breasts. Her medium breasts of ideal form.)~
  =
  ~(You begin to feel jealousy for her body.)~
  IF ~~ THEN REPLY ~And they are not so big and beautiful as mine.~ GOTO firstReaction1
END
  
IF ~~ firstReaction1
  SAY ~Ai! Who's there?~
  =
  ~Don't look, please!~
  =
  ~(Girl quickly throws away towel and quickly dresses up her no less frank outfit.)~
  =
  ~Who are you?~
  IF ~Global("VampireStronghold","GLOBAL",1)~ THEN REPLY ~I am the owner of this castle and this bath. You violate my private property!~ GOTO firstReaction3
  IF ~Gender(Player1,MALE)~ THEN REPLY ~Marry me, please!~ GOTO firstReaction4
  IF ~Gender(Player1,MALE)~ THEN REPLY ~Let's make love, right in this bath, beauty!~ GOTO  firstReaction5
  IF ~!Gender(Player1,MALE)~ THEN REPLY ~It's sad that you already finished washing. Maybe you want to go another round? I will rub your back, kitty.~ GOTO  firstReaction6
  IF ~~ THEN REPLY ~It's you who must answer first.~ GOTO firstReactionWho
END

IF ~~ firstReaction4
  SAY ~Oh, very funny. I will not marry an unknown man.~
  IF ~~ THEN REPLY ~Who are you?~ GOTO firstReactionWho
END

IF ~~ firstReaction5
  SAY ~Cool down, stallion. I am not a street girl, I will not make love with a stranger.~
  IF ~~ THEN REPLY ~Who are you?~ GOTO firstReactionWho
END

IF ~~ firstReaction6
 SAY ~No, thanks, I sense I am clean.~
  IF ~~ THEN REPLY ~Who are you?~ GOTO firstReactionWho
END  

IF ~~ firstReaction3
  SAY ~Sorry, I throught that nobody used that bath in a long time and will not get angry on me.~
  IF ~~ THEN REPLY ~Who are you?~ GOTO firstReactionWho
END  

IF ~~ firstReactionWho
  SAY ~(Girl comes closer and her nostrils are swelling, sniffing you.)~
  =
  ~(She also smells strange, maybe it is from herbals she added to water.)~
  IF ~Race(Player1,VAMPIRE)~ THEN GOTO firstReactionVampire
  IF ~Race(Player1,VAMPYRE)~ THEN GOTO firstReactionVampyre
  IF ~Race(Player1,LYCANTHROPE)~ THEN GOTO firstReactionLycan

  IF ~Race(Player1,DEMONIC)~ THEN GOTO firstReactionDemonic
  IF ~!Race(Player1,VAMPIRE)
  !Race(Player1,VAMPYRE)
  !Race(Player1,LYCANTHROPE)
  !Race(Player1,HUMAN)
  !Race(Player1,DEMONIC)~ THEN GOTO firstReactionOther
END

IF ~~ firstReactionVampire
  SAY ~I see, you are a vampire. I think I can open up to you.~
  =
  ~My name is Dahlia. Few months ago I was bitten by vampire.~
  =
  ~And I didn't become a vampire. I became a damphire.~
  =
  ~I am a light version of you. I am not immortal, and I don't have superpowers like your kind has.~
  =
  ~But I am also need a blood of people to live on.~
  =
  ~I worked as a bodyguard for our village major before all that. So when my life changed so drastically, I decided to find a work from your kind.~
  =
  ~I have heard about vampires in this castle, so I dared to try and visit this castle.~
  IF ~~ THEN REPLY ~Work? What work?~ GOTO firstReactionVampire2
END

IF ~~ firstReactionVampire2
  SAY ~A work of bodyguard. I don't fear the light. And holy magic doesn't work on me, as it does on undead like you.~
  =
  ~I could watch over you when you sleep daily in your coffin. I could even help you hunt.~
  =
  ~All I ask in exchange, that you will share blood of your victims with me, and protect my back, when you are awake and active.~
  =
  ~And of cause, give me enough money from time to time for weapons, dresses, food.~
  =
  ~What do you say?~
  IF ~~ THEN REPLY ~Hmm. If you will swear, that you be loyal to me, that come with me, Dalhia.~ GOTO firstHiredVampire1
  IF ~~ THEN REPLY ~Perhaps, it is destiny, that we met? Join my party, and maybe our relations will become more than of customer and bodyguard?~ GOTO firstHiredVampire2  
  IF ~~ THEN REPLY ~No, girl, I don't need your services right now.~ GOTO firstLeave
  IF ~Global("VampireStronghold","GLOBAL",1)~ THEN REPLY ~Get out from my castle immediately.~ GOTO firstLeave2
  IF ~~ THEN REPLY ~I don't trust you. And you now know that I am a vampire. You will not leave this place.~ GOTO firstDie
END


IF ~~ firstReactionVampyre
  SAY ~It is sad, that you are a damphire. I am one of your kind too.~
  =
  ~My name is Dahlia. Few months ago I was bitten by vampire.~
  =
  ~And I didn't become a vampire. I became a damphire like you.~
  =
  ~I worked as a bodyguard for our village major before all that. So when my life changed so drastically, I decided to find a work from vampires.~
  =
  ~I have heard about vampires in this castle, so I dared to try and visit this castle.~
  IF ~~ THEN REPLY ~Work? What work?~ GOTO firstReactionVampire2
END 
  
  IF ~~ firstReactionVampyre2
  SAY ~A work of bodyguard. I could watch over vampire when he sleeps daily in his coffin.~
  =
  ~All shall I ask in exchange, that my customer will share blood of victims with me, and protect my back, when he is awake and active.~
  IF ~~ THEN REPLY ~Clever plan you got. But I am not a vampire. Perhaps you can join me, and I will hunt for both of us?~ GOTO firstHiredVampyre1
  IF ~~ THEN REPLY ~Perhaps, it is destiny, that we met? Join my party, and maybe our relations will become more than of customer and bodyguard?~ GOTO firstHiredVampyre2
  IF ~~ THEN REPLY ~Clever plan. But I am not a vampire. Wish you luck in finding one.~ GOTO firstLeave
  IF ~Global("VampireStronghold","GLOBAL",1)~ THEN REPLY ~Get out from my castle immediately.~ GOTO firstLeave2
  IF ~~ THEN REPLY ~So you a monster as I am. I will kill you to make sure you will not hurt anyone.~ GOTO firstDie
END

IF ~~ firstReactionLycan
  SAY ~What?! No, you are a lycanthrope! Please, let me leave. I will not tell anyone about you! I want to live!~
  IF ~~ THEN REPLY ~You will not tell anyone about me. Because you will die.~ GOTO firstDie
  IF ~~ THEN REPLY ~Go away, girl. I am in a good mood today and don't eat Red Hats.~ GOTO firstLeave3
END

IF ~~ firstReactionDemonic
  SAY ~What?! No, you are a demon! Please, let me leave. I will not tell anyone about you! I want to live!~
  IF ~~ THEN REPLY ~You will not tell anyone about me. Because you will die.~ GOTO firstDie
  IF ~~ THEN REPLY ~Go away, girl. I am in a bad mood today and don't want to kill you yet.~ GOTO firstLeave3
END

IF ~~ firstReactionOther
  SAY ~You are not a type of people I search for my purposes. I will leave now. Goodbye, stranger.~
  IF ~~ THEN REPLY ~You are not going anywhere. I want to do with you some nasty things.~ GOTO firstDie
  IF ~~ THEN REPLY ~You are not going anywhere. I am in a mood of killing now.~ GOTO firstDie
  IF ~~ THEN REPLY ~I sense something inhuman in you. I better clean a world of such anomaly.~ GOTO firstDie
  IF ~~ THEN REPLY ~Goodbye, beatiful stranger.~ GOTO firstLeave3
END

IF ~~ firstHiredVampire1
  SAY ~Thank you for giving me work. I swear that I will not betray you.~
  =
  ~What is your name, by the way? I think I must know a name of the one I protect?~
  IF ~Gender(Player1,MALE)~ THEN REPLY ~My name is <CHARNAME>.~ GOTO firstJoinM
  IF ~!Gender(Player1,MALE)~ THEN REPLY ~My name is <CHARNAME>.~ GOTO firstJoinF
END

IF ~~ firstHiredVampire2
  SAY ~I don't know you yet. If you will be kind enough, I think I could fall in love with you.~
  =
  ~And thank you for giving me work. I swear that I will not betray you.~
  =
  ~What is your name, by the way? I think I must know a name of the one I protect and of one who wants more than work?~
  IF ~Gender(Player1,MALE)~ THEN REPLY ~My name is <CHARNAME>.~ GOTO firstJoinM
  IF ~!Gender(Player1,MALE)~ THEN REPLY ~My name is <CHARNAME>.~ GOTO firstJoinF
END

IF ~~ firstHiredVampyre1
  SAY ~Thank you to give me work. I swear that I will not betray you.~
  =
  ~What is your name, by the way? I think I must know a name of the one I protect?~
  IF ~Gender(Player1,MALE)~ THEN REPLY ~My name is <CHARNAME>.~ GOTO firstJoinM
  IF ~!Gender(Player1,MALE)~ THEN REPLY ~My name is <CHARNAME>.~ GOTO firstJoinF
END


IF ~~ firstHiredVampyre2
  SAY ~I don't know you yet. If you will be kind enough, I think I could fall in love with you.~
  =
  ~And thank you to give me work. I swear that I will not betray you.~
  =
  ~What is your name, by the way? I think I must know a name of the one I protect and of one who wants more than work?~
  IF ~Gender(Player1,MALE)~ THEN REPLY ~My name is <CHARNAME>.~ GOTO firstJoinM
  IF ~!Gender(Player1,MALE)~ THEN REPLY ~My name is <CHARNAME>.~ GOTO firstJoinF
END


IF ~~ firstJoinM
  SAY ~<CHARNAME>? Your parents surely were bad at naming children.~
  IF ~~ THEN DO ~SetGlobalTimer("DahliaTalk1Timer","GLOBAL",TWO_DAYS)
  JoinParty()~ EXIT
END


IF ~~ firstJoinF
  SAY ~<CHARNAME>? What a lovely cute name!~
  IF ~~ THEN DO ~SetGlobalTimer("DahliaTalk1Timer","GLOBAL",TWO_DAYS)
  JoinParty()~ EXIT
END

IF ~~ firstLeave
  SAY ~(A beautiful girl dresses up, takes her belongings and dissapears in the door frame, waving goodbye.)~
  IF ~~ THEN DO ~EscapeArea()~ EXIT
END


IF ~~ firstLeave2
  SAY ~(A beautiful girl dresses up, takes her belongings and dissapears in the door frame, throwing angered look at you at last moment.)~
  IF ~~ THEN DO ~EscapeArea()~ EXIT
END

IF ~~ firstLeave3
  SAY ~(A beautiful girl dresses up, takes her belongings and dissapears in the door frame, throwing distrustful look at you.)~
  IF ~~ THEN DO ~EscapeArea()~ EXIT
END
  
IF ~~ firstDie
  SAY ~(Girl stands in a battle pose and shows you small thick teeth, hissing at you.)~
  IF ~~ THEN DO ~Enemy()~ EXIT
END
  
  IF ~~ vampStrongholdST1
  SAY ~See you there.~
 IF ~RandomNumLT(100,15)~ THEN DO ~LeaveParty()
RunAwayFromNoInterrupt(Player1,20)
MoveBetweenAreas("DSC016",[2656.1026],W)~ EXIT
 IF ~RandomNumLT(100,15)~ THEN DO ~LeaveParty()
RunAwayFromNoInterrupt(Player1,20)
MoveBetweenAreas("DSC016",[2856.886],W)~ EXIT
 IF ~RandomNumLT(100,15)~ THEN DO ~LeaveParty()
RunAwayFromNoInterrupt(Player1,20)
MoveBetweenAreas("DSC016",[3114.1397],W)~ EXIT
 IF ~RandomNumLT(100,15)~ THEN DO ~LeaveParty()
RunAwayFromNoInterrupt(Player1,20)
MoveBetweenAreas("DSC016",[3283.1654],W)~ EXIT
 IF ~RandomNumLT(100,15)~ THEN DO ~LeaveParty()
RunAwayFromNoInterrupt(Player1,20)
MoveBetweenAreas("DSC016",[3433.1654],W)~ EXIT
 IF ~~ THEN DO ~LeaveParty()
RunAwayFromNoInterrupt(Player1,20)
MoveBetweenAreas("DSC016",[3433.1543],W)~ EXIT
END

//when thrown out
IF ~!AreaCheck("DSC014")
See(Player1)
!InParty(Myself)~ THEN BEGIN GreetingVManB1
SAY ~Do you no longer need my protection, <CHARNAME>?~ 
 ++ ~No, of cause. Dahlia, return, I need you.~ + notparty1
IF ~Gender(Player1,MALE)~ THEN REPLY ~Stay here, Dahlia, I will return.~ GOTO notparty2
IF ~!Gender(Player1,MALE)~ THEN REPLY ~Stay here, Dahlia, I will return.~ GOTO notparty2F
IF ~Global("BodhiStronghold","GLOBAL",2)~ THEN REPLY ~Go to our Stronghold in Grave Yard District. I will find you there, if it will be needed.~ GOTO notpartGoST 

   IF ~
  Global("VampireStronghold","GLOBAL",1)~ THEN REPLY ~Go to former castle of Daerthmac. I will find you there, if your help would be needed.~ GOTO vampStrongholdST1
  ++ ~You are free to go. I release you from your duty.~ + freeDuty 
 ++ ~I decided to end your life.~ + talkEndInitFight1
END

IF ~~ freeDuty
  SAY ~You are firing me? Please reconsider. I served you vell until now.~
  IF ~~ THEN REPLY ~No, Dahlia. I have limited resources and I need the most effective party. You are the weak point in it.~ GOTO freeDuty1
  IF ~~ THEN REPLY ~Well, allright. You can stay with me for some time.~ GOTO freeDuty2
  IF ~~ THEN REPLY ~Run away, before I started killing you!~ GOTO freeDuty3
END

IF ~~ freeDuty1
SAY ~Then farewell, <CHARNAME>. I wish you will find yourself a new better guardian, who will not stick aspen stake in your heart, when you will be asleep.~
IF ~~ THEN DO ~LeaveParty()
EscapeArea()
IncrementGlobal("Happiness","LOCALS",-400)~ EXIT
END

IF ~~ freeDuty2
SAY ~I will try more, <CHARNAME>. You would not want to fire better version on me.~
IF ~~ THEN DO ~IncrementGlobal("Happiness","LOCALS",40)~ EXIT
END

IF ~~ freeDuty3
SAY ~(Dahlia hisses on you, takes away her belongings and dissapears.).~
IF ~~ THEN DO ~IncrementGlobal("Happiness","LOCALS",-1000)~ EXIT
END

IF ~~ notparty2
SAY ~Okay, master!~
IF ~~ THEN DO ~~ EXIT
END

IF ~~ notparty2F
SAY ~Okay, mistress!~
IF ~~ THEN DO ~~ EXIT
END


IF ~~ notparty1m
  SAY ~Glad to hear that.~
  IF ~~ THEN DO ~
	//	DestroyItem("VVShyressa")
	//	DestroyItem("MONHP1")
		JoinParty()~ EXIT
END

IF ~~ notparty1
  SAY ~Glad to hear that.~
  IF ~~ THEN DO ~
		JoinParty()~ EXIT
END

IF ~~ notpartGoST
   SAY ~Don't forget your bodyguard, <CHARNAME>!~
   IF ~~ THEN DO ~LeaveParty()
   RunAwayFromNoInterrupt(Player1,40)
   MoveBetweenAreas("AR0808",[143.829],SE)~ EXIT
 END  

// talk in party

IF ~InParty(Myself)~ THEN BEGIN GreetingManV1
SAY ~<CHARNAME>?~ 
IF ~Race(Player1,VAMPIRE)
!Global("TalkOnBlood","LOCALS",1)
Race(Myself,VAMPYRE)~  THEN REPLY ~Are you hungry? You can suck my blood, Dahlia.~ GOTO suckbloodD
IF ~Race(Player1,VAMPIRE)
!Global("TalkOnBlood","LOCALS",1)
Race(Myself,VAMPIRE)~  THEN REPLY ~Are you hungry? You can suck my blood, Dahlia.~ GOTO suckbloodV
IF ~Gender(Player1,MALE)~ THEN REPLY  ~Tell me your story, Dahlia.~ GOTO talkDahliaM
IF ~!Gender(Player1,MALE)~ THEN REPLY  ~Tell me your story, Dahlia.~ GOTO talkDahliaF
IF ~Gender(Player1,MALE)
GlobalLT("Happiness","LOCALS",2000)~ THEN REPLY ~I cannot wait more. Dahlia, lay with me and let's make love.~ GOTO talkLoveM1
IF ~Gender(Player1,MALE)
GlobalGT("Happiness","LOCALS",2000)~ THEN REPLY ~I cannot wait more. Dahlia, lay with me and let's make love.~ GOTO talkLoveM2
IF ~!Gender(Player1,MALE)
GlobalLT("Happiness","LOCALS",2000)~ THEN REPLY ~I cannot wait more. Dahlia, lay with me and let's make love.~ GOTO talkLoveM1
IF ~!Gender(Player1,MALE)
GlobalGT("Happiness","LOCALS",2000)~ THEN REPLY ~I cannot wait more. Dahlia, lay with me and let's make love.~ GOTO talkLoveM2
IF ~!Race(Player1,VAMPIRE)
!Race(Player1,VAMPYRE)
!General(Player1,UNDEAD)
!Global("TalkOnConvertion","LOCALS",1)
~ THEN REPLY ~Turn me to damphire, Dahlia.~ GOTO vampconv

IF ~!AreaType(OUTDOOR)
Global("DahliaGetVampireHeart","GLOBAL",0)
Global("DahliaTalk1","LOCALS",2)
OR(2)
Global("DahliaTalk2","LOCALS",2)
Global("DahliaAttack1","LOCALS",2)
OR(29)
PartyHasItem("VVHVYNON")
PartyHasItem("VVHNAMI")
PartyHasItem("VVTSOLAK")
PartyHasItem("MISCBP")
PartyHasItem("VVHTANOV")
PartyHasItem("VVHDURST")
PartyHasItem("VVHGELAL")
PartyHasItem("VVHGUARD")
PartyHasItem("VVHLANA")
PartyHasItem("VVHAREIS")
PartyHasItem("VVHMERED")
PartyHasItem("VVHSALIA")
PartyHasItem("VVHVALEN")
PartyHasItem("VVHCOHN")
PartyHasItem("VVHLASAL")
PartyHasItem("VVHPARIS")
PartyHasItem("VVHULVAR")
PartyHasItem("VVHVYNN")
PartyHasItem("VVHMARIS")
PartyHasItem("VVHPHLYD")
PartyHasItem("VVHSHYR")
PartyHasItem("VVDEREK")
PartyHasItem("VVHPHREY")
PartyHasItem("VVHKALI2")
PartyHasItem("VVHKALI3")
PartyHasItem("VVHKALI4")
PartyHasItem("VVHCLAIR")
PartyHasItem("VVHDAERT")
PartyHasItem("VVDRAGO")
~ THEN REPLY ~Dahlia, I have a vampire heart and I want to give it to you. As was promised by me.~ GOTO eatVampireHeart

  IF ~
 Global("BodhiStronghold","GLOBAL",2)~ THEN REPLY ~Go to our Stronghold in Grave Yard District. I will find you there, if it will be needed.~ GOTO notpartGoST
   IF ~
  Global("VampireStronghold","GLOBAL",1)~ THEN REPLY ~Go to former castle of Daerthmac. I will find you there, if your help would be needed.~ GOTO vampStrongholdST1

IF ~Gender(Player1,MALE)~ THEN REPLY ~I want to reward you, Dahlia. You said you needed money from time to time.~ GOTO GiftProposalM
IF ~!Gender(Player1,MALE)~ THEN REPLY ~I want to reward you, Dahlia. You said you needed money from time to time.~ GOTO GiftProposalF
 ++ ~No, nothing right now, Dahlia.~ + byesilent
  ++ ~I decided to end your life.~ + talkEndInitFight1
END

IF ~~ talkLoveM1
  SAY ~Please keep your hands out of me, <CHARNAME>. I am not of a kind, that jumps to bed without feelings.~
  IF ~~ THEN DO ~~ EXIT
END


IF ~~ talkLoveM2
  SAY ~<CHARNAME>, don't get me wrong. I like you very much. But only when this mess with Bhaal legacy ends, we could find a place and could spend all the time for each other.~
  IF ~~ THEN DO ~~ EXIT
END

IF ~~ talkLoveF1
  SAY ~I am not the one who practices that kind of love relations, <CHARNAME>. Find yourself a good partner among males.~
  IF ~~ THEN DO ~~ EXIT
END


IF ~~ talkLoveF2
  SAY ~<CHARNAME>, you have influenced me very much. I also begin to feel your sexuality. But only when this mess with Bhaal legacy ends, we could find a place and could spend all the time for each other.~
  IF ~~ THEN DO ~~ EXIT
END


IF ~~ byesilent
SAY ~I like the sound of your voice, <CHARNAME>, speak to me anytime.~
  IF ~~ THEN DO ~IncrementGlobal("Happiness","LOCALS",10)~ EXIT
END


IF ~~ talkDahliaM
  SAY ~There is nothing to tell you. I am just an average village girl, that was bitten by vampire, and even there I managed to be looser and became a damphire. My youth will vanish no matter how many people I'll suck dry. And I even won't get a vampire afterlife, my cauldron is already warming up in Abyss.~
  =
  ~See, my mood is ruined. It's because you reminded me of my dark future.~
  IF ~~ THEN DO ~IncrementGlobal("Happiness","LOCALS",-50)~ EXIT
END

IF ~~ talkDahliaF
  SAY ~There is nothing to tell you. I am just an average village girl, that was bitten by vampire, and even there I managed to be looser and became a damphire. My youth will vanish no matter how many people I'll suck dry. And I even won't get a vampire afterlife, my cauldron is already warming up in Abyss.~
  =
  ~See, my mood is ruined. It's because you reminded me of my dark future.~
  IF ~~ THEN DO ~IncrementGlobal("Happiness","LOCALS",-50)~ EXIT
END


IF ~~ suckbloodV
  SAY ~Finally I can really suck your blood, <CHARNAME>!~
  IF ~~ THEN GOTO suckblood2
END


IF ~~ suckblood2
  SAY ~This is the best drink in all Amn!~
  IF ~~ THEN DO ~ApplyDamagePercent(Player1,40,MAGIC)
  SetGlobalTimer("BloodlustTimer","LOCALS",ONE_DAY)
ApplySpell(Myself,RESTORE_FULL_HEALTH)~ EXIT 
END


IF ~~ suckbloodD
  SAY ~Hey, you a vampire, remember? I can suck only living people's blood!~
  IF ~~ THEN DO ~SetGlobal("TalkOnBlood","LOCALS",1)~ EXIT
END


IF ~~ vampconv
  SAY ~Hey, don't you remember? I am damphire, I cannot turn anything. I am a failure.~
  IF ~~ THEN DO ~SetGlobal("TalkOnConvertion","LOCALS",1)~ EXIT
END



IF ~~ talkEndInitFight1
  SAY ~(Dahlia stands in a battle pose and shows you small thick teeth, hissing at you.)~
  IF ~~ THEN DO ~Enemy()~ EXIT
END
  

IF ~~ GiftProposalM
   SAY ~I will be very happy to receive gift from you, master.~
   IF ~~ THEN REPLY ~Perhaps another time, sorry Dahlia.~ DO ~IncrementGlobal("Happiness","LOCALS",-50)~ EXIT 
   IF ~PartyGoldGT(100)~ THEN REPLY ~I am giving you 100 gold. Don't refuse yourself in anything.~ DO ~TakePartyGold(100)
   DestroyGold(100)
 IncrementGlobal("Happiness","LOCALS",10)
IncrementGlobal("TookGold","LOCALS",100) 
~ GOTO GiftProposalThankYouM
   IF ~PartyGoldGT(500)~ THEN REPLY ~I am giving you 500 gold. Don't refuse yourself in anything.~ DO ~TakePartyGold(500)
   DestroyGold(500)
 IncrementGlobal("Happiness","LOCALS",50)
IncrementGlobal("TookGold","LOCALS",500) 
~ GOTO GiftProposalThankYouM
   IF ~PartyGoldGT(1000)~ THEN REPLY ~I am giving you 1000 gold. Don't refuse yourself in anything.~ DO ~TakePartyGold(1000)
   DestroyGold(1000)
 IncrementGlobal("Happiness","LOCALS",100)
IncrementGlobal("TookGold","LOCALS",1000) 
~ GOTO GiftProposalThankYouM
   IF ~PartyGoldGT(2000)~ THEN REPLY ~I am giving you 2000 gold. Don't refuse yourself in anything.~ DO ~TakePartyGold(2000)
   DestroyGold(2000)
 IncrementGlobal("Happiness","LOCALS",200)
IncrementGlobal("TookGold","LOCALS",2000) 
~ GOTO GiftProposalThankYouM
   IF ~PartyGoldGT(5000)~ THEN REPLY ~I am giving you 5000 gold. Don't refuse yourself in anything.~ DO ~TakePartyGold(5000)
   DestroyGold(5000)
 IncrementGlobal("Happiness","LOCALS",400)
IncrementGlobal("TookGold","LOCALS",5000) 
~ GOTO GiftProposalThankYouM
END   

IF ~~ GiftProposalF
   SAY ~I will be very happy to receive gift from you, mistress.~
   IF ~PartyGoldGT(100)~ THEN REPLY ~I am giving you 100 gold. Don't refuse yourself in anything.~ DO ~TakePartyGold(100)
   DestroyGold(100)
 IncrementGlobal("Happiness","LOCALS",10)
IncrementGlobal("TookGold","LOCALS",100) 
~ GOTO GiftProposalThankYouF
   IF ~PartyGoldGT(500)~ THEN REPLY ~I am giving you 500 gold. Don't refuse yourself in anything.~ DO ~TakePartyGold(500)
   DestroyGold(500)
 IncrementGlobal("Happiness","LOCALS",50)
IncrementGlobal("TookGold","LOCALS",500) 
~ GOTO GiftProposalThankYouF
   IF ~PartyGoldGT(1000)~ THEN REPLY ~I am giving you 1000 gold. Don't refuse yourself in anything.~ DO ~TakePartyGold(1000)
   DestroyGold(1000)
 IncrementGlobal("Happiness","LOCALS",100)
IncrementGlobal("TookGold","LOCALS",1000) 
~ GOTO GiftProposalThankYouF
   IF ~PartyGoldGT(2000)~ THEN REPLY ~I am giving you 2000 gold. Don't refuse yourself in anything.~ DO ~TakePartyGold(2000)
   DestroyGold(2000)
 IncrementGlobal("Happiness","LOCALS",200)
IncrementGlobal("TookGold","LOCALS",2000) 
~ GOTO GiftProposalThankYouF
   IF ~PartyGoldGT(5000)~ THEN REPLY ~I am giving you 5000 gold. Don't refuse yourself in anything.~ DO ~TakePartyGold(5000)
   DestroyGold(5000)
 IncrementGlobal("Happiness","LOCALS",400)
IncrementGlobal("TookGold","LOCALS",5000) 
~ GOTO GiftProposalThankYouF
END   


IF ~~ GiftProposalThankYouM
  SAY ~Thank you, <CHARNAME>.~
  IF ~~ THEN DO ~~ EXIT
END

IF ~~ GiftProposalThankYouF
  SAY ~Thank you, <CHARNAME>.~
  IF ~~ THEN DO ~~ EXIT
END


IF ~~ eatVampireHeart
  SAY ~My immortality! I didn't believed you will help me, <CHARNAME>. I am happy I was wrong about you.~
  =
  ~(She kisses you to cheek.)~
  =
  ~Where is it?~
  IF ~Race(Player1,VAMPIRE)~ THEN REPLY ~But Dahlia, if you will become a vampire, who will guard my coffin? We both will became vulnerable.~ DO ~SetGlobal("KeepHeart","LOCALS",1)~ GOTO eatVampireHeart1
  IF ~Gender(Player1,MALE)~ THEN REPLY ~I love you, Dahlia, and I want to preserve your beauty as soon as possible.~ DO ~SetGlobal("DahliaRomance","GLOBAL",2)~ DO ~SetGlobal("KeepHeart","LOCALS",2)~ GOTO eatVampireHeart2M
  IF ~!Gender(Player1,MALE)~ THEN REPLY ~I love you, Dahlia, and I want to preserve your beauty as soon as possible.~ DO ~SetGlobal("DahliaRomance","GLOBAL",2)~ DO ~SetGlobal("KeepHeart","LOCALS",2)~ GOTO eatVampireHeart2F
  IF ~~ THEN REPLY ~Become an immortal.~ DO ~SetGlobal("KeepHeart","LOCALS",2)~ GOTO eatVampireHeart3
END

IF ~~ eatVampireHeart1
   SAY ~Give me the heart, <CHARNAME>. I will continue to be your bodyguard as long, as we travel to solve your problems, I swear. If all will be going good, I will not eat it until we are victorous.~
   IF ~~ THEN DO ~~ GOTO eatVampireHeartTake
END


  IF ~~ eatVampireHeart2F
   SAY ~You are such a good girl, <CHARNAME>. I will always be on your side.~
   IF ~~ THEN DO ~SetGlobal("Happiness","LOCALS",700)~ GOTO eatVampireHeartTake
END

    IF ~~ eatVampireHeart2M
   SAY ~You are such a good boy, <CHARNAME>. I will always be on your side.~
   IF ~~ THEN DO ~SetGlobal("Happiness","LOCALS",800)~ GOTO eatVampireHeartTake
END

IF ~~ eatVampireHeart3
  SAY ~I will remember, what you have done to me, <CHARNAME>. I almost love you.~
  IF ~~ THEN DO ~SetGlobal("Happiness","LOCALS",500)~ GOTO eatVampireHeartTake
END

//Global("DahliaGetVampireHeart","GLOBAL",0)
IF ~~ eatVampireHeartTake
  SAY ~A heart, <CHARNAME>.~
  IF ~PartyHasItem("VVHVYNON")~ THEN REPLY ~Take the heart of Vynona.~ DO ~TakePartyItem("VVHVYNON")
   DestroyItem("VVHVYNON")~ GOTO eatVampireHeartFinal
  IF ~PartyHasItem("VVHNAMI")~ THEN REPLY ~Take the heart of Nami.~ DO ~TakePartyItem("VVHNAMI")
   DestroyItem("VVHNAMI")~ GOTO eatVampireHeartFinal
  IF ~PartyHasItem("VVTSOLAK")~ THEN REPLY ~Take the heart of Tsolak.~ DO ~TakePartyItem("VVTSOLAK")
   DestroyItem("VVTSOLAK")~ GOTO eatVampireHeartFinal
  IF ~PartyHasItem("MISCBP")~ THEN REPLY ~Take the heart of Bodhi.~ DO ~TakePartyItem("MISCBP")
   DestroyItem("MISCBP")~ GOTO eatVampireHeartFinal
  IF ~PartyHasItem("VVHTANOV")~ THEN REPLY ~Take the heart of Tanova.~ DO ~TakePartyItem("VVHTANOV")
   DestroyItem("VVHTANOV")~ GOTO eatVampireHeartFinal
  IF ~PartyHasItem("VVHDURST")~ THEN REPLY ~Take the heart of Durst.~ DO ~TakePartyItem("VVHDURST")
   DestroyItem("VVHDURST")~ GOTO eatVampireHeartFinal
  IF ~PartyHasItem("VVHGELAL")~ THEN REPLY ~Take the heart of Gelal.~ DO ~TakePartyItem("VVHGELAL")
   DestroyItem("VVHGELAL")~ GOTO eatVampireHeartFinal
  IF ~PartyHasItem("VVHGUARD")~ THEN REPLY ~Take the heart of Guard.~ DO ~TakePartyItem("VVHGUARD")
   DestroyItem("VVHGUARD")~ GOTO eatVampireHeartFinal
  IF ~PartyHasItem("VVHLANA")~ THEN REPLY ~Take the heart of Del.~ DO ~TakePartyItem("VVHLANA")
   DestroyItem("VVHLANA")~ GOTO eatVampireHeartFinal
  IF ~PartyHasItem("VVHAREIS")~ THEN REPLY ~Take the heart of Hareishan.~ DO ~TakePartyItem("VVHAREIS")
   DestroyItem("VVHAREIS")~ GOTO eatVampireHeartFinal
  IF ~PartyHasItem("VVHMERED")~ THEN REPLY ~Take the heart of Meredath.~ DO ~TakePartyItem("VVHMERED")
   DestroyItem("VVHMERED")~ GOTO eatVampireHeartFinal
  IF ~PartyHasItem("VVHSALIA")~ THEN REPLY ~Take the heart of Salia.~ DO ~TakePartyItem("VVHSALIA")
   DestroyItem("VVHSALIA")~ GOTO eatVampireHeartFinal
  IF ~PartyHasItem("VVHVALEN")~ THEN REPLY ~Take the heart of Valen.~ DO ~TakePartyItem("VVHVALEN")
   DestroyItem("VVHVALEN")~ GOTO eatVampireHeartFinal
  IF ~PartyHasItem("VVHCOHN")~ THEN REPLY ~Take the heart of Cohn.~ DO ~TakePartyItem("VVHCOHN")
   DestroyItem("VVHCOHN")~ GOTO eatVampireHeartFinal
  IF ~PartyHasItem("VVHLASAL")~ THEN REPLY ~Take the heart of Lassal.~ DO ~TakePartyItem("VVHLASAL")
   DestroyItem("VVHLASAL")~ GOTO eatVampireHeartFinal
  IF ~PartyHasItem("VVHPARIS")~ THEN REPLY ~Take the heart of Parisa.~ DO ~TakePartyItem("VVHPARIS")
   DestroyItem("VVHPARIS")~ GOTO eatVampireHeartFinal
  IF ~PartyHasItem("VVHULVAR")~ THEN REPLY ~Take the heart of Ulvaryl.~ DO ~TakePartyItem("VVHULVAR")
   DestroyItem("VVHULVAR")~ GOTO eatVampireHeartFinal
  IF ~PartyHasItem("VVHVYNN")~ THEN REPLY ~Take the heart of Saradush vampire courtesan.~ DO ~TakePartyItem("VVHVYNN")
   DestroyItem("VVHVYNN")~ GOTO eatVampireHeartFinal
  IF ~PartyHasItem("VVHMARIS")~ THEN REPLY ~Take the heart of Saradush vampire prostitute.~ DO ~TakePartyItem("VVHMARIS")
   DestroyItem("VVHMARIS")~ GOTO eatVampireHeartFinal
  IF ~PartyHasItem("VVHPHLYD")~ THEN REPLY ~Take the heart of Phlydian.~ DO ~TakePartyItem("VVHPHLYD")
   DestroyItem("VVHPHLYD")~ GOTO eatVampireHeartFinal
  IF ~PartyHasItem("VVHSHYR")~ THEN REPLY ~Take the heart of Shyressa.~ DO ~TakePartyItem("VVHSHYR")
   DestroyItem("VVHSHYR")~ GOTO eatVampireHeartFinal
  IF ~PartyHasItem("VVDEREK")~ THEN REPLY ~Take the heart of Derek.~ DO ~TakePartyItem("VVDEREK")
   DestroyItem("VVDEREK")~ GOTO eatVampireHeartFinal
  IF ~PartyHasItem("VVHPHREY")~ THEN REPLY ~Take the heart of Phrey.~ DO ~TakePartyItem("VVHPHREY")
   DestroyItem("VVHPHREY")~  GOTO eatVampireHeartFinal
  IF ~PartyHasItem("VVHKALI2")~ THEN REPLY ~Take the heart of Lilith.~ DO ~TakePartyItem("VVHKALI2")
   DestroyItem("VVHKALI2")~ GOTO eatVampireHeartFinal
  IF ~PartyHasItem("VVHKALI3")~ THEN REPLY ~Take the heart of Blood Raven.~ DO ~TakePartyItem("VVHKALI3")
   DestroyItem("VVHKALI3")~ GOTO eatVampireHeartFinal
  IF ~PartyHasItem("VVHKALI4")~ THEN REPLY ~Take the heart of Marial Delsol~ DO ~TakePartyItem("VVHKALI4")
   DestroyItem("VVHKALI4")~ GOTO eatVampireHeartFinal
  IF ~PartyHasItem("VVHCLAIR")~ THEN REPLY ~Take the heart of Clairis.~ DO ~TakePartyItem("VVHCLAIR")
   DestroyItem("VVHCLAIR")~ GOTO eatVampireHeartFinal
  IF ~PartyHasItem("VVHDAERT")~ THEN REPLY ~Take the heart of lord Daerthmac.~ DO ~TakePartyItem("VVHDAERT")
   DestroyItem("VVHDAERT")~ GOTO eatVampireHeartFinal
  IF ~PartyHasItem("VVDRAGO")~ THEN REPLY ~Take the heart of Dragomir.~ DO ~TakePartyItem("VVDRAGO")
   DestroyItem("VVDRAGO")~ GOTO eatVampireHeartFinal  
   IF ~~ THEN REPLY ~No, Dahlia, I will not give you a heart. I was joking.~ DO ~IncrementGlobal("JokingOnHeart","LOCALS",1)~ GOTO eatVampireHeartFinal2
END

IF ~~ eatVampireHeartFinal
  SAY ~Your promise is fulfilled, <CHARNAME>.~
  IF ~Global("KeepHeart","LOCALS",2)~ DO ~SetGlobal("DahliaGetVampireHeart","GLOBAL",1)~ GOTO eatCVampireHeartEat
  IF ~Global("KeepHeart","LOCALS",1)~ DO ~SetGlobal("DahliaGetVampireHeart","GLOBAL",1)~ GOTO eatCVampireHeartTake
END

IF ~~ eatCVampireHeartTake
  SAY ~Now heart is with me as my insurance. I will continue to fight on your side, <CHARNAME>.~
  IF ~~ THEN DO ~SetGlobal("HasHeart","LOCALS",1)~ EXIT
END


IF ~~ eatCVampireHeartEat
  SAY ~Excuse me, <CHARNAME>. I must eat it immediately.~
  =
  ~(Dahlia sits down and begins to tear the heart with her elegant teeth.)~
  =
  ~(At first the dried heart doesn't alloy to rip it apart.)~
  =
  ~(But at last first drops of black blood fall into Dahlia's mouth.)~
  =
  ~(After some time she managed to eat most of heart.)~
  =
  ~(Her body starts to convulse...)~
  IF ~~ THEN DO ~AdvanceTime(TEN_MINUTES)
SetGlobal("AteHeart","LOCALS",1)~ EXIT
END


IF ~~ eatVampireHeartFinal2
  SAY ~You are joking on my life, <CHARNAME>?~
  IF ~GlobalGT("JokingOnHeart","LOCALS",1)~ THEN GOTO  eatVampireHeartFinalHate
  IF ~GlobalLT("JokingOnHeart","LOCALS",1)~ THEN DO ~IncrementGlobal("Happiness","LOCALS",-1000)~ GOTO  eatVampireHeartFinalBad
END

IF ~~ eatVampireHeartFinalBad
  SAY ~Don't joke with it, <CHARNAME>. It will end badly.~
  IF ~~ THEN DO ~~ EXIT
END

IF ~~ eatVampireHeartFinalHate
  SAY ~No more of this mockery!~
  IF ~~ THEN DO ~LeaveParty()
Enemy()~ EXIT
END
  