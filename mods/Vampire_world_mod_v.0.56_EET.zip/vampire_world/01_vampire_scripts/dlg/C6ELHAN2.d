EXTEND  C6ELHAN2 66  #0
 IF ~IsValidForPartyDialog("c6bodhi")
InParty("c6bodhi")~ THEN REPLY ~This murderous vampire Bodhi is with me, anyway.~ GOTO BodhiHere
 IF ~IsValidForPartyDialog("c6bodhi")
InParty("c6bodhi")~ THEN REPLY ~My dear murderous Bodhi, show Elhan true crisis!~ GOTO BodhiElhan1
 IF ~Dead("c6bodhi")~ THEN REPLY ~You are a jerk, Elhan. Bodhi had all the rights to bring revenge and yet you have killed her by setting me on her.~ GOTO BodhiElhan2
END


APPEND C6ELHAN2




IF ~~ BodhiElhan1
  SAY ~What?! This is Bodhi?!~
 IF ~~ THEN GOTO  BodhiElhanKill
END

IF ~~ BodhiElhanKill
 SAY ~Elves, to arms, the enemy is here!~
  IF ~~ THEN DO ~SetGlobal("SummonElvenGod","AR2500",2)
	SetGlobal("GoodElfKill","GLOBAL",3)
	SetGlobal("BodhiTalkOnElves","LOCALS",2)
Enemy()~ EXIT
END

IF ~~ BodhiElhan2
SAY ~She was a menace to our kind. If even a child will be a menace to Suldanessellar, I will kill him without any throughts.~
IF ~~ THEN DO ~~ GOTO 78
END

IF ~~ BodhiHere
  SAY ~What?! This is Bodhi?!~
 =
 ~You were ordered to kill her, not to bring her at our home again!~
IF ~~ THEN REPLY ~She will help me defeat Irenicus.~ GOTO  BodhiHere2
IF ~~ THEN REPLY ~Bodhi, kill this fool!~ GOTO BodhiElhan1
END

IF ~~ BodhiHere2
  SAY ~Bodhi will go nowhere near Suldanessellar!~
IF ~~ THEN REPLY ~She is under my protection. And you don't have a luxury of time in your hands.~ GOTO  BodhiHere3
IF ~~ THEN REPLY ~Bodhi, kill this fool!~ GOTO BodhiElhan1
END


IF ~~ BodhiHere3
  SAY ~If she is with you, than I will concider you an equal treat to us!~
IF ~~ THEN REPLY ~Eltan, calm down. She is changing. I will look for her.~ GOTO  BodhiHere4
IF ~~ THEN REPLY ~Bodhi, kill this fool!~ GOTO BodhiElhan1
END

IF ~~ BodhiHere4
  SAY ~Well, if she will throw some trick, you all will be eliminated.~
IF ~~ THEN DO ~~ GOTO 78
END


END