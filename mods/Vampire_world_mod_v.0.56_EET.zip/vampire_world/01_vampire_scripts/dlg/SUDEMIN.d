EXTEND  SUDEMIN 16 #0
  IF ~InParty("c6bodhi")~ THEN REPLY ~Dear Bodhi, drive her to a true madness.~ DO ~SetGlobal("BodhiMadness","LOCALS",1)~ GOTO BodhiDemin1
END

EXTEND SUDEMIN 31 #0
  IF ~InParty("c6bodhi")~ THEN REPLY ~Dear Bodhi, drive her to a true madness.~ DO ~~ GOTO BodhiDemin1
END

EXTEND SUDEMIN 35 #0
  IF ~InParty("c6bodhi")~ THEN REPLY ~Bodhi is with me, we will stop Irenicus.~ DO ~~ GOTO BodhiDemin1
END

APPEND SUDEMIN
IF ~~ BodhiDemin1
  SAY ~Bodhi is with you?! I must have forgotten how she looks.~
  IF ~~ THEN REPLY ~Prepare to die, bitch!~ GOTO 40
  IF ~~ THEN REPLY ~Bodhi will help us fight Irenicus. Leave her be.~ GOTO BodhiDemin3
  IF ~Global("BodhiMadness","LOCALS",1)~ THEN REPLY ~How covenient, a selective amnesia. Bodhi, remind her about you.~ GOTO BodhiDemin2
END

IF ~~ BodhiDemin3
  SAY ~I don't believe she changed in last days much more, than in her other lifetime. She must be killed immediately.~
  IF ~~ THEN REPLY ~That's you who will be killed immediately.~ GOTO 40  
  IF ~~ THEN REPLY ~She is under my protection, Demin. We need her help in dealing with Irenicus.~ GOTO 39
  IF ~~ THEN REPLY ~She is under my protection, Demin. And she will change, I promise.~ GOTO 39  
END

IF ~~ BodhiDemin2
  SAY ~For Suldanessellar!~
  IF ~~ THEN DO ~~ GOTO 40
END


END