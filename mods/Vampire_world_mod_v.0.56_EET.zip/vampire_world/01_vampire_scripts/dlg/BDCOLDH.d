EXTEND  BDCOLDH 37 #0
  IF ~Class(Player1,MAGE)
    !Race(Player1,LICH)~ THEN REPLY ~Can you make me into a lich, great Coldhearth?~ DO ~~ GOTO LichPlayer1
  IF ~
  IsValidForPartyDialog(Player2)
  !Race(Player2,LICH)
  Class(Player2,MAGE)~ THEN REPLY ~Can you make <PLAYER2> into a lich, great Coldhearth?~ DO ~~ GOTO LichPlayer2
  IF ~
  IsValidForPartyDialog(Player3)
    !Race(Player3,LICH)
  Class(Player3,MAGE)~ THEN REPLY ~Can you make <PLAYER3> into a lich, great Coldhearth?~ DO ~~ GOTO LichPlayer3
  IF ~
  IsValidForPartyDialog(Player4)
    !Race(Player4,LICH)
  Class(Player4,MAGE)~ THEN REPLY ~Can you make <PLAYER4> into a lich, great Coldhearth?~ DO ~~ GOTO LichPlayer4
  IF ~
  IsValidForPartyDialog(Player5)
    !Race(Player5,LICH)
  Class(Player5,MAGE)~ THEN REPLY ~Can you make <PLAYER5> into a lich, great Coldhearth?~ DO ~~ GOTO LichPlayer5
  IF ~
  IsValidForPartyDialog(Player6)
    !Race(Player6,LICH)
  Class(Player6,MAGE)~ THEN REPLY ~Can you make <PLAYER6> into a lich, great Coldhearth?~ DO ~~ GOTO LichPlayer6
END

APPEND BDCOLDH

IF ~~ LichPlayer1
   SAY ~Yes, I can. For a sum of 100000 gold, of cause.~
   IF ~PartyGoldGT(100000)~ THEN REPLY ~Here are my money. Begin the ritual, lich!~ DO ~SetGlobal("LichPlayer1","GLOBAL",1)
      TakePartyGold(100000)
   DestroyGold(100000)~ EXIT
   IF ~~  THEN REPLY ~Perhaps, later.~ EXIT
END
   
IF ~~ LichPlayer2
   SAY ~Yes, I can. For a sum of 100000 gold, of cause.~
   IF ~PartyGoldGT(100000)~ THEN REPLY ~Here are my money. Begin the ritual, lich!~ DO ~SetGlobal("LichPlayer2","GLOBAL",1)
      TakePartyGold(100000)
   DestroyGold(100000)~ EXIT
   IF ~~  THEN REPLY ~Perhaps, later.~ EXIT
END

IF ~~ LichPlayer3
   SAY ~Yes, I can. For a sum of 100000 gold, of cause.~
   IF ~PartyGoldGT(100000)~ THEN REPLY ~Here are my money. Begin the ritual, lich!~ DO ~SetGlobal("LichPlayer3","GLOBAL",1)
   TakePartyGold(100000)
   DestroyGold(100000)~ EXIT
   IF ~~  THEN REPLY ~Perhaps, later.~ EXIT
END

IF ~~ LichPlayer4
   SAY ~Yes, I can. For a sum of 100000 gold, of cause.~
   IF ~PartyGoldGT(100000)~ THEN REPLY ~Here are my money. Begin the ritual, lich!~ DO ~SetGlobal("LichPlayer4","GLOBAL",1)
      TakePartyGold(100000)
   DestroyGold(100000)~ EXIT
   IF ~~  THEN REPLY ~Perhaps, later.~ EXIT
END

IF ~~ LichPlayer5
   SAY ~Yes, I can. For a sum of 100000 gold, of cause.~
   IF ~PartyGoldGT(100000)~ THEN REPLY ~Here are my money. Begin the ritual, lich!~ DO ~SetGlobal("LichPlayer5","GLOBAL",1)
      TakePartyGold(100000)
   DestroyGold(100000)~ EXIT
   IF ~~  THEN REPLY ~Perhaps, later.~ EXIT
END

IF ~~ LichPlayer6
   SAY ~Yes, I can. For a sum of 100000 gold, of cause.~
   IF ~PartyGoldGT(100000)~ THEN REPLY ~Here are my money. Begin the ritual, lich!~ DO ~SetGlobal("LichPlayer6","GLOBAL",1)
      TakePartyGold(100000)
   DestroyGold(100000)~ EXIT
   IF ~~  THEN REPLY ~Perhaps, later.~ EXIT
END

IF ~Global("BD_DOD_DSC_SUPPORT","GLOBAL",1)~
 THEN BEGIN  lichdome1
 SAY ~I told you to leave this place. I will respect my side of deal. Now begone!~
   IF ~~ THEN EXIT
  IF ~  Class(Player1,MAGE)
!Race(Player1,LICH)
~ THEN REPLY #456890 /* ~Can you make me into a lich, great Coldhearth?~ */ GOTO LichPlayer1
  IF ~  IsValidForPartyDialogue(Player2)
!Race(Player2,LICH)
Class(Player2,MAGE)
~ THEN REPLY #456891 /* ~Can you make <PLAYER2> into a lich, great Coldhearth?~ */ GOTO LichPlayer2
  IF ~  IsValidForPartyDialogue(Player3)
!Race(Player3,LICH)
Class(Player3,MAGE)
~ THEN REPLY #456892 /* ~Can you make <PLAYER3> into a lich, great Coldhearth?~ */ GOTO LichPlayer3
  IF ~  IsValidForPartyDialogue(Player4)
!Race(Player4,LICH)
Class(Player4,MAGE)
~ THEN REPLY #456893 /* ~Can you make <PLAYER4> into a lich, great Coldhearth?~ */ GOTO LichPlayer4
  IF ~  IsValidForPartyDialogue(Player5)
!Race(Player5,LICH)
Class(Player5,MAGE)
~ THEN REPLY #456894 /* ~Can you make <PLAYER5> into a lich, great Coldhearth?~ */ GOTO LichPlayer5
  IF ~  IsValidForPartyDialogue(Player6)
!Race(Player6,LICH)
Class(Player6,MAGE)
~ THEN REPLY #456895 /* ~Can you make <PLAYER6> into a lich, great Coldhearth?~ */ GOTO LichPlayer6
END

END