EXTEND  SUELHAN  2 #0
  IF ~~ THEN REPLY ~Actually you helped me to get to Suldanessellar, now your usefulness ends. Prepare to die!~ GOTO DieElf
  IF ~InParty("c6bodhi")~ THEN REPLY ~Bodhi, now you finally can kill this jerk!~ GOTO DieElf2
END

EXTEND  SUELHAN  3 #0
  IF ~~ THEN REPLY ~Their safety is in danger, as soon as I start murdering little scared elves!~ GOTO DieElf
  IF ~InParty("c6bodhi")~ THEN REPLY ~Bodhi, now you finally can kill this jerk!~ GOTO DieElf2
END

EXTEND  SUELHAN  57 #0
  IF ~InParty("c6bodhi")~ THEN REPLY ~Bodhi, show him some charm and send him to Hell!~ GOTO DieElf2
END

EXTEND  SUELHAN  58 #0
  IF ~InParty("c6bodhi")~ THEN REPLY ~Bodhi, you have heard? You are departed! Show him how departed kill!~ GOTO DieElf2
END

EXTEND  SUELHAN  62 #0
  IF ~~ THEN REPLY ~We will deal with Irenucis, but now it is your time, elf!~ GOTO DieElf
  IF ~InParty("c6bodhi")~ THEN REPLY ~Bodhi, drain his blood till the last drop!~ GOTO DieElf2
END

EXTEND  SUELHAN  68 #0
  IF ~~ THEN REPLY ~Only in Hell, stoopid elf. And now die!~ GOTO DieElf
  IF ~InParty("c6bodhi")~ THEN REPLY ~Bodhi, make sure we will not meet him again in this world!~ GOTO DieElf2
END

APPEND SUELHAN


IF ~~ DieElf
  SAY ~What? A treason?~
  =
  ~How foolish I've been to allow you to get to Suldanessellar!~
  IF ~~ THEN DO ~Enemy()~ EXIT
END

IF ~~ DieElf2
  SAY ~What? You ARE Bodhi?! I throught <CHARNAME> killed you.~
  =
  ~How foolish I've been to allow you to get to Suldanessellar!~
  IF ~~ THEN DO ~Enemy()~ EXIT
END


END

