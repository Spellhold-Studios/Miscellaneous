EXTEND  HEXXAT  0 #0
  IF ~Race(Player1,VAMPIRE)~ THEN REPLY ~Was it tasty?~ GOTO BloodDrink1
  IF ~!Race(Player1,VAMPIRE)
  General(Player1,UNDEAD)~ THEN REPLY ~Have a good meal.~ GOTO BloodDrink2
END


APPEND HEXXAT


IF ~~ BloodDrink1
  SAY ~Imagine abstinence from blood for years. Any blood will have a taste of Heavens.~
  =
  ~I am Hexxat of Mezro. And you are <CHARNAME>, my kinsman in blood and Bhaalspawn.~
  IF ~~ THEN DO ~~ GOTO 12 
END

IF ~~ BloodDrink2
  SAY ~Any meal will taste good if delayed for years.~
  =
  ~I am Hexxat of Mezro. And you are <CHARNAME>, my relative in undeath and Bhaalspawn.~
  IF ~~ THEN DO ~~ GOTO 12 
END


END

