Vampire World v. 0.56

by Lassal

MEAN NOTE 1 - To play VW you need to have EET installed (BG1 EE+SOD+BG2 EE).

MEAN NOTE 2 - This mod will not work good without Portraits Portraits Everywhere Mod (it uses portraits from this mod, but I strive to allow replacing all portraits by Creative Commons C0 portraits from Pixabay or similar sites).

MEAN NOTE 3 - This mod is only for English and it will be so until I will decide, that I have done all dialogues (so it will be in very distant future). And my English is not good. So you could have a heart attack reading texts.:-)

MEAN NOTE 4 - Portraits, that are available in this mod, all have Creative Commons C0 license and don't require mentioning author. More of it, most of them are renders, so no person could say he don't want his face in mod. 
If you can draw a good vampires portraits that fit BG1/2, you can send them to me and I will be using them instead of PPE ones.

This is early demo. Don't know when I will finish or will I finish mod at all (most of NPC have minimum banters and don't interact with others).
Some things may not work as intended.
If you want to make vampires party, you will need joining Vynona for BG1/SOD part: she sells cloaks of Korkorran that allow vampires to travel at day (at least until you bought a good amount of them from her).
What characteristics new made vampire gets? It depends on the one that made you a vampire (if made through dialog).
Most of convertation lead to gaining strength and constitution and loss of wisdom and intelligence (hunger is not a good friend for research). So when generating new character, try to give maximum points at wisdom and intelligence, if you want a mage or cleric).
When scenario vampires are killed, your protagonist acquires vampire's hearts. They still contain powers of vampires. You can resurrect such vampires in pool of blood in Bodhi's crypt at Athkatla's graveyard, placing there their hearts.
Or you can simply eat vampire's heart and become a vampire this way.
You can devour vampire's heart and gain primary parameters increase, if you are a vampire yourself.


Part 1.
Vampire scripts for player and party members

Scripts use DPLAYER2/3 so don't turn off party AI.
Scripts allow to convert party members and some NPCs to vampires.
When party member is attacked by zombie, ghoul or lycanthrope, he/she can become one.
Also, when you start a game, you can enter Candlekeep tavern and talk to yourself - you will choose your race then (vampire, lycanthrope, demonic, drow).
Drow will walk freely to Ust Natha not requiring Adalon's help.
Lycanthrope and vampire will be able to convert some NPCs to their kind (if mod 'Mercenaries of Sword Coast for EET' is installed).
Remember, that when you or your party members are converted to vampires, there is small possibility that you will become ghoul or damphire instead.

Part 2.
Two new joinable characters for playing vampire.
First one - Vynona - can be found in Friendly Arm Inn.
She needs main hero to become vampire. She will join after that only. She attacks lycanthropes and demons.
She currently has only two missions - to get to Underground City in Baldur's Gate and find a vampire scout Nami (for BG1 part) and to find artifical blood receipt for all vampire kind (for BG2 part, Hexxat quests in TOB and Phreya joining party are required).
Nami also can be joining party (if Vynona is in it). 

Part 3.
Vampire Tsolak can be resurrected at Bodhi's crypt, if he is killed in SOD and you used stake to his coffin (you will get his heart and can place it in blood container in spikes room).

Part 4.
Bodhi is joinable or resurrectable after defeating her in her crypt. You must propose her something good for her.
If she is killed, you can take her heart and place it in blood container in spikes room.
If she is joined in party, you can go with her straight to elven city (with Lanthorn in pockets) and she will get you straight to Jon (without licking elven boots). You have option to aid her and let Jon kill Tree of Life.
Bodhi got few additional dialogs. Bodhi got interjection with Jon and Ellesime's apparition. 
If you let her leave Imoen's soul for herself, she will gain Slayer transformation ability in Bhaal's Plane. If not, she will ask you for Malla's soul. 
Bodhi receives two new talks in Pocket Plane. One is for a case player didn't win Bodhi's heart, and second is her love confession (doesn't require romance from part 15).

Part 5. 
Bodhi Stronghold.
If you are vampire, let Bodhi join you, have not killed any vampires in coffins by stakes (during assault on crypt for Shadow Thieves or during assault after Underdark), she will propose you to rule all vampires in Ahkatla. 
Note, that if you are a vampire and have eaten vampire's heart, you will not get vampire's stronghold, you will smell like cannibal.
If you agree, you will get few 'kill them' quests from Bodhi.
Until priests in Ahkatla are not killed, from your first seconds as vampire you will be attacked in few areas by vampire hunters. So it's better to get Bodhi's Stronghold and do what she says.
All Bodhi vampires can be resurrected via pool of blood (you must have their hearts) and join party.
Cohn Ta'Glaen sells vampire goods and let buy rest.
Gellal gives a simple quest to organize a feast, if player becomes master/mistress of Vampire Stronghold.  
Note that if you place dead bodies into pool, you will raise allied ghouls, zombies or skeletons.

Part 6. 
Dead lovers (Anomen, Jaheira, Aerie, Viconia).
You can place killed lovers bodies into pool and they will be resurrected as vampires instead of regaining normal form.
They have almost no dialogs yet and for a seen future.

Part 7
Phlydian, a vampire courtesan, can be talked to join party in Saradush prison.

Part 8.
Shyressa, a member and former of Twisted Rune, is joinable. You must kill all other Twisted Rune members and she will acknowledge defeat.

Part 9.
Derek, a male vampire, that lives in cellar of burnt house in Bloodbark Grove, is recruitable and resurrectable.
He a vulgar redneck and virgin, harassing main heroine (if adult romances are enabled).
Epilogues are added.

Part 10.
Phreya, a vampiress in Korkorran's Crypt, that knows Hexxat, is joinable and resurrectable. Note, that you will need her joining for Vynona quest (not neccesary through). 

Part 11. New Solar choices.
You can make new choices in dialogue with Solar, and she will make them true. There is one choice for each Hexxat, Bodhi and Vynona in party (if they love you - Vynona's romance is not implemented yet). 


Part 12. Kali Cult can be joined

Includes New Miriam's and Kali Cult Creative Commons C0 portraits (mod Vampire Tales by Raven must be installed first)
Now you can join Kali Cult. If you are not vampire, you must agree to join Kali Cult and you will be converted by Lilith.
Note, that if you are a vampire and have eaten vampire's heart, you will be attacked by Cult.
After joining Kali Cult you get possibility to join to party Lilith, Blood Raven and Marial del Sol.
Members of Kali Cult have epilogues and additional choice from Solar at the end.

PS About half of year I tried to contact Raven and asked other people. But with no result. If you are Raven and you don't want me to modify your mod Vampire Tales, I will exclude support of it at next versions. 

Part 13. Clairis and Lord Daerthmac are ressurectable and joinable.

After defeat of vampire couple you must go to their tomb and demand to either flee (for a large sum of gold from them) or to join your party.
Clairis and Daerthmac have epilogues. 

PS I wrote K4thos about permissions to alter DSotSC, but got no answer. Few months passed. If K4thos is against using Clairis and Lord Daerthmac in mod, he can contact me and I will exclude support of DSotSC.

Part 14. Joinable damphire fighter Dahlia

This submod requires installing DSotSC and Clairis and Lord Daerthmac mod.
When Clairis and Daerthmac are defeated or joined, you must visit 3rd floor of castle tower (with bath) after a few days,
Dahlia will be there. She joins only if main character is a vampire or damphire.

Part 15. Dragomir is resurrectable and joinable (he must be killed in Dragomir's Tomb and resurrected in Bodhi's Stronghold)

Part 16. Vampire companions can be summoned to Pocket Plane.

If a vampire was in party at least once, she/he can be summoned to pocket plane.

PS About future versions that may come or not come.

Part 17. Vampire companions have adult romances 

Rated 18+ only. If you are under this age or don't tolerate undead sex relations and violence, you are forbidden to install this part of mod

All talks initiate in areas that not outdoor - vampires fear sun.

Includes:
- Bodhi (8 romance relation talks, starting in TOB, protagonist must be male, to start romance Bodhi's requests must be completed and you must not lout her)
- Derek (14 romance talks, protagonist must be of vampire race and female. Starts despite the desire of the protagonist)
- Salia (10 romance talks, protagonist must be of vampire race and male. Girdle of Gender is recommended to be in inventory)


NPCs dialogues and quests would be extended if I'd have time.