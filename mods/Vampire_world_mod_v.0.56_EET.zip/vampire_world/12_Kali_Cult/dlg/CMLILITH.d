// creator  : C:\GOG Games\baldur's gate ii - enhanced edition\weidu.exe (version 24200)
// argument : CMLILITH.DLG
// game     : .
// source   : ./override/CMLILITH.DLG
// dialog   : .\lang\en_us\dialog.tlk
// dialogF  : (none)

BEGIN ~CMLILITH~

IF ~~ THEN BEGIN 0 // from:
  SAY @1 /* ~Gabrielle says hi!~ #274725 */
END

IF ~  NumTimesTalkedTo(0)
!InParty("cmgmiriam")
!Dead("cmgblood")
!Dead("cmmarial")
~ THEN BEGIN 1 // from:
  SAY @2 /* ~Well, well look at this beautiful looking creature ladies, this <PRO_RACE> looks like a good candidate to be one with us.~ #274726 */
  IF ~~ THEN EXTERN ~CMGBLOOD~ 1
END

IF ~~ THEN BEGIN 2 // from:
  SAY @3 /* ~Marial, you are a hard one to please, but I do believe they would make a good addition to our cult. I can feel the power coming from <PRO_HIMHER>.~ #274727 */
  IF ~~ THEN REPLY @4 /* ~Blood, "be one with us", and cults what in the nine hells are you talking about?~ #274728 */ GOTO 3
END

IF ~~ THEN BEGIN 3 // from: 2.0
  SAY @5 /* ~I am glad you asked. I was starting to think you were a mute or perhaps too timid, a sign of weakness I may add, to seek an answer. We are followers of the great goddess of the past named Kali. She is the Mother of the Children of the Night and the only true god in the realms. She needs followers so she can be reborn again and gain her once prestige state of godhood. The power I feel coming from you would be a great asset to her rebirth.~ #274729 */
  IF ~~ THEN EXTERN ~CMGBLOOD~ 2
END

IF ~~ THEN BEGIN 4 // from:
  SAY @6 /* ~Now let�s not be too demanding of <CHARNAME>. It is <CHARNAME> right. Already your thoughts are becoming one with us. Come my child and become one of the Children of the Night.~ #274730 */
  IF ~Race(Player1,VAMPIRE)~ THEN REPLY @7 GOTO 14 
  IF ~!Race(Player1,VAMPIRE)
  Global("Player1RaceBlood","GLOBAL",4)~ THEN REPLY @7 /* ~Sure why not I�ll join you.~ #274731 */ GOTO 15
  IF ~!Race(Player1,VAMPIRE)
  !Global("Player1RaceBlood","GLOBAL",4)~ THEN REPLY @7 /* ~Sure why not I�ll join you.~ #274731 */ GOTO 5  
  IF ~~ THEN REPLY @8 /* ~Surely I will not. This sounds like some vampire cult and I refuse to join.~ #274732 */ GOTO 6
  IF ~~ THEN REPLY @9 /* ~You are evil and will die!~ #274733 */ GOTO 9
END

IF ~~ THEN BEGIN 5 // from: 4.0
  SAY @10 /* ~Very good to hear hahahaha.~ #274734 */
  IF ~~ THEN DO ~Kill(Player1)
~ EXIT
END

IF ~~ THEN BEGIN 6 // from: 4.1
  SAY @11 /* ~Think it over carefully, <CHARNAME>, making an enemy with us is not in your best interest.~ #274735 */
  IF ~~ THEN EXTERN ~CMMARIAL~ 2
END

IF ~~ THEN BEGIN 7 // from:
  SAY @12 /* ~I am sorry to say my, sisters, but <CHARNAME> has no desire to be one with us. Unfortunate but not a total loss my friends. We will feed of <PRO_HISHER> life essence and make us more powerful. In the end it�s <CHARNAME>�s loss and our gain.~ #274736 */
  IF ~~ THEN EXTERN ~CMMARIAL~ 3
END

IF ~~ THEN BEGIN 8 // from:
  SAY @13 /* ~Enough talk my, sisters, its time to let the blood flow.~ #274737 */
  IF ~~ THEN DO ~SetGlobal("CmgKaliHostile","GLOBAL",1)
Enemy()
~ EXIT
END

IF ~~ THEN BEGIN 9 // from: 4.2
  SAY @14 /* ~A stupid choice but good for you because it will be your last.~ #274738 */
  IF ~~ THEN DO ~SetGlobal("CmgKaliHostile","GLOBAL",1)
Enemy()
~ EXIT
END

IF ~  Detect("cmgmiriam")
InParty("cmgmiriam")
See("cmgmiriam")
!StateCheck("cmgmiriam",STATE_SLEEPING)
Global("CmgSeeMiriam","GLOBAL",0)
~ THEN BEGIN 10 // from:
  SAY @15 /* ~Look at this, sisters, one of our kind is with this group of warm bloods.~ #274774 */
  IF ~~ THEN DO ~SetGlobal("CmgSeeMiriam","GLOBAL",1)
~ EXTERN ~CMMARIAL~ 4
END

IF ~~ THEN BEGIN 11 // from:
  SAY @16 /* ~There is something odd about the aura of this one, sisters. Something strange indeed.~ #274778 */
  IF ~~ THEN EXTERN ~CMGMIRIJ~ 105
END

IF ~~ THEN BEGIN 12 // from:
  SAY @17 /* ~She is not one of us my, sisters. Look closely at her aura. She's a diablerist, one that drains the blood of her own kind!~ #274782 */
  IF ~~ THEN EXTERN ~CMMARIAL~ 6
END

IF ~~ THEN BEGIN 13 // from:
  SAY @18 /* ~Disgusting creature! She enjoys killing her own kind!~ #274786 */
  IF ~~ THEN EXTERN ~CMGMIRIJ~ 107
END


IF ~~ THEN BEGIN 14 // from: 4.0
  SAY @19 /* ~Very good to hear hahahaha.~ #274734 */
  IF ~Global("Player1CannibalVampire","GLOBAL",0)~ THEN DO ~
~ GOTO 18
  IF ~!Global("Player1CannibalVampire","GLOBAL",0)~ THEN DO ~
~ GOTO 19
END

IF ~~ THEN BEGIN 15 // from: 4.0
  SAY @20 /* ~Very good to hear hahahaha.~ #274734 */
  IF ~~ THEN DO ~ActionOverride(Player1,SetGlobal("ActorVampirisedLevel","LOCALS",1))
~ GOTO 18
END

IF ~~ THEN BEGIN 18 // from: 4.0
  SAY @22 /* ~Very good to hear hahahaha.~ #274734 */
  IF ~~ THEN DO ~SetGlobal("JoinedKaliCult","GLOBAL",1)

ActionOverride("cmgblood",SetDialog("CMGKALI3"))
ActionOverride("cmmarial",SetDialog("CMGKALI4"))  
  
   ChangeAIScript("CMGKALI2",GENERAL)
ActionOverride("cmgblood",ChangeAIScript("CMGKALI3",GENERAL))
ActionOverride("cmmarial",ChangeAIScript("CMGKALI4",GENERAL))   
  SetDialog("CMGKALI2")

//ActionOverride("cmgblood",DestroyItem("VVHKALI3")) // Empty Casket		
//ActionOverride("cmmarial",DestroyItem("VVHKALI4")) // Empty Casket	 
//    DestroyItem("cmgforg1")
//GiveItemCreate("VVCASKET",Myself,1,1,0) // Empty Casket	
//ActionOverride("cmgblood",GiveItemCreate("VVCASKET",Myself,1,1,0)) // Empty Casket		
//ActionOverride("cmmarial",GiveItemCreate("VVCASKET",Myself,1,1,0)) // Empty Casket	
  
~ EXIT
END



IF ~~ THEN BEGIN 19 // from: 4.0
  SAY ~Wait, sisters! This one is not of our kind.~
  =
  ~This is a cannibal killing our sisters and brothers to gain power.~
  =
  ~We must stop this sinner!~
  IF ~~ THEN DO ~SetGlobal("CmgKaliHostile","GLOBAL",1)
Enemy()~  EXIT
END