BEGIN SARVAM01


IF ~See(Player1)
Gender(Myself,FEMALE)
Race(Player1,VAMPIRE)
NumTimesTalkedTo(0)~ THEN BEGIN startInitTalk
  SAY ~What?! A child of Bhaal? Here?! Damn the wenches for their lustful hearts... they were warned to stay away from the blood of gods, no matter how sweet!~
  ++ ~I guess I'm just too irresistible for the likes of you.~ + talkInit1fv
  ++ ~I defeated them, but they will surely recover. I was gentle with them.~ + talkInit2f
  ++ ~I can understand them. I also prefer to drink blood of gods.~ + talkInit1fv
  ++ ~Die, vampire scum!~ + talkEndInitFight1
END

IF ~See(Player1)
!Gender(Myself,FEMALE)
Race(Player1,VAMPIRE)
NumTimesTalkedTo(0)~ THEN BEGIN startInitTalk
  SAY ~What?! A child of Bhaal? Here?! Damn the wenches for their lustful hearts... they were warned to stay away from the blood of gods, no matter how sweet!~
  ++ ~I guess I'm just too irresistible for the likes of you.~ + talkInit1mv
  ++ ~I defeated them, but they will surely recover. I was gentle with them.~ + talkInit2f
  ++ ~I can understand them. I also prefer to drink blood of gods.~ + talkInit1mv
  ++ ~Die, vampire scum!~ + talkEndInitFight1
END

IF ~See(Player1)
Gender(Myself,FEMALE)
!Race(Player1,VAMPIRE)
NumTimesTalkedTo(0)~ THEN BEGIN startInitTalk
  SAY ~What?! A child of Bhaal? Here?! Damn the wenches for their lustful hearts... they were warned to stay away from the blood of gods, no matter how sweet!~
  ++ ~I guess I'm just too irresistible for the likes of you.~ + talkInit1f
  ++ ~I defeated them, but they will surely recover. I was gentle with them.~ + talkInit2f
  ++ ~Die, vampire scum!~ + talkEndInitFight1
END



IF ~See(Player1)
!Gender(Myself,FEMALE)
!Race(Player1,VAMPIRE)
NumTimesTalkedTo(0)~ THEN BEGIN startInitTalk
  SAY ~What?! A child of Bhaal? Here?! Damn the wenches for their lustful hearts... they were warned to stay away from the blood of gods, no matter how sweet!~
  ++ ~I guess I'm just too irresistible for the likes of you.~ + talkInit1m
  ++ ~I defeated them, but they will surely recover. I was gentle with them.~ + talkInit2f
  ++ ~Die, vampire scum!~ + talkEndInitFight1
END

IF ~~ talkInit2f
  SAY ~Why you were gentle with them?~
  ++ ~I like vampires.~ + talkLoveVampF
  ++ ~I am a vampire myself.~ + talkVampF
  ++ ~I don't suppose you'd just let me pass by without a fuss?~ + talkInitFussF
END

IF ~~ talkInit1fv
  SAY ~You... you are a powerful one of your kind. I can smell the murder in your heart. You shall never let us live, I would think.~
  ++ ~Why I would never let you live? I like vampires.~ + talkLoveVampF
  ++ ~I am a vampire myself, why I would never let them live?~ + talkVampF
  ++ ~I don't suppose you'd just let me pass by without a fuss?~ + talkInitFussF
END

IF ~~ talkInit1mv
  SAY ~You... you are a powerful one of your kind. I can smell the murder in your heart. You shall never let us live, I would think.~
  ++ ~Why I would never let you live? I like vampires.~ + talkLoveVampM
  ++ ~I am a vampire myself, why I would never let them live?~ + talkVampM
  ++ ~I don't suppose you'd just let me pass by without a fuss?~ + talkInitFussM
END

IF ~~ talkInit1f
  SAY ~You... you are a powerful one of your kind. I can smell the murder in your heart. You shall never let us live, I would think.~
  ++ ~Why I would never let you live? I like vampires.~ + talkLoveVampF
  ++ ~I don't suppose you'd just let me pass by without a fuss?~ + talkInitFussF
END

IF ~~ talkInit1m
  SAY ~You... you are a powerful one of your kind. I can smell the murder in your heart. You shall never let us live, I would think.~
  ++ ~Why I would never let you live? I like vampires.~ + talkLoveVampM
  ++ ~I don't suppose you'd just let me pass by without a fuss?~  + talkInitFussM
END



IF ~~ talkInitFussF
  SAY ~If you don't want to kill us, maybe we can break out peaceably?~
  ++ ~Yes, I would like to, dear.~ + talkPeaceF
  ++ ~Maybe you can come with us? This town isn't safe and you will die here, when Yaga Shura breaks the walls.~ + talkPartyF
  ++ ~Die, vampire scum!~ + talkEndInitFight1
END  
  
 IF ~~ talkInitFussM
  SAY ~If you don't want to kill us, maybe we can break out peaceably?~
  ++ ~Yes, I would like to, woman.~ + talkPeaceM
  ++ ~Maybe you can come with us? This town isn't safe and you will die here, when Yaga Shura breaks the walls.~ + talkPartyM
  ++ ~Die, vampire scum!~ + talkEndInitFight1
END 




IF ~~ talkLoveVampF
  SAY ~You love vampires? Maybe we can break out peaceably?~
  ++ ~Yes, I would like to, dear.~ + talkPeaceF
  ++ ~Maybe you can come with us? This town isn't safe and you will die here, when Yaga Shura breaks the walls.~ + talkPartyF
  ++ ~Die, vampire scum!~ + talkEndInitFight1
END  
  
 IF ~~ talkLoveVampM
  SAY ~You love vampires? Maybe we can break out peaceably?~
  ++ ~Yes, I would like to, woman.~ + talkPeaceM
  ++ ~Maybe you can come with us? This town isn't safe and you will die here, when Yaga Shura breaks the walls.~ + talkPartyM
  ++ ~Die, vampire scum!~ + talkEndInitFight1
END  
   
  
IF ~~ talkEndInitFight1
  SAY ~Come, then, my children... we die this night, once and forever, throwing ourselves on the merciless blade that is this godling!~
  IF ~~ THEN DO ~Enemy()~ EXIT
END

IF ~~ talkEndInitFight3
  SAY ~Rrrrrr!~
  IF ~~ THEN DO ~Enemy()~ EXIT
END

IF ~~ talkVampM
  SAY ~You are one of us? Maybe we can break out peaceably?~
  ++ ~Yes, I would like to, woman.~ + talkPeaceM
  ++ ~Maybe you can come with us? This town isn't safe and you will die here, when Yaga Shura breaks the walls.~ + talkPartyMV
END  

IF ~~ talkVampF
  SAY ~You are one of us? Maybe we can break out peaceably?~
  ++ ~Yes, I would like to, woman.~ + talkPeaceF
  ++ ~Maybe you can come with us? This town isn't safe and you will die here, when Yaga Shura breaks the walls.~ + talkPartyFV
END  




IF ~~ talkPeaceF
  SAY ~Then I will apologize for my people and will take my leave. Goodbye, and let Myrkyl keeps you from death!~
  IF ~~ THEN DO ~EscapeArea()~ EXIT
END

IF ~~ talkPeaceM
  SAY ~Then I will apologize for my people and will take my leave. Goodbye, and let Myrkyl keeps you from death!~
  IF ~~ THEN DO ~EscapeArea()~ EXIT
END

IF ~~ talkEndInitFight2f
  SAY ~Come, then, my children... we die this night, once and forever, throwing ourselves on the merciless blade that is this godling!~
  ++ ~Merciless? I am the main vampire lover in this town!~ + talkLoveVampF
  ++ ~Don't do this, missis. Maybe we will break up peacefully?~ + talkPeaceF
  ++ ~Die, vampire scum!~ + talkEndInitFight3
END


IF ~~ talkEndInitFight2m
  SAY ~Come, then, my children... we die this night, once and forever, throwing ourselves on the merciless blade that is this godling!~
  ++ ~Merciless? I am the main vampire lover in this town!~ + talkLoveVampM
  ++ ~Don't do this, woman.~ + talkPeaceM
  ++ ~Die, vampire scum!~ + talkEndInitFight3
END


IF ~~ talkPartyF
  SAY ~But there is no way out of Saradush. We tried to find a way and failed...~
  ++ ~I don't like other cattle, I have a power to escape this place any time.~ + talkParty2F
  ++ ~I have a way out.~ + talkParty2F
END  
  

IF ~~ talkPartyM
  SAY ~But there is no way out of Saradush. We tried to find a way and failed...~
  ++ ~I don't like other cattle, I have a power to escape this place any time.~ + talkParty2M
  ++ ~I have a way out.~ + talkParty2M
END  

IF ~~ talkParty2M
  SAY ~But what about my people? They will die withou me.~
  ++ ~Do you want to die with them? They are doomed anyway, if they don't think about caution.~ + talkParty3M
  ++ ~Die, vampire scum!~ + talkEndInitFight3
END

IF ~~ talkParty2F
  SAY ~But what about my people? They will die withou me.~
  ++ ~Do you want to die with them? They are doomed anyway, if they don't think about caution.~ + talkParty3F
  ++ ~Die, vampire scum!~ + talkEndInitFight3
END

 IF ~~ talkPartyMV
  SAY ~But what about my people? They will die withou me.~
  ++ ~Do you want to die with them? They are doomed anyway, if they don't think about caution.~ + talkParty3M
  ++ ~Then you must stay here with them.~ + talkPeaceF
END

IF ~~ talkPartyFV
  SAY ~But what about my people? They will die withou me.~
  ++ ~Do you want to die with them? They are doomed anyway, if they don't think about caution.~  + talkParty3F
  ++ ~Then you must stay here with them.~ + talkPeaceF
END 

IF ~~ talkParty3M
  SAY ~Maybe you are right. I don't want to die here.~
  ++ ~Then join us. I plan to kill several powerful Bhaalspawns, so you will get a plenty of god blood to suck.~ + talkParty4M
  ++ ~I decided to let you stay.~ + talkPeaceF
END  

IF ~~ talkParty3F
  SAY ~Maybe you are right. I don't want to die here.~
  ++ ~Then join us. I plan to kill several powerful Bhaalspawns, so you will get a plenty of god blood to drink.~ + talkParty4F
  ++ ~I decided to let you stay.~ + talkPeaceF
END

IF ~~ talkParty4F
  SAY ~My people! Goodbye! I will come with this powerful Bhaal child. Good luck and good hunt for all of you!~
  IF ~~ THEN DO ~GiveItemCreate("VVCASKET",Myself,1,1,0)
    MakeGlobal()
  DestroyItem("VVHPHLYD")
JoinParty()~ EXIT
END

IF ~~ talkParty4M
  SAY ~My people! Goodbye! I will come with this powerful Bhaal child. Good luck and good hunt for all of you!~
  IF ~~ THEN DO ~GiveItemCreate("VVCASKET",Myself,1,1,0)
  DestroyItem("VVHPHLYD")
  MakeGlobal()
JoinParty()~ EXIT
END




IF ~See(Player1)
  Gender(Player1,FEMALE)
  Global("PhlydianResurrected","GLOBAL",1)~
THEN BEGIN greetingStartF
   SAY ~Why did you resurrect me?~
   ++ ~I will let you live, if you will serve me.~ + briefingNV1
   ++ ~I have a weakness for women.~ + briefingNV1
   ++ ~Such beauty should not die.~ + briefingNV1   
   ++ ~Die, bitch!~ + briefing3f
END


IF ~See(Player1)
!Gender(Player1,FEMALE)
  Global("PhlydianResurrected","GLOBAL",1)~
THEN BEGIN greetingStart
   SAY ~Why did you resurrect me, a pretty boy? I was your rival back then.~
   ++ ~I will let you live, if you will serve me.~ + briefingNV1f
   ++ ~I have a weakness for women.~ + briefingNV1
   ++ ~Such beauty should not die.~ + briefingNV1   
   ++ ~Die, bitch!~ + briefing3f
END


IF ~~ briefingNV1
  SAY ~I am a courtesan. People often hate us. And I fought you in my prison.~
  ++ ~Join my party, we all have dark past and a more darker future.~ + briefing2
  ++ ~Join my party, I need your skills. Maybe all of them.~ + briefing2
  ++ ~You are free to go. I release you.~ + briefing3
  ++ ~Die, bitch!~ + briefing3f
END


IF ~~ briefingNV1f
  SAY ~I am a courtesan. People often hate us. And I fought you in my prison.~
  ++ ~Join my party, we all have dark past and a more darker future.~ + briefing2f
  ++ ~Join my party, I need your skills. Maybe all of them.~ + briefing2f
  ++ ~You are free to go. I release you.~ + briefing3
  ++ ~Die, bitch!~ + briefing3f
END

IF ~~ briefing2f
  SAY ~With pleasure. You promised me Bhaalspawn blood, my master. That's alone a very good reason.~
  IF ~~ THEN DO ~
  MakeGlobal()
  SetGlobal("PhlydianResurrected","GLOBAL",2)
  DestroyItem("VVHPHLYD")
  GiveItemCreate("VVCASKET",Myself,1,1,0) // Empty Casket		
  JoinParty()
  ~ EXIT
END

IF ~~ briefing2
  SAY ~With pleasure. You promised me Bhaalspawn blood, my mistress. That's alone a very good reason.~
  IF ~~ THEN DO ~
  MakeGlobal()
  SetGlobal("PhlydianResurrected","GLOBAL",2)
  DestroyItem("VVHPHLYD")
  GiveItemCreate("VVCASKET",Myself,1,1,0) // Empty Casket		
  JoinParty()
  ~ EXIT
END

IF ~~ briefing3f
  SAY ~No!~
  IF ~~ THEN DO ~SetGlobal("PhlydianResurrected","GLOBAL",2)
  SetGlobal("PhlydianLeft","GLOBAL",1)
Enemy()
~ EXIT
END

IF ~~ briefing3
  SAY ~Goodbye, <CHARNAME>. I will found a bordel. Come visit me, you will not be dissapointed.~
  IF ~~ THEN DO ~RunAwayFromNoInterrupt(Player1,50)
  SetGlobal("PhlydianResurrected","GLOBAL",2)
DestroySelf()
~ EXIT
END

//when thrown out
IF ~!Gender(Player1,FEMALE)
!Global("BodhiStronghold","GLOBAL",2)
!InParty(Myself)~ THEN BEGIN GreetingVManB1
SAY ~Do you need me, my master?~ 
 ++ ~Return, Phlydian, I need your skills.~ + notparty1
 ++ ~Stay here, Phlydian, I will return.~ + notparty2
  ++ ~You are free to go. I release you.~ + briefing3 
 ++ ~I decided to end your life.~ + briefing3f
END

IF ~~ notparty2
SAY ~Okay, master!~
IF ~~ THEN DO ~~ EXIT
END

IF ~Gender(Player1,FEMALE)
!Global("BodhiStronghold","GLOBAL",2)
!InParty(Myself)~ THEN BEGIN GreetingVFemB1
SAY ~Do you need me, my mistress?~ 
 ++ ~Return, Phlydian, I need you, my servant.~ + notparty1
 ++ ~Stay here, Phlydian, I will return.~ + notparty2
  ++ ~You are free to go. I release you.~ + briefing3  
 ++ ~I decided to end your life.~ + briefing3f
END

IF ~Gender(Player1,FEMALE)
Global("BodhiStronghold","GLOBAL",2)
!InParty(Myself)~ THEN BEGIN GreetingVFemB1
SAY ~Do you need me, my mistress?~ 
 ++ ~Return, Phlydian, I need you, my servant.~ + notparty1
 ++ ~Go to our Stronghold in Grave Yard District. I will find you there, if it will be needed.~ + notpartGoST
 ++ ~Stay here, Phlydian, I will return.~ + notparty2
  ++ ~You are free to go. I release you.~ + briefing3  
 ++ ~I decided to end your life.~ + briefing3f
END


IF ~!Gender(Player1,FEMALE)
Global("BodhiStronghold","GLOBAL",2)
!InParty(Myself)~ THEN BEGIN GreetingVMAleB1
SAY ~Do you need me, my master?~ 
 ++ ~Return, Phlydian, I need you, my servant.~ + notparty1
 ++ ~Go to our Stronghold in Grave Yard District. I will find you there, if it will be needed.~ + notpartGoST
 ++ ~Stay here, Phlydian, I will return.~ + notparty2
  ++ ~You are free to go. I release you.~ + briefing3  
 ++ ~I decided to end your life.~ + briefing3f
END

IF ~~ notparty1m
  SAY ~I'll please you.~
  IF ~~ THEN DO ~
	//	DestroyItem("VVPhlydian")
	//	DestroyItem("MONHP1")
		JoinParty()~ EXIT
END

IF ~~ notparty1
  SAY ~With pleasures!~
  IF ~~ THEN DO ~
		JoinParty()~ EXIT
END

IF ~~ notpartGoST
   SAY ~We will see each other there, I hope?~
   IF ~~ THEN DO ~LeaveParty()
   RunAwayFromNoInterrupt(Player1,40)
   MoveBetweenAreas("AR0808",[143.829],SE)~ EXIT
 END  

// talk in party

IF ~!Gender(Player1,FEMALE)
InParty(Myself)
Race(Player1,VAMPIRE)~ THEN BEGIN GreetingManV1
SAY ~My master, do you need something from me?~ 
 ++ ~Are you hungry? You can suck my blood, Phlydian.~ + suckblood
 ++ ~Tell me your story, Phlydian.~ + talkPhlydianM
 ++ ~No, nothing right now, Phlydian.~ + byesilent
  ++ ~I decided to end your life.~ + briefing3f
END

IF ~Gender(Player1,FEMALE)
InParty(Myself)
Race(Player1,VAMPIRE)~ THEN BEGIN GreetingFemV1
SAY ~My mistress, do you need something from me?~ 
 ++ ~Are you hungry? You can suck my blood, Phlydian.~ + suckblood
 ++ ~Tell me your story, Phlydian.~ + talkPhlydianF
 ++ ~No, nothing right now, Phlydian.~ + byesilent
  ++ ~I decided to end your life.~ + briefing3f
END

IF ~!Gender(Player1,FEMALE)
InParty(Myself)
!Race(Player1,VAMPIRE)~ THEN BEGIN GreetingMan1
SAY ~<CHARNAME>, do you need something from me?~ 
 ++ ~Are you hungry? You can suck my blood, Phlydian.~ + suckblood
 ++ ~Make me a vampire, Phlydian.~ + vampconvm
 ++ ~Tell me your story, Phlydian.~ + talkPhlydianM
 ++ ~No, nothing right now, Phlydian. Sorry.~ + byesilent
   ++ ~I decided to end your life.~ + briefing3f
END

IF ~Gender(Player1,FEMALE)
InParty(Myself)
!Race(Player1,VAMPIRE)~ THEN BEGIN GreetingFem1
SAY ~<CHARNAME>, do you need something from me?~ 
 ++ ~Are you hungry? You can suck my blood, Phlydian.~ + suckblood
 ++ ~Make me a vampire, Phlydian.~ + vampconvf 
 ++ ~Tell me your story, Phlydian.~ +   talkPhlydianM
 ++ ~No, nothing right now, Phlydian. Sorry for disturbance.~ + byesilent
   ++ ~I decided to end your life.~ + briefing3f
END

IF ~~ byesilent
SAY ~Did you just want to hear my voice?~
  IF ~~ THEN DO ~~ EXIT
END


IF ~~ talkPhlydianM
  SAY ~My parents sold me to bordel. I was working prostitute as long as a remember. I liked sex, but I hated most clients. Several years ago I was hired by vampire. He made me into a vampire for his pleasures. When he went away, I returned to bordel and converted to vampires some good girls and boys. I killed others and became a matrona.~
  IF ~~ THEN GOTO talkPhlydianM2
END

IF ~~ talkPhlydianM2
  SAY ~Few weeks ago our bordel was attacked and burned down by vampire hunters. We moved to south. Then we met one your kind. Bhaalspawn's blood was so delicious, and we decided to go to Saradush, where all of bhaalspawns were gathering for some reason.~
  IF ~~ THEN GOTO talkPhlydianM3
END

IF ~~ talkPhlydianM3
  SAY ~The end you know - wenches messed with you and got hurt. And I am here, serving my generous master.~
  IF ~~ THEN EXIT
END


IF ~~ talkPhlydianF
   SAY ~My parents sold me to bordel. I was working prostitute as long as a remember. I liked sex, but I hated most clients. Several years ago I was hired by vampire. He made me into a vampire for his pleasures. When he went away, I returned to bordel and converted to vampires some good girls and boys. I killed others and became a matrona.~
  IF ~~ THEN GOTO talkPhlydianF2
END

IF ~~ talkPhlydianF2
  SAY ~Few weeks ago our bordel was attacked and burned down by vampire hunters. We moved to south. Then we met one your kind. Bhaalspawn's blood was so delicious, and we decided to go to Saradush, where all of bhaalspawns were gathering for some reason.~
  IF ~~ THEN GOTO talkPhlydianF3
END

IF ~~ talkPhlydianF3
 SAY ~The end you know - wenches messed with you and got hurt. And I am here, serving my glorious mistress.~
   IF ~~ THEN EXIT
END




IF ~~ suckblood
  SAY ~I love it!~
  IF ~!Global("Player1RaceBlood","GLOBAL",4)~ THEN GOTO suckbloodNo  
  IF ~Global("Player1RaceBlood","GLOBAL",4)~ THEN GOTO suckblood2
END

IF ~~ suckbloodNo
  SAY ~Are you trying to poison me?~
  IF ~~ THEN DO ~~ EXIT
END

IF ~~ suckblood2
  SAY ~Oooohhh!~
  IF ~~ THEN DO ~ApplyDamagePercent(Player1,80,MAGIC)
  SetGlobalTimer("BloodlustTimer","LOCALS",ONE_DAY)
		ApplySpell(Myself,RESTORE_FULL_HEALTH)~ EXIT 
END

IF ~~ vampconvm
  SAY ~(Phlydian firmly embraces you by neck and gets closer.)~
  IF ~!Global("Player1RaceBlood","GLOBAL",4)~ THEN GOTO suckbloodNo  
  IF ~Global("Player1RaceBlood","GLOBAL",4)~ THEN GOTO vampconv2
END


IF ~~ vampconvf
  SAY ~(Phlydian firmly embraces you by neck and gets closer.)~
  IF ~!Global("Player1RaceBlood","GLOBAL",4)~ THEN GOTO suckbloodNo  
  IF ~Global("Player1RaceBlood","GLOBAL",4)~ THEN GOTO vampconv2
END

IF ~~ vampconv2
  SAY ~(Suddently you feel her teeths have pierced your skin and gone to carotid vein. Blood flow is distracted and becomes pulsating. You feel that your blood flows into Phlydian.)~
IF ~~ GOTO vampconv3
END

IF ~~ vampconv3
  SAY ~(Soon you feel great weakness, your throuths are clouded. And you loose consciousness.)~
IF ~~ GOTO vampconv4
END

IF ~~ vampconv4
  SAY ~(...You open your eyes. World around you have changed. You have changed. You feel coldness of your body and immediately you feel all-consuming hunger growing in you.)~
IF ~~ GOTO vampconv5
END

IF ~~ vampconv5
  SAY ~(You are now undead, as you wished. Now you feel presence of Phlydian and her sexual throughts.)~

  IF ~~ THEN DO ~  ActionOverride(Player1,SetGlobal("ActorVampirisedLevel","LOCALS",2))
		ChangeStat(Player1,CON,1,ADD)
		ChangeStat(Player1,STR,-1,ADD)
		ChangeStat(Player1,WIS,0,ADD)
		ChangeStat(Player1,INT,0,ADD)
	

		SetGlobal("PhlydianVampirized","GLOBAL",1)	
	~ EXIT
END



