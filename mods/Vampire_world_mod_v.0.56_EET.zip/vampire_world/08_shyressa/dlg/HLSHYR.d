BEGIN HLSHYR


IF ~AreaCheck("AR1008")
See(Player1)
Gender(Player1,FEMALE)
Race(Player1,VAMPIRE)
NumTimesTalkedTo(0)
~ THEN BEGIN startInitTalk
  SAY ~Stop this madness, please! You walk in, attack our Twisted Rune counsil, kill everyone, and than point that sharp things on me! It's impolite and un-lady-like!~
  ++ ~Door was open and I walked in.~ + talkInit1f
  ++ ~Twisted Rune? I have heard of it. You organize many things around the Sword Coast.~ + talkInit2f
  ++ ~Hello, milady, we have many things in common, I see.~ + talkInit3fv
  ++ ~Die, vampire!~ + talkEndInitFight1
END

IF ~AreaCheck("AR1008")
See(Player1)
!Gender(Player1,FEMALE)
Race(Player1,VAMPIRE)
NumTimesTalkedTo(0)~ THEN BEGIN startInitTalk
  SAY ~Stop this madness, please! You walk in, attack our Twisted Rune counsil, kill everyone, and than point that sharp things on me! You are not a gentleman!~
  ++ ~Door was open and I walked in.~ + talkInit1m
  ++ ~Twisted Rune? I have heard of it. You organize many things around the Sword Coast.~ + talkInit2m
  ++ ~Hello, milady, we have many things in common, I see.~ + talkInit3mv
  ++ ~Die, vampire!~ + talkEndInitFight1
END

IF ~AreaCheck("AR1008")
See(Player1)
Gender(Player1,FEMALE)
!Race(Player1,VAMPIRE)
NumTimesTalkedTo(0)~ THEN BEGIN startInitTalk
  SAY ~Stop this madness, please! You walk in, attack our Twisted Rune counsil, kill everyone, and than point that sharp things on me! It's impolite and un-lady-like!~
  ++ ~Door was open and I walked in.~ + talkInit1f
  ++ ~Twisted Rune? I have heard of it. You organize many things around the Sword Coast.~ + talkInit2f
  ++ ~Die, vampire!~ + talkEndInitFight1
END



IF ~
AreaCheck("AR1008")
See(Player1)
!Gender(Player1,FEMALE)
!Race(Player1,VAMPIRE)
NumTimesTalkedTo(0)~ THEN BEGIN startInitTalk
  SAY ~Stop this madness, please! You walk in, attack our Twisted Rune counsil, kill everyone, and than point that sharp things on me! You are not a gentleman!~
  ++ ~Door was open and I walked in.~ + talkInit1m
  ++ ~Twisted Rune? I have heard of it. You organize many things around the Sword Coast.~ + talkInit2m
  ++ ~Hello, milady, we have many things in common, I see.~ + talkInit3mv
  ++ ~Die, vampire!~ + talkEndInitFight1
END

IF ~~ talkInit3mv
  SAY ~I see, you also love good drinks. Why do you entered this house?~
  ++ ~Sorry, milady, I just saw stange door and it opened right behind me. It is surely malfunctions.~ + talkInit1m
    ++ ~Die, vampire!~ + talkEndInitFight1
END

IF ~~ talkInit3fv
  SAY ~I see, you also love good drinks. Why do you entered this house?~
  ++ ~Sorry, I just saw stange door and it opened right behind me. It is surely malfunctions.~ + talkInit1f
    ++ ~Die, vampire!~ + talkEndInitFight1
END



IF ~~ talkInit1m
  SAY ~I see, you was educated by orcs.~
  ++ ~Sorry, milady. I will never break in Twisted Rune counsils again.~ + talkInit2m
  ++ ~Die, vampire!~ + talkEndInitFight1
END

IF ~~ talkInit1f
  SAY ~I see, you was educated by orcs.~
  ++ ~Sorry, woman. I will never break in Twisted Rune counsils again.~ + talkInit2f
  ++ ~Die, vampire!~ + talkEndInitFight1
END


IF ~~ talkInit2m
  SAY ~Forget about Twisted Rune. You just have ruined it. It will take a long time to assemble such power allies again.~
  ++ ~I am powerful enough by myself. I want to join Twisted Rune.~ + talkInitRune1m
  ++ ~You can come with us. I have a lot to accomplish, maybe you will find someones you need.~ + talkInitPartyM
  ++ ~Die, vampire!~ + talkEndInitFight1
END


IF ~~ talkInit2f
  SAY ~Forget about Twisted Rune. You just have ruined it. It will take a long time to assemble such power allies again.~
  ++ ~I am good enough by myself. I want to join Twisted Rune.~ + talkInitRune1f
  ++ ~You can come with us. I have a lot to accomplish, maybe you will find someones you need.~ + talkInitPartyF
  ++ ~Die, vampire!~ + talkEndInitFight1
END


IF ~~ talkInitRune1m
  SAY ~I don't like to take in first met person. Perhaps we can travel a little and I will decide, are you suited to be shadow host of Swoard Coast.~
  ++ ~Than join me.~ + talkInitPartyM
  ++ ~Die, vampire!~ + talkEndInitFight1
END

IF ~~ talkInitRune1f
  SAY ~I don't like to take in first met person. Perhaps we can travel a little and I will decide, are you suited to be shadow host of Swoard Coast.~
  ++ ~Than join me.~ + talkInitPartyF
  ++ ~Die, vampire!~ + talkEndInitFight1
END

IF ~~ talkInitPartyM
  SAY ~I will join you then. My name is Shyressa.~
      ++ ~You are that famous Shyressa?! It a pleasure to meet you!~ + talkInitShyr1M
  ++ ~Glad to meet you!~ + talkInitPartyM2
  ++ ~Die, vampire!~ + talkEndInitFight1
END

IF ~~ talkInitPartyF
  SAY ~I will join you then. My name is Shyressa.~
    ++ ~You are that famous Shyressa?! It a pleasure to meet you!~ + talkInitShyr1F
  ++ ~Welcome aboard!~ + talkInitPartyF2
  ++ ~Die, vampire!~ + talkEndInitFight1
END

IF ~~ talkInitShyr1M
  SAY ~I know!~
  IF ~~ THEN DO ~  MakeGlobal()
  SetGlobal("ShyressaResurrected","GLOBAL",2)
  DestroyItem("VVHSHYR")
  GiveItemCreate("VVCASKET",Myself,1,1,0) // Empty Casket		
  JoinParty()~  EXIT
  END

  IF ~~ talkInitShyr1F
  SAY ~I know!~
  IF ~~ THEN DO ~  MakeGlobal()
  SetGlobal("ShyressaResurrected","GLOBAL",2)
  DestroyItem("VVHSHYR")
  GiveItemCreate("VVCASKET",Myself,1,1,0) // Empty Casket		
  JoinParty()~  EXIT
  END
  
IF ~~ talkInitPartyM2
  SAY ~Okidoki!~
  IF ~~ THEN DO ~  MakeGlobal()
  SetGlobal("ShyressaResurrected","GLOBAL",2)
  DestroyItem("VVHSHYR")
  GiveItemCreate("VVCASKET",Myself,1,1,0) // Empty Casket		
  JoinParty()~  EXIT
  END
  
  IF ~~ talkInitPartyF2
  SAY ~Yes, lady!~
  IF ~~ THEN DO ~  MakeGlobal()
  SetGlobal("ShyressaResurrected","GLOBAL",2)
  DestroyItem("VVHSHYR")
  GiveItemCreate("VVCASKET",Myself,1,1,0) // Empty Casket		
  JoinParty()~ EXIT
  END


  IF ~~ talkEndInitFight1
  SAY ~I am not so easily defeated!~
  IF ~~ THEN DO ~ApplySpell(Myself,RESTORE_FULL_HEALTH)
  SetGlobal("ShyressaLeft","GLOBAL",1)
  Enemy()~ EXIT
END





IF ~See(Player1)
  Gender(Player1,FEMALE)
  Global("ShyressaResurrected","GLOBAL",1)~
THEN BEGIN greetingStartF
   SAY ~I was getting used to death. Why did you resurrect me?~
   ++ ~I will let you live, if you will serve me.~ + briefingNV1
   ++ ~I have a weakness for women.~ + briefingNV1
   ++ ~Such ingenoius person must not die.~ + briefingNV1   
   ++ ~Die, vampire!~ + talkEndInitFight1
END


IF ~See(Player1)
!Gender(Player1,FEMALE)
  Global("ShyressaResurrected","GLOBAL",1)~
THEN BEGIN greetingStart
   SAY ~I was getting used to death. Why did you resurrect me?~
   ++ ~I will let you live, if you will serve me.~ + briefingNV1f
   ++ ~I have a weakness for women.~ + briefingNV1
   ++ ~Such ingenoius person must not die.~ + briefingNV1   
   ++ ~Die, vampire!~ + talkEndInitFight1
END


IF ~~ briefingNV1
  SAY ~I like second chances and good relations. If you like me in party, then I agree. I have so much to teach you, if you would like.~
  ++ ~Join my party, I need your skills.~ + briefing2
  ++ ~You are free to go. I release you.~ + briefing3
  ++ ~Die, vampire!~ + talkEndInitFight1
END


IF ~~ briefingNV1f
  SAY ~I like second chances and good relations. If you like me in party, then I agree. I have so much to teach you, if you would like.~
  ++ ~Join my party, I need your skills.~ + briefing2f
  ++ ~You are free to go. I release you.~ + briefing3
  ++ ~Die, vampire!~ + talkEndInitFight1
END

IF ~~ briefing2f
  SAY ~I hope you can help me to find NEW Twisted Rune members while we are wondering. It's you who killed the previous.~
  IF ~~ THEN DO ~
  MakeGlobal()
  SetGlobal("ShyressaResurrected","GLOBAL",2)
  DestroyItem("VVHSHYR")
  GiveItemCreate("VVCASKET",Myself,1,1,0) // Empty Casket		
  JoinParty()
  ~ EXIT
END

IF ~~ briefing2
  SAY ~I hope you can help me to find NEW Twisted Rune members while we are wondering. It's you who killed the previous.~
  IF ~~ THEN DO ~
  MakeGlobal()
  SetGlobal("ShyressaResurrected","GLOBAL",2)
  DestroyItem("VVHSHYR")
  GiveItemCreate("VVCASKET",Myself,1,1,0) // Empty Casket		
  JoinParty()
  ~ EXIT
END



IF ~~ briefing3
  SAY ~Goodbye, <CHARNAME>. If I see you fit Twisted Rune, I will get in contact.~
  IF ~~ THEN DO ~RunAwayFromNoInterrupt(Player1,50)
  SetGlobal("ShyressaResurrected","GLOBAL",2)
DestroySelf()
~ EXIT
END

//when thrown out
IF ~!Gender(Player1,FEMALE)
!Global("BodhiStronghold","GLOBAL",2)
!InParty(Myself)~ THEN BEGIN GreetingVManB1
SAY ~Do you need my knowledge, <CHARNAME>?~ 
 ++ ~Return, Shyressa, I need your skills.~ + notparty1
 ++ ~Stay here, Shyressa, I will return.~ + notparty2
  ++ ~You are free to go. I release you.~ + briefing3 
 ++ ~I decided to end your life.~ + talkEndInitFight1
END

IF ~~ notparty2
SAY ~Okay, master!~
IF ~~ THEN DO ~~ EXIT
END

IF ~Gender(Player1,FEMALE)
!Global("BodhiStronghold","GLOBAL",2)
!InParty(Myself)~ THEN BEGIN GreetingVFemB1
SAY ~Do you need my knowledge, <CHARNAME>?~ 
 ++ ~Return, Shyressa, I need your skills.~ + notparty1
 ++ ~Stay here, Shyressa, I will return.~ + notparty2
  ++ ~You are free to go. I release you.~ + briefing3  
 ++ ~I decided to end your life.~ + talkEndInitFight1
END

IF ~Gender(Player1,FEMALE)
Global("BodhiStronghold","GLOBAL",2)
!InParty(Myself)~ THEN BEGIN GreetingVFemB1
SAY ~Do you need my knowledge, <CHARNAME>?~ 
 ++ ~Return, Shyressa, I need your skills.~ + notparty1
 ++ ~Go to our Stronghold in Grave Yard District. I will find you there, if it will be needed.~ + notpartGoST
 ++ ~Stay here, Shyressa, I will return.~ + notparty2
  ++ ~You are free to go. I release you.~ + briefing3  
 ++ ~I decided to end your life.~ + talkEndInitFight1
END


IF ~!Gender(Player1,FEMALE)
Global("BodhiStronghold","GLOBAL",2)
!InParty(Myself)~ THEN BEGIN GreetingVMAleB1
SAY ~Do you need my knowledge, <CHARNAME>??~ 
 ++ ~Return, Shyressa, I need your skills.~ + notparty1
 ++ ~Go to our Stronghold in Grave Yard District. I will find you there, if it will be needed.~ + notpartGoST
 ++ ~Stay here, Shyressa, I will return.~ + notparty2
  ++ ~You are free to go. I release you.~ + briefing3  
 ++ ~I decided to end your life.~ + talkEndInitFight1
END

IF ~~ notparty1m
  SAY ~Let's see how it ends.~
  IF ~~ THEN DO ~
	//	DestroyItem("VVShyressa")
	//	DestroyItem("MONHP1")
		JoinParty()~ EXIT
END

IF ~~ notparty1
  SAY ~Let's see how it ends.~
  IF ~~ THEN DO ~
		JoinParty()~ EXIT
END

IF ~~ notpartGoST
   SAY ~I'll take the most fashionable empty casket, you know!~
   IF ~~ THEN DO ~LeaveParty()
   RunAwayFromNoInterrupt(Player1,40)
   MoveBetweenAreas("AR0808",[143.829],SE)~ EXIT
 END  

// talk in party

IF ~!Gender(Player1,FEMALE)
InParty(Myself)
Race(Player1,VAMPIRE)~ THEN BEGIN GreetingManV1
SAY ~Do you need my knowledge, <CHARNAME>?~ 
 ++ ~Are you hungry? You can suck my blood, Shyressa.~ + suckblood
 ++ ~Tell me your story, Shyressa.~ + talkShyressaM
 ++ ~No, nothing right now, Shyressa.~ + byesilent
  ++ ~I decided to end your life.~ + talkEndInitFight1
END

IF ~Gender(Player1,FEMALE)
InParty(Myself)
Race(Player1,VAMPIRE)~ THEN BEGIN GreetingFemV1
SAY ~Do you need my knowledge, <CHARNAME>?~ 
 ++ ~Are you hungry? You can suck my blood, Shyressa.~ + suckblood
 ++ ~Tell me your story, Shyressa.~ + talkShyressaF
 ++ ~No, nothing right now, Shyressa.~ + byesilent
  ++ ~I decided to end your life.~ + talkEndInitFight1
END

IF ~!Gender(Player1,FEMALE)
InParty(Myself)
!Race(Player1,VAMPIRE)~ THEN BEGIN GreetingMan1
SAY ~Do you need my knowledge, <CHARNAME>?~ 
 ++ ~Are you hungry? You can suck my blood, Shyressa.~ + suckblood
 ++ ~Make me a vampire, Shyressa.~ + vampconvm
 ++ ~Tell me your story, Shyressa.~ + talkShyressaM
 ++ ~No, nothing right now, Shyressa. Sorry.~ + byesilent
   ++ ~I decided to end your life.~ + talkEndInitFight1
END

IF ~Gender(Player1,FEMALE)
InParty(Myself)
!Race(Player1,VAMPIRE)~ THEN BEGIN GreetingFem1
SAY ~Do you need my knowledge, <CHARNAME>?~ 
 ++ ~Are you hungry? You can suck my blood, Shyressa.~ + suckblood
 ++ ~Make me a vampire, Shyressa.~ + vampconvf 
 ++ ~Tell me your story, Shyressa.~ +   talkShyressaM
 ++ ~No, nothing right now, Shyressa. Sorry for disturbance.~ + byesilent
   ++ ~I decided to end your life.~ + talkEndInitFight1
END

IF ~~ byesilent
SAY ~I am all an ear.~
  IF ~~ THEN DO ~~ EXIT
END


IF ~~ talkShyressaM
  SAY ~I am mysterious woman and I won't talk much of my past hundreds of years. I like politics, diplomacy and mysteries, so I often create dark organizations like Twisted Rune and think out malicious plans. Life is so boring without plotting something evil.~
  IF ~~ THEN GOTO talkShyressaM2
END

IF ~~ talkShyressaM2
  SAY ~I had a whole castle with my beloved girls from over the world. But one day vampire hunters came in and killed most of my beauties. In Bridge District we were planning a revenge on Kelemvor charlatans and other clerics participated in this genocide of my honeys.~
  IF ~~ THEN GOTO talkShyressaM3
END

IF ~~ talkShyressaM3
  SAY ~If you will meet with somebody who likes to kill vampires, I propose you will not let him get out alive. Okay?~
  IF ~~ THEN EXIT
END


IF ~~ talkShyressaF
  SAY ~I am mysterious woman and I won't talk much of my past hundreds of years. I like politics, diplomacy and mysteries, so I often create dark organizations like Twisted Rune and think out malicious plans. Life is so boring without plotting something evil.~
  IF ~~ THEN GOTO talkShyressaF2
END

IF ~~ talkShyressaF2
   SAY ~I had a whole castle with my beloved girls from over the world. But one day vampire hunters came in and killed most of my beauties. In Bridge District we were planning a revenge on Kelemvor charlatans and other clerics participated in this genocide of my honeys.~
  IF ~~ THEN GOTO talkShyressaF3
END

IF ~~ talkShyressaF3
 SAY ~If you will meet with somebody who likes to kill vampires, I propose you will not let him get out in one piece?~
   IF ~~ THEN EXIT
END




IF ~~ suckblood
  SAY ~You are so generous!~
  IF ~!Global("Player1RaceBlood","GLOBAL",4)~ THEN GOTO suckbloodNo  
  IF ~Global("Player1RaceBlood","GLOBAL",4)~ THEN GOTO suckblood2
END

IF ~~ suckbloodNo
  SAY ~Are you trying to poison me? You are a mystery!~
  IF ~~ THEN DO ~~ EXIT
END

IF ~~ suckblood2
  SAY ~Nyam nyam!~
  IF ~~ THEN DO ~ApplyDamagePercent(Player1,80,MAGIC)
  SetGlobalTimer("BloodlustTimer","LOCALS",ONE_DAY)
		ApplySpell(Myself,RESTORE_FULL_HEALTH)~ EXIT 
END

IF ~~ vampconvm
  SAY ~(Shyressa gently embraces you by neck and gets closer.)~
  IF ~!Global("Player1RaceBlood","GLOBAL",4)~ THEN GOTO suckbloodNo  
  IF ~Global("Player1RaceBlood","GLOBAL",4)~ THEN GOTO vampconv2
END


IF ~~ vampconvf
  SAY ~(Shyressa gently embraces you by neck and gets closer.)~
  IF ~!Global("Player1RaceBlood","GLOBAL",4)~ THEN GOTO suckbloodNo  
  IF ~Global("Player1RaceBlood","GLOBAL",4)~ THEN GOTO vampconv2
END

IF ~~ vampconv2
  SAY ~(Suddently you feel her teeths have pierced your skin and gone to carotid vein. Blood flow is distracted and becomes pulsating. You feel that your blood flows into Shyressa.)~
IF ~~ GOTO vampconv3
END

IF ~~ vampconv3
  SAY ~(Soon you feel great weakness, your throuths are clouded. And you loose consciousness.)~
IF ~~ GOTO vampconv4
END

IF ~~ vampconv4
  SAY ~(...You open your eyes. World around you have changed. You have changed. You feel coldness of your body and immediately you feel all-consuming hunger growing in you.)~
IF ~~ GOTO vampconv5
END

IF ~~ vampconv5
  SAY ~(You are now undead, as you wished. Now you feel presence of Shyressa and her deep sad memories of vampires long gone.)~

  IF ~~ THEN DO ~  ActionOverride(Player1,SetGlobal("ActorVampirisedLevel","LOCALS",2))
		ChangeStat(Player1,CON,-1,ADD)
		ChangeStat(Player1,STR,-1,ADD)
		ChangeStat(Player1,WIS,2,ADD)
		ChangeStat(Player1,INT,1,ADD)
	

		SetGlobal("ShyressaVampirized","GLOBAL",1)	
	~ EXIT
END



