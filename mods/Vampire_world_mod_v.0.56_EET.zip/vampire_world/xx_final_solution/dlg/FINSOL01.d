EXTEND_TOP FINSOL01  28 #0 // from: 27.0
  IF ~~ THEN REPLY ~Are you joking? There is almost no choice. I come this far and I want to act another way!~ GOTO newSelectedChoices

END


APPEND FINSOL01

IF ~~ THEN BEGIN decision1 // from: 32.0 31.0 30.0 29.0
  SAY ~Your decision has been made, god-child. Now the act must be carried out... prepare yourself!~ [SOLAR107] 
  IF ~~ THEN DO ~SetGlobal("OHD_PCNotGod","GLOBAL",1)
  StartCutSceneMode()
StartCutSceneEx("cut233i3",FALSE)
~ EXIT
END

IF ~~ THEN BEGIN decision2 // from: 32.0 31.0 30.0 29.0
  SAY  ~Your decision has been made, god-child. Now the act must be carried out... prepare yourself!~ [SOLAR107] 
  IF ~~ THEN DO ~SetGlobal("OHH_PCGod","GLOBAL",1)
StartCutSceneMode()
StartCutSceneEx("cut233i",FALSE)
~ EXIT
END

IF ~~ THEN BEGIN decision3 // from: 32.0 31.0 30.0 29.0
  SAY ~Your decision has been made, god-child. Now the act must be carried out... prepare yourself!~ [SOLAR107] 
  IF ~~ THEN DO ~
  SetGlobal("OHD_PCNotGod","GLOBAL",1)
  StartCutSceneMode()
StartCutSceneEx("cut233i",FALSE)
~ EXIT
END

IF ~~  newSelectedChoices
  SAY ~What do you mean? These choices were presented to you by Ao himself.~
  IF ~Global("HexxatRomanceActive","GLOBAL",2)
InParty("hexxat")~ THEN REPLY ~I will share the essence of Bhaal with my beloved Hexxat and we will together become a powers of the planes.~ GOTO newSelectedLoveGodHexxat
  IF ~OR(2)
  Global("BodhiRomance","GLOBAL",1)
  Global("BodhiRomance","GLOBAL",2)
InParty("c6bodhi")~ THEN REPLY ~I will share the essence of Bhaal with my beloved Bodhi and we will together become a powers of the planes.~ GOTO newSelectedLoveGodBodhi
  IF ~Global("VynonaRomance","GLOBAL",2)
InParty("VVVYNONA")~ THEN REPLY ~I will share the essence of Bhaal with my beloved Vynona and we will together become a powers of the planes.~ GOTO newSelectedLoveGodVynona
  IF ~Global("AerieRomanceActive","GLOBAL",2)
InParty("vampaer")~ THEN REPLY ~I will share the essence of Bhaal with my beloved Aerie and we will together become a powers of the planes.~ GOTO newSelectedLoveGodAerie 
  IF ~Global("AnomenRomanceActive","GLOBAL",2)
InParty("vampano")~ THEN REPLY ~I will share the essence of Bhaal with my beloved Anomen and we will together become a powers of the planes.~ GOTO newSelectedLoveGodAnomen
  IF ~Global("JaheiraRomanceActive","GLOBAL",2)
InParty("vampjah")~ THEN REPLY ~I will share the essence of Bhaal with my beloved Jaheira and we will together become a powers of the planes.~ GOTO newSelectedLoveGodJaheira 
  IF ~Global("ViconiaRomanceActive","GLOBAL",2)
InParty("vampvic")~ THEN REPLY ~I will share the essence of Bhaal with my beloved Viconia and we will together become a powers of the planes.~ GOTO newSelectedLoveGodViconia
  IF ~Global("SaliaRomance","GLOBAL",2)
InParty("c6salia")~ THEN REPLY ~I will share the essence of Bhaal with my beloved Salia and we will together become a powers of the planes.~ GOTO newSelectedLoveGodSalia
  IF ~Global("DerekRomance","GLOBAL",2)
InParty("vvderek")~ THEN REPLY ~I will share the essence of Bhaal with he-dog Derek and we will together become a powers of the planes.~ GOTO newSelectedLoveGodDerek
  IF ~~ THEN REPLY ~I want to use this essence for myself and will become a loyal servant of Cyric. I preach to the Dark Choir!~ GOTO CyricResurrection
  IF ~~ THEN REPLY ~I want to use this essence to return my father Bhaal to life. This essence is his rightfully.~ GOTO BhaalResurrection
  IF ~~ THEN REPLY ~I want to use this essence to return god Bane to life. I worship him and this essence is his.~ GOTO BaneResurrection
  IF ~!Race(Player1,VAMPIRE)~ THEN REPLY ~I want to use this essence to return god Myrkul  to life. Without him undead nation is beeing murdered and hunted. He is the only one Lord of the Dead.~ GOTO MyrkulResurrection1 
  IF ~Race(Player1,VAMPIRE)~ THEN REPLY ~I want to use this essence to return god Myrkul  to life. Without him my undead nation is beeing murdered and hunted. He is the only one Lord of the Dead.~ GOTO MyrkulResurrection2
  IF ~Global("JoinedKaliCult","GLOBAL",1)~ THEN REPLY ~I want to use this essence to return goddess Kali her greatness and power. As a vampire, I call her my only one deuty.~ GOTO KaliResurrection
    IF ~~ THEN REPLY ~I want to give this essence to Melissan. She fought well and has a right to become Goddess of Murder.~ GOTO MelissanResurrection
	IF ~~ THEN REPLY ~I want to give this essence to Noober. He will be the fearful Lord of Murder.~ GOTO NooberResurrection
	
	
	IF ~Global("HexxatRomanceActive","GLOBAL",2)
InParty("hexxat")~ THEN REPLY ~I do not want the essence of Bhaal. Do what you want with it... I want to remain in world of the living and to be there with my beloved Hexxat.~ GOTO LoveWithHexxat	

	IF ~OR(2)
	Global("DahliaRomance","GLOBAL",1)
	Global("DahliaRomance","GLOBAL",2)
InParty("vvdahlia")~ THEN REPLY ~I do not want the essence of Bhaal. Do what you want with it... I want to remain in world of the living and to be there with my beautiful Dahlia.~ GOTO LoveWithDahlia		
	
	IF ~~ THEN REPLY ~Never mind, let's just return to my choices.~ GOTO 28
END  
  
  
IF ~~ newSelectedLoveGodHexxat
  SAY ~Interesting choice. Ao predicted it. As you wish... maybe your relations with Hexxat diminish a lust for murder. You two will get equal amounts of essence. Maybe love will subdue your temptation to kill. We shall see what manner of power you become... in time.~
  
  IF ~~ THEN DO ~
  SetGlobal("Player1ChoseGodHexxat","GLOBAL",1)
  SetGlobal("DahliaRomance","GLOBAL",3)
  SetGlobal("DerekRomance","GLOBAL",3)
  SetGlobal("SaliaRomance","GLOBAL",3)
SetGlobal("BodhiRomance","GLOBAL",3)
SetGlobal("VynonaRomance","GLOBAL",3)
SetGlobal("ViconiaRomanceActive","GLOBAL",3)
SetGlobal("JaheiraRomanceActive","GLOBAL",3)
SetGlobal("RasaadRomanceActive","GLOBAL",3)
SetGlobal("DornRomanceActive","GLOBAL",3)
SetGlobal("NeeraRomanceActive","GLOBAL",3)
SetGlobal("PlayerChoseEssence","GLOBAL",1)~ GOTO decision2
END  

  
IF ~~ newSelectedLoveGodDerek
  SAY ~Stoopidity. But Ao predicted it. As you wish... maybe this redneck will lead you both to defeat. You two will get equal amounts of essence. It's better that you will spend eternity on vulgar things and not on murder.  We shall see what manner of power you become... in time.~
  IF ~~ THEN DO ~SetGlobal("Player1ChoseGodDerek","GLOBAL",1)
  SetGlobal("DerekRomance","GLOBAL",2)
  SetGlobal("DahliaRomance","GLOBAL",3)
  SetGlobal("SaliaRomance","GLOBAL",3)
SetGlobal("BodhiRomance","GLOBAL",3)
SetGlobal("VynonaRomance","GLOBAL",3)
SetGlobal("ViconiaRomanceActive","GLOBAL",3)
SetGlobal("JaheiraRomanceActive","GLOBAL",3)
SetGlobal("RasaadRomanceActive","GLOBAL",3)
SetGlobal("DornRomanceActive","GLOBAL",3)
SetGlobal("NeeraRomanceActive","GLOBAL",3)
SetGlobal("PlayerChoseEssence","GLOBAL",1)~ GOTO decision2
END  

IF ~~ newSelectedLoveGodSalia
  SAY ~Interesting choice. But Ao predicted it. As you wish... Salia already tasted your blood and got tied up with Bhaal taint. You two will get equal amounts of essence. Maybe your experiments in lust will diminish a taste for murder.  We shall see what manner of power you become... in time.~
  IF ~~ THEN DO ~SetGlobal("Player1ChoseGodSalia","GLOBAL",1)
  SetGlobal("DahliaRomance","GLOBAL",3)
  SetGlobal("DerekRomance","GLOBAL",3)
  SetGlobal("SaliaRomance","GLOBAL",2)
SetGlobal("BodhiRomance","GLOBAL",3)
SetGlobal("VynonaRomance","GLOBAL",3)
SetGlobal("ViconiaRomanceActive","GLOBAL",3)
SetGlobal("JaheiraRomanceActive","GLOBAL",3)
SetGlobal("RasaadRomanceActive","GLOBAL",3)
SetGlobal("DornRomanceActive","GLOBAL",3)
SetGlobal("NeeraRomanceActive","GLOBAL",3)
SetGlobal("PlayerChoseEssence","GLOBAL",1)~ GOTO decision2
END  

  
IF ~~ newSelectedLoveGodVynona
  SAY ~Interesting choice. Ao predicted it. You both are vampires, you already lived by murder until this day. But I see that Vynona is a wise person and don't want unnecesary murders. You two will get equal amounts of essence. Maybe your love will shubdue lust for murder. We shall see what manner of power you become... in time.~
  IF ~~ THEN DO ~SetGlobal("HexxatRomanceActive","GLOBAL",3)
  SetGlobal("DahliaRomance","GLOBAL",3)
    SetGlobal("DerekRomance","GLOBAL",3)
  SetGlobal("SaliaRomance","GLOBAL",3)
SetGlobal("BodhiRomance","GLOBAL",3)
SetGlobal("ViconiaRomanceActive","GLOBAL",3)
SetGlobal("JaheiraRomanceActive","GLOBAL",3)
SetGlobal("RasaadRomanceActive","GLOBAL",3)
SetGlobal("DornRomanceActive","GLOBAL",3)
SetGlobal("NeeraRomanceActive","GLOBAL",3)
SetGlobal("Player1ChoseGodVynona","GLOBAL",1)
SetGlobal("PlayerChoseEssence","GLOBAL",1)~ GOTO decision2
END  

  
IF ~~ newSelectedLoveGodBodhi
  SAY ~I don't like this choice, but Ao predicted it. As you wish... Bodhi also is accustomed to Bhaal taint. You two are already mass murderers. You two will get equal amounts of essence. Maybe it's love that will subdue your lust for murder. We shall see what manner of power you become... in time.~
  IF ~~ THEN DO ~
  SetGlobal("DahliaRomance","GLOBAL",3)
  SetGlobal("DerekRomance","GLOBAL",3)
  SetGlobal("SaliaRomance","GLOBAL",3)
  SetGlobal("VynonaRomance","GLOBAL",3)
SetGlobal("HexxatRomanceActive","GLOBAL",3)
SetGlobal("ViconiaRomanceActive","GLOBAL",3)
SetGlobal("JaheiraRomanceActive","GLOBAL",3)
SetGlobal("RasaadRomanceActive","GLOBAL",3)
SetGlobal("DornRomanceActive","GLOBAL",3)
SetGlobal("NeeraRomanceActive","GLOBAL",3)
SetGlobal("Player1ChoseGodBodhi","GLOBAL",1)
SetGlobal("PlayerChoseEssence","GLOBAL",1)~ GOTO decision2
END  



IF ~~ newSelectedLoveGodAerie
  SAY ~You corrupted the very being of Aerie, turned her into insane murderer, and you say 'beloved'?! But Ao predicted it. As you wish... Aerie is surely insane and broken. As you are. You two will get equal amounts of essence. The world already knows insane god Cyric, now there will be two more. We shall see what manner of power you become... in time.~
  IF ~~ THEN DO ~  SetGlobal("DerekRomance","GLOBAL",3)
  SetGlobal("DahliaRomance","GLOBAL",3)
  SetGlobal("SaliaRomance","GLOBAL",3)
  SetGlobal("VynonaRomance","GLOBAL",3)
SetGlobal("HexxatRomanceActive","GLOBAL",3)
SetGlobal("Player1ChoseGodAerie","GLOBAL",1)
SetGlobal("ViconiaRomanceActive","GLOBAL",3)
SetGlobal("JaheiraRomanceActive","GLOBAL",3)
SetGlobal("RasaadRomanceActive","GLOBAL",3)
SetGlobal("DornRomanceActive","GLOBAL",3)
SetGlobal("NeeraRomanceActive","GLOBAL",3)
SetGlobal("BodhiRomance","GLOBAL",3)
SetGlobal("PlayerChoseEssence","GLOBAL",1)~ GOTO decision2
END  


IF ~~ newSelectedLoveGodAnomen
  SAY ~You corrupted Anomen's soul, turned him the opposite of the man it was, and now he is happy to be with you are an undead monster. But Ao predicted it. As you wish... Maybe there is some good left in Anomen, and he will influence you at least lightly. We shall see what manner of power you become... in time.~
  IF ~~ THEN DO ~  SetGlobal("DerekRomance","GLOBAL",3)
  SetGlobal("DahliaRomance","GLOBAL",3)
  SetGlobal("SaliaRomance","GLOBAL",3)
  SetGlobal("VynonaRomance","GLOBAL",3)
SetGlobal("HexxatRomanceActive","GLOBAL",3)
SetGlobal("Player1ChoseGodAnomen","GLOBAL",1)
SetGlobal("ViconiaRomanceActive","GLOBAL",3)
SetGlobal("JaheiraRomanceActive","GLOBAL",3)
SetGlobal("RasaadRomanceActive","GLOBAL",3)
SetGlobal("DornRomanceActive","GLOBAL",3)
SetGlobal("NeeraRomanceActive","GLOBAL",3)
SetGlobal("BodhiRomance","GLOBAL",3)
SetGlobal("PlayerChoseEssence","GLOBAL",1)~ GOTO decision2
END  


IF ~~ newSelectedLoveGodJaheira
  SAY ~You corrupted Jaheira's soul, made her hate you and dream of suicide, and you call her 'beloved'?. But Ao predicted it. As you wish... Maybe she will find a way to break your control and will kill you for the good of Faerun. We shall see what manner of power you become... in time.~
  IF ~~ THEN DO ~  SetGlobal("DerekRomance","GLOBAL",3)
  SetGlobal("DahliaRomance","GLOBAL",3)
  SetGlobal("SaliaRomance","GLOBAL",3)
  SetGlobal("VynonaRomance","GLOBAL",3)
SetGlobal("HexxatRomanceActive","GLOBAL",3)
SetGlobal("Player1ChoseGodJaheira","GLOBAL",1)
SetGlobal("ViconiaRomanceActive","GLOBAL",3)
SetGlobal("JaheiraRomanceActive","GLOBAL",3)
SetGlobal("RasaadRomanceActive","GLOBAL",3)
SetGlobal("DornRomanceActive","GLOBAL",3)
SetGlobal("NeeraRomanceActive","GLOBAL",3)
SetGlobal("BodhiRomance","GLOBAL",3)
SetGlobal("PlayerChoseEssence","GLOBAL",1)~ GOTO decision2
END  

IF ~~ newSelectedLoveGodViconia
  SAY ~I don't like this choice, but Ao predicted it. As you wish... Drows live by murder and cowardice. You and Viconia are alike, you both fit to be inheriting domain of Murder. You two will get equal amounts of essence. Maybe your love that will lighten your lust for murder, but maybe it will only get worse. We shall see what manner of power you become... in time.~
  IF ~~ THEN DO ~  SetGlobal("DerekRomance","GLOBAL",3)
  SetGlobal("DahliaRomance","GLOBAL",3)
  SetGlobal("SaliaRomance","GLOBAL",3)
  SetGlobal("VynonaRomance","GLOBAL",3)
SetGlobal("HexxatRomanceActive","GLOBAL",3)
SetGlobal("Player1ChoseGodViconia","GLOBAL",1)
SetGlobal("ViconiaRomanceActive","GLOBAL",3)
SetGlobal("JaheiraRomanceActive","GLOBAL",3)
SetGlobal("RasaadRomanceActive","GLOBAL",3)
SetGlobal("DornRomanceActive","GLOBAL",3)
SetGlobal("NeeraRomanceActive","GLOBAL",3)
SetGlobal("BodhiRomance","GLOBAL",3)
SetGlobal("PlayerChoseEssence","GLOBAL",1)~ GOTO decision2
END  

IF ~~ CyricResurrection
  SAY ~Ao predicted it. You are loyal to Prince of Lies and you want to fight on his side as an equal power. So be it, serve Prince of Lies, if you wish so. Even if I dislike this choice, it's better than many others.~
  IF ~~ THEN DO ~SetGlobal("Player1ChoseGodCyric","GLOBAL",1)~ GOTO decision3
END  

  
IF ~~ BhaalResurrection
  SAY ~You really want to restore your father? He tried to kill you. And he even don't think of you as his son. But as you wish... The known devil is better than unknown. Bhaal will be resurrected, and you will have to deal with him yourself. I will stop for no second when Bhaal returns here.~
  IF ~~ THEN DO ~SetGlobal("Player1ChoseGodBhaal","GLOBAL",1)~ GOTO decision3
END  
  
IF ~~ BaneResurrection
  SAY ~You really want to restore Black Lord? I see you have chosen realy evil religion. But as you wish... The known devil is better than unknown. Bhaal will be resurrected, and you will have to deal with him yourself. I will stop for no second when Bane appears here.~
  IF ~~ THEN DO ~SetGlobal("Player1ChoseGodBane","GLOBAL",1)~ GOTO decision3
END 

  
IF ~~ MyrkulResurrection1
  SAY ~You really want to restore Lord of Bones? I see you have chosen religion of undead. But as you wish... The known devil is better than unknown. Kelemvor will have to fight for his conquered plane. Myrkul will be resurrected. I will stop for no second when Myrkul returns here.~
  IF ~~ THEN DO ~SetGlobal("Player1ChoseGodMyrkul","GLOBAL",1)~ GOTO decision3
END 

IF ~~ MyrkulResurrection2
  SAY ~You really want to restore Lord of Bones? I see you have chosen religion of undead. But as you wish... The known devil is better than unknown. Kelemvor will have to fight for his conquered plane. Myrkul will be resurrected. I will stop for no second when Myrkul returns here.~
  IF ~~ THEN DO ~SetGlobal("Player1ChoseGodMyrkul","GLOBAL",1)~ GOTO decision3
END 

  
IF ~~ KaliResurrection
  SAY ~You want to give power to goddess Kali? You are a vampire, I understand your choice, through I don't like it. Kali will be restored and will gain Bhaal's powers, returning to godhood. I will stop for no second when Kali appears here.~
  IF ~~ THEN DO ~SetGlobal("Player1ChoseGodKali","GLOBAL",1)~ GOTO decision3
END 

  
IF ~~ MelissanResurrection
  SAY ~What? You want to restore Melissan? She tried to kill you. She sank realms in blood. Her scheming is a reason I am here. But Ao foreseen this choice. As you wish... I will return Melissan her powers, and she will became new goddess of Murder, but I have no doubt she will start by killing you.~
  IF ~~ THEN DO ~SetGlobal("Player1ChoseGodMelissan","GLOBAL",1)~ GOTO decision3
END 

IF ~~ NooberResurrection
  SAY ~You want to restore Noober and make him a God of Murder? You are insane. Realms are judged, all is lost. But Ao foreseen this. As you wish... Noober will become god. I will stop for no second when Noober appears here.~
  IF ~~ THEN DO ~SetGlobal("Player1ChoseGodNoober","GLOBAL",1)~ GOTO decision3
END 

IF ~~ LoveWithHexxat
  SAY ~I wish you a happy life with Hexxat, through it doesn't sound good to wish a happiness to an undead.~
  IF ~~ THEN DO ~  SetGlobal("DerekRomance","GLOBAL",3)
  SetGlobal("DahliaRomance","GLOBAL",3)
  SetGlobal("SaliaRomance","GLOBAL",3)
SetGlobal("BodhiRomance","GLOBAL",3)
  SetGlobal("VynonaRomance","GLOBAL",3)
//SetGlobal("HexxatRomanceActive","GLOBAL",3)
SetGlobal("ViconiaRomanceActive","GLOBAL",3)
SetGlobal("JaheiraRomanceActive","GLOBAL",3)
SetGlobal("RasaadRomanceActive","GLOBAL",3)
SetGlobal("DornRomanceActive","GLOBAL",3)
SetGlobal("NeeraRomanceActive","GLOBAL",3)
SetGlobal("PlayerChoseEssence","GLOBAL",0)
SetGlobal("PlayerChoseLoveHexxat","GLOBAL",1)~ GOTO  decision1
END  

IF ~~ LoveWithDahlia
  SAY ~I wish you a happy life with Dahlia, through it doesn't sound good to wish a happiness to such monsters.~
  IF ~~ THEN DO ~  SetGlobal("DerekRomance","GLOBAL",3)
  SetGlobal("DahliaRomance","GLOBAL",2)
  SetGlobal("SaliaRomance","GLOBAL",3)
SetGlobal("BodhiRomance","GLOBAL",3)
  SetGlobal("VynonaRomance","GLOBAL",3)
//SetGlobal("HexxatRomanceActive","GLOBAL",3)
SetGlobal("ViconiaRomanceActive","GLOBAL",3)
SetGlobal("JaheiraRomanceActive","GLOBAL",3)
SetGlobal("RasaadRomanceActive","GLOBAL",3)
SetGlobal("DornRomanceActive","GLOBAL",3)
SetGlobal("NeeraRomanceActive","GLOBAL",3)
SetGlobal("PlayerChoseEssence","GLOBAL",0)
SetGlobal("PlayerChoseLoveDahlia","GLOBAL",1)~ GOTO  decision1
END  


END
