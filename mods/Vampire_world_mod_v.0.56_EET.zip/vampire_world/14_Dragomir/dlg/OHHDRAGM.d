BEGIN OHHDRAGM



  
IF ~~ talkInitPartyM2
  SAY ~Well, I will take command over this band of loosers, my new master.~
  IF ~~ THEN DO ~  MakeGlobal()
  SetGlobal("DragomirResurrected","GLOBAL",2)
  DestroyItem("VVDRAGO")
  GiveItemCreate("VVCASKET",Myself,1,1,0) // Empty Casket		
  JoinParty()~  EXIT
  END
  
  IF ~~ talkInitPartyF2
  SAY ~Well, I will take command over this band of loosers, my new mistress.~
  IF ~~ THEN DO ~  MakeGlobal()
  SetGlobal("DragomirResurrected","GLOBAL",2)
  DestroyItem("VVDRAGO")
  GiveItemCreate("VVCASKET",Myself,1,1,0) // Empty Casket		
  JoinParty()~ EXIT
  END

  
  
  

  IF ~~ talkEndInitFight1
  SAY ~Dragomir is not eaily defeated!~
  IF ~~ THEN DO ~ApplySpell(Myself,RESTORE_FULL_HEALTH)
  SetGlobal("DragomirLeft","GLOBAL",1)
  Enemy()~ EXIT
END


  IF ~~ talkEndInitLeave1
  SAY ~Then I will take my leave. This is so much to do after all that years.~
  IF ~~ THEN DO ~RunAwayFromNoInterrupt(Player1,50)
  SetGlobal("DragomirResurrected","GLOBAL",2)
DestroySelf()~ EXIT
END



IF ~See(Player1)
  Global("DragomirResurrected","GLOBAL",1)~
THEN BEGIN greetingStart
   SAY ~Free at last!~
   =
   ~Oh, it's you again.~
   =
   ~What is that means? You were defiling my tomb, seeking for Hexxat. And I think you killed me.~
   =
   ~Aswer, what that means?~
   IF ~Gender(Player1,MALE)~ THEN REPLY ~It's easy. I have resurrected you in this blood pool, and you have two choices - serve me or die again.~ GOTO briefingNV1M
   IF ~!Gender(Player1,MALE)~ THEN REPLY ~It's easy. I have resurrected you in this blood pool, and you have two choices - serve me or die again.~ GOTO briefingNV1M   
   IF ~Gender(Player1,MALE)~ THEN REPLY ~I ressurrected you because I am a good man. You can walk away.~ GOTO talkEndInitLeave1
   IF ~Gender(Player1,MALE)~ THEN REPLY ~We, vampires, must help each other.~ GOTO briefingNV3M
   IF ~!Gender(Player1,MALE)~ THEN REPLY ~We, vampires, must help each other.~ GOTO briefingNV3M   
   ++ ~I enjoed killing you last time and want to feel it again. Prepare to die again!~ + talkEndInitFight1
END



IF ~~ briefingNV1M
  SAY ~You ask me, the great general, that commanded armies, to join you, isn't it?~
  IF ~~ THEN REPLY ~Yes. You can command my army, Dragomir. Your charisma and experience fit.~ GOTO briefingJoin1
  IF ~~ THEN REPLY ~If you don't want, just walk away.~ GOTO talkEndInitLeave1
  IF ~~ THEN REPLY ~I am already bored by this conversation. Prepare to die!~ GOTO talkEndInitFight1
END

IF ~~ briefingJoin1
  SAY ~I see. My powers are weakened, and you will kill me again, if I will oppose your rule.~
  =
  ~Fine, <CHARNAME>.~
  IF ~InParty("hexxat")
!Dead("hexxat")~ THEN REPLY ~But first you must pardon before Hexxat and promise that you will not have revenge on her or take Dragomir cloak from her. Act like a gentleman.~ GOTO HexxatPardon
  IF ~OR(2)
  !InParty("hexxat")
Dead("hexxat")
Gender(Player1,MALE)~ THEN REPLY ~You are a clever one. Help me to command my army.~ GOTO talkInitPartyM2
  IF ~OR(2)
  !InParty("hexxat")
Dead("hexxat")
!Gender(Player1,MALE)~ THEN REPLY ~You are a clever one. Help me to command my army.~ GOTO talkInitPartyF2
  IF ~~ THEN REPLY ~If you don't want, just walk away.~ GOTO talkEndInitLeave1
  IF ~~ THEN REPLY ~I am already bored by this conversation. Prepare to die!~ GOTO talkEndInitFight1
END 

IF ~~ HexxatPardon
  SAY ~I am a gentleman. I swear I will not harm Hexxat. It was she who called for your help. I must thank Hexxat for my salvation.~
  IF ~OR(2)
  !InParty("hexxat")
Dead("hexxat")
Gender(Player1,MALE)~ THEN REPLY ~You are a clever one. Help me to command my army.~ GOTO talkInitPartyM2
  IF ~OR(2)
  !InParty("hexxat")
Dead("hexxat")
!Gender(Player1,MALE)~ THEN REPLY ~You are a clever one. Help me to command my army.~ GOTO talkInitPartyF2
  IF ~~ THEN REPLY ~If you don't want, just walk away.~ GOTO talkEndInitLeave1
  IF ~~ THEN REPLY ~I am already bored by this conversation. Prepare to die!~ GOTO talkEndInitFight1
END  

IF ~~ briefingNV3M
   SAY ~Didn't often met vampires who help each other. But I agree, we must hold on to one another to be strong.~
   IF ~OR(2)
  !InParty("hexxat")
Dead("hexxat")
Gender(Player1,MALE)~ THEN REPLY ~You are a clever one. Help me to command my army.~ GOTO talkInitPartyM2
  IF ~OR(2)
  !InParty("hexxat")
Dead("hexxat")
!Gender(Player1,MALE)~ THEN REPLY ~You are a clever one. Help me to command my army.~ GOTO talkInitPartyF2
  IF ~~ THEN REPLY ~If you don't want, just walk away.~ GOTO talkEndInitLeave1
  IF ~~ THEN REPLY ~I am already bored by this conversation. Prepare to die!~ GOTO talkEndInitFight1  
END



//when thrown out


IF ~~ notparty2M
SAY ~Okay, master.~
IF ~~ THEN DO ~~ EXIT
END

IF ~~ notparty2F
SAY ~Okay, mistress.~
IF ~~ THEN DO ~~ EXIT
END

IF ~!InParty(Myself)
!Gender(Player1,MALE)~ THEN BEGIN GreetingF
SAY ~Master?~ 
 IF ~~ THEN REPLY ~Return, Dragomir, I need your skills.~ GOTO notparty1f
 IF ~Global("BodhiStronghold","GLOBAL",2)~  THEN REPLY ~Go to our Stronghold in Grave Yard District. I will find you there, if it will be needed.~ GOTO notpartGoST
 IF ~~ THEN REPLY ~Stay here, Dragomir, I will return.~ GOTO notparty2F
 IF ~~ THEN REPLY ~You are free to go. I release you.~ GOTO talkEndInitLeave1  
 IF ~~ THEN REPLY  ~I decided to end your life.~ GOTO talkEndInitFight1
END

IF ~Gender(Player1,MALE)
!InParty(Myself)~ THEN BEGIN GreetingM
SAY ~Mistress?~ 
 IF ~~ THEN REPLY ~Return, Dragomir, I need your skills.~ GOTO notparty1m
 IF ~Global("BodhiStronghold","GLOBAL",2)~  THEN REPLY ~Go to our Stronghold in Grave Yard District. I will find you there, if it will be needed.~ GOTO notpartGoST
 IF ~~ THEN REPLY ~Stay here, Dragomir, I will return.~ GOTO notparty2M
 IF ~~ THEN REPLY ~You are free to go. I release you.~ GOTO talkEndInitLeave1  
 IF ~~ THEN REPLY  ~I decided to end your life.~ GOTO talkEndInitFight1
END



IF ~~ notparty1m
  SAY ~If you ask, master.~
  IF ~~ THEN DO ~
	//	DestroyItem("VVDragomir")
	//	DestroyItem("MONHP1")
		JoinParty()~ EXIT
END

IF ~~ notparty1f
  SAY ~If you ask, mistress.~
  IF ~~ THEN DO ~
		JoinParty()~ EXIT
END

IF ~~ notpartGoST
   SAY ~Will go there.~
   IF ~~ THEN DO ~LeaveParty()
   RunAwayFromNoInterrupt(Player1,40)
   MoveBetweenAreas("AR0808",[143.829],SE)~ EXIT
 END  

// talk in party

IF ~Gender(Player1,MALE)
InParty(Myself)
~ THEN BEGIN GreetingMan
SAY ~Master?~ 
 IF ~Race(Player1,VAMPIRE)~ THEN REPLY ~Are you hungry? You can suck my blood, Dragomir.~ GOTO suckblood
 IF ~Global("BodhiStronghold","GLOBAL",2)~  THEN REPLY ~Go to our Stronghold in Grave Yard District. I will find you there, if it will be needed.~ GOTO notpartGoST 
 IF ~~ THEN REPLY ~Tell me your story, Dragomir.~ GOTO talkDragomirM
 IF ~~ THEN REPLY ~No, nothing right now, Dragomir.~ GOTO byesilentM
 IF ~~ THEN REPLY  ~I decided to end your life.~ GOTO talkEndInitFight1
END

IF ~!Gender(Player1,MALE)
InParty(Myself)
~ THEN BEGIN GreetingFemale
SAY ~Mistress?~ 
 IF ~Race(Player1,VAMPIRE)~ THEN REPLY ~Are you hungry? You can suck my blood, Dragomir.~ GOTO suckblood
 IF ~Global("BodhiStronghold","GLOBAL",2)~  THEN REPLY ~Go to our Stronghold in Grave Yard District. I will find you there, if it will be needed.~ GOTO notpartGoST 
 IF ~~ THEN REPLY ~Tell me your story, Dragomir.~ GOTO talkDragomirM
 IF ~~ THEN REPLY ~No, nothing right now, Dragomir.~ GOTO byesilentF
 IF ~~ THEN REPLY  ~I decided to end your life.~ GOTO talkEndInitFight1
END


IF ~~ byesilentF
SAY ~If you want me, just say.~
  IF ~~ THEN DO ~~ EXIT
END

IF ~~ byesilentM
SAY ~You are acting strange.~
  IF ~~ THEN DO ~~ EXIT
END


IF ~~ talkDragomirM
  SAY ~I was once a great warlord, world was in my hands. I fought many battles and thanks to my vampire abilities prevailed.~
  =
  ~Of cause, there is always a jealosy and greed. I commanded to create Dragomir's Respite to hold my coffin in another dimension.~
  =
  ~I used it to rest and regenerate. That is one of two things that Hexxat came to steal.~
  =
  ~And my minions have had Respite blocked and closed when I was regenerating there.~
  =
  ~For centuries I was locked in Graveyard district crypt, guarded with magical barrier.~
  =
  ~Hexxat came to steal my treasures. So I made her a vampiress and used her for my fun.~
  =
  ~She stolen my Respite than and set a magic barrier to prevent me from killing her.~
  =
  ~But it was all turned to good. I enjoyed sucking blood from people she dragged in to help her escape.~
  =
  ~And finally you managed to free me, even by killing, and to resurrect. Again thanks to this thief.~
  IF ~~ THEN DO ~~ EXIT
END






IF ~~ suckblood
  SAY ~Have a good meal, Dragomir.~
  IF ~!Global("Player1RaceBlood","GLOBAL",4)~ THEN GOTO suckbloodNo  
  IF ~Global("Player1RaceBlood","GLOBAL",4)~ THEN GOTO suckblood2
END

IF ~~ suckbloodNo
  SAY ~You blood is unfit!~
  IF ~~ THEN DO ~~ EXIT
END

IF ~~ suckblood2
  SAY ~Tasty!~
  IF ~~ THEN DO ~ApplyDamagePercent(Player1,80,MAGIC)
  SetGlobalTimer("BloodlustTimer","LOCALS",ONE_DAY)
		ApplySpell(Myself,RESTORE_FULL_HEALTH)~ EXIT 
END

IF ~~ vampconvm
  SAY ~(Dragomir roughly embraces you and gets closer to neck.)~
  IF ~!Global("Player1RaceBlood","GLOBAL",4)~ THEN GOTO suckbloodNo  
  IF ~Global("Player1RaceBlood","GLOBAL",4)~ THEN GOTO vampconv2
END


IF ~~ vampconvf
  SAY ~(Dragomir roughly embraces you and gets closer to neck.)~
  IF ~!Global("Player1RaceBlood","GLOBAL",4)~ THEN GOTO suckbloodNo  
  IF ~Global("Player1RaceBlood","GLOBAL",4)~ THEN GOTO vampconv2
END

IF ~~ vampconv2
  SAY ~(Suddently you feel that his teeths have pierced your skin and gone to carotid vein. Blood flow is distracted and becomes pulsating. You feel that your blood flows into Dragomir.)~
IF ~~ GOTO vampconv3
END

IF ~~ vampconv3
  SAY ~(Soon you feel great weakness, your throuths are clouded. And you loose consciousness.)~
IF ~~ GOTO vampconv4
END

IF ~~ vampconv4
  SAY ~(...You open your eyes. World around you have changed. You have changed. You feel coldness of your body and immediately you feel all-consuming hunger growing in you.)~
IF ~~ GOTO vampconv5
END

IF ~~ vampconv5
  SAY ~(You are now undead, as you wished. Now you feel presence of Dragomir and his ancient power.)~

  IF ~~ THEN DO ~  ActionOverride(Player1,SetGlobal("ActorVampirisedLevel","LOCALS",2))
		ChangeStat(Player1,CON,2,ADD)
		ChangeStat(Player1,STR,3,ADD)
		ChangeStat(Player1,WIS,-1,ADD)
		ChangeStat(Player1,INT,-1,ADD)
	

		SetGlobal("DragomirVampirized","GLOBAL",1)	
	~ EXIT
END



