--Installation--
Drop this folder (ScionMod) into your "..\Baldur's Gate Enhanced Edition\Data\00766\" usually found under "\Program Files (x86)".  DO NOT copy this into the folder found in your "My Documents" or similar sections.

You must already have BG:EE configured for mod installations.  If this is not the case, see in the later section "Mod setup" below.

Once that's done just double-click on "ScionMod Installer.bat", then enter "I" each of the three prompts (each component is described below under "Mod Description")

The Scion of Murder kit should now be ready to use.

--Uninstalling--

Double-click on "ScionMod Installer.bat" again, this time select "U" at each prompt.  Everything will then be uninstalled.

--Mod Setup--

The best directions I have found so far are found here: http://forum.baldursgate.com/discussion/6950/player-how-to-getting-mods-to-work-on-bgee/p1

Later versions of this Mod will come with tools to make this process easier.

--Mod Description--

This mod comes in two components:

Relax Restrictions: This removes the hard restriction on edged weapons for all clerics.  This does not allow any clerics to take those proficiencies (except for the Scion of Murder, of course).  This can be left uninstalled if a similar change is already in place, or if you'd prefer to play without this rule change.  Keep in mind that without this change, that the kit will have access to proficiencies that it will never be able to use.

Scion Kit:  This is the actual class kit, along with the spl files for two of the class abilities.  Description follows.

--Kit Description--

SCION OF MURDER: Some of the Bhaalspawn discovered their inherited power early in life and, whether they understood its true nature or not, embraced it. Rather than devoting themselves to some existing deity these scions turned their conviction inward, cultivating their own divine spark and reaping the nascent power of their progenitor.

ALIGNMENT: Any Chaotic or Evil
"Those who both respect the rule of law and the freedom or lives of others simply lack the ethical perspective required to become a living embodiment of murder."

EQUIPMENT: Scions may use Cleric equipment and wield all one handed melee weapons.  Scions have access to all styles except two-handed, and may specialize in daggers, short swords, the single weapon style, and dual wielding.
"The Bhaalspawn are Scions of murder, not wholesale slaughter. Thus they favor weapons that can be carried casually and quickly thrust between the ribs or skull of an unsuspecting enemy."

REQUIREMENTS: 12 Str, 9 Dex, 12 Wis

ADVANTAGES:
- Invisibility: Once per day at level 1, with an additional use every 4 levels thereafter
- Backstab: While invisible or otherwise hidden the Scion may backstab as a thief of the same level
- Hold Person: Once per day at level 5, with an additional use every 5 levels thereafter

DISADVANTAGES:
- None