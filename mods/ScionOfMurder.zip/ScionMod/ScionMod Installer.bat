CD ..
ScionMod\ScionMod.exe --tlkout DIALOG.TLK ScionMod\Setup-Scionmod.tp2