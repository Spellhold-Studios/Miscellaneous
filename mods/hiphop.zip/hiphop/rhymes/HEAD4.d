BEGIN ~HEAD4~

IF ~~ THEN BEGIN L-Mack101
SAY ~Evacuate the building bitch here come a plane
No, it's the madd ass Westside Connect Gang
And fuck what you plain nigga this who bang
With enough game to drive a square bitch insane
And we number one gunners no we ain't stunners
It's real with us hommie, killas and drug runners
And Mack need a D-board in a H2 Hummer
Lookin hotter than a mothafuckin L.A. summer
Let's go~
IF ~~ THEN EXTERN HEAD2 L-NateDogg2
END

IF ~~ THEN BEGIN L-Mack102
SAY ~It's a Gangsta Nation if you in you a G
And the whole world influence by the b in the sea
Now tell the truth rappers you don't bow like me
Cause I'm really from the gang ya'll is industry
And while I'm servin up and comin young hustlas and gluckas
Bangin for the hood causin havic and ruckus
You niggas actin label kissin ass like suckas
And your bitch solder down when you piss muthafuckas~
IF ~~ THEN EXTERN HEAD1 L-IceCube3
END

IF ~~ THEN BEGIN L-Mack103
SAY ~Look here man
Check this shit out man
you all might as well say fuck it
And join this Westside thang man
Cause we got a mothafuckin Gangsta Nation goin over here
And cause once you join this shit then you
as G as can mothafuckin Be Believe that homie
It ain't a hit till Nate Dogg spit~
IF ~~ THEN EXTERN HEAD2 L-NateDogg4
END