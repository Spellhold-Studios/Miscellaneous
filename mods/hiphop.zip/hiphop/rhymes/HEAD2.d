BEGIN ~HEAD2~

IF ~~ THEN BEGIN L-NateDogg1
SAY ~Na na na na na na na na (Westside)
Na na na na na na na na (ohh ohh)
Na na na na na na na na (what what)
Na na na na na na na na (So good)
Na na na na na na na na (yeah yeah)
Na na na na na na na na
Na na na na na na na na
Na na na na na na na na~
IF ~~ THEN EXTERN HEAD3 L-WC1
END

IF ~~ THEN BEGIN L-NateDogg2
SAY ~This game right here is rough as fuck
These hoes out here about the bucks
These fools out here afraid to bust
I have no fear, afraid of what
And in five beers I'm comin' up
Fools talk real loud but don't run up
When we come through they'd run it up
We still right here So what the fuck~
IF ~~ THEN EXTERN HEAD1 L-IceCube2
END

IF ~~ THEN BEGIN L-NateDogg3
SAY ~This game right here is rough as fuck
These hoes out here about the bucks
These fools out here afraid to bust
I have no fear, afraid of what
And in five beers I'm comin' up
Fools talk real loud but don't run up
When we come through they'd run it up
We still right here So what the fuck~
IF ~~ THEN EXTERN HEAD4 L-Mack102
END

IF ~~ THEN BEGIN L-NateDogg4
SAY ~This game right here is rough as fuck
These hoes out here about the bucks
These fools out here afraid to bust
I have no fear, afraid of what
And in five beers I'm comin' up
Fools talk real loud but don't run up
When we come through they'd run it up
We still right here So what the fuck~
=
~Na na na na na na na na
Na na na na na na na na
Na na na na na na na na
Na na na na na na na na~
IF ~~ THEN EXTERN HEAD1 L-IceCube4
END

IF ~~ THEN BEGIN L-NateDogg5
SAY ~Na na na na na na na na
Na na na na na na na na
Na na na na na na na na
Na na na na na na na na~
IF ~~ THEN DO ~SetGlobalTimer("IllaseraSpawnTimer","GLOBAL",30)
AddXP2DA("Heads")
StartCutSceneMode()
StartCutScene("Cut204g")~ EXIT
END