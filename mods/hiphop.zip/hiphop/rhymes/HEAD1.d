APPEND ~HEAD1~

IF WEIGHT #-5 ~True()~ THEN BEGIN L-IceCube1
SAY ~Consider this an invitation, to my Gangsta Nation~
IF ~~ THEN EXTERN HEAD2 L-NateDogg1
END
  
IF ~~ THEN BEGIN L-IceCube2
SAY ~What the fuck is Ice Cube talkin about
That's how you get these nuts parked in you mouth
Westside ride bitch, the same old shit
I don't conversate with pussy I ain't goin get
I don't holla at these hoes that sing like Ashante
Body like Beyonce, face like Andre (uhhh)
Bitch You kinda strange, but I'm rich with so my
Andre got to be bomb rate~
IF ~~ THEN EXTERN HEAD3 L-WC2
END

IF ~~ THEN BEGIN L-IceCube3
SAY ~One thing I do know I ain't the uno
Big puno rap sumo on pruno (you know)
I'd like to thank the congregation
In my affiliation to the Gangsta Nation
I'm hard on them, yeah I'm ruthless
You like stick pussy, nigga you useless
You know the side bitch, better get up on it
Cause it must be a single with Nate Dogg singin on it~
IF ~~ THEN EXTERN HEAD4 L-Mack103
END

IF ~~ THEN BEGIN L-IceCube4
SAY ~(Consider this an invitation, to my Gangsta Nation)~
IF ~~ THEN EXTERN HEAD2 L-NateDogg5
END
END