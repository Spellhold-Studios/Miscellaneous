BEGIN ~HEAD3~

IF ~~ THEN BEGIN L-WC1
SAY ~Nigga I'm tired of these niggas parkin that shit talkin that shit
From the concrete when they chalkin' that shit
In videos in a bitch pose and a throw back
Holdin' a gad ain't gonna bust and know that
It's a dub ass C thang dub C brain
And we don't FUCK with niggas in kaki g strings
Fuck moving I'm clearin the crowd
It's the who bangin bandana cri-mi-ni-mi-nal
The ori-gi-nal~
IF ~~ THEN EXTERN HEAD4 L-Mack101
END
  
IF ~~ THEN BEGIN L-WC2
SAY ~Have you seen us, naw Haters can't see us
Connect Gang we the G'est nigga
Countless calls and countless charges
Street niggas makin blunts out of Cuban cigars
Big by the linnas sip notic by the liters
With a back of hoes on us cause the cronic is the greenest
And to my G's incarcerated and on probation
I'ma stay bagin for the whole G Nation nigga~
IF ~~ THEN EXTERN HEAD2 L-NateDogg3
END