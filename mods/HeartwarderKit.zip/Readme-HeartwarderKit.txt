
                       ---------------------
                        Heartwarder of Sune
                            version 1.1
                       ---------------------

Bonus Cleric Kit for Baldur's Gate II: Throne of Bhaal



Install:
--------

Extract all files to the BG2 install folder
Run Setup-HeartwarderKit.exe and follow the prompt



Description:
------------

Sune Firehair encourages beauty, passion, and love wherever they may be
found. Heartwarders are aesthetes and hedonists who actively seek out
pleasure and beauty in all things and who nurture the creation of
beautiful objects.

Requirements:
- Chaotic Good alignment

Advantages:
- A Heartwarder is immune to charm effects
- At 4th level she gains +1 to her charisma permanently. She gains
  another point at 10th level, and a final one at 15th level.
- She has access to Charm Person as a level 1 cleric spell, and Dire
  Charm as a level 3 cleric spell
- A Heartwarder can kiss an ally to give him +1 morale bonus to hit and
  damage, and protection against fear for 2 turns. She can use this
  ability as many times as she wants, but she cannot use it on herself.
- At 8th level she gains the ability to sing with the voice of a Siren
  three times a day. Whenever she does so, nearby foes suffer -4 penalty
  to all of their saving throws for 2 turns.
- At 12th level she gains the ability to cry a single drop of tear drawn
  from the Pool of Evergold, once per day. The tear has the power to
  charm a single living creature until the magic is dispelled.

Disadvantages:
- A Heartwarder cannot wear plate mail or full plate armor
- She suffers an initial -1 penalty to strength and constitution



Version History:
----------------

1.0 - Initial Release
1.1 - Fixed a bug that caused the high level ability Dominating
        Presence not to work as intended
      Decreased Dominating Presence's duration on the caster to 2 turns
      Decreased Dominating Presence's duration on foes to 6 rounds
      Improved spell icons for Dominating Presence
      Improved text descriptions for several items and spells



Credits:
--------

by Adam Zsoldos (adul@adul.net)

Special thanks to Jarno Mikkola and Mike1072 at SHS forums, who were
patient enough to answer all of my questions



Thanks for downloading!
