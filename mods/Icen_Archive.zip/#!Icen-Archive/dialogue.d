BEGIN ~#!BrageJ~

BEGIN ~#!BrageP~

BEGIN ~#!BrageB~

APPEND BRAGE

IF WEIGHT #-1 ~Global("BrageRiddle","GLOBAL",1) Global("#!Brage","GLOBAL",1)~ BEGIN "#!100"
SAY ~Nalin! Must I remain within walls for the rest of my life? Surely atonement can be achieved on the road.~
IF ~~ THEN EXTERN NALIN "#!9"
END
END
CHAIN
IF ~Global("BrageRiddle","GLOBAL",1) Global("#!Brage","GLOBAL",1)~ THEN NALIN "#!9"
~You wish to loose yourself from here, and Helm's direct protection? Very well, and I can think of no better than <CHARNAME> to travel with you.~
== NALIN ~I have heard of a gibberling infestation, north of a Gnoll Stronghold, which you could do well to stop.~
== BRAGE ~I will take my leave, and soon report back with the area cleared.~
END
++ ~Indeed. We would be willing to have such an experienced soldier by our sides.~ DO ~SetGlobal("#!Brage",GLOBAL",2) ActionOverride("BRAGE",JoinParty())~ JOURNAL ~Brage's Penance. Brage has joined us for his redemption, first investigating an overdose of Gibberlings north of a Gnoll fortress. We both hope that fulfilling these tasks will bring Brage to favour again.~ EXIT
++ ~Not today, while admirable, we do not need another among us.~ EXIT

ALTER_TRANS BRAGE
BEGIN 9 END
BEGIN 0 END
BEGIN "ACTION" ~SetGlobal("#!Brage","GLOBAL",1)~ END

APPEND ~#!BrageJ~

IF ~Global("#!Brage1","GLOBAL",20) Global("#!Brage","GLOBAL",2)~ BEGIN "#!3"
SAY ~Well, that certainly is enough to keep them from attacking anywhere soon. Let us be off, and Nalin reported to!~
IF ~~ THEN DO ~SetGlobal("#!Brage","GLOBAL",3)~ JOURNAL ~We solved Brage's task of killing lots and lots of Gibberlings. Brage seems far more sure of himself, now that a blade hasn't made him kill us all.~ EXIT
END

IF ~Global("#!Brage","GLOBAL",10) GlobalLT("#!BrageBanters","GLOBAL",10)~ BEGIN "#!4"
SAY ~I can feel it, like a great weight lifting from my shoulders! We should speak to NALIN. To Nashkel!~
IF ~~ THEN DO ~~ EXIT
END

IF ~See("#!Priest") Global("#!PreistTalk","LOCALS",0)~ BEGIN "#!5"
SAY ~There is the priest! Soon we will be back to Nalin with lot of Gnoll corpses and a priest to boot! The act should surely finish my atonement!~
IF ~~ THEN DO ~SetGlobal("#!PriestTalk","LOCALS",1)~ EXIT
END

END

APPEND ~#!BrageP~

IF ~~ THEN BEGIN 1
SAY ~Is this to be my fate, then? To remain here until wolves or the garrison pick me off? I would venture on ahead, but I am afraid of losing myself before I am redempt.~
++ ~My mistake, Brage. Feel free to remain with us.~ DO ~JoinParty()~ EXIT
+ ~GlobalLT("#!Brage","GLOBAL",10)~ + ~No, I am afraid you will have to continue on your own. I hope we have given you a good start!~ DO ~SetGlobal("#!Brage","GLOBAL",10)~ JOURNAL ~We saw Brage off today, I can only hope that he doesn't perish before regaining his afterlife...~ EXIT
++ ~Huh, goodbye and good riddance.~ DO ~SetGlobal("#!Brage","GLOBAL",10)~ JOURNAL ~Brage was let loose again, couldn't stand him for too long. I am glad to be rid of him, and my reputation can return, now.~ EXIT 
+ ~Global("#!Brage","GLOBAL",10)~ + ~We have seen you through every task possible, Brage, it would be best if you could make your way to the Temple, I am sure you will be allowed passage.~ DO ~EscapeArea() MoveBetweenAreas("AR4802",[345.465],0)~ JOURNAL ~Now that we have seen Brage's tasks to an end, I am fairly confident he can make it to the temple on his own.~ EXIT
END
END
APPEND "NALIN"

IF WEIGHT #-1 ~Global("#!Brage","GLOBAL",3)~ BEGIN "#!99"
SAY ~Ah, I see you return victorious! Helm be praised!~
IF ~~ THEN EXTERN "#!BRAGEJ" "#!99"
END
END

CHAIN
IF ~Global("#!Brage","GLOBAL",3)~
THEN "#!BRAGEJ" "#!99"
~Yes, Helm be praised! We have accomplised something, and it is good to know that I will not go insane while holding a weapon.~
= ~However, I do not feel like I have achieved anything, that my tasks are only beginning. I am sure I am correct.~
== NALIN ~You are correct.~
= ~One of our brethren has been captured by the Gnolls, the same ones heartened by your assault on the Gibberlings.~
= ~They have attacked, far and wide, and been dealt with, mostly, but your assault needs to be at the centre of their fortress.~
= ~Attack, and reclaim a Priest of Helm!~
== "#!BRAGEJ" ~Yes, sir!~ EXIT

APPEND NALIN
IF WEIGHT #-1 ~Global("#!Brage,"GLOBAL",10) GlobalGT("#!Brage","GLOBAL",3)~ BEGIN "#!101"
SAY ~You return, with the captured priest, no less! Truly, you have earned your rights to a happy afterlife and a warm welcome at the Garrison again~
= ~However, I would enjoy it if you stayed here, with us.~
IF ~~ THEN EXTERN "#!BRAGEJ" "#!101"
END

IF ~~ THEN BEGIN "#!102" 
SAY ~<CHARNAME>, you have done especially well, and for this I will give you your due reward.~ 
IF ~~ THEN DO ~ActionOverride("#!Brage",DropInventory()) GivePartyGold(2500) AddexperienceParty(5000)~ JOURNAL ~We saw Brage off, to a happy new life as a respected Priest of Helm. Helm bless his penant soul.~ EXIT
END
END

APPEND "#!BRAGEJ"

IF ~~ THEN BEGIN "#!101"
SAY ~I agree, I have fought again, and my duties are loath to me. The sword is now my enemy, and I will enter into the clergy of Helm.~
IF ~~ THEN EXTERN NALIN "#!102"
END

END