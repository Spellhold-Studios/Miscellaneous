README
------

Mordan's Christmas Minimod WeiDU
======

WeiDU'd and Improved by hlidskialf in a moment of cold-medicine-induced abnormalicy.

Okay, I found this old mod of Mordan's in the dusty recesses of my HD.
It's been converted to WeiDU, bugfixed, and expanded to no longer need the CLUAConsole.
(It's was a creation of a TeamBG Xmas mod contest similar to the Iron Modder ones of FWP fame.)
So it IS silly. However, it is amusing and does deliver a usable item to the party in the end.
It even includes a custom made area by Mordan.

To start: Go to the Mithrest Inn in the Promenade sometime after chapter 2. Then follow the clues. 
Happy gaming and thanks to Mordan for allowing this mod to be resurrected for the masses.
  hlid.


History:

v1.0.0 - Initial Release

v1.0.1 - Added Russian translation (thanks aerie.ru)
       - Added German translation (thanks Meresin)

v1.0.2 - Fixed small traified bug in MDSDwarf.baf
       - Updated German translation
       - Added VERSION-flag
       - Added WeiDU v210

v1.0.3 - Added Italian translation (thanks Ilot)
       - Updated to WeiDU v211
