Sister of Bhaalspawn for BG2EE/EET

Author: Lassal

Version 0.2

Description:
After defeating Illasera you wake in your own Pocket Plane (Throne of Bhaal).
And here you meet your sister, that asks to join you.
Will you be caring brother/sister?
Or will you succumb to the calling of Bhaal taint and murder her?

This is demo. I didn't tested it normally through walkthrough of ToB. If you meet bugs, write in corresponding topic in the forums.

Portrait of sister has Creative Commons C0 license and don't require mentioning author (it was downloaded through pixabay.com).