EXTEND_TOP FINSOL01  28 #0 // from: 27.0
  IF ~InParty("bhsister")
!Dead("bhsister")~ THEN REPLY ~I don't need the essence of Bhaal for myself. But I want to give the Throne of Bhaal to my sister.~ GOTO sisterDecision1
  IF ~InParty("bhsister")
!Dead("bhsister")~ THEN REPLY ~I want to accept the essence of Bhaal, but divide it with my sister.~ GOTO sisterDecision2
END


APPEND FINSOL01



IF ~~ THEN BEGIN decisionSister // from: 32.0 31.0 30.0 29.0
  SAY  ~Your decision has been made, god-child. Now the act must be carried out... prepare yourself!~ [SOLAR107] 
  IF ~~ THEN DO ~SetGlobal("OHH_PCGod","GLOBAL",1)
StartCutSceneMode()
StartCutSceneEx("cut233i",FALSE)
~ EXIT
END




  
  
IF ~~ sisterDecision1
  SAY ~You want to give an enormous powers to her? She is a terrible evil. Well, maybe she is really fit to be father's successor. But making her a god is a worst thing that can happen. But it's yours choice. Only Bhaalspawn can have a Throne of Bhaal. Ao will make her a successor to the Throne.~
  IF ~~ THEN DO ~SetGlobal("PlayerChoseSister1","GLOBAL",1)~ GOTO decisionSister
END  

  
IF ~~ sisterDecision2
  SAY ~You want to give a half an enormous power to her? She is a terrible evil. Well, you cared for her until this, I hope you can control her and weaken her hunger. But it's yours choice. Only Bhaalspawn can have a Throne of Bhaal. Ao will make you and your sister successors to the Throne.~
  IF ~~ THEN DO ~SetGlobal("PlayerChoseSister2","GLOBAL",1)~ GOTO decisionSister
END  

END