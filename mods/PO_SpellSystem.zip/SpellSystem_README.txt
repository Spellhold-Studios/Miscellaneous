ALTERNATE SPELL SYSTEM FOR BG2

The short explanation: This implements a mana-based spell system for party
members in Baldur's Gate II. You can memorize spells at any time by pressing V. 
You can see how many mana points remain by hitting N. When your mana points drop 
below 0, you will suffer a penalty, and will not be able to cast spells again 
until resting. Spells take away mana point values equal to their casting level, 
so a level 1 spell like Magic Missile will take away 1 point, and a level 3 
spell like Fireball will take away 3 points. There are also slight modifications 
to existing spells.

The longer explanation: I had to modify every wizard spell in the game to set 
the appropriate variables. This mod basically takes over the GENERAL and MAGE 
script slots for wizard party members, so be careful in modding this. Very low-
level spellcasting is now allowed in Athkatla--as long as its not a large enough 
disturbance for the council to nice. Also check out SPPR318 (Zone of Sweet Air) 
to figure out the new way I handle dispelling area of effects. You can also use 
this method to script characters avoiding them!

By MaxTeamBG, aka Potencius
http://www.dragonlancetc.com
