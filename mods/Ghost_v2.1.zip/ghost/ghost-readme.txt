GHOST


Adds a new Bhaalspawn ability to the end of ToB.

F�gt eine neue Bhaalspawn F�higkeit am Ende von TdB hinzu.



Version 1
- Initial Release

Version 2 (31 March 2009 by Leomar)
- Corrected the COMPILE command
- Added German translation by Drogan Di'Umptu
- Added VERSION flag
- Added Ghost-readme.txt
- Added WeiDU v210

Version 2.1 (01 April 2010 by Leomar)
- Added Spanish translation by Lisandro
- Added backup folder
- Moved setup-ghost.tp2 into the mod folder
- Changed to README command
- Updated to WeiDU v215
