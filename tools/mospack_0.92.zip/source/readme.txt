MosPack source code
-------------------

The source is in POSIX ANSI C, and should compile on most platforms.
The included makefiles are for mingw32 (windows) and gcc/unix.

The source depends on gzip.org's zlib by Jean-loup Gailly and Mark
Adler, and the Independent JPEG Group's jpeg library. Download them
from

  http://www.gzip.org/zlib/
  http://www.ijg.org/files/


License
-------

/*
  MosPack
  version 0.92, 2005-03-26
  by Yacomo

  Notice from original tispack:

  based on
  TisPack, a tileset compression utility
  version 0.91, 2004-05-14
  Copyright (C) 2004 Per Olofsson

  This software is provided 'as-is', without any express or implied
  warranty.  In no event will the author be held liable for any damages
  arising from the use of this software.

  Permission is granted to anyone to use this software for any purpose,
  including commercial applications, and to alter it and redistribute it
  freely, subject to the following restrictions:

  1. The origin of this software must not be misrepresented; you must not
     claim that you wrote the original software. If you use this software
     in a product, an acknowledgment in the product documentation would be
     appreciated but is not required.
  2. Altered source versions must be plainly marked as such, and must not be
     misrepresented as being the original software.
  3. This notice may not be removed or altered from any source distribution.

  Per Olofsson (MagerValp@cling.gu.se)

*/
