int vers_major = 0;
int vers_minor = 92;
char copyright[] = "mospack by Yacomo 2005 based on tispack (C) Per Olofsson 2004";
