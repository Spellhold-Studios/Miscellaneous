extern int vers_major;
extern int vers_minor;
extern char copyright[];
