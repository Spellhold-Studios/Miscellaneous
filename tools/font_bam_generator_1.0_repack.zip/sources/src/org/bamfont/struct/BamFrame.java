package org.bamfont.struct;

import java.nio.ByteOrder;

import javolution.io.Struct;

/**
 * Defines a BAM frame.
 * 
 * @author Marcin Gałązka
 */
public class BamFrame extends Struct
{
	public final Unsigned16 width = new Unsigned16();
	public final Unsigned16 height = new Unsigned16();
	public final Signed16 centerX = new Signed16();
	public final Signed16 centerY = new Signed16();
	public final Unsigned32 flag = new Unsigned32();
	
	public BamFrame()
	{
	}
	
	public BamFrame(int width, int height, short centerX, short centerY, long flag)
	{
		this.width.set(width);
		this.height.set(height);
		this.centerX.set(centerX);
		this.centerY.set(centerY);
		this.flag.set(flag);
	}
	
	@Override
	public ByteOrder byteOrder()
	{
		return ByteOrder.LITTLE_ENDIAN;
	}
}