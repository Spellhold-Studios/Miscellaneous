package org.bamfont.struct;

import java.nio.ByteOrder;

import javolution.io.Struct;

/**
 * Defines a BAM header.
 * 
 * @author Marcin Gałązka
 */
public class BamHeader extends Struct
{
	public final UTF8String signature = new UTF8String(4);
	public final UTF8String version = new UTF8String(4);
	public final Unsigned16 framesCount = new Unsigned16();
	public final Unsigned8 cyclesCount = new Unsigned8();
	public final Unsigned8 compressedColorIndex = new Unsigned8();
	public final Unsigned32 framesOffset = new Unsigned32();
	public final Unsigned32 paletteOffset = new Unsigned32();
	public final Unsigned32 frameLookupTableOffset = new Unsigned32();
	
	@Override
	public ByteOrder byteOrder()
	{
		return ByteOrder.LITTLE_ENDIAN;
	}
}