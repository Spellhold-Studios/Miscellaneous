package org.bamfont.struct;

import java.nio.ByteOrder;

import javolution.io.Struct;

/**
 * Defines a BAM cycle (animation).
 * 
 * @author Marcin Gałązka
 */
public class BamCycle extends Struct
{
	public final Unsigned16 indicesCount = new Unsigned16();
	public final Unsigned16 lookupTableIndex = new Unsigned16();
	
	public BamCycle(int indicesCount, int lookupTableIndex)
	{
		this.indicesCount.set(indicesCount);
		this.lookupTableIndex.set(lookupTableIndex);
	}
	
	@Override
	public ByteOrder byteOrder()
	{
		return ByteOrder.LITTLE_ENDIAN;
	}
}