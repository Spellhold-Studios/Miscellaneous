package org.bamfont.cli;

import java.nio.charset.Charset;

import org.kohsuke.args4j.CmdLineException;
import org.kohsuke.args4j.CmdLineParser;
import org.kohsuke.args4j.OptionDef;
import org.kohsuke.args4j.spi.OptionHandler;
import org.kohsuke.args4j.spi.Parameters;
import org.kohsuke.args4j.spi.Setter;

/**
 * An argument handler for the {@link Charset} type.
 * 
 * @author Marcin Gałązka
 */
public class CharsetHandler extends OptionHandler<Charset>
{
	public CharsetHandler(CmdLineParser parser, OptionDef option, Setter<? super Charset> setter)
	{
		super(parser, option, setter);
	}

	@Override
	public String getDefaultMetaVariable()
	{
		return "CHARSET";
	}

	@Override
	public int parseArguments(Parameters params) throws CmdLineException
	{
		setter.addValue(Charset.forName(params.getParameter(0)));
        return 1;
	}
}