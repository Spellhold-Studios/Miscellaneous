package org.bamfont.cli;

import org.kohsuke.args4j.CmdLineException;
import org.kohsuke.args4j.CmdLineParser;
import org.kohsuke.args4j.OptionDef;
import org.kohsuke.args4j.spi.OptionHandler;
import org.kohsuke.args4j.spi.Parameters;
import org.kohsuke.args4j.spi.Setter;

/**
 * An argument handler for the boolean type.
 * 
 * @author Marcin Gałązka
 */
public class BooleanHandler extends OptionHandler<Boolean>
{
	public BooleanHandler(CmdLineParser parser, OptionDef option, Setter<? super Boolean> setter)
	{
		super(parser, option, setter);
	}

	@Override
	public String getDefaultMetaVariable()
	{
		return "BOOLEAN";
	}

	@Override
	public int parseArguments(Parameters params) throws CmdLineException
	{
		String value = params.getParameter(0);
		if (value.equals("true") == true)
			setter.addValue(true);
		else
			if (value.equals("false") == true)
				setter.addValue(false);
			else
				throw new CmdLineException("Invalid boolean value: " + value + ".");
        return 1;
	}
}