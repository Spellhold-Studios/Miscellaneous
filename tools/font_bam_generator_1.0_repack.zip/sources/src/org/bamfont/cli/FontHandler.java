package org.bamfont.cli;

import java.awt.Font;

import org.kohsuke.args4j.CmdLineException;
import org.kohsuke.args4j.CmdLineParser;
import org.kohsuke.args4j.OptionDef;
import org.kohsuke.args4j.spi.OptionHandler;
import org.kohsuke.args4j.spi.Parameters;
import org.kohsuke.args4j.spi.Setter;

/**
 * An argument handler for the {@link Font} type.
 * 
 * @author Marcin Gałązka
 */
public class FontHandler extends OptionHandler<Font>
{
	public FontHandler(CmdLineParser parser, OptionDef option, Setter<? super Font> setter)
	{
		super(parser, option, setter);
	}

	@Override
	public String getDefaultMetaVariable()
	{
		return "FONT";
	}

	@Override
	public int parseArguments(Parameters params) throws CmdLineException
	{
		setter.addValue(Font.decode(params.getParameter(0)));
        return 1;
	}
}