package org.bamfont;

import java.awt.Color;
import java.awt.Font;
import java.awt.Graphics2D;
import java.awt.font.FontRenderContext;
import java.awt.font.GlyphVector;
import java.awt.font.TextLayout;
import java.awt.geom.Rectangle2D;
import java.awt.image.BufferedImage;
import java.awt.image.IndexColorModel;
import java.io.ByteArrayOutputStream;
import java.io.DataOutputStream;
import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.OutputStream;
import java.io.UnsupportedEncodingException;
import java.nio.charset.Charset;
import java.text.MessageFormat;
import java.util.ArrayList;

import org.bamfont.cli.BooleanHandler;
import org.bamfont.cli.CharsetHandler;
import org.bamfont.cli.FontHandler;
import org.bamfont.struct.BamCycle;
import org.bamfont.struct.BamFrame;
import org.bamfont.struct.BamHeader;
import org.kohsuke.args4j.CmdLineException;
import org.kohsuke.args4j.CmdLineParser;
import org.kohsuke.args4j.Option;

/**
 * This class generates a BAM file {@linkplain http://iesdp.gibberlings3.net/file_formats/ie_formats/bam_v1.htm}
 * with a bitmap font characters usable by Infinity Engine-based games.
 * 
 * @author Marcin Gałązka
 */
public class Generator
{
	// BAM structs sizes.
	private static final int HEADER_SIZE = 24;
	private static final int FRAME_SIZE = 12;
	private static final int CYCLE_SIZE = 4;

	// Command line arguments.
	@Option (name="-out", required=true, usage="an output BAM file")
	File file;
	@Option (name="-charset", required=true, usage="charset", handler=CharsetHandler.class)
	Charset charset;
	@Option (name="-font", required=true, usage="font description", handler=FontHandler.class)
	Font font;
	@Option (name="-useAA", usage="if antialiasing should be used, default true", handler=BooleanHandler.class)
	boolean useAntiAliasing = true;
	@Option (name="-drawShadow", usage="if a shadow should be drawn, default false", handler=BooleanHandler.class)
	boolean drawShadow = false;
	
	/**
	 * A grayscale palette used to render fonts.
	 */
	private IndexColorModel colorModel = null;
	
	/**
	 * Generated BAM frame structs.
	 */
	private ArrayList<BamFrame> frames = new ArrayList<BamFrame>();
	
	/**
	 * Generated frames data (indices into the palette).
	 */
	private ArrayList<byte[]> framesData = new ArrayList<byte[]>();

	/**
	 * An application entry points.
	 * 
	 * @param args command line arguments.
	 * 
	 * @throws IOException if I/O error happens.
	 */
	public static void main(String[] args) throws IOException
	{
		Generator generator = new Generator();
		
		CmdLineParser parser = new CmdLineParser(generator);
		try
		{
			parser.parseArgument(args);
		} 
		catch (CmdLineException e)
		{
			System.out.println("Invalid arguments: " + e.getMessage());
			System.out.println("Usage:");
			parser.printSingleLineUsage(System.out);
			System.out.println("\nArguments description:");
			parser.printUsage(System.out);
			return;
		}
		
		generator.generate();
	}
	
	/**
	 * Generate font BAM using provided configuration.
	 * 
	 * @throws IOException if I/O error happens.
	 */
	public void generate()
	{
		System.out.println("A font generator for Infinity Engine based games.");
		System.out.println("This software uses args4j and javolution libraries.");
		System.out.println();
		System.out.println(MessageFormat.format("Generating BAM file to {0} using {1} font and {2} charset, " +
				"antiliasing is {3}, shadow is {4}.", file.getAbsolutePath(), font, charset, useAntiAliasing, drawShadow));
		System.out.flush();
		
		try
		{
			createColorModel();
			char[] chars = createCharacters();
			
			for (char c: chars)
				createFrameForCharacter(c);
			createBam();
			
			System.out.println("Done.");
		}
		catch (IOException e)
		{
			System.out.println("Error while generating BAM: " + e.getMessage());
		}
	}
	
	/**
	 * Creates a palette.
	 */
	private void createColorModel()
	{
		byte[] t = new byte[256];
		for (short i = 255; i >= 0; i--)
			t[255 - i] = (byte) (i < 128 ? i : i - 256);
		colorModel = new IndexColorModel(8, 256, t, t, t);
	}
	
	/**
	 * Creates characters to render. A font BAM contains 255 characters.
	 * 
	 * @return characters to render.
	 * 
	 * @throws UnsupportedEncodingException if requested charset is not available on this platform.
	 */
	private char[] createCharacters() throws UnsupportedEncodingException
	{
		byte[] t = new byte[255];
		for (int i = 1; i < 256; i++)
			t[i - 1] = (byte) (i < 128 ? i : i - 256);
		
		return new String(t, charset).toCharArray();
	}
	
	/**
	 * Generates a frame - frame struct and frame data - for a single character.
	 * 
	 * @param c the character.
	 */
	private void createFrameForCharacter(char c)
	{
		FontRenderContext fontCtx = new FontRenderContext(null, useAntiAliasing, false);
		GlyphVector glyphVector = font.createGlyphVector(fontCtx, "" + c);
		
		// Calculate character bounds.
        Rectangle2D bounds = glyphVector.getLogicalBounds();
        int width = (int) Math.max(Math.round(bounds.getWidth()), 1);
        int height = (int) Math.max(Math.round(bounds.getHeight()), 1);
        if (drawShadow == true)
        {
        	width += 1;
        	height += 1;
        }
		
        // Render character.
        BufferedImage img = new BufferedImage(width, height, BufferedImage.TYPE_BYTE_INDEXED, colorModel);
        Graphics2D graphics = img.createGraphics();
        TextLayout textLayout = new TextLayout("" + c, font, fontCtx);
        graphics.setColor(Color.WHITE);
        graphics.fillRect(0, 0, width, height);
        if (drawShadow == true)
        {
        	graphics.setColor(new Color(240, 240, 240));
        	graphics.drawGlyphVector(glyphVector, 1, textLayout.getAscent() + 1);
        }
        graphics.setColor(Color.BLACK);
        graphics.drawGlyphVector(glyphVector, 0, textLayout.getAscent());
        
        framesData.add(getImageData(img));
        int centerX = drawShadow == false ? 0 : -1;
		frames.add(new BamFrame(width, height, (short) centerX, (short) (textLayout.getAscent() + textLayout.getDescent()), 0));
	}
	
	private byte[] getImageData(BufferedImage img)
	{
		byte[] t = (byte[]) img.getRaster().getDataElements(0, 0, img.getWidth(), img.getHeight(), null);
		return compress(t, 0);
	}
	
	/**
	 * Compress given data using RLE.
	 * 
	 * @param data the data to compress.
	 * @param compressedIndex an index, which should be compressed.
	 * 
	 * @return a compressed data.
	 */
	private byte[] compress(byte[] data, int compressedIndex)
	{
		ByteArrayOutputStream out = new ByteArrayOutputStream();
		int count = 0;
		
		for (byte b : data)
		{
			if (b != compressedIndex)
			{
				if (count > 0)
				{
					writeCompressed(count, compressedIndex, out);
					count = 0;
				}
				out.write(b);
			}
			else
				count++;
		}
		if (count > 0)
			writeCompressed(count, compressedIndex, out);
				
		return out.toByteArray();
	}
	
	/**
	 * Writes a compressed sequence.
	 * 
	 * @param count the sequence size.
	 * @param out an output stream.
	 */
	private void writeCompressed(int count, int compressedIndex, ByteArrayOutputStream out)
	{
		if (count > 256)
		{
			out.write(compressedIndex);
			out.write(255);
			count -= 256;
		}
		out.write(compressedIndex);
		out.write(count - 1);
	}
	
	/**
	 * Creates an output BAM.
	 * 
	 * @throws IOException if I/O error happens.
	 */
	public void createBam() throws IOException
	{
		DataOutputStream dataOut = new DataOutputStream(new FileOutputStream(file));
		
		// A header.
		BamHeader header = createHeader((short) frames.size());	
		header.write(dataOut);
		// Frames structs.
		int dataOffset = (int) (header.frameLookupTableOffset.get() + frames.size() * 2);
		for (int i = 0; i < frames.size(); i++)
		{
			BamFrame frame = frames.get(i);
			frame.flag.set(dataOffset);
			frame.write(dataOut);
			dataOffset += framesData.get(i).length;
		}
		// Cycles.
		for (int i = 0; i < frames.size(); i++)
			new BamCycle(1, i).write(dataOut);
		// Palette.
		writePalette(dataOut);
		// Lookup table indices.
		for (int i = 0; i < frames.size(); i++)
			writeShort(dataOut, i);
		// Frames data.
		for (int i = 0; i < frames.size(); i++)
			dataOut.write(framesData.get(i));
	}
	
	/**
	 * Creates a BAM header.
	 * 
	 * @param count number of frames.
	 * 
	 * @return created header.
	 * 
	 * @throws IOException if I/O error happens.
	 */
	private BamHeader createHeader(short count) throws IOException
	{
		BamHeader header = new BamHeader();
		header.signature.set("BAM ");
		header.version.set("V1  ");
		header.compressedColorIndex.set((short) 0);
		header.cyclesCount.set(count);
		header.framesCount.set(count);
		header.framesOffset.set(HEADER_SIZE);
		header.paletteOffset.set(HEADER_SIZE + count * (FRAME_SIZE + CYCLE_SIZE));
		header.frameLookupTableOffset.set(256 * 4 + header.paletteOffset.get());

		return header;
	}
	
	/**
	 * Writes a palette.
	 * 
	 * @param out an output stream.
	 * 
	 * @throws IOException if I/O error happens.
	 */
	private void writePalette(OutputStream out) throws IOException
	{
		int[] palette = new int[256];
		colorModel.getRGBs(palette);
		for (int i : palette)	// Write each color as BGRA.
		{
			Color color = new Color(i);
			out.write(color.getBlue());
			out.write(color.getGreen());
			out.write(color.getRed());
			out.write(0);
		}
	}
	
	/**
	 * Writes given int as an unsigned, little endian short.
	 * 
	 * @param out an output stream.
	 * @param i a value to write.
	 * 
	 * @throws IOException if I/O error happens.
	 */
	private void writeShort(DataOutputStream out, int i) throws IOException
	{
		short s = (short) (((i & 0xff) << 8) + ((i & 0xff00) >> 8));
		out.writeShort(s);
	}
}