The utility (binaries and sources) attached. This is command line application, requires JRE (Java) 1.5 or greater. Unpack font-bam-generator-1.0.zip to whatever directory.

Usage:
-charset CHARSET [-drawShadow BOOLEAN] -font FONT -out FILE [-useAA BOOLEAN]

Parameters description:

  charset - this is a name of the charset used to encode text entries (TLK and so on). I think that this is always some 1-byte-per-character encoding like iso-8859-1 for english version and cp1250 for polish version.
  drawShadow - if bottom-right, 1x1 pixel shadow should be drawn for every character. This is tailored to the floating font, where characters should be better distinguishable from a background. Optional, default false.
  font - font description like "DejaVu Sans Bold 14" or "Tahoma Italic 15". It should be something decodable via Font#decode(), otherwise some default dialog font is used as an fallback.
  out - a path for the output BAM.
  useAA - if greyscale antialiasing should be used. Optional, default true.

Example:
java -jar font-bam-generator-1.0.jar -charset cp1250 -font "DejaVu Serif Bold 14" -out /tmp/test.bam -useAA true -drawShadow false

I suppose that integrating all above with UI installation would be problematic. Anyway, we could pregenerate BAMs for every known PS:T translation. We just need to know proper charset and get some font with support for language specific characters.

And btw, "1.0" means that this is first public version. It doesn't claim to be rock solid and bug free. It should not rape your kitty neverthless :].