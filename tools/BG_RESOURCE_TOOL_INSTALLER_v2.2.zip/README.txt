	-------------------------------------------------------------------
	*** *** *** Resource Pool Kit Upgrade TOOL, Version 2.2 *** *** ***
	-------------------------------------------------------------------
	
I N D E X :
1. LEGAL NOTICE - [legal]
2. Introduction - [int]
3. Installation - [inst]
4. Credits and Acknowledgements [cack]
5. Version notes - [version]

---------------------------------------------------------------------------------------------
1.	*** LEGAL NOTICE *** - [legal]

You have permission to use this TOOL in your MODS if you follow the following:
1.	Give credit to yowavegamer@gmail.com.
2.	Give links to the discussions about this tool, those are the links:
	a. https://forums.beamdog.com/discussion/66048/tool-resource-pool-kit-upgrade#latest
	b. http://gibberlings3.net/forums/index.php?showforum=13

---------------------------------------------------------------------------------------------
2.	*** INTRODUCTION *** - [int]

With this tool you'll be able to upgrade your own KIT abilities so they'll use a resource pool.
It goes without saying that planning your Kit with the resource pool in mind, will make the Kit much more engaging and fun to play with.

The method of Resource Pool was first developed for my KIT "Way Of The Fist",
check it out at: https://forums.beamdog.com/discussion/62445/kit-way-of-the-fist-1-3-testers-requiered

This Method introduces a new game mechanic which fuels the KIT abilities,
whenever you use an ability it subtracts number of resource points from the resource pool.
Taking my "Way Of The Fist" KIT as an example:
Say you currently have 10 points of resource pool.
You also have those abilities learned:
	a. Enhence Self, cost 1 point
	b. Ki Coat, cost 2 points
	c. Quivering Palm, cost 5 points
	
casting Quivering Palm will subtract 5 ki points from the resource pool, which means you'll be left with
5 resource points, which can be used those to cast 1 Qivering Palm, 2 Ki Coat and 1 Enehnce Self, or 5 Enhence Self.

---------------------------------------------------------------------------------------------
3.	*** INSTALLATION *** - [inst]

You should note that the TOOL comes in ZIP format. Most versions of windows should be able to extract the file.
Winzip can be used if you can't extract the files using windows built in zip extractor: http://www.winzip.com/win/en/prod_down.html

Instructions:

1. 	place the zip file in your KIT installation folder, where all the ".spl",".2da",".eff",etc.. files are.

2. 	right click the zip file and select Extract Here. Then move the zip file to another location.

3. 	Open settings.ini and fill in the information, it'll be best to open it with NOTEPAD++,
	because it'll highlight the ever important instructions.
	
4.	double click BG_RESOURCE_TOOL_INSTALLER.exe

5. 	When the installation will be DONE! you'll find those new things:
	1. 	ADD_THIS_TO_TP2.txt, will have new instructions that you'll need to copy to your installation.tp2 file.
		You might need to edit some things, so do make sure to go over it!
	2.	RESOURCE_POOL_DATA folder, which will hold all the required files, in this folder you'll find:
		a.	2DA folder, holds your CLAB file with all the abilities and passives arranged in the most efficient way
		b.	BAF folder, will hold all the scripts that have been created automatically according to settings.ini
		c.	SPL folder, edited spells, do note that there are 2 version of the same spell <SPELL_NAME> and <SPELL_NAME_RES>.
			<SPELL_NAME> - this spell is the one you'll cast and it casts <SPELL_NAME_RES>, if needed only patch: name,description,icon,flags,exclusion flags,primary/secondary type
			<SPELL_NAME_RES> - 	the real spell with the real effects, patch whatever you want.

6.	If you have any questions/suggestions you can find me lurking at shsforums/gibberlings3/beamdog forums.
	My user name is Yowave in all of those!
	Or contact me by email yowavegamer@gmail.com.
	
---------------------------------------------------------------------------------------------
4.	*** Credits and Acknowledgements *** - [cack]

1.	I would like to thank the creators of the tools I used in the writing of this mod:
		1. Near Infinity, by Jon Hauglid and Argent77
		2. NotePad++, by Don Ho
2.	Special thanks to kjeron and subtledoctore from BEAMDOG forums, Thank you both for asking the right
	Questions, and giving your valuble insight, by doing so, you stimulated my nurons in the right direction.
		
---------------------------------------------------------------------------------------------
5.	*** Version notes *** - [version]

Version 2.2 - 11/09/2015:
	*	Added COPY CLAB to ADD_THIS_TO_TP2.txt
	*	Added Append RemoveSpellRES and ApplySpellRES to ACTSLEEP.IDS, added to ADD_THIS_TO_TP2.txt
	*	USERHPRES.SPL is now copied to RESOURCE_POOL_DATA\SPL
	*	<SPELL_NAME> - having the right number of abilities, before it had an ability for every ability in the original spell.
	
Version 2.1 - 10/09/2015:
	*	Fixed hp penalty.
	*	Changed settings_.ini to settings.ini

Version 2.0 - 10/09/2017:
	*	Special thanks to kjeron and subtledoctore from BEAMDOG forums. Thank you both for asking the right
		Questions, and giving your valuble insight, by doing so, you stimulated my nurons in the right direction.
	*	Some big changes under the hood.
	*	Now works with long casting spells.

Version 1.2 - 06/09/2017:
	* 	Removed OUTPUT_DIRECTORY from settings.ini
	* 	Fixed spell cost, casted spell cost 1 point more than it should be, 
		now substructing the right amonut of points.
		
Version 1.1 - 05/09/2017:
	* 	Minor fix to readme
	
Version 1.0 - 05/09/2017:
	* 	First public release