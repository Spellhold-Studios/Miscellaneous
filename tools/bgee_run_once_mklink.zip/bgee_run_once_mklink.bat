@setlocal enableextensions
@cd /d "%~dp0"

:: replace the en_US part of this command with the appropriate folder for non-English installs
IF NOT EXIST dialog.tlk (mklink /H dialog.tlk .\lang\en_US\dialog.tlk)



:: create override foler
IF NOT EXIST override (mkdir override)

IF EXIST "%userprofile%\Documents\Baldur's Gate - Enhanced Edition" (goto yours)
IF EXIST "%userprofile%\My Documents\Baldur's Gate - Enhanced Edition" (goto mine)
goto none

: yours
:: check for and create folders only if they don't exist already

IF NOT EXIST baldur.ini (mklink /H baldur.ini "%userprofile%\Documents\Baldur's Gate - Enhanced Edition\baldur.ini")

IF NOT EXIST "%userprofile%\Documents\Baldur's Gate - Enhanced Edition\save" (
  mkdir "%userprofile%\Documents\Baldur's Gate - Enhanced Edition\save"
)
IF NOT EXIST "%userprofile%\Documents\Baldur's Gate - Enhanced Edition\characters" (
  mkdir "%userprofile%\Documents\Baldur's Gate - Enhanced Edition\characters"
)
IF NOT EXIST "%userprofile%\Documents\Baldur's Gate - Enhanced Edition\Portraits" (
  mkdir "%userprofile%\Documents\Baldur's Gate - Enhanced Edition\Portraits"
)
:: now that those folders are created, create links if they're not present already
IF NOT EXIST save (
  mklink /D save "%userprofile%\Documents\Baldur's Gate - Enhanced Edition\save"
)
IF NOT EXIST characters (
  mklink /D characters "%userprofile%\Documents\Baldur's Gate - Enhanced Edition\characters"
)
IF NOT EXIST Portraits (
  mklink /D Portraits "%userprofile%\Documents\Baldur's Gate - Enhanced Edition\Portraits"
)
goto end

: mine
:: check for and create folders only if they don't exist already

IF NOT EXIST baldur.ini (mklink /H baldur.ini "%userprofile%\My Documents\Baldur's Gate - Enhanced Edition\baldur.ini")

IF NOT EXIST "%userprofile%\My Documents\Baldur's Gate - Enhanced Edition\save" (
  mkdir "%userprofile%\My Documents\Baldur's Gate - Enhanced Edition\save"
)
IF NOT EXIST "%userprofile%\My Documents\Baldur's Gate - Enhanced Edition\characters" (
  mkdir "%userprofile%\My Documents\Baldur's Gate - Enhanced Edition\characters"
)
IF NOT EXIST "%userprofile%\My Documents\Baldur's Gate - Enhanced Edition\Portraits" (
  mkdir "%userprofile%\My Documents\Baldur's Gate - Enhanced Edition\Portraits"
)
:: now that those folders are created, create links if they're not present already
IF NOT EXIST save (
  mklink /D save "%userprofile%\My Documents\Baldur's Gate - Enhanced Edition\save"
)
IF NOT EXIST characters (
  mklink /D characters "%userprofile%\My Documents\Baldur's Gate - Enhanced Edition\characters"
)
IF NOT EXIST Portraits (
  mklink /D Portraits "%userprofile%\My Documents\Baldur's Gate - Enhanced Edition\Portraits"
)
goto end

:none
ECHO "Can't find Documents folder, not making links"

:end
pause