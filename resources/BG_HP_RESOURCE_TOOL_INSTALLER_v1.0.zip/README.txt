	-------------------------------------------------------------------
	*** *** *** HP As Resource, Kit Upgrade TOOL, Version 1.0 *** *** ***
	-------------------------------------------------------------------
	
I N D E X :
1. LEGAL NOTICE - [legal]
2. Introduction - [int]
3. Installation - [inst]
4. Credits and Acknowledgements [cack]
5. Version notes - [version]

---------------------------------------------------------------------------------------------
1.	*** LEGAL NOTICE *** - [legal]

You have permission to use this TOOL in your MODS if you follow the following:
1.	Give credit to yowavegamer@gmail.com.
2.	Give links to the discussions about this tool, those are the links:
	a. https://forums.beamdog.com/discussion/66048/tool-resource-pool-kit-upgrade#latest
	b. http://gibberlings3.net/forums/index.php?showforum=13

---------------------------------------------------------------------------------------------
2.	*** INTRODUCTION *** - [int]

This is a follow up for another game mechanic i introduced named "Resource Pool",
Check it out at: https://forums.beamdog.com/discussion/66048/tool-resource-pool-kit-upgrade-2-2

With this tool you'll be able to upgrade your own KIT abilities so they'll use HP  as a resource, to fuel their effects.
It goes without saying that planning your Kit with HP as a resource in mind, will make the Kit much more engaging and fun to play with.

This Method introduces a new game mechanic which fuels the KIT abilities,
whenever you use an ability it drains number of HP points from the user to fuel the ability.
Each ability in the ability bar will have a number, this number denotes how much HP will be drained, when the ability is used.

Now go make, Vampires,Blood Mages,Psionics and what not!

---------------------------------------------------------------------------------------------
3.	*** INSTALLATION *** - [inst]

You should note that the TOOL comes in ZIP format. Most versions of windows should be able to extract the file.
Winzip can be used if you can't extract the files using windows built in zip extractor: http://www.winzip.com/win/en/prod_down.html

Instructions:

1. 	place the zip file in your KIT installation folder, where all the ".spl",".2da",".eff",etc.. files are.

2. 	right click the zip file and select Extract Here. Then move the zip file to another location.

3. 	Open settings.ini and fill in the information, it'll be best to open it with NOTEPAD++,
	because it'll highlight the ever important instructions.
	
4.	double click BG_HP_RESOURCE_TOOL_INSTALLER.exe

5. 	When the installation will be DONE! you'll find those new things:
	1. 	ADD_THIS_TO_TP2.txt, will have new instructions that you'll need to copy to your installation.tp2 file.
		You might need to edit some things, so do make sure to go over it!
	2.	RESOURCE_POOL_DATA folder, which will hold all the required files, in this folder you'll find:
		a.	2DA folder, holds your CLAB file with all the abilities and passives arranged in the most efficient way
		b.	SPL folder, edited spells, do note that there are 2 version of the same spell <SPELL_NAME> and <SPELL_NAME_RES>.
			<SPELL_NAME> - this spell is the one you'll cast and it casts <SPELL_NAME_RES>, if needed only patch: name,description,icon,flags,exclusion flags,primary/secondary type
			<SPELL_NAME_RES> - 	the real spell with the real effects, patch whatever you want.

6.	If you have any questions/suggestions you can find me lurking at shsforums/gibberlings3/beamdog forums.
	My user name is Yowave in all of those!
	Or contact me by email yowavegamer@gmail.com.
	
---------------------------------------------------------------------------------------------
4.	*** Credits and Acknowledgements *** - [cack]

1.	I would like to thank the creators of the tools I used in the writing of this mod:
		1. Near Infinity, by Jon Hauglid and Argent77
		2. NotePad++, by Don Ho
		
---------------------------------------------------------------------------------------------
5.	*** Version notes *** - [version]
	
Version 1.0 - 11/09/2017:
	* 	First public release